; HEADER_BLOCK_START
; BambuStudio 02.06.00.51
; model printing time: 21m 48s; total estimated time: 28m 4s
; total layer number: 25
; total filament length [mm] : 4146.38
; total filament volume [cm^3] : 9973.22
; total filament weight [g] : 12.47
; filament_density: 1.25
; filament_diameter: 1.75
; max_z_height: 5.00
; filament: 1
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 70
; additional_fan_full_speed_layer = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 0
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = monotonic
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0.1
; brim_type = auto_brim
; brim_width = 5
; chamber_temperatures = 0
; change_filament_gcode = ;===== A1 20251031 =======================\nM1007 S0 ; turn off mass estimation\nG392 S0\nM620 S[next_extruder]A\nM204 S9000\nG1 Z{max_layer_z + 3.0} F1200\n\nM400\nM106 P1 S0\nM106 P2 S0\n{if old_filament_temp > 142 && next_extruder < 255}\nM104 S[old_filament_temp]\n{endif}\n\nG1 X267 F18000\n\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E-{retraction_distances_when_cut[previous_extruder]} F1200\n{else}\nM620.11 S0\n{endif}\nM400\n\nM620.1 E F{flush_volumetric_speeds[previous_extruder]/2.4053*60} T{flush_temperatures[previous_extruder]}\nM620.10 A0 F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nT[next_extruder]\nM620.1 E F{flush_volumetric_speeds[next_extruder]/2.4053*60} T{flush_temperatures[next_extruder]}\nM620.10 A1 F{flush_volumetric_speeds[next_extruder]/2.4053*60} L[flush_length] H[nozzle_diameter] T{flush_temperatures[next_extruder]}\n\nG1 Y128 F9000\n\n{if next_extruder < 255}\n\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM628 S1\nG92 E0\nG1 E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM400\nM629 S1\n{else}\nM620.11 S0\n{endif}\n\nM400\nG92 E0\nM628 S0\n\n{if flush_length_1 > 1}\n; FLUSH_START\n; always use highest temperature to flush\nM400\nM1002 set_filament_type:UNKNOWN\nM109 S[flush_temperatures[next_extruder]]\nM106 P1 S60\n{if flush_length_1 > 23.7}\nG1 E23.7 F{flush_volumetric_speeds[previous_extruder]/2.4053*60} ; do not need pulsatile flushing for start part\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\n{else}\nG1 E{flush_length_1} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{endif}\n; FLUSH_END\nG1 E-[old_retract_length_toolchange] F1800\nG1 E[old_retract_length_toolchange] F300\nM400\nM1002 set_filament_type:{filament_type[next_extruder]}\n{endif}\n\n{if flush_length_1 > 45 && flush_length_2 > 1}\n; WIPE\nM400\nM106 P1 S178\nM400 S3\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nM400\nM106 P1 S0\n{endif}\n\n{if flush_length_2 > 1}\nM106 P1 S60\n; FLUSH_START\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_2 > 45 && flush_length_3 > 1}\n; WIPE\nM400\nM106 P1 S178\nM400 S3\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nM400\nM106 P1 S0\n{endif}\n\n{if flush_length_3 > 1}\nM106 P1 S60\n; FLUSH_START\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_3 > 45 && flush_length_4 > 1}\n; WIPE\nM400\nM106 P1 S178\nM400 S3\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nM400\nM106 P1 S0\n{endif}\n\n{if flush_length_4 > 1}\nM106 P1 S60\n; FLUSH_START\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\n; FLUSH_END\n{endif}\n\nM629\n\nM400\nM106 P1 S60\nM109 S[new_filament_temp]\nG1 E6 F{flush_volumetric_speeds[next_extruder]/2.4053*60} ;Compensate for filament spillage during waiting temperature\nM400\nG92 E0\nG1 E-[new_retract_length_toolchange] F1800\nM400\nM106 P1 S178\nM400 S3\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nG1 X-38.2 F18000\nG1 X-48.2 F3000\nM400\nG1 Z{max_layer_z + 3.0} F3000\nM106 P1 S0\n{if layer_z <= (initial_layer_print_height + 0.001)}\nM204 S[initial_layer_acceleration]\n{else}\nM204 S[default_acceleration]\n{endif}\n{else}\nG1 X[x_after_toolchange] Y[y_after_toolchange] Z[z_after_toolchange] F12000\n{endif}\n\nM622.1 S0\nM9833 F{outer_wall_volumetric_speed/2.4} A0.3 ; cali dynamic extrusion compensation\nM1002 judge_flag filament_need_cali_flag\nM622 J1\n  G92 E0\n  G1 E-[new_retract_length_toolchange] F1800\n  M400\n  \n  M106 P1 S178\n  M400 S4\n  G1 X-38.2 F18000\n  G1 X-48.2 F3000\n  G1 X-38.2 F18000 ;wipe and shake\n  G1 X-48.2 F3000\n  G1 X-38.2 F12000 ;wipe and shake\n  G1 X-48.2 F3000\n  M400\n  M106 P1 S0 \nM623\n\nM621 S[next_extruder]A\nG392 S0\n\nM1007 S1\n
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; complete_print_exhaust_fan_speed = 70
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.008
; counter_coef_3 = -0.041
; counter_limit_max = 0.033
; counter_limit_min = -0.035
; curr_bed_type = Textured PEI Plate
; default_acceleration = 6000
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL A1"
; default_jerk = 0
; default_nozzle_volume_type = Standard
; default_print_profile = 0.20mm Standard @BBL A1
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = skeleton_infill_density;skin_infill_density;sparse_infill_density;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 70
; elefant_foot_compensation = 0.075
; embedding_wall_into_infill = 0
; enable_arc_fitting = 1
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 0
; enable_support = 0
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 0
; eng_plate_temp_initial_layer = 0
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 1#0|4#0;1#0|4#0
; extruder_clearance_dist_to_rod = 56.5
; extruder_clearance_height_to_lid = 256
; extruder_clearance_height_to_rod = 25
; extruder_clearance_max_radius = 73
; extruder_colour = #018001
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = Standard#1
; extruder_offset = 0x0
; extruder_printable_area = 
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard"
; fan_cooling_layer_time = 80
; fan_direction = undefine
; fan_max_speed = 80
; fan_min_speed = 60
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 100
; filament_bridge_speed = 25
; filament_change_length = 10
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_colour_type = 1
; filament_cooling_before_tower = 0
; filament_cost = 22.99
; filament_density = 1.25
; filament_dev_ams_drying_ams_limitations = 1;0
; filament_dev_ams_drying_heat_distortion_temperature = 45
; filament_dev_ams_drying_temperature = 45,45,45,45
; filament_dev_ams_drying_time = 12,12,12,12
; filament_dev_chamber_drying_bed_temperature = 70
; filament_dev_chamber_drying_time = 12
; filament_dev_drying_cooling_temperature = 45
; filament_dev_drying_softening_temperature = 50
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = "; filament end gcode \n\n"
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 0.98
; filament_flush_temp = 0
; filament_flush_volumetric_speed = 0
; filament_ids = GFL03
; filament_is_mixed = 0
; filament_is_support = 0
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 16
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_multi_colour = #00AE42
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 50
; filament_overhang_3_4_speed = 30
; filament_overhang_4_4_speed = 10
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_prime_volume = 45
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 14
; filament_scarf_gap = 15%
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "eSUN PLA+ @BBL A1"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = "; filament start gcode\n{if  (bed_temperature[current_extruder] >55)||(bed_temperature_initial_layer[current_extruder] >55)}M106 P3 S200\n{elsif(bed_temperature[current_extruder] >50)||(bed_temperature_initial_layer[current_extruder] >50)}M106 P3 S150\n{elsif(bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S50\n{endif}\n\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}"
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = eSUN
; filament_volume_map = 0
; filename_format = {input_filename_base}_{filament_type[0]}_{print_time}.gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_volumes_matrix = 0
; flush_volumes_vector = 140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.3
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.2
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 17.4
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 226x224,256x224,256x256,226x256
; hole_coef_1 = 0
; hole_coef_2 = -0.008
; hole_coef_3 = 0.23415
; hole_limit_max = 0.22
; hole_limit_min = 0.088
; host_type = octoprint
; hot_plate_temp = 65
; hot_plate_temp_initial_layer = 65
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 10
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.5
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.45
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0.8
; internal_solid_infill_line_width = 0.42
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0.21
; ironing_pattern = zig-zag
; ironing_spacing = 0.15
; ironing_speed = 30
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = ; layer num/total_layer_count: {layer_num+1}/[total_layer_count]\n; update layer progress\nM73 L{layer_num+1}\nM991 S0 P{layer_num} ;notify layer change
; layer_height = 0.2
; line_width = 0.42
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_end_gcode = ;===== date: 20231229 =====================\nG392 S0 ;turn off nozzle clog detect\n\nM400 ; wait for buffer to clear\nG92 E0 ; zero the extruder\nG1 E-0.8 F1800 ; retract\nG1 Z{max_layer_z + 0.5} F900 ; lower z a little\nG1 X0 Y{first_layer_center_no_wipe_tower[1]} F18000 ; move to safe pos\nG1 X-13.0 F3000 ; move to safe pos\n{if !spiral_mode && print_sequence != "by object"}\nM1002 judge_flag timelapse_record_flag\nM622 J1\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM991 S0 P-1 ;end timelapse at safe pos\nM623\n{endif}\n\nM140 S0 ; turn off bed\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off remote part cooling fan\nM106 P3 S0 ; turn off chamber cooling fan\n\n;G1 X27 F15000 ; wipe\n\n; pull back filament to AMS\nM620 S255\nG1 X267 F15000\nT255\nG1 X-28.5 F18000\nG1 X-48.2 F3000\nG1 X-28.5 F18000\nG1 X-48.2 F3000\nM621 S255\n\nM104 S0 ; turn off hotend\n\nM400 ; wait all motion done\nM17 S\nM17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom\n{if (max_layer_z + 100.0) < 256}\n    G1 Z{max_layer_z + 100.0} F600\n    G1 Z{max_layer_z +98.0}\n{else}\n    G1 Z256 F600\n    G1 Z256\n{endif}\nM400 P100\nM17 R ; restore z current\n\nG90\nG1 X-48 Y180 F3600\n\nM220 S100  ; Reset feedrate magnitude\nM201.2 K1.0 ; Reset acc magnitude\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 0\n\n;=====printer finish  sound=========\nM17\nM400 S1\nM1006 S1\nM1006 A0 B20 L100 C37 D20 M40 E42 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C46 D10 M80 E46 F10 N80\nM1006 A44 B20 L100 C39 D20 M60 E48 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C48 D10 M60 E44 F10 N80\nM1006 A0 B10 L100 C0 D10 M60 E0 F10  N80\nM1006 A44 B20 L100 C49 D20 M80 E41 F20 N80\nM1006 A0 B20 L100 C0 D20 M60 E0 F20 N80\nM1006 A0 B20 L100 C37 D20 M30 E37 F20 N60\nM1006 W\n;=====printer finish  sound=========\n\n;M17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power\nM400\nM18 X Y Z\n\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 25
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 12000,12000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 9000,9000
; machine_max_acceleration_x = 12000,12000
; machine_max_acceleration_y = 12000,12000
; machine_max_acceleration_z = 1500,1500
; machine_max_jerk_e = 3,3
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 3,3
; machine_max_speed_e = 30,30
; machine_max_speed_x = 500,200
; machine_max_speed_y = 500,200
; machine_max_speed_z = 30,30
; machine_min_extruding_rate = 0,0
; machine_min_travel_rate = 0,0
; machine_pause_gcode = M400 U1
; machine_prepare_compensation_time = 260
; machine_start_gcode = ;===== machine: A1 =========================\n;===== date: 20250822 ==================\nG392 S0\nM9833.2\n;M400\n;M73 P1.717\n\n;===== start to heat heatbead&hotend==========\nM1002 gcode_claim_action : 2\nM1002 set_filament_type:{filament_type[initial_no_support_extruder]}\nM104 S140\nM140 S[bed_temperature_initial_layer_single]\n\n;=====start printer sound ===================\nM17\nM400 S1\nM1006 S1\nM1006 A0 B10 L100 C37 D10 M60 E37 F10 N60\nM1006 A0 B10 L100 C41 D10 M60 E41 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A43 B10 L100 C46 D10 M70 E39 F10 N80\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N80\nM1006 A0 B10 L100 C43 D10 M60 E39 F10 N80\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N80\nM1006 A0 B10 L100 C41 D10 M80 E41 F10 N80\nM1006 A0 B10 L100 C44 D10 M80 E44 F10 N80\nM1006 A0 B10 L100 C49 D10 M80 E49 F10 N80\nM1006 A0 B10 L100 C0 D10 M80 E0 F10 N80\nM1006 A44 B10 L100 C48 D10 M60 E39 F10 N80\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N80\nM1006 A0 B10 L100 C44 D10 M80 E39 F10 N80\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N80\nM1006 A43 B10 L100 C46 D10 M60 E39 F10 N80\nM1006 W\nM18 \n;=====start printer sound ===================\n\n;=====avoid end stop =================\nG91\nG380 S2 Z40 F1200\nG380 S3 Z-15 F1200\nG90\n\n;===== reset machine status =================\n;M290 X39 Y39 Z8\nM204 S6000\n\nM630 S0 P0\nG91\nM17 Z0.3 ; lower the z-motor current\n\nG90\nM17 X0.65 Y1.2 Z0.6 ; reset motor current to default\nM960 S5 P1 ; turn on logo lamp\nG90\nM220 S100 ;Reset Feedrate\nM221 S100 ;Reset Flowrate\nM73.2   R1.0 ;Reset left time magnitude\n;M211 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem\n\n;====== cog noise reduction=================\nM982.2 S1 ; turn on cog noise reduction\n\nM1002 gcode_claim_action : 13\n\nG28 X\nG91\nG1 Z5 F1200\nG90\nG0 X128 F30000\nG0 Y254 F3000\nG91\nG1 Z-5 F1200\n\nM109 S25 H140\n\nM17 E0.3\nM83\nG1 E10 F1200\nG1 E-0.5 F30\nM17 D\n\nG28 Z P0 T140; home z with low precision,permit 300deg temperature\nM104 S{nozzle_temperature_initial_layer[initial_extruder]}\n\nM1002 judge_flag build_plate_detect_flag\nM622 S1\n  G39.4\n  G90\n  G1 Z5 F1200\nM623\n\n;M400\n;M73 P1.717\n\n;===== prepare print temperature and material ==========\nM1002 gcode_claim_action : 24\n\nM400\n;G392 S1\nM211 X0 Y0 Z0 ;turn off soft endstop\nM975 S1 ; turn on\n\nG90\nG1 X-28.5 F30000\nG1 X-48.2 F3000\n\nM620 M ;enable remap\nM620 S[initial_no_support_extruder]A   ; switch material if AMS exist\n    M1002 gcode_claim_action : 4\n    M400\n    M1002 set_filament_type:UNKNOWN\n    M109 S[nozzle_temperature_initial_layer]\n    M104 S250\n    M400\n    T[initial_no_support_extruder]\n    G1 X-48.2 F3000\n    M400\n\n    M620.1 E F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60} T{flush_temperatures[initial_no_support_extruder]}\n    M109 S250 ;set nozzle to common flush temp\n    M106 P1 S0\n    G92 E0\n    G1 E50 F200\n    M400\n    M1002 set_filament_type:{filament_type[initial_no_support_extruder]}\nM621 S[initial_no_support_extruder]A\n\nM109 S{flush_temperatures[initial_no_support_extruder]} H300\nG92 E0\nG1 E50 F200 ; lower extrusion speed to avoid clog\nM400\nM106 P1 S178\nG92 E0\nG1 E5 F200\nM104 S{nozzle_temperature_initial_layer[initial_no_support_extruder]}\nG92 E0\nG1 E-0.5 F300\n\nG1 X-28.5 F30000\nG1 X-48.2 F3000\nG1 X-28.5 F30000 ;wipe and shake\nG1 X-48.2 F3000\nG1 X-28.5 F30000 ;wipe and shake\nG1 X-48.2 F3000\n\n;G392 S0\n\nM400\nM106 P1 S0\n;===== prepare print temperature and material end =====\n\n;M400\n;M73 P1.717\n\n;===== auto extrude cali start =========================\nM975 S1\n;G392 S1\n\nG90\nM83\nT1000\nG1 X-48.2 Y0 Z10 F10000\nM400\nM1002 set_filament_type:UNKNOWN\n\nM412 S1 ;  ===turn on  filament runout detection===\nM400 P10\nM620.3 W1; === turn on filament tangle detection===\nM400 S2\n\nM1002 set_filament_type:{filament_type[initial_no_support_extruder]}\n\n;M1002 set_flag extrude_cali_flag=1\nM1002 judge_flag extrude_cali_flag\n\nM622 J1\n    M1002 gcode_claim_action : 8\n\n    M109 S{nozzle_temperature[initial_extruder]}\n    G1 E10 F{outer_wall_volumetric_speed/2.4*60}\n    M983 F{outer_wall_volumetric_speed/2.4} A0.3 H[nozzle_diameter]; cali dynamic extrusion compensation\n\n    M106 P1 S255\n    M400 S5\n    G1 X-28.5 F18000\n    G1 X-48.2 F3000\n    G1 X-28.5 F18000 ;wipe and shake\n    G1 X-48.2 F3000\n    G1 X-28.5 F12000 ;wipe and shake\n    G1 X-48.2 F3000\n    M400\n    M106 P1 S0\n\n    M1002 judge_last_extrude_cali_success\n    M622 J0\n        M983 F{outer_wall_volumetric_speed/2.4} A0.3 H[nozzle_diameter]; cali dynamic extrusion compensation\n        M106 P1 S255\n        M400 S5\n        G1 X-28.5 F18000\n        G1 X-48.2 F3000\n        G1 X-28.5 F18000 ;wipe and shake\n        G1 X-48.2 F3000\n        G1 X-28.5 F12000 ;wipe and shake\n        M400\n        M106 P1 S0\n    M623\n    \n    G1 X-48.2 F3000\n    M400\n    M984 A0.1 E1 S1 F{outer_wall_volumetric_speed/2.4} H[nozzle_diameter]\n    M106 P1 S178\n    M400 S7\n    G1 X-28.5 F18000\n    G1 X-48.2 F3000\n    G1 X-28.5 F18000 ;wipe and shake\n    G1 X-48.2 F3000\n    G1 X-28.5 F12000 ;wipe and shake\n    G1 X-48.2 F3000\n    M400\n    M106 P1 S0\nM623 ; end of "draw extrinsic para cali paint"\n\n;G392 S0\n;===== auto extrude cali end ========================\n\n;M400\n;M73 P1.717\n\nM104 S170 ; prepare to wipe nozzle\nM106 S255 ; turn on fan\n\n;===== mech mode fast check start =====================\nM1002 gcode_claim_action : 3\n\nG1 X128 Y128 F20000\nG1 Z5 F1200\nM400 P200\nM970.3 Q1 A5 K0 O3\nM974 Q1 S2 P0\n\nM970.2 Q1 K1 W58 Z0.1\nM974 S2\n\nG1 X128 Y128 F20000\nG1 Z5 F1200\nM400 P200\nM970.3 Q0 A10 K0 O1\nM974 Q0 S2 P0\n\nM970.2 Q0 K1 W78 Z0.1\nM974 S2\n\nM975 S1\nG1 F30000\nG1 X0 Y5\nG28 X ; re-home XY\n\nG1 Z4 F1200\n\n;===== mech mode fast check end =======================\n\n;M400\n;M73 P1.717\n\n;===== wipe nozzle ===============================\nM1002 gcode_claim_action : 14\n\nM975 S1\nM106 S255 ; turn on fan (G28 has turn off fan)\nM211 S; push soft endstop status\nM211 X0 Y0 Z0 ;turn off Z axis endstop\n\n;===== remove waste by touching start =====\n\nM104 S170 ; set temp down to heatbed acceptable\n\nM83\nG1 E-1 F500\nG90\nM83\n\nM109 S170\nG0 X108 Y-0.5 F30000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X110 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X112 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X114 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X116 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X118 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X120 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X122 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X124 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X126 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X128 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X130 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X132 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X134 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X136 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X138 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X140 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X142 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X144 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X146 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X148 F10000\nG380 S3 Z-5 F1200\n\nG1 Z5 F30000\n;===== remove waste by touching end =====\n\nG1 Z10 F1200\nG0 X118 Y261 F30000\nG1 Z5 F1200\nM109 S{nozzle_temperature_initial_layer[initial_extruder]-50}\n\nG28 Z P0 T300; home z with low precision,permit 300deg temperature\nG29.2 S0 ; turn off ABL\nM104 S140 ; prepare to abl\nG0 Z5 F20000\n\nG0 X128 Y261 F20000  ; move to exposed steel surface\nG0 Z-1.01 F1200      ; stop the nozzle\n\nG91\nG2 I1 J0 X2 Y0 F2000.1\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\n\nG90\nG1 Z10 F1200\n\n;===== brush material wipe nozzle =====\n\nG90\nG1 Y250 F30000\nG1 X55\nG1 Z1.300 F1200\nG1 Y262.5 F6000\nG91\nG1 X-35 F30000\nG1 Y-0.5\nG1 X45\nG1 Y-0.5\nG1 X-45\nG1 Y-0.5\nG1 X45\nG1 Y-0.5\nG1 X-45\nG1 Y-0.5\nG1 X45\nG1 Z5.000 F1200\n\nG90\nG1 X30 Y250.000 F30000\nG1 Z1.300 F1200\nG1 Y262.5 F6000\nG91\nG1 X35 F30000\nG1 Y-0.5\nG1 X-45\nG1 Y-0.5\nG1 X45\nG1 Y-0.5\nG1 X-45\nG1 Y-0.5\nG1 X45\nG1 Y-0.5\nG1 X-45\nG1 Z10.000 F1200\n\n;===== brush material wipe nozzle end =====\n\nG90\n;G0 X128 Y261 F20000  ; move to exposed steel surface\nG1 Y250 F30000\nG1 X138\nG1 Y261\nG0 Z-1.01 F1200      ; stop the nozzle\n\nG91\nG2 I1 J0 X2 Y0 F2000.1\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\n\nM109 S140\nM106 S255 ; turn on fan (G28 has turn off fan)\n\nM211 R; pop softend status\n\n;===== wipe nozzle end ================================\n\n;M400\n;M73 P1.717\n\n;===== bed leveling ==================================\nM1002 judge_flag g29_before_print_flag\n\nG90\nG1 Z5 F1200\nG1 X0 Y0 F30000\nG29.2 S1 ; turn on ABL\n\nM190 S[bed_temperature_initial_layer_single]; ensure bed temp\nM109 S140\nM106 S0 ; turn off fan , too noisy\n\nM622 J1\n    M1002 gcode_claim_action : 1\n    G29 A1 X{first_layer_print_min[0]} Y{first_layer_print_min[1]} I{first_layer_print_size[0]} J{first_layer_print_size[1]}\n    M400\n    M500 ; save cali data\nM623\n;===== bed leveling end ================================\n\n;===== home after wipe mouth============================\nM1002 judge_flag g29_before_print_flag\nM622 J0\n\n    M1002 gcode_claim_action : 13\n    G28\n\nM623\n\n;===== home after wipe mouth end =======================\n\n;M400\n;M73 P1.717\n\nG1 X108.000 Y-0.500 F30000\nG1 Z0.300 F1200\nM400\nG2814 Z0.32\n\nM104 S{nozzle_temperature_initial_layer[initial_extruder]} ; prepare to print\n\n;===== nozzle load line ===============================\n;G90\n;M83\n;G1 Z5 F1200\n;G1 X88 Y-0.5 F20000\n;G1 Z0.3 F1200\n\n;M109 S{nozzle_temperature_initial_layer[initial_extruder]}\n\n;G1 E2 F300\n;G1 X168 E4.989 F6000\n;G1 Z1 F1200\n;===== nozzle load line end ===========================\n\n;===== extrude cali test ===============================\n\nM400\n    M900 S\n    M900 C\n    G90\n    M83\n\n    M109 S{nozzle_temperature_initial_layer[initial_extruder]}\n    G0 X128 E8  F{outer_wall_volumetric_speed/(24/20)    * 60}\n    G0 X133 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G0 X138 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X143 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G0 X148 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X153 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G91\n    G1 X1 Z-0.300\n    G1 X4\n    G1 Z1 F1200\n    G90\n    M400\n\nM900 R\n\nM1002 judge_flag extrude_cali_flag\nM622 J1\n    G90\n    G1 X108.000 Y1.000 F30000\n    G91\n    G1 Z-0.700 F1200\n    G90\n    M83\n    G0 X128 E10  F{outer_wall_volumetric_speed/(24/20)    * 60}\n    G0 X133 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G0 X138 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X143 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G0 X148 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X153 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G91\n    G1 X1 Z-0.300\n    G1 X4\n    G1 Z1 F1200\n    G90\n    M400\nM623\n\nG1 Z0.2\n\n;M400\n;M73 P1.717\n\n;========turn off light and wait extrude temperature =============\nM1002 gcode_claim_action : 0\nM400\n\n;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==\n;curr_bed_type={curr_bed_type}\n{if curr_bed_type=="Textured PEI Plate"}\nG29.1 Z{-0.02} ; for Textured PEI Plate\n{endif}\n\nM960 S1 P0 ; turn off laser\nM960 S2 P0 ; turn off laser\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off big fan\nM106 P3 S0 ; turn off chamber fan\n\nM975 S1 ; turn on mech mode supression\nG90\nM83\nT1000\n\nM211 X0 Y0 Z0 ;turn off soft endstop\n;G392 S1 ; turn on clog detection\nM1007 S1 ; turn on mass estimation\nG29.4\n
; machine_switch_extruder_time = 0
; machine_unload_filament_time = 29
; master_extruder_id = 1
; max_bridge_length = 0
; max_layer_height = 0.28
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.08
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.76
; nozzle_temperature = 220
; nozzle_temperature_initial_layer = 220
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = stainless_steel
; nozzle_volume = 92
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 5000
; outer_wall_jerk = 9
; outer_wall_line_width = 0.42
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100
; overhang_fan_threshold = 50%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab A1 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL A1
; printable_area = 0x0,256x0,256x256,0x256
; printable_height = 256
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab A1
; printer_notes = 
; printer_settings_id = Bambu Lab A1 0.4 nozzle
; printer_structure = i3
; printer_technology = FFF
; printer_variant = 0.4
; printhost_authorization_type = key
; printhost_ssl_ignore_revoke = 0
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 1
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 3
; resolution = 0.012
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 255
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 0
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 1
; skeleton_infill_density = 10%
; skeleton_infill_line_width = 0.45
; skin_infill_density = 10%
; skin_infill_depth = 2
; skin_infill_line_width = 0.45
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 0
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 8
; slow_down_min_speed = 20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 80
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 10%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.45
; sparse_infill_pattern = grid
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 45
; supertack_plate_temp_initial_layer = 45
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_filament = 0
; support_interface_bottom_layers = 2
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 2
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.15
; support_ironing_speed = 30
; support_line_width = 0.42
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = tree(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 45
; template_custom_gcode = 
; textured_plate_temp = 65
; textured_plate_temp_initial_layer = 65
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = ;===================== date: 20250206 =====================\n{if !spiral_mode && print_sequence != "by object"}\n; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer\n; SKIPPABLE_START\n; SKIPTYPE: timelapse\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\nG92 E0\nG1 Z{max_layer_z + 0.4}\nG1 X0 Y{first_layer_center_no_wipe_tower[1]} F18000 ; move to safe pos\nG1 X-48.2 F3000 ; move to safe pos\nM400\nM1004 S5 P1  ; external shutter\nM400 P300\nM971 S11 C11 O0\nG92 E0\nG1 X0 F18000\nM623\n\n; SKIPTYPE: head_wrap_detect\nM622.1 S1\nM1002 judge_flag g39_3rd_layer_detect_flag\nM622 J1\n    ; enable nozzle clog detect at 3rd layer\n    {if layer_num == 2}\n      M400\n      G90\n      M83\n      M204 S5000\n      G0 Z2 F4000\n      G0 X261 Y250 F20000\n      M400 P200\n      G39 S1\n      G0 Z2 F4000\n    {endif}\n\n\n    M622.1 S1\n    M1002 judge_flag g39_detection_flag\n    M622 J1\n      {if !in_head_wrap_detect_zone}\n        M622.1 S0\n        M1002 judge_flag g39_mass_exceed_flag\n        M622 J1\n        {if layer_num > 2}\n            G392 S0\n            M400\n            G90\n            M83\n            M204 S5000\n            G0 Z{max_layer_z + 0.4} F4000\n            G39.3 S1\n            G0 Z{max_layer_z + 0.4} F4000\n            G392 S0\n          {endif}\n        M623\n    {endif}\n    M623\nM623\n; SKIPPABLE_END\n{endif}\n
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 5
; top_one_wall_type = all top
; top_shell_layers = 5
; top_shell_thickness = 1
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.42
; top_surface_pattern = monotonicline
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 700
; travel_speed_z = 0
; tree_support_branch_angle = 45
; tree_support_branch_diameter = 2
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = "0 0 0 0 0 0"
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = classic
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 216.972
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R28
M201 X12000 Y12000 Z1500 E5000
M203 X500 Y500 Z30 E30
M204 P12000 R5000 T12000
M205 X9.00 Y9.00 Z3.00 E3.00
M106 S0
; FEATURE: Custom
;===== machine: A1 =========================
;===== date: 20250822 ==================
G392 S0
M9833.2
;M400
;M73 P1.717

;===== start to heat heatbead&hotend==========
M1002 gcode_claim_action : 2
M1002 set_filament_type:PLA
M104 S140
M140 S65

;=====start printer sound ===================
M17
M400 S1
M1006 S1
M1006 A0 B10 L100 C37 D10 M60 E37 F10 N60
M1006 A0 B10 L100 C41 D10 M60 E41 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A43 B10 L100 C46 D10 M70 E39 F10 N80
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N80
M1006 A0 B10 L100 C43 D10 M60 E39 F10 N80
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N80
M1006 A0 B10 L100 C41 D10 M80 E41 F10 N80
M1006 A0 B10 L100 C44 D10 M80 E44 F10 N80
M1006 A0 B10 L100 C49 D10 M80 E49 F10 N80
M1006 A0 B10 L100 C0 D10 M80 E0 F10 N80
M1006 A44 B10 L100 C48 D10 M60 E39 F10 N80
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N80
M1006 A0 B10 L100 C44 D10 M80 E39 F10 N80
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N80
M1006 A43 B10 L100 C46 D10 M60 E39 F10 N80
M1006 W
M18 
;=====start printer sound ===================

;=====avoid end stop =================
G91
G380 S2 Z40 F1200
G380 S3 Z-15 F1200
G90

;===== reset machine status =================
;M290 X39 Y39 Z8
M204 S6000

M630 S0 P0
G91
M17 Z0.3 ; lower the z-motor current

G90
M17 X0.65 Y1.2 Z0.6 ; reset motor current to default
M960 S5 P1 ; turn on logo lamp
G90
M220 S100 ;Reset Feedrate
M221 S100 ;Reset Flowrate
M73.2   R1.0 ;Reset left time magnitude
;M211 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem

;====== cog noise reduction=================
M982.2 S1 ; turn on cog noise reduction

M1002 gcode_claim_action : 13

G28 X
G91
G1 Z5 F1200
G90
G0 X128 F30000
G0 Y254 F3000
G91
G1 Z-5 F1200

M109 S25 H140

M17 E0.3
M83
G1 E10 F1200
G1 E-0.5 F30
M17 D

G28 Z P0 T140; home z with low precision,permit 300deg temperature
M104 S220

M1002 judge_flag build_plate_detect_flag
M622 S1
  G39.4
  G90
M73 P0 R27
  G1 Z5 F1200
M623

;M400
;M73 P1.717

;===== prepare print temperature and material ==========
M1002 gcode_claim_action : 24

M400
;G392 S1
M211 X0 Y0 Z0 ;turn off soft endstop
M975 S1 ; turn on

G90
G1 X-28.5 F30000
G1 X-48.2 F3000

M620 M ;enable remap
M620 S0A   ; switch material if AMS exist
    M1002 gcode_claim_action : 4
    M400
    M1002 set_filament_type:UNKNOWN
    M109 S220
    M104 S250
    M400
    T0
    G1 X-48.2 F3000
    M400

    M620.1 E F399.119 T240
    M109 S250 ;set nozzle to common flush temp
    M106 P1 S0
    G92 E0
    G1 E50 F200
    M400
    M1002 set_filament_type:PLA
M621 S0A

M109 S240 H300
G92 E0
G1 E50 F200 ; lower extrusion speed to avoid clog
M400
M106 P1 S178
G92 E0
G1 E5 F200
M104 S220
G92 E0
M73 P2 R27
G1 E-0.5 F300

G1 X-28.5 F30000
G1 X-48.2 F3000
M73 P3 R27
G1 X-28.5 F30000 ;wipe and shake
M73 P3 R26
G1 X-48.2 F3000
G1 X-28.5 F30000 ;wipe and shake
G1 X-48.2 F3000

;G392 S0

M400
M106 P1 S0
;===== prepare print temperature and material end =====

;M400
;M73 P1.717

;===== auto extrude cali start =========================
M975 S1
;G392 S1

G90
M83
T1000
G1 X-48.2 Y0 Z10 F10000
M400
M1002 set_filament_type:UNKNOWN

M412 S1 ;  ===turn on  filament runout detection===
M400 P10
M620.3 W1; === turn on filament tangle detection===
M400 S2

M1002 set_filament_type:PLA

;M1002 set_flag extrude_cali_flag=1
M1002 judge_flag extrude_cali_flag

M622 J1
    M1002 gcode_claim_action : 8

    M109 S220
    G1 E10 F377.08
    M983 F6.28466 A0.3 H0.4; cali dynamic extrusion compensation

    M106 P1 S255
    M400 S5
    G1 X-28.5 F18000
    G1 X-48.2 F3000
M73 P4 R26
    G1 X-28.5 F18000 ;wipe and shake
    G1 X-48.2 F3000
    G1 X-28.5 F12000 ;wipe and shake
    G1 X-48.2 F3000
    M400
    M106 P1 S0

    M1002 judge_last_extrude_cali_success
    M622 J0
        M983 F6.28466 A0.3 H0.4; cali dynamic extrusion compensation
        M106 P1 S255
        M400 S5
        G1 X-28.5 F18000
        G1 X-48.2 F3000
        G1 X-28.5 F18000 ;wipe and shake
        G1 X-48.2 F3000
M73 P5 R26
        G1 X-28.5 F12000 ;wipe and shake
        M400
        M106 P1 S0
    M623
    
    G1 X-48.2 F3000
    M400
    M984 A0.1 E1 S1 F6.28466 H0.4
    M106 P1 S178
    M400 S7
    G1 X-28.5 F18000
    G1 X-48.2 F3000
    G1 X-28.5 F18000 ;wipe and shake
    G1 X-48.2 F3000
    G1 X-28.5 F12000 ;wipe and shake
    G1 X-48.2 F3000
    M400
    M106 P1 S0
M623 ; end of "draw extrinsic para cali paint"

;G392 S0
;===== auto extrude cali end ========================

;M400
;M73 P1.717

M104 S170 ; prepare to wipe nozzle
M106 S255 ; turn on fan

;===== mech mode fast check start =====================
M1002 gcode_claim_action : 3

G1 X128 Y128 F20000
G1 Z5 F1200
M400 P200
M970.3 Q1 A5 K0 O3
M974 Q1 S2 P0

M970.2 Q1 K1 W58 Z0.1
M974 S2

G1 X128 Y128 F20000
G1 Z5 F1200
M400 P200
M970.3 Q0 A10 K0 O1
M974 Q0 S2 P0

M970.2 Q0 K1 W78 Z0.1
M974 S2

M975 S1
G1 F30000
G1 X0 Y5
G28 X ; re-home XY

G1 Z4 F1200

;===== mech mode fast check end =======================

;M400
;M73 P1.717

;===== wipe nozzle ===============================
M1002 gcode_claim_action : 14

M975 S1
M106 S255 ; turn on fan (G28 has turn off fan)
M211 S; push soft endstop status
M211 X0 Y0 Z0 ;turn off Z axis endstop

;===== remove waste by touching start =====

M104 S170 ; set temp down to heatbed acceptable

M83
G1 E-1 F500
G90
M83

M109 S170
G0 X108 Y-0.5 F30000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X110 F10000
G380 S3 Z-5 F1200
M73 P21 R22
G1 Z2 F1200
G1 X112 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X114 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X116 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X118 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X120 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X122 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X124 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X126 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X128 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X130 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X132 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X134 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X136 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X138 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X140 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X142 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X144 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X146 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X148 F10000
G380 S3 Z-5 F1200

G1 Z5 F30000
;===== remove waste by touching end =====

G1 Z10 F1200
G0 X118 Y261 F30000
G1 Z5 F1200
M109 S170

G28 Z P0 T300; home z with low precision,permit 300deg temperature
G29.2 S0 ; turn off ABL
M104 S140 ; prepare to abl
G0 Z5 F20000

G0 X128 Y261 F20000  ; move to exposed steel surface
G0 Z-1.01 F1200      ; stop the nozzle

G91
G2 I1 J0 X2 Y0 F2000.1
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5

G90
G1 Z10 F1200

;===== brush material wipe nozzle =====

G90
G1 Y250 F30000
G1 X55
G1 Z1.300 F1200
G1 Y262.5 F6000
G91
G1 X-35 F30000
G1 Y-0.5
G1 X45
G1 Y-0.5
G1 X-45
G1 Y-0.5
G1 X45
G1 Y-0.5
G1 X-45
G1 Y-0.5
G1 X45
G1 Z5.000 F1200

G90
G1 X30 Y250.000 F30000
G1 Z1.300 F1200
G1 Y262.5 F6000
G91
G1 X35 F30000
G1 Y-0.5
G1 X-45
G1 Y-0.5
G1 X45
G1 Y-0.5
G1 X-45
G1 Y-0.5
G1 X45
G1 Y-0.5
G1 X-45
G1 Z10.000 F1200

;===== brush material wipe nozzle end =====

G90
;G0 X128 Y261 F20000  ; move to exposed steel surface
G1 Y250 F30000
G1 X138
G1 Y261
G0 Z-1.01 F1200      ; stop the nozzle

G91
G2 I1 J0 X2 Y0 F2000.1
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
M73 P21 R21
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5

M109 S140
M106 S255 ; turn on fan (G28 has turn off fan)

M211 R; pop softend status

;===== wipe nozzle end ================================

;M400
;M73 P1.717

;===== bed leveling ==================================
M1002 judge_flag g29_before_print_flag

G90
G1 Z5 F1200
G1 X0 Y0 F30000
G29.2 S1 ; turn on ABL

M190 S65; ensure bed temp
M109 S140
M106 S0 ; turn off fan , too noisy

M622 J1
    M1002 gcode_claim_action : 1
    G29 A1 X73 Y103 I110 J50
    M400
    M500 ; save cali data
M623
;===== bed leveling end ================================

;===== home after wipe mouth============================
M1002 judge_flag g29_before_print_flag
M622 J0

    M1002 gcode_claim_action : 13
    G28

M623

;===== home after wipe mouth end =======================

;M400
;M73 P1.717

G1 X108.000 Y-0.500 F30000
G1 Z0.300 F1200
M400
G2814 Z0.32

M104 S220 ; prepare to print

;===== nozzle load line ===============================
;G90
;M83
;G1 Z5 F1200
;G1 X88 Y-0.5 F20000
;G1 Z0.3 F1200

;M109 S220

;G1 E2 F300
;G1 X168 E4.989 F6000
;G1 Z1 F1200
;===== nozzle load line end ===========================

;===== extrude cali test ===============================

M400
    M900 S
    M900 C
    G90
    M83

    M109 S220
    G0 X128 E8  F904.991
    G0 X133 E.3742  F1508.32
    G0 X138 E.3742  F6033.27
    G0 X143 E.3742  F1508.32
    G0 X148 E.3742  F6033.27
    G0 X153 E.3742  F1508.32
    G91
    G1 X1 Z-0.300
    G1 X4
    G1 Z1 F1200
    G90
    M400

M900 R

M1002 judge_flag extrude_cali_flag
M622 J1
    G90
    G1 X108.000 Y1.000 F30000
    G91
    G1 Z-0.700 F1200
    G90
    M83
    G0 X128 E10  F904.991
    G0 X133 E.3742  F1508.32
    G0 X138 E.3742  F6033.27
    G0 X143 E.3742  F1508.32
    G0 X148 E.3742  F6033.27
    G0 X153 E.3742  F1508.32
    G91
    G1 X1 Z-0.300
    G1 X4
    G1 Z1 F1200
    G90
    M400
M623

G1 Z0.2

;M400
;M73 P1.717

;========turn off light and wait extrude temperature =============
M1002 gcode_claim_action : 0
M400

;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==
;curr_bed_type=Textured PEI Plate

G29.1 Z-0.02 ; for Textured PEI Plate


M960 S1 P0 ; turn off laser
M960 S2 P0 ; turn off laser
M106 S0 ; turn off fan
M106 P2 S0 ; turn off big fan
M106 P3 S0 ; turn off chamber fan

M975 S1 ; turn on mech mode supression
G90
M83
T1000

M211 X0 Y0 Z0 ;turn off soft endstop
;G392 S1 ; turn on clog detection
M1007 S1 ; turn on mass estimation
G29.4
; MACHINE_START_GCODE_END
; filament start gcode
M106 P3 S200


;VT0 H-1
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
; layer num/total_layer_count: 1/25
; update layer progress
M73 L1
M991 S0 P0 ;notify layer change
M106 S0
; OBJECT_ID: 91
G1 X84.282 Y125.792 F42000
M204 S6000
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
M73 P22 R21
G1 F3000
M204 S500
G1 X84.282 Y130.472 E.17433
G1 X80 Y132.944 E.18416
G1 X75.718 Y130.472 E.18416
G1 X75.718 Y125.528 E.18416
G1 X79.193 Y123.521 E.14947
G1 X80 Y123.055 E.03469
G1 X84.282 Y125.528 E.18416
G1 X84.282 Y125.732 E.00759
M204 S6000
G1 X83.825 Y125.792 F42000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X83.825 Y130.208 E.16451
G1 X80 Y132.417 E.16451
G1 X76.175 Y130.208 E.16451
G1 X76.175 Y125.792 E.16451
G1 X79.422 Y123.917 E.13964
G1 X80 Y123.583 E.02486
G1 X83.773 Y125.762 E.16227
; WIPE_START
G1 X83.796 Y127.762 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X80.229 Y134.509 Z.6 F42000
G1 X74.236 Y145.848 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F3000
M204 S500
G1 X73.898 Y144.442 E.05386
G1 X73.782 Y142.969 E.05501
G1 X73.782 Y113.031 E1.11509
G1 X73.898 Y111.558 E.05501
G1 X74.236 Y110.152 E.05387
G1 X74.789 Y108.816 E.05385
G1 X75.545 Y107.583 E.05387
G1 X76.484 Y106.484 E.05386
G1 X77.583 Y105.544 E.05386
G1 X78.816 Y104.789 E.05386
G1 X80.152 Y104.236 E.05386
G1 X81.558 Y103.898 E.05386
G1 X83.031 Y103.782 E.05501
G1 X172.969 Y103.782 E3.34986
G1 X173.434 Y103.819 E.01737
G1 X174.442 Y103.898 E.03764
G1 X175.848 Y104.236 E.05386
G1 X177.184 Y104.789 E.05386
G1 X178.417 Y105.545 E.05386
G1 X179.516 Y106.484 E.05386
G1 X180.456 Y107.583 E.05386
G1 X181.211 Y108.816 E.05386
G1 X181.764 Y110.152 E.05386
G1 X182.102 Y111.558 E.05386
G1 X182.218 Y113.031 E.05501
G1 X182.218 Y142.969 E1.11509
G1 X182.102 Y144.442 E.05501
G1 X181.764 Y145.848 E.05386
G1 X181.211 Y147.184 E.05386
G1 X180.456 Y148.417 E.05386
G1 X179.516 Y149.516 E.05386
G1 X178.417 Y150.455 E.05386
G1 X177.184 Y151.211 E.05386
G1 X175.848 Y151.764 E.05386
G1 X174.442 Y152.102 E.05386
G1 X172.969 Y152.218 E.05501
G1 X83.031 Y152.218 E3.34987
G1 X81.558 Y152.102 E.05501
G1 X80.152 Y151.764 E.05386
G1 X78.816 Y151.211 E.05386
G1 X77.583 Y150.456 E.05386
G1 X76.484 Y149.516 E.05386
G1 X75.545 Y148.417 E.05386
G1 X74.789 Y147.184 E.05386
G1 X74.259 Y145.903 E.05163
M204 S6000
G1 X73.799 Y145.989 F42000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X73.445 Y144.513 E.05654
G1 X73.325 Y142.987 E.05702
G1 X73.325 Y113.013 E1.11643
G1 X73.445 Y111.487 E.05702
G1 X73.8 Y110.01 E.05655
G1 X74.38 Y108.608 E.05653
G1 X75.174 Y107.314 E.05654
G1 X76.159 Y106.159 E.05654
G1 X77.314 Y105.174 E.05654
G1 X78.608 Y104.38 E.05654
G1 X80.011 Y103.799 E.05654
G1 X81.487 Y103.445 E.05654
G1 X83.013 Y103.325 E.05702
G1 X172.987 Y103.325 E3.3512
G1 X173.47 Y103.363 E.01803
G1 X174.513 Y103.445 E.03898
G1 X175.989 Y103.799 E.05654
G1 X177.392 Y104.38 E.05654
G1 X178.686 Y105.174 E.05654
G1 X179.841 Y106.159 E.05654
G1 X180.826 Y107.314 E.05654
G1 X181.62 Y108.608 E.05654
G1 X182.201 Y110.011 E.05654
G1 X182.555 Y111.487 E.05655
G1 X182.675 Y113.013 E.05702
G1 X182.675 Y142.987 E1.11643
G1 X182.555 Y144.513 E.05702
G1 X182.201 Y145.989 E.05654
G1 X181.62 Y147.392 E.05654
G1 X180.826 Y148.686 E.05654
G1 X179.841 Y149.841 E.05654
G1 X178.686 Y150.826 E.05654
G1 X177.392 Y151.62 E.05654
G1 X175.989 Y152.2 E.05654
G1 X174.513 Y152.555 E.05654
G1 X172.987 Y152.675 E.05702
G1 X83.013 Y152.675 E3.3512
G1 X81.487 Y152.555 E.05702
G1 X80.011 Y152.2 E.05655
G1 X78.608 Y151.62 E.05654
G1 X77.314 Y150.826 E.05654
G1 X76.159 Y149.841 E.05654
G1 X75.174 Y148.686 E.05654
G1 X74.38 Y147.392 E.05654
G1 X73.822 Y146.045 E.0543
; WIPE_START
G1 X73.445 Y144.513 E-.59941
G1 X73.412 Y144.092 E-.16059
; WIPE_END
G1 E-.04 F1800
M204 S6000
G17
G3 Z.6 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z0.6
G1 X0 Y128 F18000 ; move to safe pos
M73 P23 R21
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X176.566 Y104.731 F42000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.50053
G1 F6300
M204 S500
G1 X180.889 Y109.054 E.22799
G1 X181.347 Y110.159 E.04459
G1 X175.841 Y104.653 E.29034
G1 X175.727 Y104.606 E.00459
G1 X174.963 Y104.423 E.0293
G1 X181.577 Y111.037 E.34878
G1 X181.717 Y111.619 E.02235
G1 X181.735 Y111.841 E.0083
G1 X174.159 Y104.265 E.39951
G1 X173.456 Y104.21 E.02627
G1 X181.79 Y112.544 E.43947
G3 X181.829 Y113.23 I-4.344 J.595 E.02568
G1 X172.77 Y104.171 E.47776
G1 X172.123 Y104.171 E.02413
G1 X181.829 Y113.877 E.51189
G1 X181.829 Y114.525 E.02413
G1 X171.475 Y104.171 E.54602
G1 X170.828 Y104.171 E.02413
G1 X181.829 Y115.172 E.58015
G1 X181.829 Y115.819 E.02413
G1 X170.181 Y104.171 E.61428
G1 X169.534 Y104.171 E.02413
G1 X181.829 Y116.466 E.6484
G1 X181.829 Y117.113 E.02413
G1 X168.887 Y104.171 E.68253
G1 X168.24 Y104.171 E.02413
G1 X181.829 Y117.76 E.71666
G1 X181.829 Y118.408 E.02413
G1 X167.592 Y104.171 E.75079
G1 X166.945 Y104.171 E.02413
G1 X181.829 Y119.055 E.78492
G1 X181.829 Y119.702 E.02413
G1 X166.298 Y104.171 E.81904
G1 X165.651 Y104.171 E.02413
G1 X181.829 Y120.349 E.85317
G1 X181.829 Y120.996 E.02413
G1 X165.004 Y104.171 E.8873
G1 X164.357 Y104.171 E.02413
G1 X181.829 Y121.643 E.92143
G1 X181.829 Y122.29 E.02413
G1 X163.71 Y104.171 E.95556
G1 X163.062 Y104.171 E.02413
G1 X181.829 Y122.938 E.98968
G1 X181.829 Y123.585 E.02413
G1 X162.415 Y104.171 E1.02381
G1 X161.768 Y104.171 E.02413
G1 X181.829 Y124.232 E1.05794
G1 X181.829 Y124.879 E.02413
G1 X161.121 Y104.171 E1.09207
G1 X160.474 Y104.171 E.02413
G1 X181.829 Y125.526 E1.1262
G1 X181.829 Y126.173 E.02413
G1 X159.827 Y104.171 E1.16032
G1 X159.179 Y104.171 E.02413
G1 X181.829 Y126.821 E1.19445
G1 X181.829 Y127.468 E.02413
G1 X158.532 Y104.171 E1.22858
G1 X157.885 Y104.171 E.02413
G1 X181.829 Y128.115 E1.26271
G1 X181.829 Y128.762 E.02413
G1 X157.238 Y104.171 E1.29684
G1 X156.591 Y104.171 E.02413
G1 X181.829 Y129.409 E1.33096
G1 X181.829 Y130.056 E.02413
G1 X155.944 Y104.171 E1.36509
G1 X155.296 Y104.171 E.02413
G1 X181.829 Y130.704 E1.39922
G1 X181.829 Y131.351 E.02413
G1 X154.649 Y104.171 E1.43335
G1 X154.002 Y104.171 E.02413
G1 X181.829 Y131.998 E1.46748
G1 X181.829 Y132.645 E.02413
G1 X153.355 Y104.171 E1.5016
G1 X152.708 Y104.171 E.02413
G1 X181.829 Y133.292 E1.53573
G1 X181.829 Y133.939 E.02413
G1 X152.061 Y104.171 E1.56986
G1 X151.414 Y104.171 E.02413
G1 X181.829 Y134.586 E1.60399
G1 X181.829 Y135.234 E.02413
G1 X150.766 Y104.171 E1.63812
G1 X150.119 Y104.171 E.02413
G1 X181.829 Y135.881 E1.67224
G1 X181.829 Y136.528 E.02413
G1 X149.472 Y104.171 E1.70637
G1 X148.825 Y104.171 E.02413
M73 P24 R21
G1 X181.829 Y137.175 E1.7405
G1 X181.829 Y137.822 E.02413
G1 X148.178 Y104.171 E1.77463
G1 X147.531 Y104.171 E.02413
G1 X181.829 Y138.469 E1.80876
G1 X181.829 Y139.117 E.02413
G1 X146.883 Y104.171 E1.84288
G1 X146.236 Y104.171 E.02413
G1 X181.829 Y139.764 E1.87701
G1 X181.829 Y140.411 E.02413
G1 X145.589 Y104.171 E1.91114
G1 X144.942 Y104.171 E.02413
G1 X181.829 Y141.058 E1.94527
G1 X181.829 Y141.705 E.02413
G1 X144.295 Y104.171 E1.9794
G1 X143.648 Y104.171 E.02413
G1 X181.829 Y142.352 E2.01352
G3 X181.826 Y142.996 I-4.099 J.301 E.02403
G1 X143 Y104.171 E2.04748
G1 X142.353 Y104.171 E.02413
G1 X181.779 Y143.596 E2.07912
G1 X181.732 Y144.196 E.02244
G1 X141.706 Y104.171 E2.11075
G1 X141.059 Y104.171 E.02413
G1 X181.63 Y144.742 E2.13954
G1 X181.505 Y145.264 E.02001
G1 X140.412 Y104.171 E2.16706
G1 X139.765 Y104.171 E.02413
G1 X181.373 Y145.779 E2.1942
G1 X181.183 Y146.236 E.01847
G1 X139.118 Y104.171 E2.21834
G1 X138.47 Y104.171 E.02413
G1 X180.994 Y146.694 E2.24247
G3 X180.786 Y147.134 I-1.492 J-.435 E.01821
G1 X137.823 Y104.171 E2.26566
G1 X137.176 Y104.171 E.02413
G1 X180.54 Y147.535 E2.28682
G1 X180.294 Y147.936 E.01755
G1 X136.529 Y104.171 E2.30798
G1 X135.882 Y104.171 E.02413
G1 X180.029 Y148.318 E2.32812
G1 X179.731 Y148.667 E.01712
G1 X135.235 Y104.171 E2.34652
G1 X134.587 Y104.171 E.02413
G1 X179.433 Y149.016 E2.36493
G3 X179.117 Y149.347 I-1.203 J-.833 E.01714
G1 X133.94 Y104.171 E2.38238
G1 X133.293 Y104.171 E.02413
G1 X178.768 Y149.645 E2.3981
G1 X178.418 Y149.943 E.01712
M73 P25 R21
G1 X132.646 Y104.171 E2.41382
G1 X131.999 Y104.171 E.02413
G1 X178.052 Y150.224 E2.42861
G1 X177.65 Y150.469 E.01755
G1 X131.352 Y104.171 E2.44158
G1 X130.704 Y104.171 E.02413
G1 X177.249 Y150.715 E2.45455
G3 X176.826 Y150.939 I-.917 J-1.224 E.01793
G1 X130.057 Y104.171 E2.46634
G1 X129.41 Y104.171 E.02413
M73 P25 R20
G1 X176.368 Y151.128 E2.47633
G1 X175.91 Y151.318 E.01847
G1 X128.763 Y104.171 E2.48633
G1 X128.116 Y104.171 E.02413
G1 X175.414 Y151.469 E2.49429
G1 X174.892 Y151.594 E.02001
G1 X127.469 Y104.171 E2.5009
G1 X126.822 Y104.171 E.02413
G1 X174.369 Y151.718 E2.50743
G1 X173.769 Y151.765 E.02244
G1 X126.174 Y104.171 E2.50992
G1 X125.527 Y104.171 E.02413
G1 X173.169 Y151.812 E2.51241
G3 X172.539 Y151.829 I-.423 J-3.997 E.02353
G1 X124.88 Y104.171 E2.5133
G1 X124.233 Y104.171 E.02413
G1 X171.892 Y151.829 E2.5133
G1 X171.245 Y151.829 E.02413
G1 X123.586 Y104.171 E2.5133
G1 X122.939 Y104.171 E.02413
G1 X170.597 Y151.829 E2.5133
G1 X169.95 Y151.829 E.02413
G1 X122.291 Y104.171 E2.5133
G1 X121.644 Y104.171 E.02413
G1 X169.303 Y151.829 E2.5133
G1 X168.656 Y151.829 E.02413
G1 X120.997 Y104.171 E2.5133
G1 X120.35 Y104.171 E.02413
G1 X168.009 Y151.829 E2.5133
G1 X167.362 Y151.829 E.02413
G1 X119.703 Y104.171 E2.5133
G1 X119.056 Y104.171 E.02413
M73 P26 R20
G1 X166.714 Y151.829 E2.5133
G1 X166.067 Y151.829 E.02413
G1 X118.408 Y104.171 E2.5133
G1 X117.761 Y104.171 E.02413
G1 X165.42 Y151.829 E2.5133
G1 X164.773 Y151.829 E.02413
G1 X117.114 Y104.171 E2.5133
G1 X116.467 Y104.171 E.02413
G1 X164.126 Y151.829 E2.5133
G1 X163.479 Y151.829 E.02413
G1 X115.82 Y104.171 E2.5133
G1 X115.173 Y104.171 E.02413
G1 X162.832 Y151.829 E2.5133
G1 X162.184 Y151.829 E.02413
G1 X114.526 Y104.171 E2.5133
G1 X113.878 Y104.171 E.02413
G1 X161.537 Y151.829 E2.5133
G1 X160.89 Y151.829 E.02413
G1 X113.231 Y104.171 E2.5133
G1 X112.584 Y104.171 E.02413
G1 X160.243 Y151.829 E2.5133
G1 X159.596 Y151.829 E.02413
G1 X111.937 Y104.171 E2.5133
G1 X111.29 Y104.171 E.02413
G1 X158.949 Y151.829 E2.5133
G1 X158.301 Y151.829 E.02413
G1 X110.643 Y104.171 E2.5133
G1 X109.995 Y104.171 E.02413
G1 X157.654 Y151.829 E2.5133
G1 X157.007 Y151.829 E.02413
G1 X109.348 Y104.171 E2.5133
G1 X108.701 Y104.171 E.02413
G1 X156.36 Y151.829 E2.5133
G1 X155.713 Y151.829 E.02413
G1 X108.054 Y104.171 E2.5133
G1 X107.407 Y104.171 E.02413
G1 X155.066 Y151.829 E2.5133
G1 X154.418 Y151.829 E.02413
M73 P27 R20
G1 X106.76 Y104.171 E2.5133
G1 X106.112 Y104.171 E.02413
G1 X153.771 Y151.829 E2.5133
G1 X153.124 Y151.829 E.02413
G1 X105.465 Y104.171 E2.5133
G1 X104.818 Y104.171 E.02413
G1 X152.477 Y151.829 E2.5133
G1 X151.83 Y151.829 E.02413
G1 X104.171 Y104.171 E2.5133
G1 X103.524 Y104.171 E.02413
G1 X151.183 Y151.829 E2.5133
G1 X150.535 Y151.829 E.02413
G1 X102.877 Y104.171 E2.5133
G1 X102.229 Y104.171 E.02413
G1 X149.888 Y151.829 E2.5133
G1 X149.241 Y151.829 E.02413
G1 X101.582 Y104.171 E2.5133
G1 X100.935 Y104.171 E.02413
G1 X148.594 Y151.829 E2.5133
G1 X147.947 Y151.829 E.02413
G1 X100.288 Y104.171 E2.5133
G1 X99.641 Y104.171 E.02413
G1 X147.3 Y151.829 E2.5133
G1 X146.653 Y151.829 E.02413
G1 X98.994 Y104.171 E2.5133
G1 X98.347 Y104.171 E.02413
G1 X146.005 Y151.829 E2.5133
G1 X145.358 Y151.829 E.02413
G1 X97.699 Y104.171 E2.5133
G1 X97.052 Y104.171 E.02413
G1 X144.711 Y151.829 E2.5133
G1 X144.064 Y151.829 E.02413
G1 X96.405 Y104.171 E2.5133
G1 X95.758 Y104.171 E.02413
G1 X143.417 Y151.829 E2.5133
G1 X142.77 Y151.829 E.02413
G1 X95.111 Y104.171 E2.5133
G1 X94.464 Y104.171 E.02413
G1 X142.122 Y151.829 E2.5133
G1 X141.475 Y151.829 E.02413
M73 P28 R20
G1 X93.816 Y104.171 E2.5133
G1 X93.169 Y104.171 E.02413
G1 X140.828 Y151.829 E2.5133
G1 X140.181 Y151.829 E.02413
G1 X92.522 Y104.171 E2.5133
G1 X91.875 Y104.171 E.02413
G1 X139.534 Y151.829 E2.5133
G1 X138.887 Y151.829 E.02413
G1 X91.228 Y104.171 E2.5133
G1 X90.581 Y104.171 E.02413
G1 X138.239 Y151.829 E2.5133
G1 X137.592 Y151.829 E.02413
G1 X89.933 Y104.171 E2.5133
G1 X89.286 Y104.171 E.02413
G1 X136.945 Y151.829 E2.5133
G1 X136.298 Y151.829 E.02413
G1 X88.639 Y104.171 E2.5133
G1 X87.992 Y104.171 E.02413
G1 X135.651 Y151.829 E2.5133
G1 X135.004 Y151.829 E.02413
G1 X87.345 Y104.171 E2.5133
G1 X86.698 Y104.171 E.02413
G1 X134.357 Y151.829 E2.5133
G1 X133.709 Y151.829 E.02413
G1 X86.051 Y104.171 E2.5133
G1 X85.403 Y104.171 E.02413
G1 X133.062 Y151.829 E2.5133
G1 X132.415 Y151.829 E.02413
G1 X84.756 Y104.171 E2.5133
G1 X84.109 Y104.171 E.02413
M73 P28 R19
G1 X131.768 Y151.829 E2.5133
G1 X131.121 Y151.829 E.02413
G1 X83.462 Y104.171 E2.5133
G2 X82.832 Y104.187 I-.208 J4.012 E.02354
G1 X130.474 Y151.829 E2.51241
G1 X129.826 Y151.829 E.02413
G1 X82.232 Y104.235 E2.50992
G1 X81.632 Y104.282 E.02244
M73 P29 R19
G1 X129.179 Y151.829 E2.50743
G1 X128.532 Y151.829 E.02413
G1 X81.108 Y104.406 E2.50091
G1 X80.586 Y104.531 E.02001
G1 X127.885 Y151.829 E2.4943
G1 X127.238 Y151.829 E.02413
G1 X80.09 Y104.682 E2.48634
G1 X79.633 Y104.871 E.01847
G1 X126.591 Y151.829 E2.47635
G1 X125.943 Y151.829 E.02413
G1 X79.175 Y105.061 E2.46635
G2 X78.751 Y105.284 I.494 J1.449 E.01793
G1 X125.296 Y151.829 E2.45456
G1 X124.649 Y151.829 E.02413
G1 X78.35 Y105.53 E2.4416
G1 X77.949 Y105.776 E.01755
G1 X124.002 Y151.829 E2.42863
G1 X123.355 Y151.829 E.02413
G1 X77.582 Y106.057 E2.41384
G1 X77.233 Y106.355 E.01712
G1 X122.708 Y151.829 E2.39812
G1 X122.061 Y151.829 E.02413
G1 X76.884 Y106.653 E2.3824
G2 X76.568 Y106.984 I.886 J1.164 E.01714
G1 X121.413 Y151.829 E2.36495
G1 X120.766 Y151.829 E.02413
G1 X76.269 Y107.333 E2.34655
G1 X75.971 Y107.682 E.01712
G1 X120.119 Y151.829 E2.32814
G1 X119.472 Y151.829 E.02413
G1 X75.706 Y108.063 E2.30801
G1 X75.46 Y108.465 E.01755
G1 X118.825 Y151.829 E2.28685
G1 X118.178 Y151.829 E.02413
G1 X75.214 Y108.866 E2.26569
G2 X75.007 Y109.306 I1.284 J.875 E.0182
G1 X117.53 Y151.829 E2.2425
G1 X116.883 Y151.829 E.02413
G1 X74.817 Y109.763 E2.21837
G1 X74.628 Y110.221 E.01847
M73 P30 R19
G1 X116.236 Y151.829 E2.19423
G1 X115.589 Y151.829 E.02413
G1 X74.495 Y110.736 E2.1671
G1 X74.37 Y111.257 E.02001
G1 X114.942 Y151.829 E2.13958
G1 X114.295 Y151.829 E.02413
G1 X74.268 Y111.803 E2.11079
G1 X74.221 Y112.403 E.02244
G1 X113.647 Y151.829 E2.07915
G1 X113 Y151.829 E.02413
G1 X74.174 Y113.003 E2.04752
G2 X74.171 Y113.647 I4.095 J.343 E.02403
G1 X112.353 Y151.829 E2.01357
G1 X111.706 Y151.829 E.02413
G1 X74.171 Y114.294 E1.97944
G1 X74.171 Y114.941 E.02413
G1 X111.059 Y151.829 E1.94531
G1 X110.412 Y151.829 E.02413
G1 X84.671 Y126.088 E1.35746
G1 X84.671 Y126.735 E.02413
G1 X109.765 Y151.829 E1.32334
G1 X109.117 Y151.829 E.02413
G1 X84.671 Y127.383 E1.28921
G1 X84.671 Y128.03 E.02413
G1 X108.47 Y151.829 E1.25508
G1 X107.823 Y151.829 E.02413
G1 X84.671 Y128.677 E1.22095
G1 X84.671 Y129.324 E.02413
G1 X107.176 Y151.829 E1.18682
G1 X106.529 Y151.829 E.02413
G1 X84.671 Y129.971 E1.15269
G1 X84.671 Y130.618 E.02413
G1 X105.882 Y151.829 E1.11857
G1 X105.234 Y151.829 E.02413
G1 X84.31 Y130.905 E1.10346
G1 X83.9 Y131.142 E.01767
G1 X104.587 Y151.829 E1.09097
G1 X103.94 Y151.829 E.02413
G1 X83.489 Y131.379 E1.07848
G1 X83.079 Y131.615 E.01767
G1 X103.293 Y151.829 E1.06599
G1 X102.646 Y151.829 E.02413
M73 P31 R19
G1 X82.669 Y131.852 E1.0535
G1 X82.258 Y132.089 E.01767
G1 X101.999 Y151.829 E1.041
G1 X101.351 Y151.829 E.02413
G1 X81.848 Y132.326 E1.02851
G1 X81.438 Y132.563 E.01767
G1 X100.704 Y151.829 E1.01602
G1 X100.057 Y151.829 E.02413
G1 X81.028 Y132.8 E1.00353
G1 X80.617 Y133.037 E.01767
G1 X99.41 Y151.829 E.99104
G1 X98.763 Y151.829 E.02413
G1 X80.207 Y133.274 E.97855
G1 X80 Y133.393 E.00891
G1 X79.241 Y132.955 E.03266
G1 X98.116 Y151.829 E.99534
G1 X97.469 Y151.829 E.02413
G1 X77.148 Y131.509 E1.07159
; WIPE_START
G1 X78.562 Y132.923 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X82.451 Y126.356 Z.6 F42000
G1 X83.376 Y124.793 Z.6
G1 Z.2
G1 E.8 F1800
G1 F6300
M204 S500
G1 X74.171 Y115.588 E.48542
G1 X74.171 Y116.235 E.02413
G1 X81.282 Y123.347 E.37504
G1 X80 Y122.607 E.05522
G1 X79.933 Y122.645 E.00287
G1 X74.171 Y116.883 E.3039
G1 X74.171 Y117.53 E.02413
G1 X79.523 Y122.882 E.28226
G1 X79.113 Y123.119 E.01767
G1 X74.171 Y118.177 E.26063
G1 X74.171 Y118.824 E.02413
G1 X78.702 Y123.356 E.23899
G1 X78.292 Y123.593 E.01767
G1 X74.171 Y119.471 E.21735
G1 X74.171 Y120.118 E.02413
G1 X77.882 Y123.83 E.19572
G1 X77.472 Y124.067 E.01767
G1 X74.171 Y120.766 E.17408
G1 X74.171 Y121.413 E.02413
G1 X77.061 Y124.304 E.15245
G1 X76.651 Y124.54 E.01767
G1 X74.171 Y122.06 E.13081
G1 X74.171 Y122.707 E.02413
G1 X76.241 Y124.777 E.10917
G1 X75.831 Y125.014 E.01767
G1 X74.171 Y123.354 E.08754
G1 X74.171 Y124.001 E.02413
G1 X75.42 Y125.251 E.0659
G1 X75.329 Y125.303 E.00391
G1 X75.329 Y125.807 E.01879
G1 X74.171 Y124.649 E.06111
G1 X74.171 Y125.296 E.02413
G1 X75.329 Y126.455 E.06111
G1 X75.329 Y127.102 E.02413
G1 X74.171 Y125.943 E.06111
G1 X74.171 Y126.59 E.02413
G1 X75.329 Y127.749 E.06111
G1 X75.329 Y128.396 E.02413
G1 X74.171 Y127.237 E.06111
G1 X74.171 Y127.884 E.02413
G1 X75.329 Y129.043 E.06111
G1 X75.329 Y129.69 E.02413
G1 X74.171 Y128.531 E.06111
G1 X74.171 Y129.179 E.02413
G1 X75.329 Y130.337 E.06111
G1 X75.329 Y130.697 E.01339
G1 X76.179 Y131.187 E.03658
G1 X96.821 Y151.829 E1.08858
G1 X96.174 Y151.829 E.02413
G1 X74.171 Y129.826 E1.16037
G1 X74.171 Y130.473 E.02413
G1 X95.527 Y151.829 E1.12624
G1 X94.88 Y151.829 E.02413
G1 X74.171 Y131.12 E1.09211
G1 X74.171 Y131.767 E.02413
G1 X94.233 Y151.829 E1.05798
G1 X93.586 Y151.829 E.02413
G1 X74.171 Y132.414 E1.02385
G1 X74.171 Y133.062 E.02413
G1 X92.938 Y151.829 E.98973
G1 X92.291 Y151.829 E.02413
G1 X74.171 Y133.709 E.9556
G1 X74.171 Y134.356 E.02413
G1 X91.644 Y151.829 E.92147
G1 X90.997 Y151.829 E.02413
G1 X74.171 Y135.003 E.88734
G1 X74.171 Y135.65 E.02413
G1 X90.35 Y151.829 E.85321
G1 X89.703 Y151.829 E.02413
G1 X74.171 Y136.297 E.81909
G1 X74.171 Y136.945 E.02413
G1 X89.055 Y151.829 E.78496
G1 X88.408 Y151.829 E.02413
G1 X74.171 Y137.592 E.75083
G1 X74.171 Y138.239 E.02413
G1 X87.761 Y151.829 E.7167
G1 X87.114 Y151.829 E.02413
M73 P32 R19
G1 X74.171 Y138.886 E.68257
G1 X74.171 Y139.533 E.02413
G1 X86.467 Y151.829 E.64845
G1 X85.82 Y151.829 E.02413
G1 X74.171 Y140.18 E.61432
G1 X74.171 Y140.827 E.02413
G1 X85.173 Y151.829 E.58019
G1 X84.525 Y151.829 E.02413
G1 X74.171 Y141.475 E.54606
G1 X74.171 Y142.122 E.02413
G1 X83.878 Y151.829 E.51193
G1 X83.231 Y151.829 E.02413
G1 X74.171 Y142.769 E.47781
G2 X74.21 Y143.456 I4.382 J.093 E.02567
G1 X82.544 Y151.79 E.43951
G1 X81.842 Y151.735 E.02627
G1 X74.265 Y144.158 E.39956
G1 X74.283 Y144.381 E.00833
G1 X74.422 Y144.962 E.02231
G1 X81.038 Y151.577 E.34885
G1 X80.273 Y151.394 E.02934
G1 X80.16 Y151.347 E.00454
G1 X74.653 Y145.84 E.29044
G1 X75.11 Y146.945 E.04459
G1 X79.055 Y150.89 E.20805
M73 P32 R18
G1 X77.812 Y150.14 E.05413
G1 X76.761 Y149.242 E.05157
G1 X75.48 Y147.961 E.06757
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F6300
G1 X76.761 Y149.242 E-.68853
G1 X76.904 Y149.364 E-.07147
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 2/25
; update layer progress
M73 L2
M991 S0 P1 ;notify layer change
M106 S158.1
; open powerlost recovery
M1003 S1
; OBJECT_ID: 91
M204 S10000
G17
G3 Z.6 I1.164 J.356 P1  F42000
G1 X84.102 Y125.858 Z.6
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X84.102 Y130.368 E.14961
G1 X80 Y132.737 E.15712
G1 X75.898 Y130.368 E.15712
G1 X75.898 Y125.632 E.15712
G1 X76.724 Y125.155 E.03164
G1 X80 Y123.263 E.12548
G1 X84.102 Y125.632 E.15712
G1 X84.102 Y125.798 E.00552
M204 S250
G1 X83.71 Y125.858 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X76.92 Y125.494 E.02235
G1 X80 Y123.716 E.10928
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.097 Y134.566 Z.8 F42000
G1 X74.064 Y145.904 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X73.72 Y144.47 E.04891
G1 X73.602 Y142.976 E.0497
G1 X73.602 Y113.024 E.99358
G1 X73.72 Y111.53 E.0497
G1 X74.064 Y110.096 E.04891
G1 X74.628 Y108.734 E.04891
G1 X75.398 Y107.477 E.04891
G1 X76.356 Y106.356 E.04891
G1 X77.477 Y105.398 E.04891
G1 X78.734 Y104.628 E.04891
G1 X80.096 Y104.064 E.04891
G1 X81.53 Y103.72 E.04891
G1 X83.024 Y103.602 E.0497
G1 X172.976 Y103.602 E2.98389
G1 X174.282 Y103.705 E.04346
G1 X174.47 Y103.72 E.00624
G1 X175.904 Y104.064 E.04891
G1 X177.266 Y104.628 E.04891
G1 X178.523 Y105.398 E.04891
G1 X179.644 Y106.356 E.04891
G1 X180.602 Y107.477 E.04891
G1 X181.372 Y108.734 E.04891
G1 X181.936 Y110.096 E.04891
G1 X182.28 Y111.53 E.04891
G1 X182.398 Y113.024 E.0497
G1 X182.398 Y142.976 E.99358
G1 X182.28 Y144.47 E.0497
G1 X181.936 Y145.904 E.04891
G1 X181.372 Y147.266 E.04891
G1 X180.602 Y148.523 E.04891
G1 X179.644 Y149.644 E.04891
G1 X178.523 Y150.602 E.04891
G1 X177.266 Y151.372 E.04891
G1 X175.904 Y151.936 E.04891
G1 X174.47 Y152.28 E.04891
G1 X172.976 Y152.398 E.0497
G1 X83.024 Y152.398 E2.98389
G1 X81.53 Y152.28 E.0497
G1 X80.096 Y151.936 E.04891
G1 X78.734 Y151.372 E.04891
G1 X77.477 Y150.602 E.04891
G1 X76.356 Y149.644 E.04891
G1 X75.398 Y148.523 E.04891
G1 X74.628 Y147.266 E.04891
G1 X74.087 Y145.959 E.04692
M204 S250
G1 X73.689 Y146.023 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.331 Y144.531 E.04712
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X74.278 Y108.556 E.0472
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X172.992 Y103.21 E2.76494
G1 X174.313 Y103.314 E.04073
G1 X174.531 Y103.331 E.00673
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.712 Y146.078 E.04544
; WIPE_START
M204 S6000
G1 X73.331 Y144.531 E-.6053
G1 X73.299 Y144.125 E-.15471
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z.8 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z0.8
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X73.766 Y140.894 F42000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42012
G1 F12725.344
M204 S6000
G1 X83.639 Y131.02 E.42919
G1 X82.377 Y131.749 E.0448
G1 X73.935 Y140.191 E.36695
G1 X73.935 Y139.657 E.0164
G1 X81.115 Y132.478 E.31208
G1 X80 Y133.121 E.03957
G1 X79.961 Y133.099 E.0014
G1 X73.935 Y139.124 E.26191
G1 X73.935 Y138.59 E.0164
G1 X79.622 Y132.903 E.24721
G1 X79.284 Y132.708 E.012
G1 X73.935 Y138.057 E.23251
G1 X73.935 Y137.524 E.0164
G1 X78.946 Y132.513 E.21781
G1 X78.608 Y132.318 E.012
G1 X73.935 Y136.99 E.20311
G1 X73.935 Y136.457 E.0164
G1 X78.27 Y132.122 E.1884
G1 X77.931 Y131.927 E.012
G1 X73.935 Y135.923 E.1737
G1 X73.935 Y135.39 E.0164
G1 X77.593 Y131.732 E.159
G1 X77.255 Y131.537 E.012
G1 X73.935 Y134.856 E.1443
G1 X73.935 Y134.323 E.0164
G1 X76.917 Y131.341 E.1296
G1 X76.579 Y131.146 E.012
G1 X73.935 Y133.789 E.1149
M73 P33 R18
G1 X73.935 Y133.256 E.0164
G1 X76.24 Y130.951 E.1002
G1 X75.902 Y130.756 E.012
G1 X73.935 Y132.723 E.0855
G1 X73.935 Y132.189 E.0164
G1 X75.565 Y130.56 E.07083
G1 X75.565 Y130.026 E.0164
G1 X73.935 Y131.656 E.07083
G1 X73.935 Y131.122 E.0164
G1 X75.565 Y129.493 E.07083
G1 X75.565 Y128.959 E.0164
G1 X73.935 Y130.589 E.07083
G1 X73.935 Y130.055 E.0164
G1 X75.565 Y128.426 E.07083
G1 X75.565 Y127.893 E.0164
G1 X73.935 Y129.522 E.07083
G1 X73.935 Y128.988 E.0164
G1 X75.565 Y127.359 E.07083
G1 X75.565 Y126.826 E.0164
G1 X73.935 Y128.455 E.07083
G1 X73.935 Y127.922 E.0164
G1 X75.565 Y126.292 E.07083
G1 X75.565 Y125.759 E.0164
G1 X73.935 Y127.388 E.07083
G1 X73.935 Y126.855 E.0164
G1 X96.855 Y103.935 E.99628
G1 X97.388 Y103.935 E.0164
G1 X76.321 Y125.003 E.91577
G1 X77.583 Y124.274 E.0448
G1 X97.922 Y103.935 E.8841
G1 X98.455 Y103.935 E.0164
G1 X78.845 Y123.545 E.85242
G1 X80 Y122.879 E.04099
G1 X80.029 Y122.895 E.00102
G1 X98.988 Y103.935 E.82416
G1 X99.522 Y103.935 E.0164
G1 X80.367 Y123.09 E.83265
G1 X80.705 Y123.286 E.012
G1 X100.055 Y103.935 E.84113
G1 X100.589 Y103.935 E.0164
G1 X81.043 Y123.481 E.84962
G1 X81.381 Y123.676 E.012
G1 X101.122 Y103.935 E.85811
G1 X101.656 Y103.935 E.0164
G1 X81.72 Y123.871 E.86659
G1 X82.058 Y124.067 E.012
G1 X102.189 Y103.935 E.87508
G1 X102.723 Y103.935 E.0164
G1 X82.396 Y124.262 E.88357
G1 X82.734 Y124.457 E.012
G1 X103.256 Y103.935 E.89206
G1 X103.789 Y103.935 E.0164
G1 X83.072 Y124.652 E.90054
G1 X83.411 Y124.848 E.012
G1 X104.323 Y103.935 E.90903
G1 X104.856 Y103.935 E.0164
G1 X83.749 Y125.043 E.91752
G1 X84.087 Y125.238 E.012
G1 X105.39 Y103.935 E.92601
G1 X105.923 Y103.935 E.0164
G1 X84.425 Y125.433 E.93449
G1 X84.435 Y125.957 E.01609
G1 X106.457 Y103.935 E.95724
G1 X106.99 Y103.935 E.0164
G1 X84.435 Y126.49 E.98043
G1 X84.435 Y127.024 E.0164
G1 X107.524 Y103.935 E1.00362
G1 X108.057 Y103.935 E.0164
G1 X84.435 Y127.557 E1.0268
G1 X84.435 Y128.09 E.0164
G1 X108.59 Y103.935 E1.04999
G1 X109.124 Y103.935 E.0164
G1 X84.435 Y128.624 E1.07318
G1 X84.435 Y129.157 E.0164
G1 X109.657 Y103.935 E1.09637
G1 X110.191 Y103.935 E.0164
G1 X84.435 Y129.691 E1.11956
G1 X84.435 Y130.224 E.0164
G1 X110.724 Y103.935 E1.14274
G1 X111.258 Y103.935 E.0164
G1 X73.935 Y141.258 E1.62235
G1 X73.935 Y141.791 E.0164
G1 X111.791 Y103.935 E1.64554
G1 X112.325 Y103.935 E.0164
G1 X73.935 Y142.325 E1.66873
G1 X73.935 Y142.858 E.0164
G1 X112.858 Y103.935 E1.69192
G1 X113.391 Y103.935 E.0164
G1 X73.967 Y143.36 E1.71375
G1 X74.005 Y143.855 E.01525
G1 X113.925 Y103.935 E1.73524
G1 X114.458 Y103.935 E.0164
G1 X74.044 Y144.349 E1.75674
G1 X74.139 Y144.788 E.0138
G1 X114.992 Y103.935 E1.77583
G1 X115.525 Y103.935 E.0164
G1 X74.242 Y145.218 E1.79452
G1 X74.345 Y145.649 E.0136
G1 X116.059 Y103.935 E1.81322
G1 X116.592 Y103.935 E.0164
G1 X74.483 Y146.044 E1.83043
G1 X74.639 Y146.422 E.01255
G1 X117.125 Y103.935 E1.84683
G1 X117.659 Y103.935 E.0164
G1 X74.795 Y146.799 E1.86322
G2 X74.959 Y147.168 I1.249 J-.333 E.01248
G1 X118.192 Y103.935 E1.87929
G1 X118.726 Y103.935 E.0164
G1 X75.162 Y147.499 E1.89366
G1 X75.365 Y147.83 E.01192
G1 X119.259 Y103.935 E1.90804
G1 X119.793 Y103.935 E.0164
G1 X75.567 Y148.161 E1.92242
G2 X75.791 Y148.47 I1.088 J-.553 E.01179
G1 X120.326 Y103.935 E1.93586
G1 X120.86 Y103.935 E.0164
G1 X76.037 Y148.758 E1.94837
G1 X76.283 Y149.045 E.01163
G1 X121.393 Y103.935 E1.96088
G1 X121.926 Y103.935 E.0164
G1 X76.529 Y149.333 E1.97338
G2 X76.806 Y149.59 I.948 J-.746 E.01165
G1 X122.46 Y103.935 E1.98454
G1 X122.993 Y103.935 E.0164
G1 X77.093 Y149.835 E1.99522
G1 X77.381 Y150.081 E.01163
G1 X123.527 Y103.935 E2.0059
G1 X124.06 Y103.935 E.0164
G1 X77.669 Y150.327 E2.01658
G1 X77.999 Y150.53 E.01192
G1 X124.594 Y103.935 E2.02542
G1 X125.127 Y103.935 E.0164
G1 X78.329 Y150.733 E2.03424
G1 X78.66 Y150.936 E.01192
G1 X125.661 Y103.935 E2.04305
G1 X126.194 Y103.935 E.0164
G1 X79.006 Y151.124 E2.05122
G1 X79.383 Y151.28 E.01255
G1 X126.727 Y103.935 E2.05801
G1 X127.261 Y103.935 E.0164
G1 X79.76 Y151.436 E2.0648
G1 X80.137 Y151.592 E.01255
G1 X127.794 Y103.935 E2.07159
G1 X128.328 Y103.935 E.0164
G1 X80.559 Y151.704 E2.07646
G1 X80.989 Y151.808 E.0136
G1 X128.861 Y103.935 E2.08095
G1 X129.395 Y103.935 E.0164
G1 X81.419 Y151.911 E2.08544
G2 X81.889 Y151.974 I.435 J-1.452 E.01464
G1 X129.928 Y103.935 E2.0882
G1 X130.462 Y103.935 E.0164
G1 X82.384 Y152.013 E2.08989
G1 X82.878 Y152.052 E.01525
G1 X130.995 Y103.935 E2.09158
G1 X131.528 Y103.935 E.0164
G1 X83.399 Y152.065 E2.09212
G1 X83.932 Y152.065 E.0164
G1 X132.062 Y103.935 E2.09212
G1 X132.595 Y103.935 E.0164
G1 X84.466 Y152.065 E2.09212
G1 X84.999 Y152.065 E.0164
G1 X133.129 Y103.935 E2.09212
G1 X133.662 Y103.935 E.0164
M73 P34 R18
G1 X85.533 Y152.065 E2.09212
G1 X86.066 Y152.065 E.0164
G1 X134.196 Y103.935 E2.09212
G1 X134.729 Y103.935 E.0164
G1 X86.6 Y152.065 E2.09212
G1 X87.133 Y152.065 E.0164
G1 X135.263 Y103.935 E2.09212
G1 X135.796 Y103.935 E.0164
G1 X87.667 Y152.065 E2.09212
G1 X88.2 Y152.065 E.0164
G1 X136.329 Y103.935 E2.09212
G1 X136.863 Y103.935 E.0164
G1 X88.733 Y152.065 E2.09212
G1 X89.267 Y152.065 E.0164
G1 X137.396 Y103.935 E2.09212
G1 X137.93 Y103.935 E.0164
G1 X89.8 Y152.065 E2.09212
G1 X90.334 Y152.065 E.0164
G1 X138.463 Y103.935 E2.09212
G1 X138.997 Y103.935 E.0164
G1 X90.867 Y152.065 E2.09212
G1 X91.401 Y152.065 E.0164
G1 X139.53 Y103.935 E2.09212
G1 X140.063 Y103.935 E.0164
G1 X91.934 Y152.065 E2.09212
G1 X92.468 Y152.065 E.0164
G1 X140.597 Y103.935 E2.09212
G1 X141.13 Y103.935 E.0164
G1 X93.001 Y152.065 E2.09212
G1 X93.534 Y152.065 E.0164
G1 X141.664 Y103.935 E2.09212
G1 X142.197 Y103.935 E.0164
G1 X94.068 Y152.065 E2.09212
G1 X94.601 Y152.065 E.0164
G1 X142.731 Y103.935 E2.09212
G1 X143.264 Y103.935 E.0164
G1 X95.135 Y152.065 E2.09212
G1 X95.668 Y152.065 E.0164
G1 X143.798 Y103.935 E2.09212
G1 X144.331 Y103.935 E.0164
G1 X96.202 Y152.065 E2.09212
G1 X96.735 Y152.065 E.0164
G1 X144.864 Y103.935 E2.09212
G1 X145.398 Y103.935 E.0164
G1 X97.269 Y152.065 E2.09212
G1 X97.802 Y152.065 E.0164
G1 X145.931 Y103.935 E2.09212
G1 X146.465 Y103.935 E.0164
G1 X98.335 Y152.065 E2.09212
G1 X98.869 Y152.065 E.0164
G1 X146.998 Y103.935 E2.09212
G1 X147.532 Y103.935 E.0164
G1 X99.402 Y152.065 E2.09212
G1 X99.936 Y152.065 E.0164
G1 X148.065 Y103.935 E2.09212
G1 X148.599 Y103.935 E.0164
G1 X100.469 Y152.065 E2.09212
G1 X101.003 Y152.065 E.0164
G1 X149.132 Y103.935 E2.09212
G1 X149.665 Y103.935 E.0164
G1 X101.536 Y152.065 E2.09212
G1 X102.069 Y152.065 E.0164
G1 X150.199 Y103.935 E2.09212
G1 X150.732 Y103.935 E.0164
G1 X102.603 Y152.065 E2.09212
G1 X103.136 Y152.065 E.0164
G1 X151.266 Y103.935 E2.09212
G1 X151.799 Y103.935 E.0164
G1 X103.67 Y152.065 E2.09212
G1 X104.203 Y152.065 E.0164
G1 X152.333 Y103.935 E2.09212
G1 X152.866 Y103.935 E.0164
G1 X104.737 Y152.065 E2.09212
G1 X105.27 Y152.065 E.0164
G1 X153.4 Y103.935 E2.09212
G1 X153.933 Y103.935 E.0164
G1 X105.804 Y152.065 E2.09212
G1 X106.337 Y152.065 E.0164
G1 X154.466 Y103.935 E2.09212
G1 X155 Y103.935 E.0164
G1 X106.87 Y152.065 E2.09212
G1 X107.404 Y152.065 E.0164
G1 X155.533 Y103.935 E2.09212
G1 X156.067 Y103.935 E.0164
G1 X107.937 Y152.065 E2.09212
G1 X108.471 Y152.065 E.0164
G1 X156.6 Y103.935 E2.09212
G1 X157.134 Y103.935 E.0164
G1 X109.004 Y152.065 E2.09212
G1 X109.538 Y152.065 E.0164
G1 X157.667 Y103.935 E2.09212
G1 X158.2 Y103.935 E.0164
M73 P35 R18
G1 X110.071 Y152.065 E2.09212
G1 X110.605 Y152.065 E.0164
G1 X158.734 Y103.935 E2.09212
G1 X159.267 Y103.935 E.0164
G1 X111.138 Y152.065 E2.09212
G1 X111.671 Y152.065 E.0164
G1 X159.801 Y103.935 E2.09212
G1 X160.334 Y103.935 E.0164
G1 X112.205 Y152.065 E2.09212
G1 X112.738 Y152.065 E.0164
G1 X160.868 Y103.935 E2.09212
G1 X161.401 Y103.935 E.0164
G1 X113.272 Y152.065 E2.09212
G1 X113.805 Y152.065 E.0164
G1 X161.935 Y103.935 E2.09212
G1 X162.468 Y103.935 E.0164
G1 X114.339 Y152.065 E2.09212
G1 X114.872 Y152.065 E.0164
G1 X163.001 Y103.935 E2.09212
G1 X163.535 Y103.935 E.0164
G1 X115.406 Y152.065 E2.09212
G1 X115.939 Y152.065 E.0164
G1 X164.068 Y103.935 E2.09212
G1 X164.602 Y103.935 E.0164
G1 X116.472 Y152.065 E2.09212
G1 X117.006 Y152.065 E.0164
G1 X165.135 Y103.935 E2.09212
G1 X165.669 Y103.935 E.0164
G1 X117.539 Y152.065 E2.09212
G1 X118.073 Y152.065 E.0164
G1 X166.202 Y103.935 E2.09212
G1 X166.736 Y103.935 E.0164
G1 X118.606 Y152.065 E2.09212
G1 X119.14 Y152.065 E.0164
G1 X167.269 Y103.935 E2.09212
G1 X167.802 Y103.935 E.0164
G1 X119.673 Y152.065 E2.09212
G1 X120.207 Y152.065 E.0164
G1 X168.336 Y103.935 E2.09212
G1 X168.869 Y103.935 E.0164
G1 X120.74 Y152.065 E2.09212
G1 X121.273 Y152.065 E.0164
G1 X169.403 Y103.935 E2.09212
G1 X169.936 Y103.935 E.0164
G1 X121.807 Y152.065 E2.09212
G1 X122.34 Y152.065 E.0164
G1 X170.47 Y103.935 E2.09212
G1 X171.003 Y103.935 E.0164
G1 X122.874 Y152.065 E2.09212
G1 X123.407 Y152.065 E.0164
G1 X171.537 Y103.935 E2.09212
G1 X172.07 Y103.935 E.0164
G1 X123.941 Y152.065 E2.09212
G1 X124.474 Y152.065 E.0164
G1 X172.603 Y103.935 E2.09212
G3 X173.124 Y103.948 I.18 J3.313 E.01603
G1 X125.007 Y152.065 E2.09157
G1 X125.541 Y152.065 E.0164
G1 X173.619 Y103.987 E2.08988
G1 X174.113 Y104.026 E.01525
G1 X126.074 Y152.065 E2.08819
G1 X126.608 Y152.065 E.0164
G1 X174.583 Y104.089 E2.08542
G1 X175.013 Y104.193 E.0136
G1 X127.141 Y152.065 E2.08093
G1 X127.675 Y152.065 E.0164
G1 X175.443 Y104.296 E2.07644
G1 X175.864 Y104.408 E.0134
G1 X128.208 Y152.065 E2.07156
G1 X128.742 Y152.065 E.0164
G1 X176.242 Y104.565 E2.06477
G1 X176.619 Y104.721 E.01255
G1 X129.275 Y152.065 E2.05798
G1 X129.808 Y152.065 E.0164
G1 X176.996 Y104.877 E2.05119
G3 X177.341 Y105.065 I-.421 J1.184 E.01214
G1 X130.342 Y152.065 E2.04301
G1 X130.875 Y152.065 E.0164
G1 X177.672 Y105.268 E2.0342
G1 X178.003 Y105.471 E.01192
G1 X131.409 Y152.065 E2.02538
G1 X131.942 Y152.065 E.0164
M73 P35 R17
G1 X178.333 Y105.674 E2.01653
G1 X178.62 Y105.92 E.01163
G1 X132.476 Y152.065 E2.00585
G1 X133.009 Y152.065 E.0164
G1 X178.908 Y106.166 E1.99517
G1 X179.196 Y106.411 E.01163
G1 X133.543 Y152.065 E1.98449
G1 X134.076 Y152.065 E.0164
M73 P36 R17
G1 X179.472 Y106.668 E1.97333
G1 X179.718 Y106.956 E.01163
G1 X134.609 Y152.065 E1.96082
G1 X135.143 Y152.065 E.0164
G1 X179.964 Y107.244 E1.94831
G1 X180.21 Y107.531 E.01163
G1 X135.676 Y152.065 E1.93581
G1 X136.21 Y152.065 E.0164
G1 X180.434 Y107.841 E1.92235
G1 X180.636 Y108.172 E.01192
G1 X136.743 Y152.065 E1.90798
G1 X137.277 Y152.065 E.0164
G1 X180.839 Y108.502 E1.8936
G1 X181.042 Y108.833 E.01192
G1 X137.81 Y152.065 E1.87922
G1 X138.344 Y152.065 E.0164
G1 X181.205 Y109.203 E1.86315
G1 X181.362 Y109.58 E.01255
G1 X138.877 Y152.065 E1.84675
G1 X139.41 Y152.065 E.0164
G1 X181.518 Y109.957 E1.83036
G3 X181.655 Y110.353 I-1.183 J.632 E.01294
G1 X139.944 Y152.065 E1.81314
G1 X140.477 Y152.065 E.0164
G1 X181.758 Y110.784 E1.79444
G1 X181.862 Y111.214 E.0136
G1 X141.011 Y152.065 E1.77574
G1 X141.544 Y152.065 E.0164
G1 X181.956 Y111.653 E1.75664
G1 X181.995 Y112.148 E.01525
G1 X142.078 Y152.065 E1.73514
G1 X142.611 Y152.065 E.0164
G1 X182.034 Y112.642 E1.71365
G3 X182.065 Y113.144 I-3.177 J.449 E.01549
G1 X143.144 Y152.065 E1.69181
G1 X143.678 Y152.065 E.0164
G1 X182.065 Y113.678 E1.66862
G1 X182.065 Y114.211 E.0164
G1 X144.211 Y152.065 E1.64543
G1 X144.745 Y152.065 E.0164
G1 X182.065 Y114.745 E1.62225
G1 X182.065 Y115.278 E.0164
G1 X145.278 Y152.065 E1.59906
G1 X145.812 Y152.065 E.0164
G1 X182.065 Y115.812 E1.57587
G1 X182.065 Y116.345 E.0164
G1 X146.345 Y152.065 E1.55268
G1 X146.879 Y152.065 E.0164
G1 X182.065 Y116.879 E1.52949
G1 X182.065 Y117.412 E.0164
G1 X147.412 Y152.065 E1.50631
G1 X147.945 Y152.065 E.0164
G1 X182.065 Y117.945 E1.48312
G1 X182.065 Y118.479 E.0164
G1 X148.479 Y152.065 E1.45993
G1 X149.012 Y152.065 E.0164
G1 X182.065 Y119.012 E1.43674
G1 X182.065 Y119.546 E.0164
G1 X149.546 Y152.065 E1.41355
G1 X150.079 Y152.065 E.0164
G1 X182.065 Y120.079 E1.39037
G1 X182.065 Y120.613 E.0164
G1 X150.613 Y152.065 E1.36718
G1 X151.146 Y152.065 E.0164
G1 X182.065 Y121.146 E1.34399
G1 X182.065 Y121.68 E.0164
G1 X151.68 Y152.065 E1.3208
G1 X152.213 Y152.065 E.0164
G1 X182.065 Y122.213 E1.29761
G1 X182.065 Y122.746 E.0164
G1 X152.746 Y152.065 E1.27443
G1 X153.28 Y152.065 E.0164
G1 X182.065 Y123.28 E1.25124
G1 X182.065 Y123.813 E.0164
G1 X153.813 Y152.065 E1.22805
G1 X154.347 Y152.065 E.0164
G1 X182.065 Y124.347 E1.20486
G1 X182.065 Y124.88 E.0164
G1 X154.88 Y152.065 E1.18167
G1 X155.414 Y152.065 E.0164
G1 X182.065 Y125.414 E1.15849
G1 X182.065 Y125.947 E.0164
G1 X155.947 Y152.065 E1.1353
G1 X156.481 Y152.065 E.0164
G1 X182.065 Y126.481 E1.11211
G1 X182.065 Y127.014 E.0164
G1 X157.014 Y152.065 E1.08892
G1 X157.547 Y152.065 E.0164
G1 X182.065 Y127.547 E1.06573
G1 X182.065 Y128.081 E.0164
G1 X158.081 Y152.065 E1.04255
G1 X158.614 Y152.065 E.0164
G1 X182.065 Y128.614 E1.01936
G1 X182.065 Y129.148 E.0164
G1 X159.148 Y152.065 E.99617
G1 X159.681 Y152.065 E.0164
G1 X182.065 Y129.681 E.97298
G1 X182.065 Y130.215 E.0164
G1 X160.215 Y152.065 E.94979
G1 X160.748 Y152.065 E.0164
G1 X182.065 Y130.748 E.92661
G1 X182.065 Y131.281 E.0164
G1 X161.281 Y152.065 E.90342
G1 X161.815 Y152.065 E.0164
G1 X182.065 Y131.815 E.88023
G1 X182.065 Y132.348 E.0164
G1 X162.348 Y152.065 E.85704
G1 X162.882 Y152.065 E.0164
G1 X182.065 Y132.882 E.83385
G1 X182.065 Y133.415 E.0164
M73 P37 R17
G1 X163.415 Y152.065 E.81067
G1 X163.949 Y152.065 E.0164
G1 X182.065 Y133.949 E.78748
G1 X182.065 Y134.482 E.0164
G1 X164.482 Y152.065 E.76429
G1 X165.016 Y152.065 E.0164
G1 X182.065 Y135.016 E.7411
G1 X182.065 Y135.549 E.0164
G1 X165.549 Y152.065 E.71791
G1 X166.082 Y152.065 E.0164
G1 X182.065 Y136.082 E.69473
G1 X182.065 Y136.616 E.0164
G1 X166.616 Y152.065 E.67154
G1 X167.149 Y152.065 E.0164
G1 X182.065 Y137.149 E.64835
G1 X182.065 Y137.683 E.0164
G1 X167.683 Y152.065 E.62516
G1 X168.216 Y152.065 E.0164
G1 X182.065 Y138.216 E.60197
G1 X182.065 Y138.75 E.0164
G1 X168.75 Y152.065 E.57879
G1 X169.283 Y152.065 E.0164
G1 X182.065 Y139.283 E.5556
G1 X182.065 Y139.817 E.0164
G1 X169.817 Y152.065 E.53241
G1 X170.35 Y152.065 E.0164
G1 X182.065 Y140.35 E.50922
G1 X182.065 Y140.883 E.0164
G1 X170.883 Y152.065 E.48603
G1 X171.417 Y152.065 E.0164
G1 X182.065 Y141.417 E.46285
G1 X182.065 Y141.95 E.0164
G1 X171.95 Y152.065 E.43966
G1 X172.484 Y152.065 E.0164
G1 X182.065 Y142.484 E.41647
G3 X182.06 Y143.022 I-3.42 J.24 E.01656
G1 X173.022 Y152.06 E.39288
G1 X173.601 Y152.014 E.01785
G1 X182.014 Y143.601 E.36573
G1 X181.969 Y144.18 E.01785
G1 X174.18 Y151.969 E.33858
G2 X174.831 Y151.851 I-.047 J-2.116 E.02043
G1 X181.851 Y144.831 E.30513
G1 X181.682 Y145.533 E.02219
G1 X175.533 Y151.682 E.26729
G1 X175.8 Y151.618 E.00844
G1 X176.365 Y151.385 E.01877
G1 X181.385 Y146.365 E.21821
G1 X181.074 Y147.114 E.02493
G1 X180.925 Y147.358 E.0088
G1 X176.962 Y151.321 E.17226
; WIPE_START
G1 X178.376 Y149.907 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X170.928 Y148.239 Z.8 F42000
G1 X73.766 Y126.491 Z.8
G1 Z.4
G1 E.8 F1800
G1 F12725.344
M204 S6000
G1 X96.321 Y103.935 E.98046
G1 X95.788 Y103.935 E.0164
G1 X73.935 Y125.788 E.9499
G1 X73.935 Y125.254 E.0164
G1 X95.254 Y103.935 E.92671
G1 X94.721 Y103.935 E.0164
G1 X73.935 Y124.721 E.90352
G1 X73.935 Y124.188 E.0164
G1 X94.188 Y103.935 E.88034
G1 X93.654 Y103.935 E.0164
G1 X73.935 Y123.654 E.85715
G1 X73.935 Y123.121 E.0164
G1 X93.121 Y103.935 E.83396
G1 X92.587 Y103.935 E.0164
G1 X73.935 Y122.587 E.81077
G1 X73.935 Y122.054 E.0164
G1 X92.054 Y103.935 E.78758
G1 X91.52 Y103.935 E.0164
G1 X73.935 Y121.52 E.7644
G1 X73.935 Y120.987 E.0164
G1 X90.987 Y103.935 E.74121
G1 X90.453 Y103.935 E.0164
G1 X73.935 Y120.453 E.71802
G1 X73.935 Y119.92 E.0164
G1 X89.92 Y103.935 E.69483
G1 X89.387 Y103.935 E.0164
G1 X73.935 Y119.387 E.67164
G1 X73.935 Y118.853 E.0164
G1 X88.853 Y103.935 E.64846
G1 X88.32 Y103.935 E.0164
G1 X73.935 Y118.32 E.62527
G1 X73.935 Y117.786 E.0164
G1 X87.786 Y103.935 E.60208
G1 X87.253 Y103.935 E.0164
G1 X73.935 Y117.253 E.57889
G1 X73.935 Y116.719 E.0164
G1 X86.719 Y103.935 E.5557
G1 X86.186 Y103.935 E.0164
G1 X73.935 Y116.186 E.53252
G1 X73.935 Y115.652 E.0164
G1 X85.652 Y103.935 E.50933
G1 X85.119 Y103.935 E.0164
G1 X73.935 Y115.119 E.48614
G1 X73.935 Y114.586 E.0164
G1 X84.586 Y103.935 E.46295
G1 X84.052 Y103.935 E.0164
G1 X73.935 Y114.052 E.43976
G1 X73.935 Y113.519 E.0164
G1 X83.519 Y103.935 E.41658
G2 X82.981 Y103.94 I-.241 J3.412 E.01655
G1 X73.94 Y112.981 E.393
G1 X73.985 Y112.402 E.01785
G1 X82.402 Y103.985 E.36586
G1 X81.823 Y104.031 E.01785
G1 X74.031 Y111.823 E.33871
G3 X74.148 Y111.172 I2.113 J.045 E.02041
G1 X81.172 Y104.148 E.3053
G1 X80.47 Y104.317 E.02219
G1 X74.317 Y110.47 E.26746
G1 X74.382 Y110.2 E.00854
G1 X74.614 Y109.64 E.01863
G1 X79.64 Y104.614 E.21847
G1 X78.886 Y104.926 E.02507
G1 X78.648 Y105.072 E.00857
G1 X75.072 Y108.648 E.15548
G1 X75.669 Y107.674 E.03514
G1 X76.582 Y106.605 E.04321
G1 X77.785 Y105.402 E.05228
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12725.344
G1 X76.582 Y106.605 E-.64635
G1 X76.388 Y106.832 E-.11365
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 3/25
; update layer progress
M73 L3
M991 S0 P2 ;notify layer change
M106 S160.65
; OBJECT_ID: 91
M204 S10000
G17
G3 Z.8 I-1.128 J.457 P1  F42000
G1 X84.102 Y125.858 Z.8
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X84.102 Y130.368 E.14961
G1 X80 Y132.737 E.15712
G1 X75.898 Y130.368 E.15712
G1 X75.898 Y125.632 E.15712
G1 X80 Y123.263 E.15712
G1 X84.102 Y125.632 E.15712
G1 X84.102 Y125.798 E.00552
M204 S250
G1 X83.71 Y125.858 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X80 Y123.716 E.13163
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.097 Y134.566 Z1 F42000
G1 X74.064 Y145.904 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X73.72 Y144.47 E.04891
G1 X73.602 Y142.976 E.0497
G1 X73.602 Y113.024 E.99358
G1 X73.72 Y111.53 E.0497
G1 X74.064 Y110.096 E.04891
G1 X74.496 Y109.053 E.03747
G1 X74.628 Y108.734 E.01144
G1 X75.398 Y107.477 E.04891
G1 X76.356 Y106.356 E.04891
G1 X77.477 Y105.398 E.04891
G1 X78.734 Y104.628 E.04891
G1 X80.096 Y104.064 E.04891
G1 X81.53 Y103.72 E.04891
G1 X83.024 Y103.602 E.0497
G1 X172.976 Y103.602 E2.98389
G1 X174.126 Y103.693 E.03826
G1 X174.47 Y103.72 E.01144
G1 X175.904 Y104.064 E.04891
G1 X177.266 Y104.628 E.04891
G1 X178.523 Y105.398 E.04891
G1 X179.644 Y106.356 E.04891
G1 X180.602 Y107.477 E.04891
G1 X181.372 Y108.734 E.04891
G1 X181.936 Y110.096 E.04891
G1 X182.28 Y111.53 E.04891
G1 X182.398 Y113.024 E.0497
G1 X182.398 Y142.976 E.99358
G1 X182.28 Y144.47 E.0497
G1 X181.936 Y145.904 E.04891
G1 X181.372 Y147.266 E.04891
G1 X180.602 Y148.523 E.04891
G1 X179.644 Y149.644 E.04891
G1 X178.523 Y150.602 E.04891
G1 X177.266 Y151.372 E.04891
G1 X175.904 Y151.936 E.04891
G1 X174.47 Y152.28 E.04891
G1 X172.976 Y152.398 E.0497
G1 X83.024 Y152.398 E2.98389
G1 X81.53 Y152.28 E.0497
G1 X80.096 Y151.936 E.04891
G1 X78.734 Y151.372 E.04891
G1 X77.477 Y150.602 E.04891
G1 X76.356 Y149.644 E.04891
G1 X75.398 Y148.523 E.04891
G1 X74.628 Y147.266 E.04891
G1 X74.087 Y145.959 E.04692
M204 S250
G1 X73.691 Y146.027 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.69 Y146.025 E.00007
G1 X73.331 Y144.531 E.0472
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X74.134 Y108.903 E.03565
G1 X74.278 Y108.556 E.01155
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X172.992 Y103.21 E2.76494
G1 X174.157 Y103.302 E.03591
G1 X174.531 Y103.331 E.01155
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.714 Y146.082 E.04529
; WIPE_START
M204 S6000
G1 X73.69 Y146.025 E-.02362
G1 X73.331 Y144.531 E-.58372
G1 X73.3 Y144.131 E-.15266
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    
      M400
      G90
      M83
      M204 S5000
      G0 Z2 F4000
      G0 X261 Y250 F20000
      M400 P200
      G39 S1
      G0 Z2 F4000
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
        M623
    
    M623
M623
; SKIPPABLE_END


G1 Z1.000
G1 X75.402 Y148.215 F42000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42012
G1 F12725.344
M204 S6000
G1 X76.605 Y149.418 E.05229
G1 X77.674 Y150.331 E.04321
G1 X78.648 Y150.928 E.03514
G1 X75.071 Y147.352 E.15548
G1 X74.926 Y147.114 E.00857
G1 X74.614 Y146.36 E.02507
G1 X79.64 Y151.386 E.21847
G1 X80.2 Y151.618 E.01863
G1 X80.47 Y151.683 E.00854
G1 X74.317 Y145.53 E.26746
G1 X74.148 Y144.828 E.02219
G1 X81.172 Y151.852 E.30531
G2 X81.823 Y151.969 I.696 J-1.996 E.02041
G1 X74.031 Y144.177 E.33871
G1 X73.985 Y143.598 E.01785
G1 X82.402 Y152.015 E.36586
G1 X82.981 Y152.06 E.01785
G1 X73.94 Y143.019 E.39301
G3 X73.935 Y142.481 I3.421 J-.297 E.01655
M73 P38 R17
G1 X83.519 Y152.065 E.41658
G1 X84.052 Y152.065 E.0164
G1 X73.935 Y141.948 E.43977
G1 X73.935 Y141.414 E.0164
G1 X84.586 Y152.065 E.46295
G1 X85.119 Y152.065 E.0164
G1 X73.935 Y140.881 E.48614
G1 X73.935 Y140.348 E.0164
G1 X85.652 Y152.065 E.50933
G1 X86.186 Y152.065 E.0164
G1 X73.935 Y139.814 E.53252
G1 X73.935 Y139.281 E.0164
G1 X86.719 Y152.065 E.55571
G1 X87.253 Y152.065 E.0164
G1 X73.935 Y138.747 E.57889
G1 X73.935 Y138.214 E.0164
G1 X87.786 Y152.065 E.60208
G1 X88.32 Y152.065 E.0164
G1 X73.935 Y137.68 E.62527
G1 X73.935 Y137.147 E.0164
G1 X88.853 Y152.065 E.64846
G1 X89.387 Y152.065 E.0164
G1 X73.935 Y136.613 E.67165
G1 X73.935 Y136.08 E.0164
G1 X89.92 Y152.065 E.69483
G1 X90.453 Y152.065 E.0164
G1 X73.935 Y135.547 E.71802
G1 X73.935 Y135.013 E.0164
G1 X90.987 Y152.065 E.74121
G1 X91.52 Y152.065 E.0164
G1 X73.935 Y134.48 E.7644
G1 X73.935 Y133.946 E.0164
G1 X92.054 Y152.065 E.78759
G1 X92.587 Y152.065 E.0164
G1 X73.935 Y133.413 E.81077
G1 X73.935 Y132.879 E.0164
G1 X93.121 Y152.065 E.83396
G1 X93.654 Y152.065 E.0164
G1 X73.935 Y132.346 E.85715
G1 X73.935 Y131.812 E.0164
G1 X94.188 Y152.065 E.88034
G1 X94.721 Y152.065 E.0164
G1 X73.935 Y131.279 E.90353
G1 X73.935 Y130.746 E.0164
G1 X95.254 Y152.065 E.92671
G1 X95.788 Y152.065 E.0164
G1 X73.935 Y130.212 E.9499
G1 X73.935 Y129.679 E.0164
G1 X96.491 Y152.234 E.98047
M204 S10000
G1 X110.894 Y152.234 F42000
G1 F12725.344
M204 S6000
G1 X84.435 Y125.776 E1.15012
G1 X84.435 Y126.309 E.0164
G1 X110.191 Y152.065 E1.11956
G1 X109.657 Y152.065 E.0164
G1 X84.435 Y126.843 E1.09637
G1 X84.435 Y127.376 E.0164
G1 X109.124 Y152.065 E1.07318
G1 X108.59 Y152.065 E.0164
G1 X84.435 Y127.91 E1.04999
G1 X84.435 Y128.443 E.0164
G1 X108.057 Y152.065 E1.0268
G1 X107.524 Y152.065 E.0164
G1 X84.435 Y128.976 E1.00362
G1 X84.435 Y129.51 E.0164
G1 X106.99 Y152.065 E.98043
G1 X106.457 Y152.065 E.0164
G1 X84.435 Y130.043 E.95724
G1 X84.425 Y130.567 E.01609
G1 X105.923 Y152.065 E.93449
G1 X105.39 Y152.065 E.0164
G1 X84.087 Y130.762 E.92601
G1 X83.749 Y130.957 E.012
G1 X104.856 Y152.065 E.91752
G1 X104.323 Y152.065 E.0164
G1 X83.411 Y131.152 E.90903
G1 X83.072 Y131.348 E.012
G1 X103.789 Y152.065 E.90054
G1 X103.256 Y152.065 E.0164
G1 X82.734 Y131.543 E.89206
G1 X82.396 Y131.738 E.012
G1 X102.723 Y152.065 E.88357
G1 X102.189 Y152.065 E.0164
G1 X82.058 Y131.933 E.87508
G1 X81.72 Y132.129 E.012
G1 X101.656 Y152.065 E.86659
G1 X101.122 Y152.065 E.0164
G1 X81.381 Y132.324 E.85811
G1 X81.043 Y132.519 E.012
G1 X100.589 Y152.065 E.84962
G1 X100.055 Y152.065 E.0164
G1 X80.705 Y132.714 E.84113
G1 X80.367 Y132.91 E.012
G1 X99.522 Y152.065 E.83265
G1 X98.988 Y152.065 E.0164
G1 X80.029 Y133.105 E.82416
G1 X80 Y133.121 E.00102
G1 X78.845 Y132.455 E.04099
G1 X98.455 Y152.065 E.85242
G1 X97.922 Y152.065 E.0164
G1 X77.583 Y131.726 E.8841
G1 X76.321 Y130.997 E.0448
G1 X97.388 Y152.065 E.91577
G1 X96.855 Y152.065 E.0164
G1 X73.935 Y129.145 E.99628
G1 X73.935 Y128.612 E.0164
G1 X75.565 Y130.241 E.07083
G1 X75.565 Y129.708 E.0164
G1 X73.935 Y128.078 E.07083
G1 X73.935 Y127.545 E.0164
G1 X75.565 Y129.174 E.07083
G1 X75.565 Y128.641 E.0164
G1 X73.935 Y127.011 E.07083
G1 X73.935 Y126.478 E.0164
G1 X75.565 Y128.107 E.07083
G1 X75.565 Y127.574 E.0164
G1 X73.935 Y125.945 E.07083
G1 X73.935 Y125.411 E.0164
G1 X75.565 Y127.041 E.07083
G1 X75.565 Y126.507 E.0164
G1 X73.935 Y124.878 E.07083
G1 X73.935 Y124.344 E.0164
G1 X75.565 Y125.974 E.07083
G1 X75.565 Y125.44 E.0164
G1 X73.935 Y123.811 E.07083
G1 X73.935 Y123.277 E.0164
G1 X75.902 Y125.244 E.0855
G1 X76.24 Y125.049 E.012
G1 X73.935 Y122.744 E.1002
G1 X73.935 Y122.211 E.0164
G1 X76.579 Y124.854 E.1149
G1 X76.917 Y124.659 E.012
G1 X73.935 Y121.677 E.1296
G1 X73.935 Y121.144 E.0164
G1 X77.255 Y124.463 E.1443
G1 X77.593 Y124.268 E.012
G1 X73.935 Y120.61 E.159
G1 X73.935 Y120.077 E.0164
G1 X77.931 Y124.073 E.1737
G1 X78.27 Y123.878 E.012
G1 X73.935 Y119.543 E.18841
G1 X73.935 Y119.01 E.0164
G1 X78.608 Y123.682 E.20311
G1 X78.946 Y123.487 E.012
G1 X73.935 Y118.476 E.21781
G1 X73.935 Y117.943 E.0164
G1 X79.284 Y123.292 E.23251
G1 X79.622 Y123.097 E.012
G1 X73.935 Y117.41 E.24721
G1 X73.935 Y116.876 E.0164
G1 X79.961 Y122.901 E.26191
G1 X80 Y122.879 E.0014
G1 X81.115 Y123.522 E.03957
G1 X73.935 Y116.343 E.31208
G1 X73.935 Y115.809 E.0164
G1 X82.377 Y124.251 E.36695
G1 X83.639 Y124.98 E.0448
G1 X73.935 Y115.276 E.42181
G1 X73.935 Y114.742 E.0164
G1 X111.258 Y152.065 E1.62235
G1 X111.791 Y152.065 E.0164
G1 X73.935 Y114.209 E1.64554
G1 X73.935 Y113.675 E.0164
G1 X112.325 Y152.065 E1.66873
G1 X112.858 Y152.065 E.0164
G1 X73.935 Y113.142 E1.69192
G3 X73.967 Y112.64 I3.207 J-.053 E.01548
G1 X113.391 Y152.065 E1.71375
G1 X113.925 Y152.065 E.0164
G1 X74.005 Y112.145 E1.73524
G1 X74.044 Y111.651 E.01525
G1 X114.458 Y152.065 E1.75674
G1 X114.992 Y152.065 E.0164
G1 X74.139 Y111.212 E1.77583
G1 X74.242 Y110.782 E.0136
G1 X115.525 Y152.065 E1.79452
G1 X116.059 Y152.065 E.0164
G1 X74.345 Y110.351 E1.81322
G3 X74.483 Y109.956 I1.318 J.236 E.01294
G1 X116.592 Y152.065 E1.83043
G1 X117.125 Y152.065 E.0164
G1 X74.639 Y109.578 E1.84683
G1 X74.795 Y109.201 E.01255
G1 X117.659 Y152.065 E1.86322
G1 X118.192 Y152.065 E.0164
G1 X74.959 Y108.832 E1.87929
G1 X75.162 Y108.501 E.01192
G1 X118.726 Y152.065 E1.89367
G1 X119.259 Y152.065 E.0164
G1 X75.365 Y108.17 E1.90804
G1 X75.567 Y107.839 E.01192
G1 X119.793 Y152.065 E1.92242
G1 X120.326 Y152.065 E.0164
G1 X75.791 Y107.53 E1.93586
G1 X76.037 Y107.242 E.01163
G1 X120.86 Y152.065 E1.94837
G1 X121.393 Y152.065 E.0164
G1 X76.283 Y106.955 E1.96088
G1 X76.529 Y106.667 E.01163
G1 X121.926 Y152.065 E1.97338
G1 X122.46 Y152.065 E.0164
G1 X76.806 Y106.41 E1.98454
G1 X77.093 Y106.165 E.01163
G1 X122.993 Y152.065 E1.99522
G1 X123.527 Y152.065 E.0164
G1 X77.381 Y105.919 E2.0059
M73 P39 R17
G1 X77.669 Y105.673 E.01163
G1 X124.06 Y152.065 E2.01658
G1 X124.594 Y152.065 E.0164
G1 X77.999 Y105.47 E2.02543
G1 X78.329 Y105.267 E.01192
G1 X125.127 Y152.065 E2.03424
G1 X125.661 Y152.065 E.0164
G1 X78.66 Y105.064 E2.04305
G3 X79.006 Y104.876 I.766 J.997 E.01214
G1 X126.194 Y152.065 E2.05122
G1 X126.727 Y152.065 E.0164
G1 X79.383 Y104.72 E2.05801
G1 X79.76 Y104.564 E.01255
G1 X127.261 Y152.065 E2.0648
G1 X127.794 Y152.065 E.0164
G1 X80.137 Y104.408 E2.07159
G1 X80.559 Y104.296 E.0134
G1 X128.328 Y152.065 E2.07646
G1 X128.861 Y152.065 E.0164
G1 X80.989 Y104.192 E2.08095
G1 X81.419 Y104.089 E.0136
G1 X129.395 Y152.065 E2.08544
G1 X129.928 Y152.065 E.0164
G1 X81.889 Y104.026 E2.0882
G1 X82.384 Y103.987 E.01525
G1 X130.462 Y152.065 E2.08989
G1 X130.995 Y152.065 E.0164
G1 X82.878 Y103.948 E2.09158
G3 X83.399 Y103.935 I.34 J3.304 E.01603
G1 X131.528 Y152.065 E2.09212
G1 X132.062 Y152.065 E.0164
G1 X83.932 Y103.935 E2.09212
G1 X84.466 Y103.935 E.0164
G1 X132.595 Y152.065 E2.09212
G1 X133.129 Y152.065 E.0164
G1 X84.999 Y103.935 E2.09212
G1 X85.533 Y103.935 E.0164
G1 X133.662 Y152.065 E2.09212
G1 X134.196 Y152.065 E.0164
G1 X86.066 Y103.935 E2.09212
G1 X86.6 Y103.935 E.0164
G1 X134.729 Y152.065 E2.09212
G1 X135.263 Y152.065 E.0164
G1 X87.133 Y103.935 E2.09212
M73 P39 R16
G1 X87.667 Y103.935 E.0164
G1 X135.796 Y152.065 E2.09212
G1 X136.329 Y152.065 E.0164
G1 X88.2 Y103.935 E2.09212
G1 X88.733 Y103.935 E.0164
G1 X136.863 Y152.065 E2.09212
G1 X137.396 Y152.065 E.0164
G1 X89.267 Y103.935 E2.09212
G1 X89.8 Y103.935 E.0164
G1 X137.93 Y152.065 E2.09212
G1 X138.463 Y152.065 E.0164
G1 X90.334 Y103.935 E2.09212
G1 X90.867 Y103.935 E.0164
G1 X138.997 Y152.065 E2.09212
G1 X139.53 Y152.065 E.0164
G1 X91.401 Y103.935 E2.09212
G1 X91.934 Y103.935 E.0164
G1 X140.063 Y152.065 E2.09212
G1 X140.597 Y152.065 E.0164
G1 X92.468 Y103.935 E2.09212
G1 X93.001 Y103.935 E.0164
G1 X141.13 Y152.065 E2.09212
G1 X141.664 Y152.065 E.0164
G1 X93.534 Y103.935 E2.09212
G1 X94.068 Y103.935 E.0164
G1 X142.197 Y152.065 E2.09212
G1 X142.731 Y152.065 E.0164
G1 X94.601 Y103.935 E2.09212
G1 X95.135 Y103.935 E.0164
G1 X143.264 Y152.065 E2.09212
G1 X143.798 Y152.065 E.0164
G1 X95.668 Y103.935 E2.09212
G1 X96.202 Y103.935 E.0164
G1 X144.331 Y152.065 E2.09212
G1 X144.864 Y152.065 E.0164
G1 X96.735 Y103.935 E2.09212
G1 X97.269 Y103.935 E.0164
G1 X145.398 Y152.065 E2.09212
G1 X145.931 Y152.065 E.0164
G1 X97.802 Y103.935 E2.09212
G1 X98.335 Y103.935 E.0164
G1 X146.465 Y152.065 E2.09212
G1 X146.998 Y152.065 E.0164
G1 X98.869 Y103.935 E2.09212
G1 X99.402 Y103.935 E.0164
G1 X147.532 Y152.065 E2.09212
G1 X148.065 Y152.065 E.0164
G1 X99.936 Y103.935 E2.09212
G1 X100.469 Y103.935 E.0164
G1 X148.599 Y152.065 E2.09212
M73 P40 R16
G1 X149.132 Y152.065 E.0164
G1 X101.003 Y103.935 E2.09212
G1 X101.536 Y103.935 E.0164
G1 X149.665 Y152.065 E2.09212
G1 X150.199 Y152.065 E.0164
G1 X102.069 Y103.935 E2.09212
G1 X102.603 Y103.935 E.0164
G1 X150.732 Y152.065 E2.09212
G1 X151.266 Y152.065 E.0164
G1 X103.136 Y103.935 E2.09212
G1 X103.67 Y103.935 E.0164
G1 X151.799 Y152.065 E2.09212
G1 X152.333 Y152.065 E.0164
G1 X104.203 Y103.935 E2.09212
G1 X104.737 Y103.935 E.0164
G1 X152.866 Y152.065 E2.09212
G1 X153.4 Y152.065 E.0164
G1 X105.27 Y103.935 E2.09212
G1 X105.804 Y103.935 E.0164
G1 X153.933 Y152.065 E2.09212
G1 X154.466 Y152.065 E.0164
G1 X106.337 Y103.935 E2.09212
G1 X106.87 Y103.935 E.0164
G1 X155 Y152.065 E2.09212
G1 X155.533 Y152.065 E.0164
G1 X107.404 Y103.935 E2.09212
G1 X107.937 Y103.935 E.0164
G1 X156.067 Y152.065 E2.09212
G1 X156.6 Y152.065 E.0164
G1 X108.471 Y103.935 E2.09212
G1 X109.004 Y103.935 E.0164
G1 X157.134 Y152.065 E2.09212
G1 X157.667 Y152.065 E.0164
G1 X109.538 Y103.935 E2.09212
G1 X110.071 Y103.935 E.0164
G1 X158.2 Y152.065 E2.09212
G1 X158.734 Y152.065 E.0164
G1 X110.605 Y103.935 E2.09212
G1 X111.138 Y103.935 E.0164
G1 X159.267 Y152.065 E2.09212
G1 X159.801 Y152.065 E.0164
G1 X111.671 Y103.935 E2.09212
G1 X112.205 Y103.935 E.0164
G1 X160.334 Y152.065 E2.09212
G1 X160.868 Y152.065 E.0164
G1 X112.738 Y103.935 E2.09212
G1 X113.272 Y103.935 E.0164
G1 X161.401 Y152.065 E2.09212
G1 X161.935 Y152.065 E.0164
G1 X113.805 Y103.935 E2.09212
G1 X114.339 Y103.935 E.0164
G1 X162.468 Y152.065 E2.09212
G1 X163.001 Y152.065 E.0164
G1 X114.872 Y103.935 E2.09212
G1 X115.406 Y103.935 E.0164
G1 X163.535 Y152.065 E2.09212
G1 X164.068 Y152.065 E.0164
G1 X115.939 Y103.935 E2.09212
G1 X116.472 Y103.935 E.0164
G1 X164.602 Y152.065 E2.09212
G1 X165.135 Y152.065 E.0164
G1 X117.006 Y103.935 E2.09212
G1 X117.539 Y103.935 E.0164
G1 X165.669 Y152.065 E2.09212
G1 X166.202 Y152.065 E.0164
G1 X118.073 Y103.935 E2.09212
G1 X118.606 Y103.935 E.0164
G1 X166.736 Y152.065 E2.09212
G1 X167.269 Y152.065 E.0164
G1 X119.14 Y103.935 E2.09212
G1 X119.673 Y103.935 E.0164
G1 X167.802 Y152.065 E2.09212
G1 X168.336 Y152.065 E.0164
G1 X120.207 Y103.935 E2.09212
G1 X120.74 Y103.935 E.0164
G1 X168.869 Y152.065 E2.09212
G1 X169.403 Y152.065 E.0164
G1 X121.273 Y103.935 E2.09212
G1 X121.807 Y103.935 E.0164
G1 X169.936 Y152.065 E2.09212
G1 X170.47 Y152.065 E.0164
G1 X122.34 Y103.935 E2.09212
G1 X122.874 Y103.935 E.0164
G1 X171.003 Y152.065 E2.09212
G1 X171.537 Y152.065 E.0164
G1 X123.407 Y103.935 E2.09212
G1 X123.941 Y103.935 E.0164
G1 X172.07 Y152.065 E2.09212
G1 X172.603 Y152.065 E.0164
G1 X124.474 Y103.935 E2.09212
M73 P41 R16
G1 X125.007 Y103.935 E.0164
G1 X173.124 Y152.052 E2.09157
G1 X173.619 Y152.013 E.01525
G1 X125.541 Y103.935 E2.08988
G1 X126.074 Y103.935 E.0164
G1 X174.113 Y151.974 E2.08819
G2 X174.583 Y151.91 I.034 J-1.515 E.01463
G1 X126.608 Y103.935 E2.08542
G1 X127.141 Y103.935 E.0164
G1 X175.013 Y151.807 E2.08093
G1 X175.443 Y151.704 E.0136
G1 X127.675 Y103.935 E2.07644
G1 X128.208 Y103.935 E.0164
G1 X175.864 Y151.592 E2.07156
G1 X176.242 Y151.435 E.01255
G1 X128.742 Y103.935 E2.06477
G1 X129.275 Y103.935 E.0164
G1 X176.619 Y151.279 E2.05798
G1 X176.996 Y151.123 E.01255
G1 X129.808 Y103.935 E2.05119
G1 X130.342 Y103.935 E.0164
G1 X177.341 Y150.935 E2.04301
G1 X177.672 Y150.732 E.01192
G1 X130.875 Y103.935 E2.0342
G1 X131.409 Y103.935 E.0164
G1 X178.003 Y150.529 E2.02538
G1 X178.333 Y150.326 E.01191
G1 X131.942 Y103.935 E2.01653
G1 X132.476 Y103.935 E.0164
G1 X178.62 Y150.08 E2.00585
G1 X178.908 Y149.834 E.01163
G1 X133.009 Y103.935 E1.99517
G1 X133.543 Y103.935 E.0164
G1 X179.196 Y149.589 E1.98449
G2 X179.472 Y149.332 I-.672 J-1.002 E.01165
G1 X134.076 Y103.935 E1.97333
G1 X134.609 Y103.935 E.0164
G1 X179.718 Y149.044 E1.96082
G1 X179.964 Y148.756 E.01163
G1 X135.143 Y103.935 E1.94831
G1 X135.676 Y103.935 E.0164
G1 X180.21 Y148.469 E1.93581
G2 X180.434 Y148.159 I-.865 J-.862 E.01179
G1 X136.21 Y103.935 E1.92235
G1 X136.743 Y103.935 E.0164
G1 X180.636 Y147.828 E1.90798
G1 X180.839 Y147.498 E.01192
G1 X137.277 Y103.935 E1.8936
G1 X137.81 Y103.935 E.0164
G1 X181.042 Y147.167 E1.87922
G2 X181.205 Y146.797 I-1.084 J-.701 E.01248
G1 X138.344 Y103.935 E1.86315
G1 X138.877 Y103.935 E.0164
G1 X181.362 Y146.42 E1.84675
G1 X181.518 Y146.043 E.01255
G1 X139.41 Y103.935 E1.83036
G1 X139.944 Y103.935 E.0164
G1 X181.655 Y145.647 E1.81314
G1 X181.758 Y145.216 E.0136
G1 X140.477 Y103.935 E1.79444
G1 X141.011 Y103.935 E.0164
G1 X181.862 Y144.786 E1.77574
G1 X181.956 Y144.347 E.01381
G1 X141.544 Y103.935 E1.75664
G1 X142.078 Y103.935 E.0164
G1 X181.995 Y143.852 E1.73514
G1 X182.034 Y143.358 E.01525
G1 X142.611 Y103.935 E1.71365
G1 X143.144 Y103.935 E.0164
G1 X182.065 Y142.856 E1.69181
G1 X182.065 Y142.322 E.0164
G1 X143.678 Y103.935 E1.66862
G1 X144.211 Y103.935 E.0164
G1 X182.065 Y141.789 E1.64543
G1 X182.065 Y141.255 E.0164
G1 X144.745 Y103.935 E1.62225
G1 X145.278 Y103.935 E.0164
G1 X182.065 Y140.722 E1.59906
G1 X182.065 Y140.188 E.0164
G1 X145.812 Y103.935 E1.57587
G1 X146.345 Y103.935 E.0164
G1 X182.065 Y139.655 E1.55268
G1 X182.065 Y139.121 E.0164
G1 X146.879 Y103.935 E1.52949
G1 X147.412 Y103.935 E.0164
G1 X182.065 Y138.588 E1.50631
G1 X182.065 Y138.055 E.0164
G1 X147.945 Y103.935 E1.48312
G1 X148.479 Y103.935 E.0164
G1 X182.065 Y137.521 E1.45993
G1 X182.065 Y136.988 E.0164
G1 X149.012 Y103.935 E1.43674
G1 X149.546 Y103.935 E.0164
G1 X182.065 Y136.454 E1.41355
G1 X182.065 Y135.921 E.0164
G1 X150.079 Y103.935 E1.39037
M73 P42 R16
G1 X150.613 Y103.935 E.0164
G1 X182.065 Y135.387 E1.36718
G1 X182.065 Y134.854 E.0164
G1 X151.146 Y103.935 E1.34399
G1 X151.68 Y103.935 E.0164
G1 X182.065 Y134.32 E1.3208
G1 X182.065 Y133.787 E.0164
G1 X152.213 Y103.935 E1.29761
G1 X152.746 Y103.935 E.0164
G1 X182.065 Y133.254 E1.27443
G1 X182.065 Y132.72 E.0164
G1 X153.28 Y103.935 E1.25124
G1 X153.813 Y103.935 E.0164
G1 X182.065 Y132.187 E1.22805
G1 X182.065 Y131.653 E.0164
G1 X154.347 Y103.935 E1.20486
G1 X154.88 Y103.935 E.0164
G1 X182.065 Y131.12 E1.18167
G1 X182.065 Y130.586 E.0164
G1 X155.414 Y103.935 E1.15849
G1 X155.947 Y103.935 E.0164
G1 X182.065 Y130.053 E1.1353
G1 X182.065 Y129.519 E.0164
G1 X156.481 Y103.935 E1.11211
G1 X157.014 Y103.935 E.0164
G1 X182.065 Y128.986 E1.08892
G1 X182.065 Y128.453 E.0164
G1 X157.547 Y103.935 E1.06573
G1 X158.081 Y103.935 E.0164
G1 X182.065 Y127.919 E1.04255
G1 X182.065 Y127.386 E.0164
G1 X158.614 Y103.935 E1.01936
G1 X159.148 Y103.935 E.0164
G1 X182.065 Y126.852 E.99617
G1 X182.065 Y126.319 E.0164
G1 X159.681 Y103.935 E.97298
G1 X160.215 Y103.935 E.0164
G1 X182.065 Y125.785 E.94979
G1 X182.065 Y125.252 E.0164
G1 X160.748 Y103.935 E.92661
G1 X161.281 Y103.935 E.0164
G1 X182.065 Y124.719 E.90342
G1 X182.065 Y124.185 E.0164
G1 X161.815 Y103.935 E.88023
G1 X162.348 Y103.935 E.0164
G1 X182.065 Y123.652 E.85704
G1 X182.065 Y123.118 E.0164
G1 X162.882 Y103.935 E.83385
G1 X163.415 Y103.935 E.0164
G1 X182.065 Y122.585 E.81067
G1 X182.065 Y122.051 E.0164
G1 X163.949 Y103.935 E.78748
G1 X164.482 Y103.935 E.0164
G1 X182.065 Y121.518 E.76429
G1 X182.065 Y120.984 E.0164
G1 X165.016 Y103.935 E.7411
G1 X165.549 Y103.935 E.0164
G1 X182.065 Y120.451 E.71791
G1 X182.065 Y119.918 E.0164
G1 X166.082 Y103.935 E.69473
G1 X166.616 Y103.935 E.0164
G1 X182.065 Y119.384 E.67154
G1 X182.065 Y118.851 E.0164
G1 X167.149 Y103.935 E.64835
G1 X167.683 Y103.935 E.0164
G1 X182.065 Y118.317 E.62516
G1 X182.065 Y117.784 E.0164
G1 X168.216 Y103.935 E.60197
G1 X168.75 Y103.935 E.0164
G1 X182.065 Y117.25 E.57879
G1 X182.065 Y116.717 E.0164
G1 X169.283 Y103.935 E.5556
G1 X169.817 Y103.935 E.0164
G1 X182.065 Y116.183 E.53241
G1 X182.065 Y115.65 E.0164
G1 X170.35 Y103.935 E.50922
G1 X170.883 Y103.935 E.0164
G1 X182.065 Y115.117 E.48603
G1 X182.065 Y114.583 E.0164
G1 X171.417 Y103.935 E.46285
G1 X171.95 Y103.935 E.0164
G1 X182.065 Y114.05 E.43966
G1 X182.065 Y113.516 E.0164
G1 X172.484 Y103.935 E.41647
G3 X173.022 Y103.94 I.24 J3.419 E.01656
G1 X182.06 Y112.978 E.39288
G1 X182.014 Y112.399 E.01785
G1 X173.601 Y103.986 E.36573
G1 X174.18 Y104.031 E.01785
G1 X181.969 Y111.82 E.33858
G2 X181.851 Y111.169 I-2.115 J.047 E.02044
G1 X174.831 Y104.149 E.30513
G1 X175.533 Y104.318 E.02219
G1 X181.682 Y110.467 E.26729
G1 X181.618 Y110.2 E.00844
G1 X181.385 Y109.635 E.01877
G1 X176.365 Y104.616 E.21821
G1 X177.114 Y104.926 E.02493
G1 X177.358 Y105.075 E.00879
G1 X181.321 Y109.038 E.17226
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12725.344
G1 X179.907 Y107.624 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 4/25
; update layer progress
M73 L4
M991 S0 P3 ;notify layer change
M106 S198.9
; OBJECT_ID: 91
M204 S10000
G17
G3 Z1 I-.228 J-1.196 P1  F42000
G1 X84.102 Y125.858 Z1
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X84.102 Y130.368 E.14961
G1 X80 Y132.737 E.15712
G1 X75.898 Y130.368 E.15712
G1 X75.898 Y125.632 E.15712
G1 X77.424 Y124.751 E.05845
G1 X80 Y123.263 E.09867
G1 X84.102 Y125.632 E.15712
G1 X84.102 Y125.798 E.00552
M204 S250
G1 X83.71 Y125.858 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X77.62 Y125.09 E.04719
G1 X80 Y123.716 E.08444
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.097 Y134.566 Z1.2 F42000
G1 X74.064 Y145.904 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X73.72 Y144.47 E.04891
G1 X73.602 Y142.976 E.0497
G1 X73.602 Y113.024 E.99358
G1 X73.72 Y111.53 E.0497
G1 X74.064 Y110.096 E.04891
G1 X74.436 Y109.198 E.03226
G1 X74.628 Y108.734 E.01665
G1 X75.398 Y107.477 E.04891
G1 X76.356 Y106.356 E.04891
G1 X77.477 Y105.398 E.04891
G1 X78.734 Y104.628 E.04891
G1 X80.096 Y104.064 E.04891
G1 X81.53 Y103.72 E.04891
G1 X83.024 Y103.602 E.0497
G1 X172.976 Y103.602 E2.98389
G1 X173.97 Y103.68 E.03305
G1 X174.47 Y103.72 E.01665
G1 X175.904 Y104.064 E.04891
G1 X177.266 Y104.628 E.04891
G1 X178.523 Y105.398 E.04891
G1 X179.644 Y106.356 E.04891
G1 X180.602 Y107.477 E.04891
G1 X181.372 Y108.734 E.04891
G1 X181.936 Y110.096 E.04891
G1 X182.28 Y111.53 E.04891
G1 X182.398 Y113.024 E.0497
G1 X182.398 Y142.976 E.99358
G1 X182.28 Y144.47 E.0497
G1 X181.936 Y145.904 E.04891
G1 X181.372 Y147.266 E.04891
G1 X180.602 Y148.523 E.04891
G1 X179.644 Y149.644 E.04891
G1 X178.523 Y150.602 E.04891
G1 X177.266 Y151.372 E.04891
G1 X175.904 Y151.936 E.04891
G1 X174.47 Y152.28 E.04891
G1 X172.976 Y152.398 E.0497
G1 X83.024 Y152.398 E2.98389
G1 X81.53 Y152.28 E.0497
G1 X80.096 Y151.936 E.04891
G1 X78.734 Y151.372 E.04891
G1 X77.477 Y150.602 E.04891
G1 X76.356 Y149.644 E.04891
G1 X75.398 Y148.523 E.04891
G1 X74.628 Y147.266 E.04891
G1 X74.087 Y145.959 E.04692
M204 S250
G1 X73.689 Y146.023 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.331 Y144.531 E.04715
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X74.074 Y109.048 E.03083
G1 X74.278 Y108.556 E.01637
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X172.992 Y103.21 E2.76494
G1 X174 Y103.289 E.03109
G1 X174.531 Y103.331 E.01637
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
M73 P43 R16
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.712 Y146.079 E.04541
; WIPE_START
M204 S6000
G1 X73.331 Y144.531 E-.60563
G1 X73.299 Y144.126 E-.15438
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1.2
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z1.2 F4000
            G39.3 S1
            G0 Z1.2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X76.565 Y124.845 F42000
G1 Z.8
M73 P43 R15
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X77.975 Y124.031 E.05401
G1 X73.95 Y120.006 E.18879
G1 X73.95 Y124.48 E.14841
G1 X94.48 Y103.95 E.96309
G1 X92.436 Y103.95 E.06779
G1 X140.536 Y152.05 E2.25644
G1 X138.492 Y152.05 E.06779
G1 X181.233 Y109.309 E2.00506
G3 X182.044 Y112.96 I-8.864 J3.883 E.12485
G1 X173.04 Y103.956 E.42237
G1 X173.942 Y104.027 E.03002
G3 X174.857 Y104.171 I.005 J2.96 E.03085
G1 X126.978 Y152.05 E2.2461
G1 X129.022 Y152.05 E.06779
G1 X81.143 Y104.171 E2.2461
G1 X81.585 Y104.065 E.01508
G1 X82.96 Y103.956 E.04575
G1 X73.956 Y112.96 E.42237
G3 X74.767 Y109.309 I8.539 J-.02 E.12507
G1 X117.508 Y152.05 E2.00506
G1 X115.464 Y152.05 E.06779
G1 X163.564 Y103.95 E2.25644
G1 X161.52 Y103.95 E.06779
G1 X182.05 Y124.48 E.96309
G1 X182.05 Y120.006 E.1484
G1 X150.006 Y152.05 E1.50323
G1 X152.05 Y152.05 E.06779
G1 X103.95 Y103.95 E2.25644
G1 X105.994 Y103.95 E.06779
G1 X84.45 Y125.494 E1.01065
G1 X84.45 Y130.506 E.16626
G1 X105.994 Y152.05 E1.01065
G1 X103.95 Y152.05 E.06779
G1 X152.05 Y103.95 E2.25644
G1 X150.006 Y103.95 E.06779
G1 X182.05 Y135.994 E1.50323
G1 X182.05 Y131.52 E.14841
G1 X161.52 Y152.05 E.96309
G1 X163.564 Y152.05 E.06779
G1 X115.464 Y103.95 E2.25644
G1 X117.508 Y103.95 E.06779
G1 X74.767 Y146.691 E2.00506
G3 X73.956 Y143.04 I8.864 J-3.883 E.12485
G1 X82.96 Y152.044 E.42237
G1 X81.585 Y151.935 E.04576
G1 X81.143 Y151.829 E.01508
G1 X129.022 Y103.95 E2.2461
G1 X126.978 Y103.95 E.06779
G1 X174.857 Y151.829 E2.2461
G1 X174.415 Y151.935 E.01508
G1 X173.04 Y152.044 E.04576
G1 X182.044 Y143.04 E.42237
G3 X181.233 Y146.691 I-9.674 J-.232 E.12485
G1 X138.492 Y103.95 E2.00506
G1 X140.536 Y103.95 E.06779
G1 X92.436 Y152.05 E2.25644
G1 X94.48 Y152.05 E.06779
G1 X73.95 Y131.52 E.96309
G1 X73.95 Y135.994 E.1484
G1 X77.975 Y131.969 E.18879
G1 X76.565 Y131.155 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F11791.304
G1 X77.975 Y131.969 E-.61876
G1 X77.712 Y132.232 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 5/25
; update layer progress
M73 L5
M991 S0 P4 ;notify layer change
M106 S196.35
; OBJECT_ID: 91
M204 S10000
G17
G3 Z1.2 I.859 J.862 P1  F42000
G1 X84.102 Y125.858 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F11791.304
M204 S6000
G1 X84.102 Y130.368 E.14961
G1 X80 Y132.737 E.15712
G1 X75.898 Y130.368 E.15712
G1 X75.898 Y125.632 E.15712
G1 X77.774 Y124.549 E.07186
G1 X80 Y123.263 E.08526
G1 X84.102 Y125.632 E.15712
G1 X84.102 Y125.798 E.00552
M204 S250
G1 X83.71 Y125.858 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X77.97 Y124.888 E.05961
G1 X80 Y123.716 E.07203
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.097 Y134.566 Z1.4 F42000
G1 X74.064 Y145.904 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X73.72 Y144.47 E.04891
G1 X73.602 Y142.976 E.0497
G1 X73.602 Y113.024 E.99358
G1 X73.72 Y111.53 E.0497
G1 X74.064 Y110.096 E.04891
G1 X74.628 Y108.734 E.04891
G1 X75.398 Y107.477 E.04891
G1 X76.356 Y106.356 E.04891
G1 X77.477 Y105.398 E.04891
G1 X78.734 Y104.628 E.04891
G1 X80.096 Y104.064 E.04891
G1 X81.53 Y103.72 E.04891
G1 X83.024 Y103.602 E.0497
G1 X172.976 Y103.602 E2.98389
G1 X173.813 Y103.668 E.02785
G1 X174.47 Y103.72 E.02185
G1 X175.904 Y104.064 E.04891
G1 X177.266 Y104.628 E.04891
G1 X178.523 Y105.398 E.04891
G1 X179.644 Y106.356 E.04891
G1 X180.602 Y107.477 E.04891
G1 X181.372 Y108.734 E.04891
G1 X181.936 Y110.096 E.04891
G1 X182.28 Y111.53 E.04891
G1 X182.398 Y113.024 E.0497
G1 X182.398 Y142.976 E.99358
G1 X182.28 Y144.47 E.0497
G1 X181.936 Y145.904 E.04891
G1 X181.372 Y147.266 E.04891
G1 X180.602 Y148.523 E.04891
G1 X179.644 Y149.644 E.04891
G1 X178.523 Y150.602 E.04891
G1 X177.266 Y151.372 E.04891
G1 X175.904 Y151.936 E.04891
G1 X174.47 Y152.28 E.04891
G1 X172.976 Y152.398 E.0497
G1 X83.024 Y152.398 E2.98389
G1 X81.53 Y152.28 E.0497
G1 X80.096 Y151.936 E.04891
G1 X78.734 Y151.372 E.04891
G1 X77.477 Y150.602 E.04891
G1 X76.356 Y149.644 E.04891
G1 X75.398 Y148.523 E.04891
G1 X74.628 Y147.266 E.04891
G1 X74.087 Y145.959 E.04692
M204 S250
G1 X73.69 Y146.024 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.331 Y144.531 E.04716
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X74.278 Y108.556 E.0472
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X172.992 Y103.21 E2.76494
G1 X173.844 Y103.277 E.02627
G1 X174.531 Y103.331 E.02119
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.712 Y146.079 E.04539
; WIPE_START
M204 S6000
G1 X73.331 Y144.531 E-.60582
G1 X73.299 Y144.127 E-.15419
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.4 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1.4
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z1.4 F4000
            G39.3 S1
            G0 Z1.4 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X76.288 Y131.431 F42000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X77.699 Y132.246 E.05401
G1 X74.327 Y135.617 E.15815
G1 X74.327 Y131.897 E.12338
G1 X94.103 Y151.673 E.9277
G1 X92.814 Y151.673 E.04277
G1 X140.159 Y104.327 E2.22105
G1 X138.869 Y104.327 E.04277
G1 X180.944 Y146.402 E1.97382
G2 X181.633 Y143.451 I-8.055 J-3.435 E.10105
G1 X173.451 Y151.633 E.38384
G2 X174.544 Y151.516 I.179 J-3.511 E.03663
G1 X127.355 Y104.327 E2.21373
G1 X128.645 Y104.327 E.04277
G1 X81.456 Y151.516 E2.21373
G2 X82.549 Y151.633 I.914 J-3.393 E.03663
G1 X74.367 Y143.451 E.38384
G2 X75.056 Y146.402 I8.744 J-.484 E.10105
G1 X117.131 Y104.327 E1.97382
G1 X115.841 Y104.327 E.04277
G1 X163.186 Y151.673 E2.22105
G1 X161.897 Y151.673 E.04277
G1 X181.673 Y131.897 E.9277
M73 P44 R15
G1 X181.673 Y135.617 E.12338
G1 X150.383 Y104.327 E1.46784
G1 X151.673 Y104.327 E.04277
G1 X104.327 Y151.673 E2.22105
G1 X105.617 Y151.673 E.04277
G1 X84.767 Y130.822 E.97812
G1 X84.827 Y130.787 E.00233
G1 X84.827 Y125.213 E.18491
G1 X84.767 Y125.178 E.00233
G1 X105.617 Y104.327 E.97812
G1 X104.327 Y104.327 E.04277
G1 X151.673 Y151.673 E2.22105
G1 X150.383 Y151.673 E.04277
G1 X181.673 Y120.383 E1.46784
G1 X181.673 Y124.103 E.12338
G1 X161.897 Y104.327 E.9277
G1 X163.186 Y104.327 E.04277
G1 X115.841 Y151.673 E2.22105
G1 X117.131 Y151.673 E.04277
G1 X75.056 Y109.598 E1.97382
G2 X74.367 Y112.549 I8.056 J3.436 E.10105
G1 X82.549 Y104.367 E.38384
G2 X81.456 Y104.484 I-.179 J3.512 E.03663
G1 X128.645 Y151.673 E2.21373
G1 X127.355 Y151.673 E.04277
G1 X174.544 Y104.484 E2.21373
G2 X173.451 Y104.367 I-1.492 J8.821 E.0365
G1 X181.633 Y112.549 E.38384
G2 X180.944 Y109.598 I-8.744 J.484 E.10105
G1 X138.869 Y151.673 E1.97382
G1 X140.159 Y151.673 E.04277
G1 X92.814 Y104.327 E2.22105
G1 X94.103 Y104.327 E.04277
G1 X74.327 Y124.103 E.9277
G1 X74.327 Y120.383 E.12338
G1 X77.699 Y123.754 E.15815
G1 X76.288 Y124.569 E.05401
; WIPE_START
G1 X77.699 Y123.754 E-.61876
G1 X77.436 Y123.492 E-.14124
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X84.385 Y125.376 Z1.4 F42000
G1 Z1
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.383468
G1 F3000;_EXTRUDE_SET_SPEED
M204 S6000
G3 X84.465 Y125.514 I-.03 J.109 E.0049
G1 X84.465 Y130.486 E.13797
G3 X84.385 Y130.624 I-.109 J.029 E.0049
G1 X80.08 Y133.11 E.13797
G3 X79.92 Y133.11 I-.08 J-.08 E.0049
G1 X75.615 Y130.624 E.13797
G3 X75.535 Y130.486 I.03 J-.109 E.0049
G1 X75.535 Y125.514 E.13797
G3 X75.615 Y125.376 I.109 J-.029 E.0049
G1 X79.92 Y122.89 E.13797
G3 X80.08 Y122.89 I.08 J.08 E.0049
G1 X84.333 Y125.346 E.1363
; Slow Down End
M204 S10000
G1 X174.425 Y151.918 F42000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
M204 S6000
G1 X172.956 Y152.035 E.04084
G1 X83.038 Y152.035 E2.49123
G1 X81.575 Y151.918 E.04067
G1 X80.221 Y151.593 E.03857
G1 X78.911 Y151.053 E.03926
G1 X77.681 Y150.299 E.03995
G1 X76.623 Y149.395 E.03857
G1 X75.701 Y148.318 E.03926
G1 X74.947 Y147.089 E.03995
G1 X74.407 Y145.779 E.03926
G1 X74.078 Y144.4 E.03926
G1 X73.965 Y142.956 E.04015
G1 X73.965 Y113.038 E.82889
G1 X74.082 Y111.575 E.04067
G1 X74.415 Y110.197 E.03926
G1 X74.947 Y108.911 E.03857
G1 X75.686 Y107.702 E.03927
G1 X76.605 Y106.623 E.03926
G1 X77.681 Y105.701 E.03926
G1 X78.889 Y104.959 E.03926
G1 X80.197 Y104.415 E.03926
G1 X81.575 Y104.082 E.03926
G1 X83.044 Y103.965 E.04084
G1 X172.962 Y103.965 E2.49123
G1 X174.425 Y104.082 E.04067
G1 X175.779 Y104.407 E.03857
G1 X177.089 Y104.947 E.03926
G1 X178.319 Y105.701 E.03995
G1 X179.377 Y106.605 E.03857
G1 X180.299 Y107.681 E.03926
G1 X181.053 Y108.911 E.03995
G1 X181.593 Y110.221 E.03926
G1 X181.922 Y111.6 E.03926
G1 X182.035 Y113.044 E.04015
G1 X182.035 Y142.962 E.82889
G1 X181.922 Y144.401 E.03998
G1 X181.593 Y145.779 E.03926
G1 X181.053 Y147.089 E.03926
G1 X180.299 Y148.318 E.03995
G1 X179.377 Y149.395 E.03926
G1 X178.298 Y150.314 E.03926
G1 X177.089 Y151.053 E.03926
G1 X175.803 Y151.585 E.03857
G1 X174.484 Y151.904 E.0376
; Slow Down End
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X175.803 Y151.585 E-.51573
G1 X176.397 Y151.339 E-.24427
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 6/25
; update layer progress
M73 L6
M991 S0 P5 ;notify layer change
M106 S153
; OBJECT_ID: 91
M204 S10000
G17
G3 Z1.4 I.324 J-1.173 P1  F42000
G1 X84.102 Y125.858 Z1.4
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X84.102 Y130.368 E.14961
G1 X80 Y132.737 E.15712
G1 X75.898 Y130.368 E.15712
G1 X75.898 Y125.632 E.15712
G1 X78.124 Y124.346 E.08526
G1 X80 Y123.263 E.07186
G1 X84.102 Y125.632 E.15712
G1 X84.102 Y125.798 E.00552
M204 S250
G1 X83.71 Y125.858 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X78.32 Y124.686 E.07203
G1 X80 Y123.716 E.05961
M73 P45 R15
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.097 Y134.566 Z1.6 F42000
G1 X74.064 Y145.904 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X73.72 Y144.47 E.04891
G1 X73.602 Y142.976 E.0497
G1 X73.602 Y113.024 E.99358
G1 X73.72 Y111.53 E.0497
G1 X74.064 Y110.096 E.04891
G1 X74.628 Y108.734 E.04891
G1 X75.398 Y107.477 E.04891
G1 X76.356 Y106.356 E.04891
G1 X77.477 Y105.398 E.04891
G1 X78.734 Y104.628 E.04891
G1 X80.096 Y104.064 E.04891
G1 X81.53 Y103.72 E.04891
G1 X83.024 Y103.602 E.0497
G1 X172.976 Y103.602 E2.98389
G1 X173.657 Y103.656 E.02264
G1 X174.47 Y103.72 E.02706
G1 X175.904 Y104.064 E.04891
G1 X177.266 Y104.628 E.04891
G1 X178.523 Y105.398 E.04891
G1 X179.644 Y106.356 E.04891
G1 X180.602 Y107.477 E.04891
G1 X181.372 Y108.734 E.04891
G1 X181.936 Y110.096 E.04891
G1 X182.28 Y111.53 E.04891
G1 X182.398 Y113.024 E.0497
G1 X182.398 Y142.976 E.99358
G1 X182.28 Y144.47 E.0497
G1 X181.936 Y145.904 E.04891
G1 X181.372 Y147.266 E.04891
G1 X180.602 Y148.523 E.04891
G1 X179.644 Y149.644 E.04891
G1 X178.523 Y150.602 E.04891
G1 X177.266 Y151.372 E.04891
G1 X175.904 Y151.936 E.04891
G1 X174.47 Y152.28 E.04891
G1 X172.976 Y152.398 E.0497
G1 X83.024 Y152.398 E2.98389
G1 X81.53 Y152.28 E.0497
G1 X80.096 Y151.936 E.04891
G1 X78.734 Y151.372 E.04891
G1 X77.477 Y150.602 E.04891
G1 X76.356 Y149.644 E.04891
G1 X75.398 Y148.523 E.04891
G1 X74.628 Y147.266 E.04891
G1 X74.087 Y145.959 E.04692
M204 S250
G1 X73.69 Y146.026 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.69 Y146.025 E.00002
G1 X73.331 Y144.531 E.0472
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X73.954 Y109.338 E.02119
G1 X74.278 Y108.556 E.02601
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X172.992 Y103.21 E2.76494
G1 X173.687 Y103.265 E.02145
G1 X174.531 Y103.331 E.02601
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.713 Y146.081 E.04534
; WIPE_START
M204 S6000
G1 X73.69 Y146.025 E-.02304
G1 X73.331 Y144.531 E-.58373
G1 X73.3 Y144.129 E-.15323
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.6 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1.6
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z1.6 F4000
            G39.3 S1
            G0 Z1.6 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X75.334 Y148.097 F42000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40133
; LAYER_HEIGHT: 0.4
M106 S255
G1 F3000
M204 S6000
G1 X76.618 Y149.382 E.09363
G1 X77.695 Y150.302 E.07298
G1 X78.926 Y151.051 E.07428
G1 X74.949 Y147.074 E.28989
G1 X74.497 Y145.985 E.06079
G1 X80.015 Y151.503 E.4022
G1 X80.211 Y151.584 E.01091
G1 X80.9 Y151.749 E.03653
G1 X74.251 Y145.1 E.48466
G1 X74.086 Y144.412 E.03647
G1 X74.076 Y144.287 E.00647
G1 X81.713 Y151.924 E.5567
G1 X82.406 Y151.979 E.03582
G1 X74.021 Y143.594 E.61117
G3 X73.972 Y142.906 I4.345 J-.66 E.03559
G1 X83.094 Y152.028 E.66495
G1 X83.733 Y152.028 E.0329
G1 X73.972 Y142.267 E.71147
G1 X73.972 Y141.629 E.0329
G1 X84.371 Y152.028 E.75799
G1 X85.009 Y152.028 E.0329
G1 X73.972 Y140.991 E.80452
G1 X73.972 Y140.353 E.0329
G1 X85.647 Y152.028 E.85104
G1 X86.286 Y152.028 E.0329
G1 X73.972 Y139.714 E.89757
G1 X73.972 Y139.076 E.0329
G1 X86.924 Y152.028 E.94409
G1 X87.562 Y152.028 E.0329
G1 X73.972 Y138.438 E.99061
G1 X73.972 Y137.799 E.0329
G1 X88.2 Y152.028 E1.03714
G1 X88.839 Y152.028 E.0329
G1 X73.972 Y137.161 E1.08366
G1 X73.972 Y136.523 E.0329
G1 X89.477 Y152.028 E1.13019
G1 X90.115 Y152.028 E.0329
G1 X73.972 Y135.885 E1.17671
G1 X73.972 Y135.246 E.0329
G1 X90.754 Y152.028 E1.22324
G1 X91.392 Y152.028 E.0329
G1 X73.972 Y134.608 E1.26976
G1 X73.972 Y133.97 E.0329
G1 X92.03 Y152.028 E1.31628
G1 X92.668 Y152.028 E.0329
G1 X73.972 Y133.332 E1.36281
G1 X73.972 Y132.693 E.0329
G1 X93.307 Y152.028 E1.40933
G1 X93.945 Y152.028 E.0329
G1 X73.972 Y132.055 E1.45586
G1 X73.972 Y131.417 E.0329
G1 X94.583 Y152.028 E1.50238
G1 X95.222 Y152.028 E.0329
G1 X73.972 Y130.778 E1.5489
G1 X73.972 Y130.14 E.0329
G1 X95.86 Y152.028 E1.59543
G1 X96.498 Y152.028 E.0329
G1 X73.972 Y129.502 E1.64195
G1 X73.972 Y128.864 E.0329
G1 X97.136 Y152.028 E1.68847
G1 X97.775 Y152.028 E.0329
G1 X77.421 Y131.674 E1.48361
G1 X78.931 Y132.546 E.08988
G1 X98.413 Y152.028 E1.42005
G1 X99.051 Y152.028 E.0329
G1 X80.118 Y133.095 E1.38003
G1 X80.523 Y132.862 E.02408
G1 X99.689 Y152.028 E1.39706
G1 X100.328 Y152.028 E.0329
G1 X80.927 Y132.628 E1.41409
G1 X81.332 Y132.394 E.02408
G1 X100.966 Y152.028 E1.43112
G1 X101.604 Y152.028 E.0329
G1 X81.737 Y132.161 E1.44815
G1 X82.141 Y131.927 E.02408
G1 X102.243 Y152.028 E1.46518
G1 X102.881 Y152.028 E.0329
G1 X82.546 Y131.693 E1.4822
G1 X82.951 Y131.46 E.02408
G1 X103.519 Y152.028 E1.49923
G1 X104.157 Y152.028 E.0329
G1 X83.355 Y131.226 E1.51626
G1 X83.76 Y130.993 E.02408
G1 X104.796 Y152.028 E1.53329
G1 X105.434 Y152.028 E.0329
G1 X84.165 Y130.759 E1.55032
G1 X84.472 Y130.582 E.01827
G1 X84.472 Y130.428 E.00794
M73 P46 R15
G1 X106.072 Y152.028 E1.57447
G1 X106.711 Y152.028 E.0329
G1 X84.472 Y129.789 E1.62099
G1 X84.472 Y129.151 E.0329
G1 X107.349 Y152.028 E1.66751
G1 X107.987 Y152.028 E.0329
G1 X84.472 Y128.513 E1.71404
G1 X84.472 Y127.875 E.0329
G1 X108.625 Y152.028 E1.76056
G1 X109.264 Y152.028 E.0329
G1 X84.472 Y127.236 E1.80709
G1 X84.472 Y126.598 E.0329
G1 X109.902 Y152.028 E1.85361
G1 X110.54 Y152.028 E.0329
G1 X84.472 Y125.96 E1.90013
G1 X84.472 Y125.418 E.02791
G1 X83.19 Y124.679 E.07625
G1 X73.972 Y115.46 E.67195
G1 X73.972 Y116.098 E.0329
G1 X81.68 Y123.807 E.56188
G1 X80.17 Y122.935 E.08988
G1 X73.972 Y116.736 E.4518
G1 X73.972 Y117.375 E.0329
G1 X79.641 Y123.044 E.41323
G1 X79.236 Y123.277 E.02408
G1 X73.972 Y118.013 E.38374
G1 X73.972 Y118.651 E.0329
G1 X78.832 Y123.511 E.35424
G1 X78.427 Y123.745 E.02408
G1 X73.972 Y119.289 E.32475
G1 X73.972 Y119.928 E.0329
G1 X78.022 Y123.978 E.29525
M73 P46 R14
G1 X77.618 Y124.212 E.02408
G1 X73.972 Y120.566 E.26575
G1 X73.972 Y121.204 E.0329
G1 X77.213 Y124.446 E.23626
G1 X76.808 Y124.679 E.02408
G1 X73.972 Y121.843 E.20677
G1 X73.972 Y122.481 E.0329
G1 X76.404 Y124.913 E.17727
G1 X75.999 Y125.146 E.02408
G1 X73.972 Y123.119 E.14777
G1 X73.972 Y123.757 E.0329
G1 X75.594 Y125.38 E.11828
G1 X75.528 Y125.418 E.00393
G1 X75.528 Y125.952 E.02752
G1 X73.972 Y124.396 E.11346
G1 X73.972 Y125.034 E.0329
G1 X75.528 Y126.591 E.11346
G1 X75.528 Y127.229 E.0329
G1 X73.972 Y125.672 E.11346
G1 X73.972 Y126.31 E.0329
G1 X75.528 Y127.867 E.11346
G1 X75.528 Y128.505 E.0329
G1 X73.972 Y126.949 E.11346
G1 X73.972 Y127.587 E.0329
G1 X75.528 Y129.144 E.11346
G1 X75.528 Y129.782 E.0329
G1 X73.769 Y128.023 E.12822
M106 S153
M204 S10000
G1 X73.769 Y114.619 F42000
M106 S255
M73 P47 R14
G1 F3000
M204 S6000
G1 X111.178 Y152.028 E2.72676
G1 X111.817 Y152.028 E.0329
G1 X73.972 Y114.183 E2.75853
G1 X73.972 Y113.545 E.0329
G1 X112.455 Y152.028 E2.80505
G1 X113.093 Y152.028 E.0329
G1 X73.981 Y112.916 E2.85088
G1 X74.028 Y112.325 E.03059
G1 X113.732 Y152.028 E2.89401
G1 X114.37 Y152.028 E.0329
G1 X74.074 Y111.733 E2.93714
G3 X74.179 Y111.199 I1.736 J.064 E.02814
G1 X115.008 Y152.028 E2.97602
G1 X115.646 Y152.028 E.0329
G1 X74.303 Y110.685 E3.01354
G1 X74.431 Y110.175 E.02709
G1 X116.285 Y152.028 E3.05069
G1 X116.923 Y152.028 E.0329
G1 X74.618 Y109.724 E3.08359
G1 X74.805 Y109.272 E.02518
G1 X117.561 Y152.028 E3.11648
G1 X118.2 Y152.028 E.0329
G1 X75.002 Y108.831 E3.14865
G1 X75.245 Y108.435 E.02392
G1 X118.838 Y152.028 E3.1775
G1 X119.476 Y152.028 E.0329
G1 X75.487 Y108.04 E3.20634
G1 X75.737 Y107.65 E.02381
G1 X120.114 Y152.028 E3.2347
G1 X120.753 Y152.028 E.0329
G1 X76.031 Y107.306 E3.2598
G1 X76.325 Y106.962 E.02333
G1 X121.391 Y152.028 E3.28489
G1 X122.029 Y152.028 E.0329
G1 X76.619 Y106.618 E3.30998
G1 X76.963 Y106.324 E.02333
G1 X122.667 Y152.028 E3.33141
G1 X123.306 Y152.028 E.0329
G1 X77.307 Y106.03 E3.35284
G1 X77.651 Y105.736 E.02333
G1 X123.944 Y152.028 E3.37427
G1 X124.582 Y152.028 E.0329
G1 X78.041 Y105.487 E3.39242
G1 X78.436 Y105.244 E.02392
G1 X125.221 Y152.028 E3.4101
G1 X125.859 Y152.028 E.0329
G1 X78.832 Y105.002 E3.42778
G1 X79.274 Y104.805 E.02491
G1 X126.497 Y152.028 E3.44213
G1 X127.135 Y152.028 E.0329
G1 X79.725 Y104.618 E3.45575
G1 X80.176 Y104.431 E.02518
G1 X127.774 Y152.028 E3.46938
G1 X128.412 Y152.028 E.0329
G1 X80.686 Y104.302 E3.47874
G1 X81.201 Y104.179 E.02728
G1 X129.05 Y152.028 E3.48775
G1 X129.688 Y152.028 E.0329
G1 X81.735 Y104.074 E3.49537
M73 P48 R14
G1 X82.326 Y104.028 E.03059
G1 X130.327 Y152.028 E3.49876
G1 X130.965 Y152.028 E.0329
G1 X82.918 Y103.981 E3.50216
G3 X83.547 Y103.972 I.375 J3.987 E.03245
G1 X131.603 Y152.028 E3.50285
G1 X132.242 Y152.028 E.0329
G1 X84.185 Y103.972 E3.50285
G1 X84.823 Y103.972 E.0329
G1 X132.88 Y152.028 E3.50285
G1 X133.518 Y152.028 E.0329
G1 X85.462 Y103.972 E3.50285
G1 X86.1 Y103.972 E.0329
G1 X134.156 Y152.028 E3.50285
G1 X134.795 Y152.028 E.0329
G1 X86.738 Y103.972 E3.50285
G1 X87.376 Y103.972 E.0329
G1 X135.433 Y152.028 E3.50285
G1 X136.071 Y152.028 E.0329
G1 X88.015 Y103.972 E3.50285
G1 X88.653 Y103.972 E.0329
G1 X136.71 Y152.028 E3.50285
G1 X137.348 Y152.028 E.0329
G1 X89.291 Y103.972 E3.50285
G1 X89.93 Y103.972 E.0329
G1 X137.986 Y152.028 E3.50285
M73 P49 R14
G1 X138.624 Y152.028 E.0329
G1 X90.568 Y103.972 E3.50285
G1 X91.206 Y103.972 E.0329
G1 X139.263 Y152.028 E3.50285
G1 X139.901 Y152.028 E.0329
G1 X91.844 Y103.972 E3.50285
G1 X92.483 Y103.972 E.0329
G1 X140.539 Y152.028 E3.50285
G1 X141.177 Y152.028 E.0329
G1 X93.121 Y103.972 E3.50285
G1 X93.759 Y103.972 E.0329
G1 X141.816 Y152.028 E3.50285
G1 X142.454 Y152.028 E.0329
G1 X94.397 Y103.972 E3.50285
G1 X95.036 Y103.972 E.0329
G1 X143.092 Y152.028 E3.50285
G1 X143.731 Y152.028 E.0329
G1 X95.674 Y103.972 E3.50285
G1 X96.312 Y103.972 E.0329
G1 X144.369 Y152.028 E3.50285
G1 X145.007 Y152.028 E.0329
G1 X96.951 Y103.972 E3.50285
G1 X97.589 Y103.972 E.0329
G1 X145.645 Y152.028 E3.50285
M73 P50 R14
G1 X146.284 Y152.028 E.0329
G1 X98.227 Y103.972 E3.50285
G1 X98.865 Y103.972 E.0329
G1 X146.922 Y152.028 E3.50285
M73 P50 R13
G1 X147.56 Y152.028 E.0329
G1 X99.504 Y103.972 E3.50285
G1 X100.142 Y103.972 E.0329
G1 X148.199 Y152.028 E3.50285
G1 X148.837 Y152.028 E.0329
G1 X100.78 Y103.972 E3.50285
G1 X101.418 Y103.972 E.0329
G1 X149.475 Y152.028 E3.50285
G1 X150.113 Y152.028 E.0329
G1 X102.057 Y103.972 E3.50285
G1 X102.695 Y103.972 E.0329
G1 X150.752 Y152.028 E3.50285
G1 X151.39 Y152.028 E.0329
G1 X103.333 Y103.972 E3.50285
G1 X103.972 Y103.972 E.0329
G1 X152.028 Y152.028 E3.50285
G1 X152.666 Y152.028 E.0329
G1 X104.61 Y103.972 E3.50285
G1 X105.248 Y103.972 E.0329
G1 X153.305 Y152.028 E3.50285
G1 X153.943 Y152.028 E.0329
G1 X105.886 Y103.972 E3.50285
M73 P51 R13
G1 X106.525 Y103.972 E.0329
G1 X154.581 Y152.028 E3.50285
G1 X155.22 Y152.028 E.0329
G1 X107.163 Y103.972 E3.50285
G1 X107.801 Y103.972 E.0329
G1 X155.858 Y152.028 E3.50285
G1 X156.496 Y152.028 E.0329
G1 X108.44 Y103.972 E3.50285
G1 X109.078 Y103.972 E.0329
G1 X157.134 Y152.028 E3.50285
G1 X157.773 Y152.028 E.0329
G1 X109.716 Y103.972 E3.50285
G1 X110.354 Y103.972 E.0329
G1 X158.411 Y152.028 E3.50285
G1 X159.049 Y152.028 E.0329
G1 X110.993 Y103.972 E3.50285
G1 X111.631 Y103.972 E.0329
G1 X159.687 Y152.028 E3.50285
G1 X160.326 Y152.028 E.0329
G1 X112.269 Y103.972 E3.50285
G1 X112.907 Y103.972 E.0329
G1 X160.964 Y152.028 E3.50285
G1 X161.602 Y152.028 E.0329
G1 X113.546 Y103.972 E3.50285
M73 P52 R13
G1 X114.184 Y103.972 E.0329
G1 X162.241 Y152.028 E3.50285
G1 X162.879 Y152.028 E.0329
G1 X114.822 Y103.972 E3.50285
G1 X115.461 Y103.972 E.0329
G1 X163.517 Y152.028 E3.50285
G1 X164.155 Y152.028 E.0329
G1 X116.099 Y103.972 E3.50285
G1 X116.737 Y103.972 E.0329
G1 X164.794 Y152.028 E3.50285
G1 X165.432 Y152.028 E.0329
G1 X117.375 Y103.972 E3.50285
G1 X118.014 Y103.972 E.0329
G1 X166.07 Y152.028 E3.50285
G1 X166.709 Y152.028 E.0329
G1 X118.652 Y103.972 E3.50285
G1 X119.29 Y103.972 E.0329
G1 X167.347 Y152.028 E3.50285
G1 X167.985 Y152.028 E.0329
G1 X119.929 Y103.972 E3.50285
G1 X120.567 Y103.972 E.0329
G1 X168.623 Y152.028 E3.50285
G1 X169.262 Y152.028 E.0329
G1 X121.205 Y103.972 E3.50285
M73 P53 R13
G1 X121.843 Y103.972 E.0329
G1 X169.9 Y152.028 E3.50285
G1 X170.538 Y152.028 E.0329
G1 X122.482 Y103.972 E3.50285
G1 X123.12 Y103.972 E.0329
G1 X171.176 Y152.028 E3.50285
G1 X171.815 Y152.028 E.0329
G1 X123.758 Y103.972 E3.50285
G1 X124.396 Y103.972 E.0329
G1 X172.453 Y152.028 E3.50285
G2 X173.082 Y152.019 I.254 J-3.999 E.03245
G1 X125.035 Y103.972 E3.50216
G1 X125.673 Y103.972 E.0329
G1 X173.674 Y151.972 E3.49876
G1 X174.265 Y151.926 E.03059
G1 X126.311 Y103.972 E3.49537
G1 X126.95 Y103.972 E.0329
G1 X174.799 Y151.821 E3.48775
M73 P53 R12
G1 X175.314 Y151.698 E.02728
G1 X127.588 Y103.972 E3.47875
G1 X128.226 Y103.972 E.0329
G1 X175.824 Y151.569 E3.46938
G1 X176.275 Y151.382 E.02518
G1 X128.864 Y103.972 E3.45576
M73 P54 R12
G1 X129.503 Y103.972 E.0329
G1 X176.726 Y151.195 E3.44213
G1 X177.168 Y150.999 E.02491
G1 X130.141 Y103.972 E3.42779
G1 X130.779 Y103.972 E.0329
G1 X177.563 Y150.756 E3.41011
G1 X177.959 Y150.513 E.02392
G1 X131.417 Y103.972 E3.39243
G1 X132.056 Y103.972 E.0329
G1 X178.348 Y150.264 E3.37428
G1 X178.693 Y149.97 E.02333
G1 X132.694 Y103.972 E3.35285
G1 X133.332 Y103.972 E.0329
G1 X179.037 Y149.676 E3.33142
G1 X179.381 Y149.382 E.02333
G1 X133.971 Y103.972 E3.30998
G1 X134.609 Y103.972 E.0329
G1 X179.675 Y149.038 E3.2849
G1 X179.969 Y148.694 E.02333
G1 X135.247 Y103.972 E3.2598
G1 X135.885 Y103.972 E.0329
G1 X180.263 Y148.35 E3.23471
G1 X180.513 Y147.961 E.02381
G1 X136.524 Y103.972 E3.20635
M73 P55 R12
G1 X137.162 Y103.972 E.0329
G1 X180.755 Y147.565 E3.17751
G1 X180.998 Y147.169 E.02392
G1 X137.8 Y103.972 E3.14866
G1 X138.439 Y103.972 E.0329
G1 X181.195 Y146.728 E3.1165
G1 X181.382 Y146.277 E.02518
G1 X139.077 Y103.972 E3.0836
G1 X139.715 Y103.972 E.0329
G1 X181.569 Y145.825 E3.0507
G1 X181.697 Y145.316 E.02709
G1 X140.353 Y103.972 E3.01356
G1 X140.992 Y103.972 E.0329
G1 X181.821 Y144.801 E2.97604
G2 X181.926 Y144.267 I-1.632 J-.597 E.02814
G1 X141.63 Y103.972 E2.93715
G1 X142.268 Y103.972 E.0329
G1 X181.972 Y143.676 E2.89402
G1 X182.019 Y143.084 E.03059
G1 X142.906 Y103.972 E2.85089
G1 X143.545 Y103.972 E.0329
G1 X182.028 Y142.455 E2.80507
G1 X182.028 Y141.817 E.0329
G1 X144.183 Y103.972 E2.75854
G1 X144.821 Y103.972 E.0329
G1 X182.028 Y141.179 E2.71202
M73 P56 R12
G1 X182.028 Y140.54 E.0329
G1 X145.46 Y103.972 E2.6655
G1 X146.098 Y103.972 E.0329
G1 X182.028 Y139.902 E2.61897
G1 X182.028 Y139.264 E.0329
G1 X146.736 Y103.972 E2.57245
G1 X147.374 Y103.972 E.0329
G1 X182.028 Y138.626 E2.52592
G1 X182.028 Y137.987 E.0329
G1 X148.013 Y103.972 E2.4794
G1 X148.651 Y103.972 E.0329
G1 X182.028 Y137.349 E2.43288
G1 X182.028 Y136.711 E.0329
G1 X149.289 Y103.972 E2.38635
G1 X149.928 Y103.972 E.0329
G1 X182.028 Y136.072 E2.33983
G1 X182.028 Y135.434 E.0329
G1 X150.566 Y103.972 E2.2933
G1 X151.204 Y103.972 E.0329
G1 X182.028 Y134.796 E2.24678
G1 X182.028 Y134.158 E.0329
G1 X151.842 Y103.972 E2.20026
G1 X152.481 Y103.972 E.0329
G1 X182.028 Y133.519 E2.15373
G1 X182.028 Y132.881 E.0329
G1 X153.119 Y103.972 E2.10721
M73 P57 R12
G1 X153.757 Y103.972 E.0329
G1 X182.028 Y132.243 E2.06068
G1 X182.028 Y131.605 E.0329
G1 X154.395 Y103.972 E2.01416
G1 X155.034 Y103.972 E.0329
G1 X182.028 Y130.966 E1.96764
G1 X182.028 Y130.328 E.0329
G1 X155.672 Y103.972 E1.92111
G1 X156.31 Y103.972 E.0329
G1 X182.028 Y129.69 E1.87459
M73 P57 R11
G1 X182.028 Y129.051 E.0329
G1 X156.949 Y103.972 E1.82806
G1 X157.587 Y103.972 E.0329
G1 X182.028 Y128.413 E1.78154
G1 X182.028 Y127.775 E.0329
G1 X158.225 Y103.972 E1.73502
G1 X158.863 Y103.972 E.0329
G1 X182.028 Y127.137 E1.68849
G1 X182.028 Y126.498 E.0329
G1 X159.502 Y103.972 E1.64197
G1 X160.14 Y103.972 E.0329
G1 X182.028 Y125.86 E1.59544
G1 X182.028 Y125.222 E.0329
G1 X160.778 Y103.972 E1.54892
G1 X161.417 Y103.972 E.0329
G1 X182.028 Y124.583 E1.50239
G1 X182.028 Y123.945 E.0329
G1 X162.055 Y103.972 E1.45587
G1 X162.693 Y103.972 E.0329
G1 X182.028 Y123.307 E1.40935
G1 X182.028 Y122.669 E.0329
G1 X163.331 Y103.972 E1.36282
G1 X163.97 Y103.972 E.0329
G1 X182.028 Y122.03 E1.3163
M73 P58 R11
G1 X182.028 Y121.392 E.0329
G1 X164.608 Y103.972 E1.26978
G1 X165.246 Y103.972 E.0329
G1 X182.028 Y120.754 E1.22325
G1 X182.028 Y120.116 E.0329
G1 X165.884 Y103.972 E1.17673
G1 X166.523 Y103.972 E.0329
G1 X182.028 Y119.477 E1.1302
G1 X182.028 Y118.839 E.0329
G1 X167.161 Y103.972 E1.08368
G1 X167.799 Y103.972 E.0329
G1 X182.028 Y118.201 E1.03716
G1 X182.028 Y117.562 E.0329
G1 X168.438 Y103.972 E.99063
G1 X169.076 Y103.972 E.0329
G1 X182.028 Y116.924 E.94411
G1 X182.028 Y116.286 E.0329
G1 X169.714 Y103.972 E.89758
G1 X170.352 Y103.972 E.0329
G1 X182.028 Y115.648 E.85106
G1 X182.028 Y115.009 E.0329
G1 X170.991 Y103.972 E.80454
G1 X171.629 Y103.972 E.0329
G1 X182.028 Y114.371 E.75801
G1 X182.028 Y113.733 E.0329
G1 X172.267 Y103.972 E.71149
G1 X172.905 Y103.972 E.0329
G1 X182.028 Y113.095 E.66496
G2 X181.979 Y112.407 I-4.396 J-.028 E.03559
G1 X173.593 Y104.021 E.61119
G1 X174.286 Y104.076 E.03582
G1 X181.924 Y111.714 E.55672
G1 X181.914 Y111.588 E.00649
G1 X181.749 Y110.9 E.03646
G1 X175.1 Y104.251 E.48468
G1 X175.473 Y104.341 E.01978
G3 X175.984 Y104.497 I-.239 J1.692 E.02769
G1 X181.503 Y110.016 E.40224
G1 X181.051 Y108.926 E.06079
G1 X177.074 Y104.949 E.28992
G1 X178.305 Y105.698 E.0743
G1 X179.38 Y106.617 E.07288
G1 X180.667 Y107.903 E.09376
M106 S153
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X179.38 Y106.617 E-.69128
G1 X179.243 Y106.499 E-.06873
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 7/25
; update layer progress
M73 L7
M991 S0 P6 ;notify layer change
M106 S158.1
; OBJECT_ID: 91
M204 S10000
G17
G3 Z1.6 I-.243 J-1.193 P1  F42000
G1 X84.102 Y125.858 Z1.6
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X84.102 Y130.368 E.14961
G1 X80 Y132.737 E.15712
G1 X75.898 Y130.368 E.15712
G1 X75.898 Y125.632 E.15712
G1 X78.474 Y124.144 E.09867
G1 X80 Y123.263 E.05845
G1 X84.102 Y125.632 E.15712
G1 X84.102 Y125.798 E.00552
M204 S250
M73 P59 R11
G1 X83.71 Y125.858 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X78.67 Y124.484 E.08444
G1 X80 Y123.716 E.04719
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.097 Y134.566 Z1.8 F42000
G1 X74.064 Y145.904 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X73.72 Y144.47 E.04891
G1 X73.602 Y142.976 E.0497
G1 X73.602 Y113.024 E.99358
G1 X73.72 Y111.53 E.0497
G1 X74.064 Y110.096 E.04891
G1 X74.628 Y108.734 E.04891
G1 X75.398 Y107.477 E.04891
G1 X76.356 Y106.356 E.04891
G1 X77.477 Y105.398 E.04891
G1 X78.734 Y104.628 E.04891
G1 X80.096 Y104.064 E.04891
G1 X81.53 Y103.72 E.04891
G1 X83.024 Y103.602 E.0497
G1 X172.976 Y103.602 E2.98389
G1 X173.5 Y103.643 E.01744
G1 X174.47 Y103.72 E.03226
G1 X175.904 Y104.064 E.04891
G1 X177.266 Y104.628 E.04891
G1 X178.523 Y105.398 E.04891
G1 X179.644 Y106.356 E.04891
G1 X180.602 Y107.477 E.04891
G1 X181.372 Y108.734 E.04891
G1 X181.936 Y110.096 E.04891
G1 X182.28 Y111.53 E.04891
G1 X182.398 Y113.024 E.0497
G1 X182.398 Y142.976 E.99358
G1 X182.28 Y144.47 E.0497
G1 X181.936 Y145.904 E.04891
G1 X181.372 Y147.266 E.04891
G1 X180.602 Y148.523 E.04891
G1 X179.644 Y149.644 E.04891
G1 X178.523 Y150.602 E.04891
G1 X177.266 Y151.372 E.04891
G1 X175.904 Y151.936 E.04891
G1 X174.47 Y152.28 E.04891
G1 X172.976 Y152.398 E.0497
G1 X83.024 Y152.398 E2.98389
G1 X81.53 Y152.28 E.0497
G1 X80.096 Y151.936 E.04891
G1 X78.734 Y151.372 E.04891
G1 X77.477 Y150.602 E.04891
G1 X76.356 Y149.644 E.04891
G1 X75.398 Y148.523 E.04891
G1 X74.628 Y147.266 E.04891
G1 X74.087 Y145.959 E.04692
M204 S250
G1 X73.69 Y146.025 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.69 Y146.025 E0
G1 X73.331 Y144.531 E.0472
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X73.894 Y109.483 E.01637
G1 X74.278 Y108.556 E.03083
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X172.992 Y103.21 E2.76494
G1 X173.531 Y103.252 E.01663
G1 X174.531 Y103.331 E.03083
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.713 Y146.081 E.04535
; WIPE_START
M204 S6000
G1 X73.69 Y146.025 E-.02285
G1 X73.331 Y144.531 E-.58373
G1 X73.3 Y144.129 E-.15342
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.8 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1.8
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z1.8 F4000
            G39.3 S1
            G0 Z1.8 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X75.402 Y148.215 F42000
G1 Z1.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42012
G1 F12725.344
M204 S6000
G1 X76.605 Y149.418 E.05229
G1 X77.674 Y150.331 E.04321
G1 X78.648 Y150.929 E.03514
G1 X75.071 Y147.352 E.15549
G1 X74.926 Y147.114 E.00857
G1 X74.614 Y146.36 E.02507
G1 X79.64 Y151.386 E.21847
G1 X80.2 Y151.618 E.01863
G1 X80.47 Y151.683 E.00854
G1 X74.317 Y145.53 E.26747
G1 X74.148 Y144.828 E.02219
G1 X81.172 Y151.852 E.3053
G2 X81.823 Y151.969 I.696 J-1.996 E.02041
G1 X74.031 Y144.177 E.33871
G1 X73.985 Y143.598 E.01785
G1 X82.402 Y152.015 E.36586
G1 X82.981 Y152.06 E.01785
G1 X73.94 Y143.019 E.39301
G3 X73.935 Y142.481 I3.415 J-.297 E.01655
G1 X83.519 Y152.065 E.41658
G1 X84.052 Y152.065 E.0164
G1 X73.935 Y141.948 E.43977
G1 X73.935 Y141.414 E.0164
G1 X84.586 Y152.065 E.46295
G1 X85.119 Y152.065 E.0164
G1 X73.935 Y140.881 E.48614
G1 X73.935 Y140.348 E.0164
G1 X85.652 Y152.065 E.50933
G1 X86.186 Y152.065 E.0164
G1 X73.935 Y139.814 E.53252
G1 X73.935 Y139.281 E.0164
G1 X86.719 Y152.065 E.55571
G1 X87.253 Y152.065 E.0164
G1 X73.935 Y138.747 E.57889
G1 X73.935 Y138.214 E.0164
G1 X87.786 Y152.065 E.60208
G1 X88.32 Y152.065 E.0164
G1 X73.935 Y137.68 E.62527
G1 X73.935 Y137.147 E.0164
G1 X88.853 Y152.065 E.64846
G1 X89.387 Y152.065 E.0164
G1 X73.935 Y136.613 E.67165
G1 X73.935 Y136.08 E.0164
G1 X89.92 Y152.065 E.69483
G1 X90.453 Y152.065 E.0164
G1 X73.935 Y135.547 E.71802
G1 X73.935 Y135.013 E.0164
G1 X90.987 Y152.065 E.74121
G1 X91.52 Y152.065 E.0164
G1 X73.935 Y134.48 E.7644
G1 X73.935 Y133.946 E.0164
G1 X92.054 Y152.065 E.78759
G1 X92.587 Y152.065 E.0164
G1 X73.935 Y133.413 E.81077
G1 X73.935 Y132.879 E.0164
G1 X93.121 Y152.065 E.83396
G1 X93.654 Y152.065 E.0164
G1 X73.935 Y132.346 E.85715
G1 X73.935 Y131.812 E.0164
G1 X94.188 Y152.065 E.88034
G1 X94.721 Y152.065 E.0164
G1 X73.935 Y131.279 E.90353
G1 X73.935 Y130.746 E.0164
G1 X95.254 Y152.065 E.92671
G1 X95.788 Y152.065 E.0164
G1 X73.935 Y130.212 E.9499
G1 X73.935 Y129.679 E.0164
G1 X96.491 Y152.234 E.98047
M204 S10000
G1 X110.894 Y152.234 F42000
G1 F12725.344
M204 S6000
G1 X84.435 Y125.776 E1.15012
G1 X84.435 Y126.309 E.0164
G1 X110.191 Y152.065 E1.11956
G1 X109.657 Y152.065 E.0164
G1 X84.435 Y126.843 E1.09637
G1 X84.435 Y127.376 E.0164
G1 X109.124 Y152.065 E1.07318
G1 X108.59 Y152.065 E.0164
G1 X84.435 Y127.91 E1.04999
G1 X84.435 Y128.443 E.0164
G1 X108.057 Y152.065 E1.0268
G1 X107.524 Y152.065 E.0164
G1 X84.435 Y128.976 E1.00362
G1 X84.435 Y129.51 E.0164
G1 X106.99 Y152.065 E.98043
G1 X106.457 Y152.065 E.0164
G1 X84.435 Y130.043 E.95724
G1 X84.425 Y130.567 E.01609
G1 X105.923 Y152.065 E.93449
G1 X105.39 Y152.065 E.0164
G1 X84.087 Y130.762 E.92601
G1 X83.749 Y130.957 E.012
G1 X104.856 Y152.065 E.91752
G1 X104.323 Y152.065 E.0164
G1 X83.411 Y131.152 E.90903
G1 X83.072 Y131.348 E.012
G1 X103.789 Y152.065 E.90054
G1 X103.256 Y152.065 E.0164
G1 X82.734 Y131.543 E.89206
G1 X82.396 Y131.738 E.012
G1 X102.723 Y152.065 E.88357
G1 X102.189 Y152.065 E.0164
G1 X82.058 Y131.933 E.87508
G1 X81.72 Y132.129 E.012
G1 X101.656 Y152.065 E.86659
G1 X101.122 Y152.065 E.0164
G1 X81.381 Y132.324 E.85811
G1 X81.043 Y132.519 E.012
G1 X100.589 Y152.065 E.84962
G1 X100.055 Y152.065 E.0164
G1 X80.705 Y132.714 E.84113
G1 X80.367 Y132.91 E.012
G1 X99.522 Y152.065 E.83265
G1 X98.988 Y152.065 E.0164
G1 X80.029 Y133.105 E.82416
G1 X80 Y133.121 E.00102
G1 X78.845 Y132.455 E.04099
G1 X98.455 Y152.065 E.85242
G1 X97.922 Y152.065 E.0164
G1 X77.583 Y131.726 E.8841
G1 X76.321 Y130.997 E.0448
G1 X97.388 Y152.065 E.91577
G1 X96.855 Y152.065 E.0164
G1 X73.935 Y129.145 E.99628
G1 X73.935 Y128.612 E.0164
G1 X75.565 Y130.241 E.07083
G1 X75.565 Y129.708 E.0164
G1 X73.935 Y128.078 E.07083
G1 X73.935 Y127.545 E.0164
G1 X75.565 Y129.174 E.07083
G1 X75.565 Y128.641 E.0164
G1 X73.935 Y127.011 E.07083
G1 X73.935 Y126.478 E.0164
G1 X75.565 Y128.107 E.07083
G1 X75.565 Y127.574 E.0164
G1 X73.935 Y125.945 E.07083
G1 X73.935 Y125.411 E.0164
G1 X75.565 Y127.041 E.07083
G1 X75.565 Y126.507 E.0164
G1 X73.935 Y124.878 E.07083
G1 X73.935 Y124.344 E.0164
G1 X75.565 Y125.974 E.07083
G1 X75.565 Y125.44 E.0164
M73 P60 R11
G1 X73.935 Y123.811 E.07083
G1 X73.935 Y123.277 E.0164
G1 X75.902 Y125.244 E.0855
G1 X76.24 Y125.049 E.012
G1 X73.935 Y122.744 E.1002
G1 X73.935 Y122.211 E.0164
G1 X76.579 Y124.854 E.1149
G1 X76.917 Y124.659 E.012
G1 X73.935 Y121.677 E.1296
G1 X73.935 Y121.144 E.0164
G1 X77.255 Y124.463 E.1443
G1 X77.593 Y124.268 E.012
G1 X73.935 Y120.61 E.159
G1 X73.935 Y120.077 E.0164
G1 X77.931 Y124.073 E.1737
G1 X78.27 Y123.878 E.012
G1 X73.935 Y119.543 E.1884
G1 X73.935 Y119.01 E.0164
G1 X78.608 Y123.682 E.20311
G1 X78.946 Y123.487 E.012
G1 X73.935 Y118.476 E.21781
G1 X73.935 Y117.943 E.0164
G1 X79.284 Y123.292 E.23251
G1 X79.622 Y123.097 E.012
G1 X73.935 Y117.41 E.24721
G1 X73.935 Y116.876 E.0164
G1 X79.961 Y122.901 E.26191
G1 X80 Y122.879 E.0014
G1 X81.115 Y123.522 E.03957
G1 X73.935 Y116.343 E.31208
G1 X73.935 Y115.809 E.0164
G1 X82.377 Y124.251 E.36695
G1 X83.639 Y124.98 E.0448
G1 X73.935 Y115.276 E.42181
G1 X73.935 Y114.742 E.0164
G1 X111.258 Y152.065 E1.62235
G1 X111.791 Y152.065 E.0164
G1 X73.935 Y114.209 E1.64554
G1 X73.935 Y113.675 E.0164
G1 X112.325 Y152.065 E1.66873
G1 X112.858 Y152.065 E.0164
G1 X73.935 Y113.142 E1.69192
G3 X73.967 Y112.64 I3.207 J-.053 E.01548
G1 X113.391 Y152.065 E1.71375
G1 X113.925 Y152.065 E.0164
G1 X74.005 Y112.145 E1.73524
G1 X74.044 Y111.651 E.01525
G1 X114.458 Y152.065 E1.75674
G1 X114.992 Y152.065 E.0164
G1 X74.139 Y111.212 E1.77583
G1 X74.242 Y110.782 E.0136
G1 X115.525 Y152.065 E1.79452
G1 X116.059 Y152.065 E.0164
G1 X74.345 Y110.351 E1.81322
G3 X74.483 Y109.956 I1.318 J.236 E.01294
G1 X116.592 Y152.065 E1.83043
G1 X117.125 Y152.065 E.0164
G1 X74.639 Y109.578 E1.84683
G1 X74.795 Y109.201 E.01255
G1 X117.659 Y152.065 E1.86322
G1 X118.192 Y152.065 E.0164
G1 X74.959 Y108.832 E1.87929
G1 X75.162 Y108.501 E.01192
G1 X118.726 Y152.065 E1.89367
G1 X119.259 Y152.065 E.0164
G1 X75.365 Y108.17 E1.90804
G1 X75.567 Y107.839 E.01192
G1 X119.793 Y152.065 E1.92242
G1 X120.326 Y152.065 E.0164
G1 X75.791 Y107.53 E1.93586
G1 X76.037 Y107.242 E.01163
G1 X120.86 Y152.065 E1.94837
G1 X121.393 Y152.065 E.0164
G1 X76.283 Y106.955 E1.96088
G1 X76.529 Y106.667 E.01163
G1 X121.926 Y152.065 E1.97338
G1 X122.46 Y152.065 E.0164
G1 X76.806 Y106.41 E1.98454
G1 X77.093 Y106.165 E.01163
G1 X122.993 Y152.065 E1.99522
G1 X123.527 Y152.065 E.0164
G1 X77.381 Y105.919 E2.0059
G1 X77.669 Y105.673 E.01163
G1 X124.06 Y152.065 E2.01658
G1 X124.594 Y152.065 E.0164
G1 X77.999 Y105.47 E2.02543
G1 X78.329 Y105.267 E.01192
G1 X125.127 Y152.065 E2.03424
G1 X125.661 Y152.065 E.0164
G1 X78.66 Y105.064 E2.04305
G3 X79.006 Y104.876 I.766 J.997 E.01214
G1 X126.194 Y152.065 E2.05122
G1 X126.727 Y152.065 E.0164
G1 X79.383 Y104.72 E2.05801
G1 X79.76 Y104.564 E.01255
G1 X127.261 Y152.065 E2.0648
G1 X127.794 Y152.065 E.0164
G1 X80.137 Y104.408 E2.07159
G1 X80.559 Y104.296 E.0134
G1 X128.328 Y152.065 E2.07646
G1 X128.861 Y152.065 E.0164
G1 X80.989 Y104.192 E2.08095
G1 X81.419 Y104.089 E.0136
G1 X129.395 Y152.065 E2.08544
G1 X129.928 Y152.065 E.0164
G1 X81.889 Y104.026 E2.08819
G1 X82.384 Y103.987 E.01525
G1 X130.462 Y152.065 E2.08989
G1 X130.995 Y152.065 E.0164
G1 X82.878 Y103.948 E2.09158
G3 X83.399 Y103.935 I.34 J3.305 E.01603
G1 X131.528 Y152.065 E2.09212
G1 X132.062 Y152.065 E.0164
G1 X83.932 Y103.935 E2.09212
G1 X84.466 Y103.935 E.0164
G1 X132.595 Y152.065 E2.09212
G1 X133.129 Y152.065 E.0164
G1 X84.999 Y103.935 E2.09212
G1 X85.533 Y103.935 E.0164
G1 X133.662 Y152.065 E2.09212
G1 X134.196 Y152.065 E.0164
G1 X86.066 Y103.935 E2.09212
G1 X86.6 Y103.935 E.0164
G1 X134.729 Y152.065 E2.09212
G1 X135.263 Y152.065 E.0164
G1 X87.133 Y103.935 E2.09212
G1 X87.667 Y103.935 E.0164
G1 X135.796 Y152.065 E2.09212
G1 X136.329 Y152.065 E.0164
G1 X88.2 Y103.935 E2.09212
G1 X88.733 Y103.935 E.0164
G1 X136.863 Y152.065 E2.09212
G1 X137.396 Y152.065 E.0164
G1 X89.267 Y103.935 E2.09212
G1 X89.8 Y103.935 E.0164
G1 X137.93 Y152.065 E2.09212
M73 P60 R10
G1 X138.463 Y152.065 E.0164
G1 X90.334 Y103.935 E2.09212
G1 X90.867 Y103.935 E.0164
G1 X138.997 Y152.065 E2.09212
G1 X139.53 Y152.065 E.0164
G1 X91.401 Y103.935 E2.09212
G1 X91.934 Y103.935 E.0164
G1 X140.063 Y152.065 E2.09212
G1 X140.597 Y152.065 E.0164
G1 X92.468 Y103.935 E2.09212
G1 X93.001 Y103.935 E.0164
G1 X141.13 Y152.065 E2.09212
G1 X141.664 Y152.065 E.0164
G1 X93.534 Y103.935 E2.09212
M73 P61 R10
G1 X94.068 Y103.935 E.0164
G1 X142.197 Y152.065 E2.09212
G1 X142.731 Y152.065 E.0164
G1 X94.601 Y103.935 E2.09212
G1 X95.135 Y103.935 E.0164
G1 X143.264 Y152.065 E2.09212
G1 X143.798 Y152.065 E.0164
G1 X95.668 Y103.935 E2.09212
G1 X96.202 Y103.935 E.0164
G1 X144.331 Y152.065 E2.09212
G1 X144.864 Y152.065 E.0164
G1 X96.735 Y103.935 E2.09212
G1 X97.269 Y103.935 E.0164
G1 X145.398 Y152.065 E2.09212
G1 X145.931 Y152.065 E.0164
G1 X97.802 Y103.935 E2.09212
G1 X98.335 Y103.935 E.0164
G1 X146.465 Y152.065 E2.09212
G1 X146.998 Y152.065 E.0164
G1 X98.869 Y103.935 E2.09212
G1 X99.402 Y103.935 E.0164
G1 X147.532 Y152.065 E2.09212
G1 X148.065 Y152.065 E.0164
G1 X99.936 Y103.935 E2.09212
G1 X100.469 Y103.935 E.0164
G1 X148.599 Y152.065 E2.09212
G1 X149.132 Y152.065 E.0164
G1 X101.003 Y103.935 E2.09212
G1 X101.536 Y103.935 E.0164
G1 X149.665 Y152.065 E2.09212
G1 X150.199 Y152.065 E.0164
G1 X102.069 Y103.935 E2.09212
G1 X102.603 Y103.935 E.0164
G1 X150.732 Y152.065 E2.09212
G1 X151.266 Y152.065 E.0164
G1 X103.136 Y103.935 E2.09212
G1 X103.67 Y103.935 E.0164
G1 X151.799 Y152.065 E2.09212
G1 X152.333 Y152.065 E.0164
G1 X104.203 Y103.935 E2.09212
G1 X104.737 Y103.935 E.0164
G1 X152.866 Y152.065 E2.09212
G1 X153.4 Y152.065 E.0164
G1 X105.27 Y103.935 E2.09212
G1 X105.804 Y103.935 E.0164
G1 X153.933 Y152.065 E2.09212
G1 X154.466 Y152.065 E.0164
G1 X106.337 Y103.935 E2.09212
G1 X106.87 Y103.935 E.0164
G1 X155 Y152.065 E2.09212
G1 X155.533 Y152.065 E.0164
G1 X107.404 Y103.935 E2.09212
G1 X107.937 Y103.935 E.0164
G1 X156.067 Y152.065 E2.09212
G1 X156.6 Y152.065 E.0164
G1 X108.471 Y103.935 E2.09212
G1 X109.004 Y103.935 E.0164
G1 X157.134 Y152.065 E2.09212
G1 X157.667 Y152.065 E.0164
G1 X109.538 Y103.935 E2.09212
G1 X110.071 Y103.935 E.0164
G1 X158.2 Y152.065 E2.09212
G1 X158.734 Y152.065 E.0164
G1 X110.605 Y103.935 E2.09212
G1 X111.138 Y103.935 E.0164
G1 X159.267 Y152.065 E2.09212
G1 X159.801 Y152.065 E.0164
G1 X111.671 Y103.935 E2.09212
G1 X112.205 Y103.935 E.0164
G1 X160.334 Y152.065 E2.09212
G1 X160.868 Y152.065 E.0164
G1 X112.738 Y103.935 E2.09212
G1 X113.272 Y103.935 E.0164
G1 X161.401 Y152.065 E2.09212
G1 X161.935 Y152.065 E.0164
G1 X113.805 Y103.935 E2.09212
G1 X114.339 Y103.935 E.0164
G1 X162.468 Y152.065 E2.09212
G1 X163.001 Y152.065 E.0164
G1 X114.872 Y103.935 E2.09212
G1 X115.406 Y103.935 E.0164
G1 X163.535 Y152.065 E2.09212
G1 X164.068 Y152.065 E.0164
G1 X115.939 Y103.935 E2.09212
G1 X116.472 Y103.935 E.0164
G1 X164.602 Y152.065 E2.09212
G1 X165.135 Y152.065 E.0164
G1 X117.006 Y103.935 E2.09212
G1 X117.539 Y103.935 E.0164
G1 X165.669 Y152.065 E2.09212
M73 P62 R10
G1 X166.202 Y152.065 E.0164
G1 X118.073 Y103.935 E2.09212
G1 X118.606 Y103.935 E.0164
G1 X166.736 Y152.065 E2.09212
G1 X167.269 Y152.065 E.0164
G1 X119.14 Y103.935 E2.09212
G1 X119.673 Y103.935 E.0164
G1 X167.802 Y152.065 E2.09212
G1 X168.336 Y152.065 E.0164
G1 X120.207 Y103.935 E2.09212
G1 X120.74 Y103.935 E.0164
G1 X168.869 Y152.065 E2.09212
G1 X169.403 Y152.065 E.0164
G1 X121.273 Y103.935 E2.09212
G1 X121.807 Y103.935 E.0164
G1 X169.936 Y152.065 E2.09212
G1 X170.47 Y152.065 E.0164
G1 X122.34 Y103.935 E2.09212
G1 X122.874 Y103.935 E.0164
G1 X171.003 Y152.065 E2.09212
G1 X171.537 Y152.065 E.0164
G1 X123.407 Y103.935 E2.09212
G1 X123.941 Y103.935 E.0164
G1 X172.07 Y152.065 E2.09212
G1 X172.603 Y152.065 E.0164
G1 X124.474 Y103.935 E2.09212
G1 X125.007 Y103.935 E.0164
G1 X173.124 Y152.052 E2.09157
G1 X173.619 Y152.013 E.01525
G1 X125.541 Y103.935 E2.08988
G1 X126.074 Y103.935 E.0164
G1 X174.113 Y151.974 E2.08819
G2 X174.583 Y151.91 I.034 J-1.515 E.01463
G1 X126.608 Y103.935 E2.08542
G1 X127.141 Y103.935 E.0164
G1 X175.013 Y151.807 E2.08093
G1 X175.443 Y151.704 E.0136
G1 X127.675 Y103.935 E2.07644
G1 X128.208 Y103.935 E.0164
G1 X175.864 Y151.592 E2.07156
G1 X176.242 Y151.435 E.01255
G1 X128.742 Y103.935 E2.06477
G1 X129.275 Y103.935 E.0164
G1 X176.619 Y151.279 E2.05798
G1 X176.996 Y151.123 E.01255
G1 X129.808 Y103.935 E2.05119
G1 X130.342 Y103.935 E.0164
G1 X177.341 Y150.935 E2.04301
G1 X177.672 Y150.732 E.01192
G1 X130.875 Y103.935 E2.0342
G1 X131.409 Y103.935 E.0164
G1 X178.003 Y150.529 E2.02538
G1 X178.333 Y150.326 E.01191
G1 X131.942 Y103.935 E2.01653
G1 X132.476 Y103.935 E.0164
G1 X178.62 Y150.08 E2.00585
G1 X178.908 Y149.834 E.01163
G1 X133.009 Y103.935 E1.99517
G1 X133.543 Y103.935 E.0164
G1 X179.196 Y149.589 E1.98449
G2 X179.472 Y149.332 I-.672 J-1.002 E.01165
G1 X134.076 Y103.935 E1.97333
G1 X134.609 Y103.935 E.0164
G1 X179.718 Y149.044 E1.96082
G1 X179.964 Y148.756 E.01163
G1 X135.143 Y103.935 E1.94831
G1 X135.676 Y103.935 E.0164
G1 X180.21 Y148.469 E1.93581
G2 X180.434 Y148.159 I-.865 J-.862 E.01179
G1 X136.21 Y103.935 E1.92235
G1 X136.743 Y103.935 E.0164
G1 X180.636 Y147.828 E1.90798
G1 X180.839 Y147.498 E.01192
G1 X137.277 Y103.935 E1.8936
G1 X137.81 Y103.935 E.0164
G1 X181.042 Y147.167 E1.87922
G2 X181.205 Y146.797 I-1.084 J-.701 E.01248
G1 X138.344 Y103.935 E1.86315
G1 X138.877 Y103.935 E.0164
G1 X181.362 Y146.42 E1.84675
G1 X181.518 Y146.043 E.01255
G1 X139.41 Y103.935 E1.83036
G1 X139.944 Y103.935 E.0164
G1 X181.655 Y145.647 E1.81314
G1 X181.758 Y145.216 E.0136
G1 X140.477 Y103.935 E1.79444
G1 X141.011 Y103.935 E.0164
G1 X181.862 Y144.786 E1.77574
G1 X181.956 Y144.347 E.01381
G1 X141.544 Y103.935 E1.75664
G1 X142.078 Y103.935 E.0164
G1 X181.995 Y143.852 E1.73514
M73 P63 R10
G1 X182.034 Y143.358 E.01525
G1 X142.611 Y103.935 E1.71365
G1 X143.144 Y103.935 E.0164
G1 X182.065 Y142.856 E1.69181
G1 X182.065 Y142.322 E.0164
G1 X143.678 Y103.935 E1.66862
G1 X144.211 Y103.935 E.0164
G1 X182.065 Y141.789 E1.64543
G1 X182.065 Y141.255 E.0164
G1 X144.745 Y103.935 E1.62225
G1 X145.278 Y103.935 E.0164
G1 X182.065 Y140.722 E1.59906
G1 X182.065 Y140.188 E.0164
G1 X145.812 Y103.935 E1.57587
G1 X146.345 Y103.935 E.0164
G1 X182.065 Y139.655 E1.55268
G1 X182.065 Y139.121 E.0164
G1 X146.879 Y103.935 E1.52949
G1 X147.412 Y103.935 E.0164
G1 X182.065 Y138.588 E1.50631
G1 X182.065 Y138.055 E.0164
G1 X147.945 Y103.935 E1.48312
G1 X148.479 Y103.935 E.0164
G1 X182.065 Y137.521 E1.45993
G1 X182.065 Y136.988 E.0164
G1 X149.012 Y103.935 E1.43674
G1 X149.546 Y103.935 E.0164
G1 X182.065 Y136.454 E1.41355
G1 X182.065 Y135.921 E.0164
G1 X150.079 Y103.935 E1.39037
G1 X150.613 Y103.935 E.0164
G1 X182.065 Y135.387 E1.36718
G1 X182.065 Y134.854 E.0164
G1 X151.146 Y103.935 E1.34399
G1 X151.68 Y103.935 E.0164
G1 X182.065 Y134.32 E1.3208
G1 X182.065 Y133.787 E.0164
G1 X152.213 Y103.935 E1.29761
G1 X152.746 Y103.935 E.0164
G1 X182.065 Y133.254 E1.27443
G1 X182.065 Y132.72 E.0164
G1 X153.28 Y103.935 E1.25124
G1 X153.813 Y103.935 E.0164
G1 X182.065 Y132.187 E1.22805
G1 X182.065 Y131.653 E.0164
G1 X154.347 Y103.935 E1.20486
G1 X154.88 Y103.935 E.0164
G1 X182.065 Y131.12 E1.18167
G1 X182.065 Y130.586 E.0164
G1 X155.414 Y103.935 E1.15849
G1 X155.947 Y103.935 E.0164
G1 X182.065 Y130.053 E1.1353
G1 X182.065 Y129.519 E.0164
G1 X156.481 Y103.935 E1.11211
G1 X157.014 Y103.935 E.0164
G1 X182.065 Y128.986 E1.08892
G1 X182.065 Y128.453 E.0164
G1 X157.547 Y103.935 E1.06573
G1 X158.081 Y103.935 E.0164
G1 X182.065 Y127.919 E1.04255
G1 X182.065 Y127.386 E.0164
G1 X158.614 Y103.935 E1.01936
G1 X159.148 Y103.935 E.0164
G1 X182.065 Y126.852 E.99617
G1 X182.065 Y126.319 E.0164
G1 X159.681 Y103.935 E.97298
G1 X160.215 Y103.935 E.0164
G1 X182.065 Y125.785 E.94979
G1 X182.065 Y125.252 E.0164
G1 X160.748 Y103.935 E.92661
G1 X161.281 Y103.935 E.0164
G1 X182.065 Y124.719 E.90342
G1 X182.065 Y124.185 E.0164
G1 X161.815 Y103.935 E.88023
G1 X162.348 Y103.935 E.0164
G1 X182.065 Y123.652 E.85704
G1 X182.065 Y123.118 E.0164
G1 X162.882 Y103.935 E.83385
G1 X163.415 Y103.935 E.0164
G1 X182.065 Y122.585 E.81067
G1 X182.065 Y122.051 E.0164
G1 X163.949 Y103.935 E.78748
G1 X164.482 Y103.935 E.0164
G1 X182.065 Y121.518 E.76429
G1 X182.065 Y120.984 E.0164
G1 X165.016 Y103.935 E.7411
G1 X165.549 Y103.935 E.0164
G1 X182.065 Y120.451 E.71791
G1 X182.065 Y119.918 E.0164
G1 X166.082 Y103.935 E.69473
G1 X166.616 Y103.935 E.0164
G1 X182.065 Y119.384 E.67154
G1 X182.065 Y118.851 E.0164
G1 X167.149 Y103.935 E.64835
G1 X167.683 Y103.935 E.0164
G1 X182.065 Y118.317 E.62516
G1 X182.065 Y117.784 E.0164
G1 X168.216 Y103.935 E.60197
G1 X168.75 Y103.935 E.0164
G1 X182.065 Y117.25 E.57879
G1 X182.065 Y116.717 E.0164
G1 X169.283 Y103.935 E.5556
G1 X169.817 Y103.935 E.0164
G1 X182.065 Y116.183 E.53241
G1 X182.065 Y115.65 E.0164
G1 X170.35 Y103.935 E.50922
G1 X170.883 Y103.935 E.0164
G1 X182.065 Y115.117 E.48603
G1 X182.065 Y114.583 E.0164
G1 X171.417 Y103.935 E.46285
G1 X171.95 Y103.935 E.0164
G1 X182.065 Y114.05 E.43966
G1 X182.065 Y113.516 E.0164
G1 X172.484 Y103.935 E.41647
G3 X173.022 Y103.94 I.24 J3.421 E.01656
G1 X182.06 Y112.978 E.39288
G1 X182.014 Y112.399 E.01785
G1 X173.601 Y103.986 E.36573
G1 X174.18 Y104.031 E.01785
G1 X181.969 Y111.82 E.33858
G2 X181.851 Y111.169 I-2.115 J.047 E.02044
G1 X174.831 Y104.149 E.30513
G1 X175.533 Y104.318 E.02219
G1 X181.682 Y110.467 E.26729
G1 X181.618 Y110.2 E.00844
G1 X181.385 Y109.635 E.01877
G1 X176.365 Y104.615 E.21821
G1 X177.114 Y104.926 E.02493
G1 X177.358 Y105.075 E.0088
G1 X181.321 Y109.038 E.17226
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
M73 P64 R10
G1 F12725.344
G1 X179.907 Y107.624 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 8/25
; update layer progress
M73 L8
M991 S0 P7 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z1.8 I-.228 J-1.196 P1  F42000
G1 X84.102 Y125.858 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X84.102 Y130.368 E.14961
G1 X80 Y132.737 E.15712
G1 X75.898 Y130.368 E.15712
G1 X75.898 Y125.632 E.15712
G1 X80 Y123.263 E.15712
G1 X84.102 Y125.632 E.15712
G1 X84.102 Y125.798 E.00552
M204 S250
G1 X83.71 Y125.858 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X80 Y123.716 E.13163
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.097 Y134.566 Z2 F42000
G1 X74.064 Y145.904 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X73.72 Y144.47 E.04891
G1 X73.602 Y142.976 E.0497
G1 X73.602 Y113.024 E.99358
G1 X73.72 Y111.53 E.0497
G1 X74.064 Y110.096 E.04891
G1 X74.196 Y109.778 E.01144
G1 X74.628 Y108.734 E.03747
G1 X75.398 Y107.477 E.04891
G1 X76.356 Y106.356 E.04891
G1 X77.477 Y105.398 E.04891
G1 X78.734 Y104.628 E.04891
G1 X80.096 Y104.064 E.04891
G1 X81.53 Y103.72 E.04891
G1 X83.024 Y103.602 E.0497
G1 X172.976 Y103.602 E2.98389
G1 X173.344 Y103.631 E.01223
G1 X174.47 Y103.72 E.03747
G1 X175.904 Y104.064 E.04891
G1 X177.266 Y104.628 E.04891
G1 X178.523 Y105.398 E.04891
G1 X179.644 Y106.356 E.04891
G1 X180.602 Y107.477 E.04891
G1 X181.372 Y108.734 E.04891
G1 X181.936 Y110.096 E.04891
G1 X182.28 Y111.53 E.04891
G1 X182.398 Y113.024 E.0497
G1 X182.398 Y142.976 E.99358
G1 X182.28 Y144.47 E.0497
G1 X181.936 Y145.904 E.04891
G1 X181.372 Y147.266 E.04891
G1 X180.602 Y148.523 E.04891
G1 X179.644 Y149.644 E.04891
G1 X178.523 Y150.602 E.04891
G1 X177.266 Y151.372 E.04891
G1 X175.904 Y151.936 E.04891
G1 X174.47 Y152.28 E.04891
G1 X172.976 Y152.398 E.0497
G1 X83.024 Y152.398 E2.98389
G1 X81.53 Y152.28 E.0497
G1 X80.096 Y151.936 E.04891
G1 X78.734 Y151.372 E.04891
G1 X77.477 Y150.602 E.04891
G1 X76.356 Y149.644 E.04891
G1 X75.398 Y148.523 E.04891
G1 X74.628 Y147.266 E.04891
G1 X74.087 Y145.959 E.04692
M204 S250
G1 X73.69 Y146.025 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.331 Y144.531 E.0472
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X73.834 Y109.628 E.01155
G1 X74.278 Y108.556 E.03565
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X172.992 Y103.21 E2.76494
G1 X173.375 Y103.24 E.0118
G1 X174.531 Y103.331 E.03566
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.713 Y146.081 E.04536
; WIPE_START
M204 S6000
G1 X73.331 Y144.531 E-.60625
G1 X73.299 Y144.128 E-.15375
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2 F4000
            G39.3 S1
            G0 Z2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X73.766 Y140.894 F42000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42012
G1 F12725.344
M204 S6000
G1 X83.639 Y131.02 E.42919
G1 X82.377 Y131.749 E.0448
G1 X73.935 Y140.191 E.36695
G1 X73.935 Y139.657 E.0164
G1 X81.115 Y132.478 E.31208
G1 X80 Y133.121 E.03957
G1 X79.961 Y133.099 E.0014
G1 X73.935 Y139.124 E.26191
G1 X73.935 Y138.59 E.0164
G1 X79.622 Y132.903 E.24721
G1 X79.284 Y132.708 E.012
G1 X73.935 Y138.057 E.23251
M73 P64 R9
G1 X73.935 Y137.524 E.0164
G1 X78.946 Y132.513 E.21781
G1 X78.608 Y132.318 E.012
G1 X73.935 Y136.99 E.20311
G1 X73.935 Y136.457 E.0164
G1 X78.27 Y132.122 E.1884
G1 X77.931 Y131.927 E.012
G1 X73.935 Y135.923 E.1737
G1 X73.935 Y135.39 E.0164
G1 X77.593 Y131.732 E.159
G1 X77.255 Y131.537 E.012
G1 X73.935 Y134.856 E.1443
G1 X73.935 Y134.323 E.0164
G1 X76.917 Y131.341 E.1296
G1 X76.579 Y131.146 E.012
G1 X73.935 Y133.789 E.1149
G1 X73.935 Y133.256 E.0164
G1 X76.24 Y130.951 E.1002
G1 X75.902 Y130.756 E.012
G1 X73.935 Y132.723 E.0855
G1 X73.935 Y132.189 E.0164
G1 X75.565 Y130.56 E.07083
G1 X75.565 Y130.026 E.0164
G1 X73.935 Y131.656 E.07083
G1 X73.935 Y131.122 E.0164
G1 X75.565 Y129.493 E.07083
G1 X75.565 Y128.959 E.0164
G1 X73.935 Y130.589 E.07083
G1 X73.935 Y130.055 E.0164
G1 X75.565 Y128.426 E.07083
G1 X75.565 Y127.893 E.0164
G1 X73.935 Y129.522 E.07083
G1 X73.935 Y128.988 E.0164
G1 X75.565 Y127.359 E.07083
G1 X75.565 Y126.826 E.0164
G1 X73.935 Y128.455 E.07083
G1 X73.935 Y127.922 E.0164
G1 X75.565 Y126.292 E.07083
G1 X75.565 Y125.759 E.0164
G1 X73.935 Y127.388 E.07083
G1 X73.935 Y126.855 E.0164
G1 X96.855 Y103.935 E.99628
G1 X97.388 Y103.935 E.0164
G1 X76.321 Y125.003 E.91577
G1 X77.583 Y124.274 E.0448
G1 X97.922 Y103.935 E.8841
G1 X98.455 Y103.935 E.0164
G1 X78.845 Y123.545 E.85242
G1 X80 Y122.879 E.04099
G1 X80.029 Y122.895 E.00102
G1 X98.988 Y103.935 E.82416
G1 X99.522 Y103.935 E.0164
G1 X80.367 Y123.09 E.83265
G1 X80.705 Y123.286 E.012
G1 X100.055 Y103.935 E.84113
G1 X100.589 Y103.935 E.0164
G1 X81.043 Y123.481 E.84962
G1 X81.381 Y123.676 E.012
G1 X101.122 Y103.935 E.85811
G1 X101.656 Y103.935 E.0164
G1 X81.72 Y123.871 E.86659
G1 X82.058 Y124.067 E.012
G1 X102.189 Y103.935 E.87508
G1 X102.723 Y103.935 E.0164
G1 X82.396 Y124.262 E.88357
G1 X82.734 Y124.457 E.012
G1 X103.256 Y103.935 E.89206
G1 X103.789 Y103.935 E.0164
G1 X83.072 Y124.652 E.90054
G1 X83.411 Y124.848 E.012
G1 X104.323 Y103.935 E.90903
G1 X104.856 Y103.935 E.0164
G1 X83.749 Y125.043 E.91752
G1 X84.087 Y125.238 E.012
G1 X105.39 Y103.935 E.92601
G1 X105.923 Y103.935 E.0164
G1 X84.425 Y125.433 E.93449
G1 X84.435 Y125.957 E.01609
G1 X106.457 Y103.935 E.95724
G1 X106.99 Y103.935 E.0164
G1 X84.435 Y126.49 E.98043
G1 X84.435 Y127.024 E.0164
G1 X107.524 Y103.935 E1.00362
G1 X108.057 Y103.935 E.0164
G1 X84.435 Y127.557 E1.0268
G1 X84.435 Y128.09 E.0164
G1 X108.59 Y103.935 E1.04999
G1 X109.124 Y103.935 E.0164
G1 X84.435 Y128.624 E1.07318
G1 X84.435 Y129.157 E.0164
G1 X109.657 Y103.935 E1.09637
G1 X110.191 Y103.935 E.0164
G1 X84.435 Y129.691 E1.11956
G1 X84.435 Y130.224 E.0164
G1 X110.724 Y103.935 E1.14274
G1 X111.258 Y103.935 E.0164
G1 X73.935 Y141.258 E1.62235
G1 X73.935 Y141.791 E.0164
G1 X111.791 Y103.935 E1.64554
G1 X112.325 Y103.935 E.0164
G1 X73.935 Y142.325 E1.66873
G1 X73.935 Y142.858 E.0164
G1 X112.858 Y103.935 E1.69192
G1 X113.391 Y103.935 E.0164
G1 X73.967 Y143.36 E1.71375
G1 X74.005 Y143.855 E.01525
G1 X113.925 Y103.935 E1.73524
G1 X114.458 Y103.935 E.0164
G1 X74.044 Y144.349 E1.75674
G1 X74.139 Y144.788 E.0138
G1 X114.992 Y103.935 E1.77582
G1 X115.525 Y103.935 E.0164
G1 X74.242 Y145.218 E1.79452
G1 X74.345 Y145.649 E.0136
G1 X116.059 Y103.935 E1.81322
G1 X116.592 Y103.935 E.0164
G1 X74.483 Y146.044 E1.83043
G1 X74.639 Y146.422 E.01255
G1 X117.125 Y103.935 E1.84683
G1 X117.659 Y103.935 E.0164
G1 X74.795 Y146.799 E1.86322
G2 X74.959 Y147.168 I1.248 J-.333 E.01248
G1 X118.192 Y103.935 E1.87929
G1 X118.726 Y103.935 E.0164
G1 X75.162 Y147.499 E1.89367
G1 X75.365 Y147.83 E.01192
G1 X119.259 Y103.935 E1.90804
G1 X119.793 Y103.935 E.0164
G1 X75.567 Y148.161 E1.92242
G2 X75.791 Y148.47 I1.088 J-.553 E.01179
G1 X120.326 Y103.935 E1.93586
G1 X120.86 Y103.935 E.0164
G1 X76.037 Y148.758 E1.94837
G1 X76.283 Y149.045 E.01163
G1 X121.393 Y103.935 E1.96088
G1 X121.926 Y103.935 E.0164
G1 X76.529 Y149.333 E1.97338
M73 P65 R9
G2 X76.806 Y149.59 I.948 J-.745 E.01165
G1 X122.46 Y103.935 E1.98454
G1 X122.993 Y103.935 E.0164
G1 X77.093 Y149.835 E1.99522
G1 X77.381 Y150.081 E.01163
G1 X123.527 Y103.935 E2.0059
G1 X124.06 Y103.935 E.0164
G1 X77.669 Y150.327 E2.01658
G1 X77.999 Y150.53 E.01192
G1 X124.594 Y103.935 E2.02542
G1 X125.127 Y103.935 E.0164
G1 X78.329 Y150.733 E2.03424
G1 X78.66 Y150.936 E.01192
G1 X125.661 Y103.935 E2.04305
G1 X126.194 Y103.935 E.0164
G1 X79.006 Y151.124 E2.05122
G1 X79.383 Y151.28 E.01255
G1 X126.727 Y103.935 E2.05801
G1 X127.261 Y103.935 E.0164
G1 X79.76 Y151.436 E2.0648
G1 X80.137 Y151.592 E.01255
G1 X127.794 Y103.935 E2.07159
G1 X128.328 Y103.935 E.0164
G1 X80.559 Y151.704 E2.07646
G1 X80.989 Y151.808 E.0136
G1 X128.861 Y103.935 E2.08095
G1 X129.395 Y103.935 E.0164
G1 X81.419 Y151.911 E2.08544
G2 X81.889 Y151.974 I.435 J-1.452 E.01464
G1 X129.928 Y103.935 E2.0882
G1 X130.462 Y103.935 E.0164
G1 X82.384 Y152.013 E2.08989
G1 X82.878 Y152.052 E.01525
G1 X130.995 Y103.935 E2.09158
G1 X131.528 Y103.935 E.0164
G1 X83.399 Y152.065 E2.09212
G1 X83.932 Y152.065 E.0164
G1 X132.062 Y103.935 E2.09212
G1 X132.595 Y103.935 E.0164
G1 X84.466 Y152.065 E2.09212
G1 X84.999 Y152.065 E.0164
G1 X133.129 Y103.935 E2.09212
G1 X133.662 Y103.935 E.0164
G1 X85.533 Y152.065 E2.09212
G1 X86.066 Y152.065 E.0164
G1 X134.196 Y103.935 E2.09212
G1 X134.729 Y103.935 E.0164
G1 X86.6 Y152.065 E2.09212
G1 X87.133 Y152.065 E.0164
G1 X135.263 Y103.935 E2.09212
G1 X135.796 Y103.935 E.0164
G1 X87.667 Y152.065 E2.09212
G1 X88.2 Y152.065 E.0164
G1 X136.329 Y103.935 E2.09212
G1 X136.863 Y103.935 E.0164
G1 X88.733 Y152.065 E2.09212
G1 X89.267 Y152.065 E.0164
G1 X137.396 Y103.935 E2.09212
G1 X137.93 Y103.935 E.0164
G1 X89.8 Y152.065 E2.09212
G1 X90.334 Y152.065 E.0164
G1 X138.463 Y103.935 E2.09212
G1 X138.997 Y103.935 E.0164
G1 X90.867 Y152.065 E2.09212
G1 X91.401 Y152.065 E.0164
G1 X139.53 Y103.935 E2.09212
G1 X140.063 Y103.935 E.0164
G1 X91.934 Y152.065 E2.09212
G1 X92.468 Y152.065 E.0164
G1 X140.597 Y103.935 E2.09212
G1 X141.13 Y103.935 E.0164
G1 X93.001 Y152.065 E2.09212
G1 X93.534 Y152.065 E.0164
G1 X141.664 Y103.935 E2.09212
G1 X142.197 Y103.935 E.0164
G1 X94.068 Y152.065 E2.09212
G1 X94.601 Y152.065 E.0164
G1 X142.731 Y103.935 E2.09212
G1 X143.264 Y103.935 E.0164
G1 X95.135 Y152.065 E2.09212
G1 X95.668 Y152.065 E.0164
G1 X143.798 Y103.935 E2.09212
G1 X144.331 Y103.935 E.0164
G1 X96.202 Y152.065 E2.09212
G1 X96.735 Y152.065 E.0164
G1 X144.864 Y103.935 E2.09212
G1 X145.398 Y103.935 E.0164
G1 X97.269 Y152.065 E2.09212
G1 X97.802 Y152.065 E.0164
G1 X145.931 Y103.935 E2.09212
G1 X146.465 Y103.935 E.0164
G1 X98.335 Y152.065 E2.09212
G1 X98.869 Y152.065 E.0164
G1 X146.998 Y103.935 E2.09212
G1 X147.532 Y103.935 E.0164
G1 X99.402 Y152.065 E2.09212
M73 P66 R9
G1 X99.936 Y152.065 E.0164
G1 X148.065 Y103.935 E2.09212
G1 X148.599 Y103.935 E.0164
G1 X100.469 Y152.065 E2.09212
G1 X101.003 Y152.065 E.0164
G1 X149.132 Y103.935 E2.09212
G1 X149.665 Y103.935 E.0164
G1 X101.536 Y152.065 E2.09212
G1 X102.069 Y152.065 E.0164
G1 X150.199 Y103.935 E2.09212
G1 X150.732 Y103.935 E.0164
G1 X102.603 Y152.065 E2.09212
G1 X103.136 Y152.065 E.0164
G1 X151.266 Y103.935 E2.09212
G1 X151.799 Y103.935 E.0164
G1 X103.67 Y152.065 E2.09212
G1 X104.203 Y152.065 E.0164
G1 X152.333 Y103.935 E2.09212
G1 X152.866 Y103.935 E.0164
G1 X104.737 Y152.065 E2.09212
G1 X105.27 Y152.065 E.0164
G1 X153.4 Y103.935 E2.09212
G1 X153.933 Y103.935 E.0164
G1 X105.804 Y152.065 E2.09212
G1 X106.337 Y152.065 E.0164
G1 X154.466 Y103.935 E2.09212
G1 X155 Y103.935 E.0164
G1 X106.87 Y152.065 E2.09212
G1 X107.404 Y152.065 E.0164
G1 X155.533 Y103.935 E2.09212
G1 X156.067 Y103.935 E.0164
G1 X107.937 Y152.065 E2.09212
G1 X108.471 Y152.065 E.0164
G1 X156.6 Y103.935 E2.09212
G1 X157.134 Y103.935 E.0164
G1 X109.004 Y152.065 E2.09212
G1 X109.538 Y152.065 E.0164
G1 X157.667 Y103.935 E2.09212
G1 X158.2 Y103.935 E.0164
G1 X110.071 Y152.065 E2.09212
G1 X110.605 Y152.065 E.0164
G1 X158.734 Y103.935 E2.09212
G1 X159.267 Y103.935 E.0164
G1 X111.138 Y152.065 E2.09212
G1 X111.671 Y152.065 E.0164
G1 X159.801 Y103.935 E2.09212
G1 X160.334 Y103.935 E.0164
G1 X112.205 Y152.065 E2.09212
G1 X112.738 Y152.065 E.0164
G1 X160.868 Y103.935 E2.09212
G1 X161.401 Y103.935 E.0164
G1 X113.272 Y152.065 E2.09212
G1 X113.805 Y152.065 E.0164
G1 X161.935 Y103.935 E2.09212
G1 X162.468 Y103.935 E.0164
G1 X114.339 Y152.065 E2.09212
G1 X114.872 Y152.065 E.0164
G1 X163.001 Y103.935 E2.09212
G1 X163.535 Y103.935 E.0164
G1 X115.406 Y152.065 E2.09212
G1 X115.939 Y152.065 E.0164
G1 X164.068 Y103.935 E2.09212
G1 X164.602 Y103.935 E.0164
G1 X116.472 Y152.065 E2.09212
G1 X117.006 Y152.065 E.0164
G1 X165.135 Y103.935 E2.09212
G1 X165.669 Y103.935 E.0164
G1 X117.539 Y152.065 E2.09212
G1 X118.073 Y152.065 E.0164
G1 X166.202 Y103.935 E2.09212
G1 X166.736 Y103.935 E.0164
G1 X118.606 Y152.065 E2.09212
G1 X119.14 Y152.065 E.0164
G1 X167.269 Y103.935 E2.09212
G1 X167.802 Y103.935 E.0164
G1 X119.673 Y152.065 E2.09212
G1 X120.207 Y152.065 E.0164
G1 X168.336 Y103.935 E2.09212
G1 X168.869 Y103.935 E.0164
G1 X120.74 Y152.065 E2.09212
G1 X121.273 Y152.065 E.0164
G1 X169.403 Y103.935 E2.09212
G1 X169.936 Y103.935 E.0164
G1 X121.807 Y152.065 E2.09212
G1 X122.34 Y152.065 E.0164
G1 X170.47 Y103.935 E2.09212
G1 X171.003 Y103.935 E.0164
G1 X122.874 Y152.065 E2.09212
G1 X123.407 Y152.065 E.0164
G1 X171.537 Y103.935 E2.09212
G1 X172.07 Y103.935 E.0164
G1 X123.941 Y152.065 E2.09212
M73 P67 R9
G1 X124.474 Y152.065 E.0164
G1 X172.603 Y103.935 E2.09212
G3 X173.124 Y103.948 I.18 J3.314 E.01603
G1 X125.007 Y152.065 E2.09157
G1 X125.541 Y152.065 E.0164
G1 X173.619 Y103.987 E2.08988
G1 X174.113 Y104.026 E.01525
G1 X126.074 Y152.065 E2.08819
G1 X126.608 Y152.065 E.0164
G1 X174.583 Y104.089 E2.08542
G1 X175.013 Y104.193 E.0136
G1 X127.141 Y152.065 E2.08093
G1 X127.675 Y152.065 E.0164
G1 X175.443 Y104.296 E2.07644
G1 X175.864 Y104.408 E.0134
G1 X128.208 Y152.065 E2.07156
G1 X128.742 Y152.065 E.0164
G1 X176.242 Y104.565 E2.06477
G1 X176.619 Y104.721 E.01255
G1 X129.275 Y152.065 E2.05798
G1 X129.808 Y152.065 E.0164
G1 X176.996 Y104.877 E2.05119
G3 X177.341 Y105.065 I-.421 J1.184 E.01214
G1 X130.342 Y152.065 E2.04301
G1 X130.875 Y152.065 E.0164
G1 X177.672 Y105.268 E2.0342
G1 X178.003 Y105.471 E.01192
G1 X131.409 Y152.065 E2.02538
G1 X131.942 Y152.065 E.0164
G1 X178.333 Y105.674 E2.01653
G1 X178.62 Y105.92 E.01163
G1 X132.476 Y152.065 E2.00585
G1 X133.009 Y152.065 E.0164
G1 X178.908 Y106.166 E1.99517
G1 X179.196 Y106.411 E.01163
G1 X133.543 Y152.065 E1.98449
G1 X134.076 Y152.065 E.0164
G1 X179.472 Y106.668 E1.97333
G1 X179.718 Y106.956 E.01163
G1 X134.609 Y152.065 E1.96082
G1 X135.143 Y152.065 E.0164
G1 X179.964 Y107.244 E1.94831
G1 X180.21 Y107.531 E.01163
G1 X135.676 Y152.065 E1.93581
G1 X136.21 Y152.065 E.0164
G1 X180.434 Y107.841 E1.92235
G1 X180.636 Y108.172 E.01192
G1 X136.743 Y152.065 E1.90798
G1 X137.277 Y152.065 E.0164
G1 X180.839 Y108.502 E1.8936
G1 X181.042 Y108.833 E.01192
G1 X137.81 Y152.065 E1.87922
G1 X138.344 Y152.065 E.0164
G1 X181.205 Y109.203 E1.86315
G1 X181.362 Y109.58 E.01255
G1 X138.877 Y152.065 E1.84675
G1 X139.41 Y152.065 E.0164
G1 X181.518 Y109.957 E1.83036
G3 X181.655 Y110.353 I-1.183 J.632 E.01294
G1 X139.944 Y152.065 E1.81314
G1 X140.477 Y152.065 E.0164
G1 X181.758 Y110.784 E1.79444
G1 X181.862 Y111.214 E.0136
G1 X141.011 Y152.065 E1.77574
G1 X141.544 Y152.065 E.0164
G1 X181.956 Y111.653 E1.75664
G1 X181.995 Y112.148 E.01525
G1 X142.078 Y152.065 E1.73514
G1 X142.611 Y152.065 E.0164
G1 X182.034 Y112.642 E1.71365
G3 X182.065 Y113.144 I-3.177 J.449 E.01549
G1 X143.144 Y152.065 E1.69181
G1 X143.678 Y152.065 E.0164
G1 X182.065 Y113.678 E1.66862
G1 X182.065 Y114.211 E.0164
G1 X144.211 Y152.065 E1.64543
G1 X144.745 Y152.065 E.0164
G1 X182.065 Y114.745 E1.62225
G1 X182.065 Y115.278 E.0164
G1 X145.278 Y152.065 E1.59906
G1 X145.812 Y152.065 E.0164
G1 X182.065 Y115.812 E1.57587
G1 X182.065 Y116.345 E.0164
G1 X146.345 Y152.065 E1.55268
G1 X146.879 Y152.065 E.0164
G1 X182.065 Y116.879 E1.52949
G1 X182.065 Y117.412 E.0164
G1 X147.412 Y152.065 E1.50631
G1 X147.945 Y152.065 E.0164
G1 X182.065 Y117.945 E1.48312
M73 P67 R8
G1 X182.065 Y118.479 E.0164
G1 X148.479 Y152.065 E1.45993
M73 P68 R8
G1 X149.012 Y152.065 E.0164
G1 X182.065 Y119.012 E1.43674
G1 X182.065 Y119.546 E.0164
G1 X149.546 Y152.065 E1.41355
G1 X150.079 Y152.065 E.0164
G1 X182.065 Y120.079 E1.39037
G1 X182.065 Y120.613 E.0164
G1 X150.613 Y152.065 E1.36718
G1 X151.146 Y152.065 E.0164
G1 X182.065 Y121.146 E1.34399
G1 X182.065 Y121.68 E.0164
G1 X151.68 Y152.065 E1.3208
G1 X152.213 Y152.065 E.0164
G1 X182.065 Y122.213 E1.29761
G1 X182.065 Y122.746 E.0164
G1 X152.746 Y152.065 E1.27443
G1 X153.28 Y152.065 E.0164
G1 X182.065 Y123.28 E1.25124
G1 X182.065 Y123.813 E.0164
G1 X153.813 Y152.065 E1.22805
G1 X154.347 Y152.065 E.0164
G1 X182.065 Y124.347 E1.20486
G1 X182.065 Y124.88 E.0164
G1 X154.88 Y152.065 E1.18167
G1 X155.414 Y152.065 E.0164
G1 X182.065 Y125.414 E1.15849
G1 X182.065 Y125.947 E.0164
G1 X155.947 Y152.065 E1.1353
G1 X156.481 Y152.065 E.0164
G1 X182.065 Y126.481 E1.11211
G1 X182.065 Y127.014 E.0164
G1 X157.014 Y152.065 E1.08892
G1 X157.547 Y152.065 E.0164
G1 X182.065 Y127.547 E1.06573
G1 X182.065 Y128.081 E.0164
G1 X158.081 Y152.065 E1.04255
G1 X158.614 Y152.065 E.0164
G1 X182.065 Y128.614 E1.01936
G1 X182.065 Y129.148 E.0164
G1 X159.148 Y152.065 E.99617
G1 X159.681 Y152.065 E.0164
G1 X182.065 Y129.681 E.97298
G1 X182.065 Y130.215 E.0164
G1 X160.215 Y152.065 E.94979
G1 X160.748 Y152.065 E.0164
G1 X182.065 Y130.748 E.92661
G1 X182.065 Y131.281 E.0164
G1 X161.281 Y152.065 E.90342
G1 X161.815 Y152.065 E.0164
G1 X182.065 Y131.815 E.88023
G1 X182.065 Y132.348 E.0164
G1 X162.348 Y152.065 E.85704
G1 X162.882 Y152.065 E.0164
G1 X182.065 Y132.882 E.83385
G1 X182.065 Y133.415 E.0164
G1 X163.415 Y152.065 E.81067
G1 X163.949 Y152.065 E.0164
G1 X182.065 Y133.949 E.78748
G1 X182.065 Y134.482 E.0164
G1 X164.482 Y152.065 E.76429
G1 X165.016 Y152.065 E.0164
G1 X182.065 Y135.016 E.7411
G1 X182.065 Y135.549 E.0164
G1 X165.549 Y152.065 E.71791
G1 X166.082 Y152.065 E.0164
G1 X182.065 Y136.082 E.69473
G1 X182.065 Y136.616 E.0164
G1 X166.616 Y152.065 E.67154
G1 X167.149 Y152.065 E.0164
G1 X182.065 Y137.149 E.64835
G1 X182.065 Y137.683 E.0164
G1 X167.683 Y152.065 E.62516
G1 X168.216 Y152.065 E.0164
G1 X182.065 Y138.216 E.60197
G1 X182.065 Y138.75 E.0164
G1 X168.75 Y152.065 E.57879
G1 X169.283 Y152.065 E.0164
G1 X182.065 Y139.283 E.5556
G1 X182.065 Y139.817 E.0164
G1 X169.817 Y152.065 E.53241
G1 X170.35 Y152.065 E.0164
G1 X182.065 Y140.35 E.50922
G1 X182.065 Y140.883 E.0164
G1 X170.883 Y152.065 E.48603
G1 X171.417 Y152.065 E.0164
G1 X182.065 Y141.417 E.46285
G1 X182.065 Y141.95 E.0164
G1 X171.95 Y152.065 E.43966
G1 X172.484 Y152.065 E.0164
G1 X182.065 Y142.484 E.41647
G3 X182.06 Y143.022 I-3.42 J.24 E.01656
G1 X173.022 Y152.06 E.39288
G1 X173.601 Y152.014 E.01785
G1 X182.014 Y143.601 E.36573
G1 X181.969 Y144.18 E.01785
G1 X174.18 Y151.969 E.33858
G2 X174.831 Y151.851 I-.047 J-2.116 E.02043
G1 X181.851 Y144.831 E.30513
G1 X181.682 Y145.533 E.02219
G1 X175.533 Y151.682 E.26729
G1 X175.8 Y151.618 E.00844
G1 X176.365 Y151.385 E.01877
G1 X181.385 Y146.365 E.21821
G1 X181.074 Y147.114 E.02493
G1 X180.925 Y147.358 E.00879
G1 X176.962 Y151.321 E.17226
; WIPE_START
G1 X178.376 Y149.907 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X170.928 Y148.239 Z2 F42000
G1 X73.766 Y126.491 Z2
G1 Z1.6
G1 E.8 F1800
G1 F12725.344
M204 S6000
G1 X96.321 Y103.935 E.98046
G1 X95.788 Y103.935 E.0164
G1 X73.935 Y125.788 E.9499
G1 X73.935 Y125.254 E.0164
G1 X95.254 Y103.935 E.92671
G1 X94.721 Y103.935 E.0164
G1 X73.935 Y124.721 E.90352
G1 X73.935 Y124.188 E.0164
G1 X94.188 Y103.935 E.88034
G1 X93.654 Y103.935 E.0164
G1 X73.935 Y123.654 E.85715
G1 X73.935 Y123.121 E.0164
G1 X93.121 Y103.935 E.83396
G1 X92.587 Y103.935 E.0164
G1 X73.935 Y122.587 E.81077
G1 X73.935 Y122.054 E.0164
G1 X92.054 Y103.935 E.78758
G1 X91.52 Y103.935 E.0164
G1 X73.935 Y121.52 E.7644
G1 X73.935 Y120.987 E.0164
G1 X90.987 Y103.935 E.74121
G1 X90.453 Y103.935 E.0164
G1 X73.935 Y120.453 E.71802
G1 X73.935 Y119.92 E.0164
G1 X89.92 Y103.935 E.69483
G1 X89.387 Y103.935 E.0164
G1 X73.935 Y119.387 E.67164
G1 X73.935 Y118.853 E.0164
G1 X88.853 Y103.935 E.64846
G1 X88.32 Y103.935 E.0164
G1 X73.935 Y118.32 E.62527
G1 X73.935 Y117.786 E.0164
G1 X87.786 Y103.935 E.60208
G1 X87.253 Y103.935 E.0164
G1 X73.935 Y117.253 E.57889
G1 X73.935 Y116.719 E.0164
G1 X86.719 Y103.935 E.5557
G1 X86.186 Y103.935 E.0164
G1 X73.935 Y116.186 E.53252
G1 X73.935 Y115.652 E.0164
G1 X85.652 Y103.935 E.50933
G1 X85.119 Y103.935 E.0164
G1 X73.935 Y115.119 E.48614
G1 X73.935 Y114.586 E.0164
G1 X84.586 Y103.935 E.46295
G1 X84.052 Y103.935 E.0164
G1 X73.935 Y114.052 E.43976
G1 X73.935 Y113.519 E.0164
G1 X83.519 Y103.935 E.41658
G2 X82.981 Y103.94 I-.241 J3.412 E.01655
G1 X73.94 Y112.981 E.393
G1 X73.985 Y112.402 E.01785
G1 X82.402 Y103.985 E.36586
M73 P69 R8
G1 X81.823 Y104.031 E.01785
G1 X74.031 Y111.823 E.33871
G3 X74.148 Y111.172 I2.114 J.045 E.02041
G1 X81.172 Y104.148 E.3053
G1 X80.47 Y104.317 E.02219
G1 X74.317 Y110.47 E.26746
G3 X74.614 Y109.64 I4.291 J1.066 E.02715
G1 X79.64 Y104.614 E.21847
G1 X78.886 Y104.926 E.02507
G1 X78.648 Y105.072 E.00857
G1 X75.072 Y108.648 E.15548
G1 X75.669 Y107.674 E.03514
G1 X76.582 Y106.605 E.04321
G1 X77.785 Y105.402 E.05228
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12725.344
G1 X76.582 Y106.605 E-.64635
G1 X76.388 Y106.832 E-.11365
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 9/25
; update layer progress
M73 L9
M991 S0 P8 ;notify layer change
M106 S160.65
; OBJECT_ID: 91
M204 S10000
G17
G3 Z2 I-1.128 J.457 P1  F42000
G1 X84.102 Y125.858 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X84.102 Y130.368 E.14961
G1 X80 Y132.737 E.15712
G1 X75.898 Y130.368 E.15712
G1 X75.898 Y125.632 E.15712
G1 X79.174 Y123.74 E.12548
G1 X80 Y123.263 E.03164
G1 X84.102 Y125.632 E.15712
G1 X84.102 Y125.798 E.00552
M204 S250
G1 X83.71 Y125.858 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X79.37 Y124.08 E.10928
G1 X80 Y123.716 E.02235
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.097 Y134.566 Z2.2 F42000
G1 X74.064 Y145.904 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11791.304
M204 S6000
G1 X73.72 Y144.47 E.04891
G1 X73.602 Y142.976 E.0497
G1 X73.602 Y113.024 E.99358
G1 X73.72 Y111.53 E.0497
G1 X74.064 Y110.096 E.04891
G1 X74.136 Y109.923 E.00624
G1 X74.628 Y108.734 E.04267
G1 X75.398 Y107.477 E.04891
G1 X76.356 Y106.356 E.04891
G1 X77.477 Y105.398 E.04891
G1 X78.734 Y104.628 E.04891
G1 X80.096 Y104.064 E.04891
G1 X81.53 Y103.72 E.04891
G1 X83.024 Y103.602 E.0497
G1 X172.976 Y103.602 E2.98389
G1 X173.187 Y103.619 E.00702
G1 X174.47 Y103.72 E.04267
G1 X175.904 Y104.064 E.04891
G1 X177.266 Y104.628 E.04891
G1 X178.523 Y105.398 E.04891
G1 X179.644 Y106.356 E.04891
G1 X180.602 Y107.477 E.04891
G1 X181.372 Y108.734 E.04891
G1 X181.936 Y110.096 E.04891
G1 X182.28 Y111.53 E.04891
G1 X182.398 Y113.024 E.0497
G1 X182.398 Y142.976 E.99358
G1 X182.28 Y144.47 E.0497
G1 X181.936 Y145.904 E.04891
G1 X181.372 Y147.266 E.04891
G1 X180.602 Y148.523 E.04891
G1 X179.644 Y149.644 E.04891
G1 X178.523 Y150.602 E.04891
G1 X177.266 Y151.372 E.04891
G1 X175.904 Y151.936 E.04891
G1 X174.47 Y152.28 E.04891
G1 X172.976 Y152.398 E.0497
G1 X83.024 Y152.398 E2.98389
G1 X81.53 Y152.28 E.0497
G1 X80.096 Y151.936 E.04891
G1 X78.734 Y151.372 E.04891
G1 X77.477 Y150.602 E.04891
G1 X76.356 Y149.644 E.04891
G1 X75.398 Y148.523 E.04891
G1 X74.628 Y147.266 E.04891
G1 X74.087 Y145.959 E.04692
M204 S250
G1 X73.69 Y146.025 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.331 Y144.531 E.0472
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X73.774 Y109.773 E.00672
G1 X74.278 Y108.556 E.04048
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X172.992 Y103.21 E2.76494
G1 X173.218 Y103.228 E.00698
G1 X174.531 Y103.331 E.04048
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.713 Y146.081 E.04536
; WIPE_START
M204 S6000
G1 X73.331 Y144.531 E-.60626
G1 X73.299 Y144.128 E-.15374
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2.2
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2.2 F4000
            G39.3 S1
            G0 Z2.2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X75.402 Y148.215 F42000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42012
G1 F12725.344
M204 S6000
G1 X76.605 Y149.418 E.05228
G1 X77.674 Y150.331 E.04321
G1 X78.648 Y150.928 E.03514
G1 X75.071 Y147.352 E.15548
G1 X74.926 Y147.114 E.00857
G1 X74.614 Y146.36 E.02507
G1 X79.64 Y151.386 E.21847
G1 X80.2 Y151.618 E.01863
G1 X80.47 Y151.683 E.00854
G1 X74.317 Y145.53 E.26747
G1 X74.148 Y144.828 E.02219
G1 X81.172 Y151.852 E.3053
G2 X81.823 Y151.969 I.696 J-1.996 E.02041
G1 X74.031 Y144.177 E.33871
G1 X73.985 Y143.598 E.01785
G1 X82.402 Y152.015 E.36586
G1 X82.981 Y152.06 E.01785
G1 X73.94 Y143.019 E.39301
G3 X73.935 Y142.481 I3.421 J-.297 E.01655
G1 X83.519 Y152.065 E.41658
G1 X84.052 Y152.065 E.0164
G1 X73.935 Y141.948 E.43977
G1 X73.935 Y141.414 E.0164
G1 X84.586 Y152.065 E.46295
G1 X85.119 Y152.065 E.0164
G1 X73.935 Y140.881 E.48614
G1 X73.935 Y140.348 E.0164
G1 X85.652 Y152.065 E.50933
G1 X86.186 Y152.065 E.0164
G1 X73.935 Y139.814 E.53252
G1 X73.935 Y139.281 E.0164
G1 X86.719 Y152.065 E.55571
G1 X87.253 Y152.065 E.0164
G1 X73.935 Y138.747 E.57889
G1 X73.935 Y138.214 E.0164
G1 X87.786 Y152.065 E.60208
G1 X88.32 Y152.065 E.0164
G1 X73.935 Y137.68 E.62527
G1 X73.935 Y137.147 E.0164
G1 X88.853 Y152.065 E.64846
G1 X89.387 Y152.065 E.0164
G1 X73.935 Y136.613 E.67165
G1 X73.935 Y136.08 E.0164
G1 X89.92 Y152.065 E.69483
G1 X90.453 Y152.065 E.0164
G1 X73.935 Y135.547 E.71802
G1 X73.935 Y135.013 E.0164
G1 X90.987 Y152.065 E.74121
G1 X91.52 Y152.065 E.0164
G1 X73.935 Y134.48 E.7644
G1 X73.935 Y133.946 E.0164
G1 X92.054 Y152.065 E.78759
G1 X92.587 Y152.065 E.0164
G1 X73.935 Y133.413 E.81077
G1 X73.935 Y132.879 E.0164
G1 X93.121 Y152.065 E.83396
G1 X93.654 Y152.065 E.0164
G1 X73.935 Y132.346 E.85715
G1 X73.935 Y131.812 E.0164
G1 X94.188 Y152.065 E.88034
G1 X94.721 Y152.065 E.0164
G1 X73.935 Y131.279 E.90353
G1 X73.935 Y130.746 E.0164
G1 X95.254 Y152.065 E.92671
G1 X95.788 Y152.065 E.0164
G1 X73.935 Y130.212 E.9499
G1 X73.935 Y129.679 E.0164
G1 X96.491 Y152.234 E.98047
M204 S10000
G1 X110.894 Y152.234 F42000
G1 F12725.344
M204 S6000
G1 X84.435 Y125.776 E1.15012
G1 X84.435 Y126.309 E.0164
G1 X110.191 Y152.065 E1.11956
G1 X109.657 Y152.065 E.0164
G1 X84.435 Y126.843 E1.09637
G1 X84.435 Y127.376 E.0164
G1 X109.124 Y152.065 E1.07318
G1 X108.59 Y152.065 E.0164
G1 X84.435 Y127.91 E1.04999
G1 X84.435 Y128.443 E.0164
G1 X108.057 Y152.065 E1.0268
G1 X107.524 Y152.065 E.0164
G1 X84.435 Y128.976 E1.00362
G1 X84.435 Y129.51 E.0164
G1 X106.99 Y152.065 E.98043
G1 X106.457 Y152.065 E.0164
G1 X84.435 Y130.043 E.95724
G1 X84.425 Y130.567 E.01609
G1 X105.923 Y152.065 E.93449
G1 X105.39 Y152.065 E.0164
G1 X84.087 Y130.762 E.92601
G1 X83.749 Y130.957 E.012
G1 X104.856 Y152.065 E.91752
G1 X104.323 Y152.065 E.0164
G1 X83.411 Y131.152 E.90903
G1 X83.072 Y131.348 E.012
G1 X103.789 Y152.065 E.90054
G1 X103.256 Y152.065 E.0164
G1 X82.734 Y131.543 E.89206
G1 X82.396 Y131.738 E.012
G1 X102.723 Y152.065 E.88357
G1 X102.189 Y152.065 E.0164
G1 X82.058 Y131.933 E.87508
G1 X81.72 Y132.129 E.012
G1 X101.656 Y152.065 E.86659
G1 X101.122 Y152.065 E.0164
G1 X81.381 Y132.324 E.85811
G1 X81.043 Y132.519 E.012
G1 X100.589 Y152.065 E.84962
G1 X100.055 Y152.065 E.0164
G1 X80.705 Y132.714 E.84113
G1 X80.367 Y132.91 E.012
G1 X99.522 Y152.065 E.83265
G1 X98.988 Y152.065 E.0164
G1 X80.029 Y133.105 E.82416
G1 X80 Y133.121 E.00102
G1 X78.845 Y132.455 E.04099
G1 X98.455 Y152.065 E.85242
G1 X97.922 Y152.065 E.0164
G1 X77.583 Y131.726 E.8841
G1 X76.321 Y130.997 E.0448
G1 X97.388 Y152.065 E.91577
G1 X96.855 Y152.065 E.0164
G1 X73.935 Y129.145 E.99628
G1 X73.935 Y128.612 E.0164
G1 X75.565 Y130.241 E.07083
G1 X75.565 Y129.708 E.0164
M73 P70 R8
G1 X73.935 Y128.078 E.07083
G1 X73.935 Y127.545 E.0164
G1 X75.565 Y129.174 E.07083
G1 X75.565 Y128.641 E.0164
G1 X73.935 Y127.011 E.07083
G1 X73.935 Y126.478 E.0164
G1 X75.565 Y128.107 E.07083
G1 X75.565 Y127.574 E.0164
G1 X73.935 Y125.945 E.07083
G1 X73.935 Y125.411 E.0164
G1 X75.565 Y127.041 E.07083
G1 X75.565 Y126.507 E.0164
G1 X73.935 Y124.878 E.07083
G1 X73.935 Y124.344 E.0164
G1 X75.565 Y125.974 E.07083
G1 X75.565 Y125.44 E.0164
G1 X73.935 Y123.811 E.07083
G1 X73.935 Y123.277 E.0164
G1 X75.902 Y125.244 E.0855
G1 X76.24 Y125.049 E.012
G1 X73.935 Y122.744 E.1002
G1 X73.935 Y122.211 E.0164
G1 X76.579 Y124.854 E.1149
G1 X76.917 Y124.659 E.012
G1 X73.935 Y121.677 E.1296
G1 X73.935 Y121.144 E.0164
G1 X77.255 Y124.463 E.1443
G1 X77.593 Y124.268 E.012
G1 X73.935 Y120.61 E.159
G1 X73.935 Y120.077 E.0164
G1 X77.931 Y124.073 E.1737
G1 X78.27 Y123.878 E.012
G1 X73.935 Y119.543 E.1884
G1 X73.935 Y119.01 E.0164
G1 X78.608 Y123.682 E.20311
G1 X78.946 Y123.487 E.012
G1 X73.935 Y118.476 E.21781
G1 X73.935 Y117.943 E.0164
G1 X79.284 Y123.292 E.23251
G1 X79.622 Y123.097 E.012
G1 X73.935 Y117.41 E.24721
G1 X73.935 Y116.876 E.0164
G1 X79.961 Y122.901 E.26191
G1 X80 Y122.879 E.0014
G1 X81.115 Y123.522 E.03957
G1 X73.935 Y116.343 E.31208
G1 X73.935 Y115.809 E.0164
G1 X82.377 Y124.251 E.36695
G1 X83.639 Y124.98 E.0448
G1 X73.935 Y115.276 E.42181
G1 X73.935 Y114.742 E.0164
G1 X111.258 Y152.065 E1.62235
G1 X111.791 Y152.065 E.0164
G1 X73.935 Y114.209 E1.64554
G1 X73.935 Y113.675 E.0164
G1 X112.325 Y152.065 E1.66873
G1 X112.858 Y152.065 E.0164
G1 X73.935 Y113.142 E1.69192
G3 X73.967 Y112.64 I3.207 J-.053 E.01548
G1 X113.391 Y152.065 E1.71375
G1 X113.925 Y152.065 E.0164
G1 X74.005 Y112.145 E1.73524
G1 X74.044 Y111.651 E.01525
G1 X114.458 Y152.065 E1.75674
G1 X114.992 Y152.065 E.0164
G1 X74.139 Y111.212 E1.77583
G1 X74.242 Y110.782 E.0136
G1 X115.525 Y152.065 E1.79452
G1 X116.059 Y152.065 E.0164
G1 X74.345 Y110.351 E1.81322
G3 X74.444 Y110.05 I1 J.16 E.00978
G1 X74.483 Y109.956 E.00315
G1 X116.592 Y152.065 E1.83043
G1 X117.125 Y152.065 E.0164
G1 X74.639 Y109.578 E1.84683
G1 X74.795 Y109.201 E.01255
G1 X117.659 Y152.065 E1.86322
G1 X118.192 Y152.065 E.0164
G1 X74.959 Y108.832 E1.87929
G1 X75.162 Y108.501 E.01192
G1 X118.726 Y152.065 E1.89367
G1 X119.259 Y152.065 E.0164
G1 X75.365 Y108.17 E1.90804
G1 X75.567 Y107.839 E.01192
G1 X119.793 Y152.065 E1.92242
G1 X120.326 Y152.065 E.0164
G1 X75.791 Y107.53 E1.93586
G1 X76.037 Y107.242 E.01163
G1 X120.86 Y152.065 E1.94837
G1 X121.393 Y152.065 E.0164
G1 X76.283 Y106.955 E1.96088
G1 X76.529 Y106.667 E.01163
G1 X121.926 Y152.065 E1.97338
G1 X122.46 Y152.065 E.0164
G1 X76.806 Y106.41 E1.98454
G1 X77.093 Y106.165 E.01163
G1 X122.993 Y152.065 E1.99522
G1 X123.527 Y152.065 E.0164
G1 X77.381 Y105.919 E2.0059
G1 X77.669 Y105.673 E.01163
G1 X124.06 Y152.065 E2.01658
G1 X124.594 Y152.065 E.0164
G1 X77.999 Y105.47 E2.02543
G1 X78.329 Y105.267 E.01192
G1 X125.127 Y152.065 E2.03424
G1 X125.661 Y152.065 E.0164
G1 X78.66 Y105.064 E2.04305
G3 X79.006 Y104.876 I.766 J.997 E.01214
G1 X126.194 Y152.065 E2.05122
G1 X126.727 Y152.065 E.0164
G1 X79.383 Y104.72 E2.05801
G1 X79.76 Y104.564 E.01255
G1 X127.261 Y152.065 E2.0648
G1 X127.794 Y152.065 E.0164
G1 X80.137 Y104.408 E2.07159
G1 X80.559 Y104.296 E.0134
G1 X128.328 Y152.065 E2.07646
G1 X128.861 Y152.065 E.0164
G1 X80.989 Y104.192 E2.08095
G1 X81.419 Y104.089 E.0136
G1 X129.395 Y152.065 E2.08544
G1 X129.928 Y152.065 E.0164
G1 X81.889 Y104.026 E2.0882
G1 X82.384 Y103.987 E.01525
G1 X130.462 Y152.065 E2.08989
G1 X130.995 Y152.065 E.0164
G1 X82.878 Y103.948 E2.09158
G3 X83.399 Y103.935 I.34 J3.302 E.01603
G1 X131.528 Y152.065 E2.09212
G1 X132.062 Y152.065 E.0164
G1 X83.932 Y103.935 E2.09212
G1 X84.466 Y103.935 E.0164
G1 X132.595 Y152.065 E2.09212
G1 X133.129 Y152.065 E.0164
G1 X84.999 Y103.935 E2.09212
G1 X85.533 Y103.935 E.0164
G1 X133.662 Y152.065 E2.09212
G1 X134.196 Y152.065 E.0164
G1 X86.066 Y103.935 E2.09212
G1 X86.6 Y103.935 E.0164
G1 X134.729 Y152.065 E2.09212
G1 X135.263 Y152.065 E.0164
G1 X87.133 Y103.935 E2.09212
G1 X87.667 Y103.935 E.0164
G1 X135.796 Y152.065 E2.09212
G1 X136.329 Y152.065 E.0164
G1 X88.2 Y103.935 E2.09212
G1 X88.733 Y103.935 E.0164
G1 X136.863 Y152.065 E2.09212
G1 X137.396 Y152.065 E.0164
G1 X89.267 Y103.935 E2.09212
G1 X89.8 Y103.935 E.0164
G1 X137.93 Y152.065 E2.09212
G1 X138.463 Y152.065 E.0164
G1 X90.334 Y103.935 E2.09212
G1 X90.867 Y103.935 E.0164
G1 X138.997 Y152.065 E2.09212
G1 X139.53 Y152.065 E.0164
G1 X91.401 Y103.935 E2.09212
G1 X91.934 Y103.935 E.0164
G1 X140.063 Y152.065 E2.09212
M73 P71 R8
G1 X140.597 Y152.065 E.0164
G1 X92.468 Y103.935 E2.09212
G1 X93.001 Y103.935 E.0164
G1 X141.13 Y152.065 E2.09212
G1 X141.664 Y152.065 E.0164
G1 X93.534 Y103.935 E2.09212
G1 X94.068 Y103.935 E.0164
G1 X142.197 Y152.065 E2.09212
G1 X142.731 Y152.065 E.0164
G1 X94.601 Y103.935 E2.09212
G1 X95.135 Y103.935 E.0164
G1 X143.264 Y152.065 E2.09212
G1 X143.798 Y152.065 E.0164
G1 X95.668 Y103.935 E2.09212
G1 X96.202 Y103.935 E.0164
G1 X144.331 Y152.065 E2.09212
G1 X144.864 Y152.065 E.0164
G1 X96.735 Y103.935 E2.09212
G1 X97.269 Y103.935 E.0164
G1 X145.398 Y152.065 E2.09212
G1 X145.931 Y152.065 E.0164
G1 X97.802 Y103.935 E2.09212
G1 X98.335 Y103.935 E.0164
G1 X146.465 Y152.065 E2.09212
G1 X146.998 Y152.065 E.0164
G1 X98.869 Y103.935 E2.09212
G1 X99.402 Y103.935 E.0164
G1 X147.532 Y152.065 E2.09212
G1 X148.065 Y152.065 E.0164
G1 X99.936 Y103.935 E2.09212
G1 X100.469 Y103.935 E.0164
G1 X148.599 Y152.065 E2.09212
G1 X149.132 Y152.065 E.0164
G1 X101.003 Y103.935 E2.09212
G1 X101.536 Y103.935 E.0164
G1 X149.665 Y152.065 E2.09212
G1 X150.199 Y152.065 E.0164
G1 X102.07 Y103.935 E2.09212
G1 X102.603 Y103.935 E.0164
G1 X150.732 Y152.065 E2.09212
G1 X151.266 Y152.065 E.0164
G1 X103.136 Y103.935 E2.09212
G1 X103.67 Y103.935 E.0164
G1 X151.799 Y152.065 E2.09212
G1 X152.333 Y152.065 E.0164
G1 X104.203 Y103.935 E2.09212
G1 X104.737 Y103.935 E.0164
G1 X152.866 Y152.065 E2.09212
M73 P71 R7
G1 X153.4 Y152.065 E.0164
G1 X105.27 Y103.935 E2.09212
G1 X105.804 Y103.935 E.0164
G1 X153.933 Y152.065 E2.09212
G1 X154.466 Y152.065 E.0164
G1 X106.337 Y103.935 E2.09212
G1 X106.87 Y103.935 E.0164
G1 X155 Y152.065 E2.09212
G1 X155.533 Y152.065 E.0164
G1 X107.404 Y103.935 E2.09212
G1 X107.937 Y103.935 E.0164
G1 X156.067 Y152.065 E2.09212
G1 X156.6 Y152.065 E.0164
G1 X108.471 Y103.935 E2.09212
G1 X109.004 Y103.935 E.0164
G1 X157.134 Y152.065 E2.09212
G1 X157.667 Y152.065 E.0164
G1 X109.538 Y103.935 E2.09212
G1 X110.071 Y103.935 E.0164
G1 X158.2 Y152.065 E2.09212
G1 X158.734 Y152.065 E.0164
G1 X110.605 Y103.935 E2.09212
G1 X111.138 Y103.935 E.0164
G1 X159.267 Y152.065 E2.09212
G1 X159.801 Y152.065 E.0164
G1 X111.671 Y103.935 E2.09212
G1 X112.205 Y103.935 E.0164
G1 X160.334 Y152.065 E2.09212
G1 X160.868 Y152.065 E.0164
G1 X112.738 Y103.935 E2.09212
G1 X113.272 Y103.935 E.0164
G1 X161.401 Y152.065 E2.09212
G1 X161.935 Y152.065 E.0164
G1 X113.805 Y103.935 E2.09212
G1 X114.339 Y103.935 E.0164
G1 X162.468 Y152.065 E2.09212
G1 X163.001 Y152.065 E.0164
G1 X114.872 Y103.935 E2.09212
G1 X115.406 Y103.935 E.0164
G1 X163.535 Y152.065 E2.09212
G1 X164.068 Y152.065 E.0164
G1 X115.939 Y103.935 E2.09212
M73 P72 R7
G1 X116.472 Y103.935 E.0164
G1 X164.602 Y152.065 E2.09212
G1 X165.135 Y152.065 E.0164
G1 X117.006 Y103.935 E2.09212
G1 X117.539 Y103.935 E.0164
G1 X165.669 Y152.065 E2.09212
G1 X166.202 Y152.065 E.0164
G1 X118.073 Y103.935 E2.09212
G1 X118.606 Y103.935 E.0164
G1 X166.736 Y152.065 E2.09212
G1 X167.269 Y152.065 E.0164
G1 X119.14 Y103.935 E2.09212
G1 X119.673 Y103.935 E.0164
G1 X167.802 Y152.065 E2.09212
G1 X168.336 Y152.065 E.0164
G1 X120.207 Y103.935 E2.09212
G1 X120.74 Y103.935 E.0164
G1 X168.869 Y152.065 E2.09212
G1 X169.403 Y152.065 E.0164
G1 X121.273 Y103.935 E2.09212
G1 X121.807 Y103.935 E.0164
G1 X169.936 Y152.065 E2.09212
G1 X170.47 Y152.065 E.0164
G1 X122.34 Y103.935 E2.09212
G1 X122.874 Y103.935 E.0164
G1 X171.003 Y152.065 E2.09212
G1 X171.537 Y152.065 E.0164
G1 X123.407 Y103.935 E2.09212
G1 X123.941 Y103.935 E.0164
G1 X172.07 Y152.065 E2.09212
G1 X172.603 Y152.065 E.0164
G1 X124.474 Y103.935 E2.09212
G1 X125.007 Y103.935 E.0164
G1 X173.124 Y152.052 E2.09157
G1 X173.619 Y152.013 E.01525
G1 X125.541 Y103.935 E2.08988
G1 X126.074 Y103.935 E.0164
G1 X174.113 Y151.974 E2.08819
G2 X174.583 Y151.91 I.034 J-1.515 E.01463
G1 X126.608 Y103.935 E2.08542
G1 X127.141 Y103.935 E.0164
G1 X175.013 Y151.807 E2.08093
G1 X175.443 Y151.704 E.0136
G1 X127.675 Y103.935 E2.07644
G1 X128.208 Y103.935 E.0164
G1 X175.864 Y151.592 E2.07156
G1 X176.242 Y151.435 E.01255
G1 X128.742 Y103.935 E2.06477
G1 X129.275 Y103.935 E.0164
G1 X176.619 Y151.279 E2.05798
G1 X176.996 Y151.123 E.01255
G1 X129.808 Y103.935 E2.05119
G1 X130.342 Y103.935 E.0164
G1 X177.341 Y150.935 E2.04301
G1 X177.672 Y150.732 E.01192
G1 X130.875 Y103.935 E2.0342
G1 X131.409 Y103.935 E.0164
G1 X178.003 Y150.529 E2.02538
G1 X178.333 Y150.326 E.01191
G1 X131.942 Y103.935 E2.01653
G1 X132.476 Y103.935 E.0164
G1 X178.62 Y150.08 E2.00585
G1 X178.908 Y149.834 E.01163
G1 X133.009 Y103.935 E1.99517
G1 X133.543 Y103.935 E.0164
G1 X179.196 Y149.589 E1.98449
G2 X179.472 Y149.332 I-.673 J-1.002 E.01165
G1 X134.076 Y103.935 E1.97333
G1 X134.609 Y103.935 E.0164
G1 X179.718 Y149.044 E1.96082
G1 X179.964 Y148.756 E.01163
G1 X135.143 Y103.935 E1.94831
G1 X135.676 Y103.935 E.0164
G1 X180.21 Y148.469 E1.93581
G2 X180.434 Y148.159 I-.865 J-.862 E.01179
G1 X136.21 Y103.935 E1.92235
G1 X136.743 Y103.935 E.0164
G1 X180.636 Y147.828 E1.90798
G1 X180.839 Y147.498 E.01192
G1 X137.277 Y103.935 E1.8936
G1 X137.81 Y103.935 E.0164
G1 X181.042 Y147.167 E1.87922
G2 X181.205 Y146.797 I-1.086 J-.702 E.01248
G1 X138.344 Y103.935 E1.86315
G1 X138.877 Y103.935 E.0164
G1 X181.362 Y146.42 E1.84675
G1 X181.518 Y146.043 E.01255
G1 X139.41 Y103.935 E1.83036
G1 X139.944 Y103.935 E.0164
G1 X181.655 Y145.647 E1.81314
G1 X181.758 Y145.216 E.0136
G1 X140.477 Y103.935 E1.79444
M73 P73 R7
G1 X141.011 Y103.935 E.0164
G1 X181.862 Y144.786 E1.77574
G1 X181.956 Y144.347 E.01381
G1 X141.544 Y103.935 E1.75664
G1 X142.078 Y103.935 E.0164
G1 X181.995 Y143.852 E1.73514
G1 X182.034 Y143.358 E.01525
G1 X142.611 Y103.935 E1.71365
G1 X143.144 Y103.935 E.0164
G1 X182.065 Y142.856 E1.69181
G1 X182.065 Y142.322 E.0164
G1 X143.678 Y103.935 E1.66862
G1 X144.211 Y103.935 E.0164
G1 X182.065 Y141.789 E1.64543
G1 X182.065 Y141.255 E.0164
G1 X144.745 Y103.935 E1.62225
G1 X145.278 Y103.935 E.0164
G1 X182.065 Y140.722 E1.59906
G1 X182.065 Y140.188 E.0164
G1 X145.812 Y103.935 E1.57587
G1 X146.345 Y103.935 E.0164
G1 X182.065 Y139.655 E1.55268
G1 X182.065 Y139.121 E.0164
G1 X146.879 Y103.935 E1.52949
G1 X147.412 Y103.935 E.0164
G1 X182.065 Y138.588 E1.50631
G1 X182.065 Y138.055 E.0164
G1 X147.945 Y103.935 E1.48312
G1 X148.479 Y103.935 E.0164
G1 X182.065 Y137.521 E1.45993
G1 X182.065 Y136.988 E.0164
G1 X149.012 Y103.935 E1.43674
G1 X149.546 Y103.935 E.0164
G1 X182.065 Y136.454 E1.41355
G1 X182.065 Y135.921 E.0164
G1 X150.079 Y103.935 E1.39037
G1 X150.613 Y103.935 E.0164
G1 X182.065 Y135.387 E1.36718
G1 X182.065 Y134.854 E.0164
G1 X151.146 Y103.935 E1.34399
G1 X151.68 Y103.935 E.0164
G1 X182.065 Y134.32 E1.3208
G1 X182.065 Y133.787 E.0164
G1 X152.213 Y103.935 E1.29761
G1 X152.746 Y103.935 E.0164
G1 X182.065 Y133.254 E1.27443
G1 X182.065 Y132.72 E.0164
G1 X153.28 Y103.935 E1.25124
G1 X153.813 Y103.935 E.0164
G1 X182.065 Y132.187 E1.22805
G1 X182.065 Y131.653 E.0164
G1 X154.347 Y103.935 E1.20486
G1 X154.88 Y103.935 E.0164
G1 X182.065 Y131.12 E1.18167
G1 X182.065 Y130.586 E.0164
G1 X155.414 Y103.935 E1.15849
G1 X155.947 Y103.935 E.0164
G1 X182.065 Y130.053 E1.1353
G1 X182.065 Y129.519 E.0164
G1 X156.481 Y103.935 E1.11211
G1 X157.014 Y103.935 E.0164
G1 X182.065 Y128.986 E1.08892
G1 X182.065 Y128.453 E.0164
G1 X157.547 Y103.935 E1.06573
G1 X158.081 Y103.935 E.0164
G1 X182.065 Y127.919 E1.04255
G1 X182.065 Y127.386 E.0164
G1 X158.614 Y103.935 E1.01936
G1 X159.148 Y103.935 E.0164
G1 X182.065 Y126.852 E.99617
G1 X182.065 Y126.319 E.0164
G1 X159.681 Y103.935 E.97298
G1 X160.215 Y103.935 E.0164
G1 X182.065 Y125.785 E.94979
G1 X182.065 Y125.252 E.0164
G1 X160.748 Y103.935 E.92661
G1 X161.281 Y103.935 E.0164
G1 X182.065 Y124.719 E.90342
G1 X182.065 Y124.185 E.0164
G1 X161.815 Y103.935 E.88023
G1 X162.348 Y103.935 E.0164
G1 X182.065 Y123.652 E.85704
G1 X182.065 Y123.118 E.0164
G1 X162.882 Y103.935 E.83385
G1 X163.415 Y103.935 E.0164
G1 X182.065 Y122.585 E.81067
G1 X182.065 Y122.051 E.0164
G1 X163.949 Y103.935 E.78748
G1 X164.482 Y103.935 E.0164
G1 X182.065 Y121.518 E.76429
G1 X182.065 Y120.984 E.0164
G1 X165.016 Y103.935 E.7411
G1 X165.549 Y103.935 E.0164
G1 X182.065 Y120.451 E.71791
G1 X182.065 Y119.918 E.0164
G1 X166.082 Y103.935 E.69473
G1 X166.616 Y103.935 E.0164
G1 X182.065 Y119.384 E.67154
G1 X182.065 Y118.851 E.0164
G1 X167.149 Y103.935 E.64835
G1 X167.683 Y103.935 E.0164
G1 X182.065 Y118.317 E.62516
G1 X182.065 Y117.784 E.0164
G1 X168.216 Y103.935 E.60197
G1 X168.75 Y103.935 E.0164
G1 X182.065 Y117.25 E.57879
G1 X182.065 Y116.717 E.0164
G1 X169.283 Y103.935 E.5556
G1 X169.817 Y103.935 E.0164
G1 X182.065 Y116.183 E.53241
G1 X182.065 Y115.65 E.0164
G1 X170.35 Y103.935 E.50922
G1 X170.883 Y103.935 E.0164
G1 X182.065 Y115.117 E.48603
G1 X182.065 Y114.583 E.0164
G1 X171.417 Y103.935 E.46285
G1 X171.95 Y103.935 E.0164
G1 X182.065 Y114.05 E.43966
M73 P74 R7
G1 X182.065 Y113.516 E.0164
G1 X172.484 Y103.935 E.41647
G3 X173.022 Y103.94 I.24 J3.422 E.01656
G1 X182.06 Y112.978 E.39288
G1 X182.014 Y112.399 E.01785
G1 X173.601 Y103.985 E.36573
G1 X174.18 Y104.031 E.01785
G1 X181.969 Y111.82 E.33858
G2 X181.851 Y111.169 I-2.116 J.047 E.02043
G1 X174.831 Y104.149 E.30513
G1 X175.533 Y104.318 E.02219
G1 X181.682 Y110.467 E.26729
G1 X181.618 Y110.2 E.00844
G1 X181.385 Y109.635 E.01877
G1 X176.365 Y104.615 E.21821
G1 X177.114 Y104.926 E.02493
G1 X177.358 Y105.075 E.0088
G1 X181.321 Y109.038 E.17226
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12725.344
G1 X179.907 Y107.624 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 10/25
; update layer progress
M73 L10
M991 S0 P9 ;notify layer change
M106 S153
; OBJECT_ID: 91
M204 S10000
G17
G3 Z2.2 I-.227 J-1.196 P1  F42000
G1 X83.71 Y125.858 Z2.2
G1 Z2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X83.71 Y130.142 E.13163
G1 X80 Y132.284 E.13163
G1 X76.29 Y130.142 E.13163
G1 X76.29 Y125.858 E.13163
G1 X79.72 Y123.878 E.1217
G1 X80 Y123.716 E.00993
G1 X83.658 Y125.828 E.12979
; WIPE_START
M204 S6000
G1 X83.682 Y127.828 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.008 Y134.518 Z2.4 F42000
G1 X73.69 Y146.025 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S5000
G1 X73.331 Y144.531 E.0472
G1 X73.21 Y142.992 E.04746
G1 X73.21 Y113.008 E.9213
G1 X73.331 Y111.469 E.04746
G1 X73.69 Y109.975 E.0472
G1 X74.278 Y108.556 E.0472
G1 X75.08 Y107.246 E.0472
G1 X76.078 Y106.078 E.0472
G1 X77.246 Y105.08 E.0472
G1 X78.556 Y104.278 E.0472
G1 X79.975 Y103.69 E.0472
G1 X81.469 Y103.331 E.0472
G1 X83.008 Y103.21 E.04746
G1 X173.062 Y103.216 E2.76709
G1 X174.531 Y103.331 E.0453
G1 X176.025 Y103.69 E.0472
G1 X177.444 Y104.278 E.0472
G1 X178.754 Y105.08 E.0472
G1 X179.922 Y106.078 E.0472
G1 X180.92 Y107.246 E.0472
G1 X181.722 Y108.556 E.0472
G1 X182.31 Y109.975 E.0472
G1 X182.669 Y111.469 E.0472
G1 X182.79 Y113.008 E.04746
G1 X182.79 Y142.992 E.9213
G1 X182.669 Y144.531 E.04746
G1 X182.31 Y146.025 E.0472
G1 X181.722 Y147.444 E.0472
G1 X180.92 Y148.754 E.0472
G1 X179.922 Y149.922 E.0472
G1 X178.754 Y150.92 E.0472
G1 X177.444 Y151.722 E.0472
G1 X176.025 Y152.31 E.0472
G1 X174.531 Y152.669 E.0472
G1 X172.992 Y152.79 E.04746
G1 X83.008 Y152.79 E2.76494
G1 X81.469 Y152.669 E.04746
G1 X79.975 Y152.31 E.0472
G1 X78.556 Y151.722 E.0472
G1 X77.246 Y150.92 E.0472
G1 X76.078 Y149.922 E.0472
G1 X75.08 Y148.754 E.0472
G1 X74.278 Y147.444 E.0472
G1 X73.713 Y146.081 E.04536
; WIPE_START
M204 S6000
G1 X73.331 Y144.531 E-.60626
G1 X73.299 Y144.128 E-.15374
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.4 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2.4
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2.4 F4000
            G39.3 S1
            G0 Z2.4 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X99.06 Y131.304 F42000
G1 Z2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.110644
G1 F15000
M204 S6000
G1 X99.142 Y131.136 E.00103
; LINE_WIDTH: 0.139646
G1 X99.19 Y131.056 E.00073
; LINE_WIDTH: 0.170104
G1 X99.234 Y130.982 E.00089
; LINE_WIDTH: 0.199173
G1 X99.323 Y130.857 E.00195
; LINE_WIDTH: 0.228059
G1 X99.412 Y130.732 E.00232
; LINE_WIDTH: 0.263838
G3 X99.539 Y130.599 I.709 J.55 E.00333
; LINE_WIDTH: 0.295517
G1 X99.644 Y130.493 E.00306
; LINE_WIDTH: 0.312833
G1 X99.817 Y130.345 E.005
; LINE_WIDTH: 0.342237
G3 X100.32 Y130.031 I11.334 J17.627 E.01446
G1 X100.388 Y129.998 E.00186
; LINE_WIDTH: 0.390518
G1 F13809.067
G3 X101.29 Y129.649 I3.469 J7.615 E.0274
G2 X104.544 Y128.734 I-50.799 J-186.905 E.09574
; LINE_WIDTH: 0.341152
G1 F15000
G1 X104.988 Y128.594 E.01132
; LINE_WIDTH: 0.319189
G2 X105.701 Y128.289 I-2.478 J-6.783 E.01746
; LINE_WIDTH: 0.281315
G2 X106.262 Y127.934 I-2.317 J-4.284 E.01292
; LINE_WIDTH: 0.231441
G2 X106.523 Y127.695 I-2.015 J-2.458 E.00544
; LINE_WIDTH: 0.194437
G1 X106.625 Y127.584 E.00185
; LINE_WIDTH: 0.156675
G2 X106.809 Y127.331 I-1.529 J-1.311 E.0029
; LINE_WIDTH: 0.112248
G1 X106.883 Y127.22 E.00076
; WIPE_START
G1 X106.809 Y127.331 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X99.636 Y124.724 Z2.4 F42000
G1 X98.753 Y124.403 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.275458
G1 F15000
M204 S6000
G1 X98.947 Y123.788 E.01221
; WIPE_START
G1 X98.753 Y124.403 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.016 Y126.748 Z2.4 F42000
G1 X116.064 Y129.992 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.225275
G1 F15000
M204 S6000
G1 X116.389 Y129.799 E.00561
; WIPE_START
G1 X116.064 Y129.992 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X123.543 Y128.466 Z2.4 F42000
G1 X136.149 Y125.894 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.0981104
G1 F15000
M204 S6000
G2 X136.132 Y125.692 I-1.458 J.022 E.00091
; WIPE_START
G1 X136.149 Y125.894 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.231 Y133.237 Z2.4 F42000
G1 X138.325 Y133.568 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.101609
G1 F15000
M204 S6000
G1 X138.327 Y133.628 E.00029
; LINE_WIDTH: 0.129806
G1 X138.328 Y133.834 E.00146
; LINE_WIDTH: 0.176786
G1 X138.33 Y134.039 E.00224
; LINE_WIDTH: 0.223767
G1 X138.331 Y134.245 E.00303
; LINE_WIDTH: 0.250916
G2 X138.357 Y134.424 I.304 J.047 E.0031
; LINE_WIDTH: 0.193345
G2 X138.44 Y134.469 I.155 J-.185 E.00116
; WIPE_START
G1 X138.357 Y134.424 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X145.745 Y132.505 Z2.4 F42000
G1 X147.728 Y131.99 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.108459
G1 F15000
M204 S6000
G2 X147.508 Y130.746 I-3.288 J-.06 E.00679
; WIPE_START
G1 X147.675 Y131.334 E-.36572
G1 X147.728 Y131.99 E-.39428
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.708 Y128.902 Z2.4 F42000
G1 X156.894 Y127.935 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.10473
G1 F15000
M204 S6000
G1 X156.918 Y127.867 E.00036
; LINE_WIDTH: 0.135454
G1 X156.979 Y127.636 E.0018
; LINE_WIDTH: 0.181297
G1 X157.04 Y127.405 E.00269
; LINE_WIDTH: 0.216028
G1 X157.094 Y127.039 E.00522
; LINE_WIDTH: 0.252437
G1 X157.116 Y126.855 E.00316
; LINE_WIDTH: 0.268311
G2 X157.137 Y126.414 I-3.434 J-.383 E.00811
; LINE_WIDTH: 0.251646
G2 X157.048 Y125.474 I-6.672 J.156 E.01608
; LINE_WIDTH: 0.197864
G1 X157.003 Y125.188 E.00365
; LINE_WIDTH: 0.157383
G1 X156.968 Y125.045 E.00137
; LINE_WIDTH: 0.117071
G1 X156.933 Y124.902 E.00089
; WIPE_START
G1 X156.968 Y125.045 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X161.59 Y131.118 Z2.4 F42000
G1 X177.184 Y151.606 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X181.606 Y147.184 E.19216
G1 X181.983 Y146.273
G1 X176.273 Y151.983 E.2481
G1 X175.5 Y152.223
G1 X182.223 Y145.5 E.29214
G1 X182.391 Y144.798
G1 X174.798 Y152.391 E.32996
G1 X174.167 Y152.489
G1 X182.489 Y144.167 E.36165
G1 X182.535 Y143.588
G1 X173.588 Y152.535 E.38878
G1 X173.009 Y152.581
G1 X182.581 Y143.009 E.41591
G1 X182.583 Y142.474
G1 X172.474 Y152.583 E.43926
G1 X171.941 Y152.583
G1 X182.583 Y141.941 E.46243
G1 X182.583 Y141.408
G1 X171.408 Y152.583 E.48561
G1 X170.874 Y152.583
G1 X182.583 Y140.874 E.50878
G1 X182.583 Y140.341
G1 X170.341 Y152.583 E.53195
G1 X169.808 Y152.583
G1 X182.583 Y139.808 E.55512
G1 X182.583 Y139.275
G1 X169.275 Y152.583 E.5783
G1 X168.741 Y152.583
G1 X182.583 Y138.741 E.60147
G1 X182.583 Y138.208
G1 X168.208 Y152.583 E.62464
G1 X167.675 Y152.583
G1 X182.583 Y137.675 E.64781
G1 X182.583 Y137.142
G1 X167.142 Y152.583 E.67099
G1 X166.608 Y152.583
G1 X182.583 Y136.608 E.69416
G1 X182.583 Y136.075
G1 X166.075 Y152.583 E.71733
G1 X165.542 Y152.583
G1 X182.583 Y135.542 E.74051
G1 X182.583 Y135.009
G1 X165.009 Y152.583 E.76368
G1 X164.475 Y152.583
G1 X182.583 Y134.475 E.78685
G1 X182.583 Y133.942
G1 X163.942 Y152.583 E.81002
G1 X163.409 Y152.583
G1 X182.583 Y133.409 E.8332
G1 X182.583 Y132.876
G1 X162.876 Y152.583 E.85637
G1 X162.342 Y152.583
G1 X182.583 Y132.342 E.87954
G1 X182.583 Y131.809
G1 X161.809 Y152.583 E.90271
G1 X161.276 Y152.583
G1 X182.583 Y131.276 E.92589
G1 X182.583 Y130.743
G1 X160.742 Y152.583 E.94906
G1 X160.209 Y152.583
G1 X182.583 Y130.209 E.97223
G1 X182.583 Y129.676
G1 X159.676 Y152.583 E.9954
G1 X159.143 Y152.583
G1 X182.583 Y129.143 E1.01858
G1 X182.583 Y128.609
G1 X158.609 Y152.583 E1.04175
G1 X158.076 Y152.583
G1 X182.583 Y128.076 E1.06492
G1 X182.583 Y127.543
G1 X157.543 Y152.583 E1.08809
G1 X157.01 Y152.583
G1 X182.583 Y127.01 E1.11127
G1 X182.583 Y126.476
G1 X156.476 Y152.583 E1.13444
G1 X155.943 Y152.583
G1 X182.583 Y125.943 E1.15761
G1 X182.583 Y125.41
G1 X155.41 Y152.583 E1.18078
G1 X154.877 Y152.583
G1 X182.583 Y124.877 E1.20396
G1 X182.583 Y124.343
G1 X154.343 Y152.583 E1.22713
G1 X153.81 Y152.583
G1 X182.583 Y123.81 E1.2503
G1 X182.583 Y123.277
G1 X153.277 Y152.583 E1.27347
G1 X152.744 Y152.583
G1 X182.583 Y122.744 E1.29665
G1 X182.583 Y122.21
G1 X152.21 Y152.583 E1.31982
G1 X151.677 Y152.583
G1 X182.583 Y121.677 E1.34299
G1 X182.583 Y121.144
G1 X151.144 Y152.583 E1.36617
G1 X150.611 Y152.583
G1 X182.583 Y120.611 E1.38934
G1 X182.583 Y120.077
G1 X150.077 Y152.583 E1.41251
G1 X149.544 Y152.583
G1 X182.583 Y119.544 E1.43568
G1 X182.583 Y119.011
G1 X149.011 Y152.583 E1.45886
M73 P75 R7
G1 X148.478 Y152.583
G1 X182.583 Y118.478 E1.48203
G1 X182.583 Y117.944
G1 X147.944 Y152.583 E1.5052
G1 X147.411 Y152.583
G1 X182.583 Y117.411 E1.52837
G1 X182.583 Y116.878
G1 X146.878 Y152.583 E1.55155
G1 X146.345 Y152.583
G1 X182.583 Y116.345 E1.57472
G1 X182.583 Y115.811
G1 X145.811 Y152.583 E1.59789
M73 P75 R6
G1 X145.278 Y152.583
G1 X182.583 Y115.278 E1.62106
G1 X182.583 Y114.745
G1 X144.745 Y152.583 E1.64424
G1 X144.212 Y152.583
G1 X182.583 Y114.212 E1.66741
G1 X182.583 Y113.678
G1 X143.678 Y152.583 E1.69058
G1 X143.145 Y152.583
G1 X182.583 Y113.145 E1.71375
G1 X182.553 Y112.641
G1 X142.612 Y152.583 E1.73564
G1 X142.078 Y152.583
G1 X182.514 Y112.147 E1.75713
G1 X182.475 Y111.653
G1 X141.545 Y152.583 E1.77861
G1 X141.012 Y152.583
G1 X182.392 Y111.203 E1.79815
G1 X182.289 Y110.773
G1 X140.479 Y152.583 E1.81684
G1 X139.945 Y152.583
G1 X182.185 Y110.343 E1.83552
G1 X182.066 Y109.928
G1 X139.412 Y152.583 E1.85353
G1 X138.879 Y152.583
G1 X181.91 Y109.551 E1.86992
G1 X181.754 Y109.174
G1 X138.346 Y152.583 E1.88631
G1 X137.812 Y152.583
G1 X181.598 Y108.797 E1.90269
G1 X181.413 Y108.448
G1 X137.279 Y152.583 E1.91785
G1 X136.746 Y152.583
G1 X181.211 Y108.118 E1.93221
G1 X181.008 Y107.787
G1 X136.213 Y152.583 E1.94658
G1 X135.679 Y152.583
G1 X180.806 Y107.456 E1.96095
G1 X180.571 Y107.157
G1 X135.146 Y152.583 E1.97395
G1 X134.613 Y152.583
G1 X180.326 Y106.87 E1.98644
G1 X180.08 Y106.582
G1 X134.08 Y152.583 E1.99894
G1 X133.546 Y152.583
G1 X179.834 Y106.295 E2.01144
G1 X179.557 Y106.039
G1 X133.013 Y152.583 E2.02256
G1 X132.48 Y152.583
G1 X179.269 Y105.793 E2.03323
G1 X178.982 Y105.547
G1 X157.155 Y127.374 E.94848
G1 X157.261 Y126.735
G1 X178.694 Y105.302 E.93136
G1 X178.373 Y105.09
G1 X157.261 Y126.201 E.9174
G1 X157.22 Y125.709
G1 X178.042 Y104.887 E.90481
G1 X177.712 Y104.685
G1 X157.12 Y125.277 E.89482
G1 X156.979 Y124.884
G1 X177.381 Y104.482 E.88658
; WIPE_START
M204 S6000
G1 X175.967 Y105.896 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X170.933 Y111.634 Z2.4 F42000
G1 X156.893 Y127.636 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X131.947 Y152.583 E1.08406
G1 X131.413 Y152.583
G1 X156.971 Y127.025 E1.11058
G1 X156.996 Y126.467
G1 X130.88 Y152.583 E1.13485
G1 X130.347 Y152.583
G1 X156.976 Y125.953 E1.15718
G1 X156.933 Y125.463
G1 X129.814 Y152.583 E1.17847
G1 X129.28 Y152.583
G1 X156.889 Y124.974 E1.19975
; WIPE_START
M204 S6000
G1 X155.475 Y126.388 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
M73 P76 R6
G1 X160.806 Y120.925 Z2.4 F42000
G1 X177.008 Y104.321 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X128.747 Y152.583 E2.09718
G1 X128.214 Y152.583
G1 X176.631 Y104.165 E2.10397
G1 X176.254 Y104.009
G1 X127.681 Y152.583 E2.11075
G1 X127.147 Y152.583
G1 X147.683 Y132.047 E.89236
G1 X147.635 Y131.562
G1 X126.614 Y152.583 E.91345
G1 X126.081 Y152.583
G1 X147.554 Y131.11 E.9331
G1 X147.44 Y130.69
G1 X125.547 Y152.583 E.95134
; WIPE_START
M204 S6000
G1 X126.962 Y151.168 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X132.57 Y145.991 Z2.4 F42000
G1 X147.782 Y131.947 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X175.865 Y103.865 E1.22033
G1 X175.435 Y103.761
G1 X147.748 Y131.449 E1.20314
G1 X147.647 Y131.016
G1 X175.005 Y103.658 E1.18884
G1 X174.575 Y103.555
G1 X147.506 Y130.624 E1.17627
; WIPE_START
M204 S6000
G1 X148.921 Y129.21 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.463 Y134.545 Z2.4 F42000
G1 X125.014 Y152.583 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X174.092 Y103.505 E2.13268
G1 X173.598 Y103.466
G1 X124.481 Y152.583 E2.13437
G1 X123.948 Y152.583
G1 X173.104 Y103.427 E2.13606
G1 X172.58 Y103.417
G1 X150.827 Y125.171 E.94528
G1 X150.548 Y125.449
G1 X123.414 Y152.583 E1.17909
G1 X122.881 Y152.583
G1 X172.046 Y103.417 E2.13647
G1 X171.513 Y103.417
G1 X122.348 Y152.583 E2.13647
G1 X121.815 Y152.583
G1 X170.98 Y103.417 E2.13647
G1 X170.447 Y103.417
G1 X121.281 Y152.583 E2.13647
G1 X120.748 Y152.583
G1 X169.913 Y103.417 E2.13647
G1 X169.38 Y103.417
G1 X141.92 Y130.878 E1.19328
G1 X141.254 Y131.543
G1 X138.471 Y134.327 E.12096
G1 X138.413 Y133.852
G1 X168.847 Y103.417 E1.32251
G1 X168.314 Y103.417
G1 X138.342 Y133.389 E1.3024
G1 X138.257 Y134.54
G1 X120.215 Y152.583 E.78404
G1 X119.682 Y152.583
G1 X138.224 Y134.04 E.80576
G1 X138.296 Y133.435
G1 X119.148 Y152.583 E.83205
G1 X118.615 Y152.583
G1 X167.78 Y103.417 E2.13647
G1 X167.247 Y103.417
G1 X147.71 Y122.955 E.84899
G1 X147.702 Y122.963
G1 X118.082 Y152.583 E1.28714
G1 X117.549 Y152.583
G1 X166.714 Y103.417 E2.13647
G1 X166.181 Y103.417
G1 X117.015 Y152.583 E2.13647
G1 X116.482 Y152.583
G1 X165.647 Y103.417 E2.13647
G1 X165.114 Y103.417
G1 X115.949 Y152.583 E2.13647
G1 X115.416 Y152.583
G1 X164.581 Y103.417 E2.13647
G1 X164.048 Y103.417
G1 X114.882 Y152.583 E2.13647
G1 X114.349 Y152.583
G1 X163.514 Y103.417 E2.13647
G1 X162.981 Y103.417
G1 X113.816 Y152.583 E2.13647
G1 X113.283 Y152.583
G1 X162.448 Y103.417 E2.13647
G1 X161.915 Y103.417
G1 X112.749 Y152.583 E2.13647
G1 X112.216 Y152.583
G1 X161.381 Y103.417 E2.13647
G1 X160.848 Y103.417
G1 X141.41 Y122.855 E.84467
G1 X141.357 Y122.909
G1 X111.683 Y152.583 E1.28947
G1 X111.15 Y152.583
G1 X160.315 Y103.417 E2.13647
G1 X159.782 Y103.417
G1 X136.193 Y127.006 E1.02504
G1 X136.234 Y126.432
G1 X159.248 Y103.417 E1.00009
G1 X158.715 Y103.417
G1 X136.204 Y125.928 E.97821
G1 X136.138 Y125.461
G1 X158.182 Y103.417 E.95791
; WIPE_START
M204 S6000
G1 X156.768 Y104.832 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
M73 P77 R6
G1 X151.575 Y110.426 Z2.4 F42000
G1 X136.113 Y127.086 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X110.616 Y152.583 E1.10795
G1 X110.083 Y152.583
G1 X136.135 Y126.531 E1.13208
G1 X136.106 Y126.027
G1 X109.55 Y152.583 E1.15398
G1 X109.017 Y152.583
G1 X126.194 Y135.405 E.74645
G1 X126.203 Y135.396
G1 X136.067 Y125.532 E.42865
; WIPE_START
M204 S6000
G1 X134.653 Y126.946 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X139.988 Y121.488 Z2.4 F42000
G1 X157.649 Y103.417 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X108.483 Y152.583 E2.13647
G1 X107.95 Y152.583
G1 X157.115 Y103.417 E2.13647
G1 X156.582 Y103.417
G1 X107.417 Y152.583 E2.13647
G1 X106.883 Y152.583
G1 X156.049 Y103.417 E2.13647
G1 X155.515 Y103.417
G1 X106.35 Y152.583 E2.13647
G1 X105.817 Y152.583
G1 X154.982 Y103.417 E2.13647
G1 X154.449 Y103.417
G1 X105.284 Y152.583 E2.13647
G1 X104.75 Y152.583
G1 X153.916 Y103.417 E2.13647
G1 X153.382 Y103.417
G1 X129.574 Y127.225 E1.03457
G1 X129.547 Y126.719
G1 X152.849 Y103.417 E1.01257
G1 X152.316 Y103.417
G1 X129.548 Y126.185 E.98938
G1 X129.575 Y125.625
G1 X151.783 Y103.417 E.96503
; WIPE_START
M204 S6000
G1 X150.368 Y104.832 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X145.174 Y110.424 Z2.4 F42000
G1 X129.513 Y127.287 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X104.217 Y152.583 E1.09922
G1 X103.684 Y152.583
G1 X129.461 Y126.805 E1.12016
G1 X129.446 Y126.287
G1 X103.151 Y152.583 E1.14268
G1 X102.617 Y152.583
G1 X129.485 Y125.715 E1.16751
; WIPE_START
M204 S6000
G1 X128.071 Y127.13 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X133.406 Y121.672 Z2.4 F42000
G1 X151.249 Y103.417 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X102.084 Y152.583 E2.13647
G1 X101.551 Y152.583
G1 X150.716 Y103.417 E2.13647
G1 X150.183 Y103.417
G1 X101.018 Y152.583 E2.13647
G1 X100.484 Y152.583
G1 X149.65 Y103.417 E2.13647
G1 X149.116 Y103.417
G1 X99.951 Y152.583 E2.13647
G1 X99.418 Y152.583
G1 X148.583 Y103.417 E2.13647
G1 X148.05 Y103.417
G1 X98.885 Y152.583 E2.13647
G1 X98.351 Y152.583
G1 X147.517 Y103.417 E2.13647
G1 X146.983 Y103.417
G1 X97.818 Y152.583 E2.13647
G1 X97.285 Y152.583
G1 X146.45 Y103.417 E2.13647
G1 X145.917 Y103.417
G1 X96.752 Y152.583 E2.13647
G1 X96.218 Y152.583
G1 X145.384 Y103.417 E2.13647
G1 X144.85 Y103.417
G1 X95.685 Y152.583 E2.13647
G1 X95.152 Y152.583
G1 X144.317 Y103.417 E2.13647
G1 X143.784 Y103.417
G1 X94.619 Y152.583 E2.13647
G1 X94.085 Y152.583
G1 X143.251 Y103.417 E2.13647
G1 X142.717 Y103.417
G1 X116.389 Y129.746 E1.1441
G1 X116.116 Y130.019
G1 X93.552 Y152.583 E.98052
G1 X93.019 Y152.583
G1 X142.184 Y103.417 E2.13647
G1 X141.651 Y103.417
G1 X92.486 Y152.583 E2.13647
G1 X91.952 Y152.583
G1 X141.118 Y103.417 E2.13647
G1 X140.584 Y103.417
G1 X91.419 Y152.583 E2.13647
G1 X90.886 Y152.583
G1 X140.051 Y103.417 E2.13647
G1 X139.518 Y103.417
G1 X90.352 Y152.583 E2.13647
M73 P78 R6
G1 X89.819 Y152.583
G1 X138.984 Y103.417 E2.13647
G1 X138.451 Y103.417
G1 X89.286 Y152.583 E2.13647
G1 X88.753 Y152.583
G1 X110.339 Y130.996 E.93804
G1 X110.483 Y130.852
G1 X137.918 Y103.417 E1.19216
G1 X137.385 Y103.417
G1 X88.219 Y152.583 E2.13647
G1 X87.686 Y152.583
G1 X106.369 Y133.899 E.81188
G1 X106.414 Y133.855
G1 X136.851 Y103.417 E1.32265
G1 X136.318 Y103.417
G1 X87.153 Y152.583 E2.13647
G1 X86.62 Y152.583
G1 X135.785 Y103.417 E2.13647
G1 X135.252 Y103.417
G1 X86.086 Y152.583 E2.13647
G1 X85.553 Y152.583
G1 X134.718 Y103.417 E2.13647
G1 X134.185 Y103.417
G1 X85.02 Y152.583 E2.13647
G1 X84.487 Y152.583
G1 X133.652 Y103.417 E2.13647
G1 X133.119 Y103.417
G1 X83.953 Y152.583 E2.13647
G1 X83.42 Y152.583
G1 X132.585 Y103.417 E2.13647
G1 X132.052 Y103.417
G1 X82.896 Y152.573 E2.13606
G1 X82.402 Y152.534
G1 X115.054 Y119.882 E1.41888
G1 X115.062 Y119.874
G1 X131.519 Y103.417 E.71511
G1 X130.986 Y103.417
G1 X81.908 Y152.495 E2.13268
G1 X81.425 Y152.445
G1 X105.163 Y128.707 E1.03152
G1 X104.327 Y129.01
G1 X80.995 Y152.342 E1.01389
G1 X80.565 Y152.239
G1 X103.573 Y129.23 E.99983
G1 X102.84 Y129.43
G1 X80.135 Y152.135 E.98665
G1 X79.746 Y151.991
G1 X102.107 Y129.63 E.97169
G1 X101.374 Y129.83
G1 X79.369 Y151.835 E.95621
G1 X78.992 Y151.678
G1 X100.523 Y130.147 E.93566
M204 S10000
M73 P78 R5
G1 X99.113 Y131.024 F42000
G1 F12000
M204 S2000
G1 X78.619 Y151.518 E.89058
; WIPE_START
M204 S6000
G1 X80.033 Y150.104 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X85.634 Y144.918 Z2.4 F42000
G1 X130.452 Y103.417 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X105.831 Y128.039 E1.06993
G1 X104.887 Y128.449
G1 X129.919 Y103.417 E1.08776
G1 X129.386 Y103.417
G1 X104.156 Y128.647 E1.09637
G1 X103.424 Y128.846
G1 X128.853 Y103.417 E1.10498
G1 X128.319 Y103.417
G1 X102.693 Y129.044 E1.1136
G1 X101.947 Y129.257
G1 X127.786 Y103.417 E1.12285
G1 X127.253 Y103.417
G1 X101.201 Y129.47 E1.1321
G1 X100.306 Y129.831
G1 X126.72 Y103.417 E1.1478
G1 X126.186 Y103.417
G1 X78.288 Y151.315 E2.0814
G1 X77.958 Y151.113
M73 P79 R5
G1 X125.653 Y103.417 E2.07259
G1 X125.12 Y103.417
G1 X77.627 Y150.91 E2.06379
G1 X77.306 Y150.698
G1 X124.587 Y103.417 E2.05458
G1 X124.053 Y103.417
G1 X77.018 Y150.452 E2.0439
G1 X76.731 Y150.207
G1 X123.52 Y103.417 E2.03323
G1 X122.987 Y103.417
G1 X76.443 Y149.961 E2.02255
G1 X76.166 Y149.705
G1 X122.454 Y103.417 E2.01144
G1 X121.92 Y103.417
G1 X75.92 Y149.418 E1.99894
G1 X75.674 Y149.13
G1 X121.387 Y103.417 E1.98644
G1 X120.854 Y103.417
G1 X75.429 Y148.843 E1.97394
G1 X75.194 Y148.543
G1 X120.32 Y103.417 E1.96095
G1 X119.787 Y103.417
G1 X98.852 Y124.352 E.90972
G1 X98.937 Y123.735
G1 X119.254 Y103.417 E.88289
G1 X118.721 Y103.417
G1 X98.682 Y123.456 E.87079
G1 X98.72 Y124.484
G1 X74.992 Y148.213 E1.03112
G1 X74.789 Y147.882
G1 X98.72 Y123.951 E1.03992
G1 X98.682 Y123.456
G1 X74.587 Y147.552 E1.04705
G1 X74.402 Y147.203
G1 X118.187 Y103.417 E1.90269
G1 X117.654 Y103.417
G1 X74.246 Y146.826 E1.8863
G1 X74.09 Y146.449
G1 X117.121 Y103.417 E1.86992
G1 X116.588 Y103.417
G1 X73.934 Y146.072 E1.85353
G1 X73.815 Y145.657
G1 X116.054 Y103.417 E1.83552
G1 X115.521 Y103.417
G1 X73.711 Y145.227 E1.81683
G1 X73.608 Y144.797
G1 X114.988 Y103.417 E1.79815
G1 X114.455 Y103.417
G1 X73.525 Y144.347 E1.7786
G1 X73.486 Y143.853
G1 X113.921 Y103.417 E1.75712
G1 X113.388 Y103.417
G1 X73.447 Y143.359 E1.73564
G1 X73.417 Y142.855
G1 X112.855 Y103.417 E1.71375
G1 X112.322 Y103.417
G1 X73.417 Y142.322 E1.69058
G1 X73.417 Y141.788
G1 X111.788 Y103.417 E1.6674
G1 X111.255 Y103.417
G1 X73.417 Y141.255 E1.64423
G1 X73.417 Y140.722
G1 X83.823 Y130.316 E.45218
; WIPE_START
M204 S6000
G1 X82.409 Y131.73 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X82.561 Y131.045 Z2.4 F42000
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X73.417 Y140.189 E.39735
G1 X73.417 Y139.655
G1 X81.3 Y131.773 E.34252
; WIPE_START
M204 S6000
G1 X79.885 Y133.187 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.038 Y132.501 Z2.4 F42000
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X73.417 Y139.122 E.28769
G1 X73.417 Y138.589
G1 X79.672 Y132.334 E.2718
G1 X79.334 Y132.139
G1 X73.417 Y138.056 E.25711
G1 X73.417 Y137.522
G1 X78.996 Y131.944 E.24242
G1 X78.658 Y131.749
G1 X73.417 Y136.989 E.22772
G1 X73.417 Y136.456
G1 X78.32 Y131.553 E.21303
G1 X77.982 Y131.358
G1 X73.417 Y135.923 E.19834
G1 X73.417 Y135.389
G1 X77.644 Y131.163 E.18365
G1 X77.306 Y130.968
G1 X73.417 Y134.856 E.16896
G1 X73.417 Y134.323
G1 X76.968 Y130.773 E.15427
G1 X76.629 Y130.577
G1 X73.417 Y133.789 E.13958
M73 P80 R5
G1 X73.417 Y133.256
G1 X76.291 Y130.382 E.12489
G1 X76.083 Y130.058
G1 X73.417 Y132.723 E.11582
G1 X73.417 Y132.19
G1 X76.083 Y129.524 E.11582
G1 X76.083 Y128.991
G1 X73.417 Y131.656 E.11582
G1 X73.417 Y131.123
G1 X76.083 Y128.458 E.11582
G1 X76.083 Y127.925
G1 X73.417 Y130.59 E.11582
G1 X73.417 Y130.057
G1 X76.083 Y127.391 E.11582
G1 X76.083 Y126.858
G1 X73.417 Y129.523 E.11582
G1 X73.417 Y128.99
G1 X76.083 Y126.325 E.11582
G1 X76.083 Y125.792
G1 X73.417 Y128.457 E.11582
; WIPE_START
M204 S6000
G1 X74.832 Y127.043 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X82.036 Y129.563 Z2.4 F42000
G1 X83.917 Y130.222 Z2.4
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X110.722 Y103.417 E1.16478
G1 X110.189 Y103.417
G1 X83.917 Y129.689 E1.14161
G1 X83.917 Y129.155
G1 X109.655 Y103.417 E1.11844
G1 X109.122 Y103.417
G1 X83.917 Y128.622 E1.09527
G1 X83.917 Y128.089
G1 X108.589 Y103.417 E1.07209
G1 X108.056 Y103.417
G1 X83.917 Y127.556 E1.04892
G1 X83.917 Y127.022
G1 X107.522 Y103.417 E1.02575
G1 X106.989 Y103.417
G1 X83.917 Y126.489 E1.00258
G1 X83.917 Y125.956
G1 X106.456 Y103.417 E.9794
G1 X105.923 Y103.417
G1 X83.717 Y125.623 E.96493
G1 X83.379 Y125.428
G1 X105.389 Y103.417 E.95645
G1 X104.856 Y103.417
G1 X83.041 Y125.232 E.94797
G1 X82.703 Y125.037
G1 X104.323 Y103.417 E.93948
G1 X103.789 Y103.417
G1 X82.365 Y124.842 E.931
G1 X82.027 Y124.647
G1 X103.256 Y103.417 E.92252
G1 X102.723 Y103.417
G1 X81.689 Y124.452 E.91404
G1 X81.351 Y124.256
G1 X102.19 Y103.417 E.90556
G1 X101.656 Y103.417
G1 X81.013 Y124.061 E.89708
G1 X80.675 Y123.866
G1 X101.123 Y103.417 E.88859
G1 X100.59 Y103.417
G1 X80.336 Y123.671 E.88011
G1 X79.994 Y123.48
G1 X100.057 Y103.417 E.87182
G1 X99.523 Y103.417
G1 X78.732 Y124.208 E.90347
; WIPE_START
M204 S6000
G1 X80.147 Y122.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X77.471 Y124.937 Z2.4 F42000
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X98.99 Y103.417 E.93513
G1 X98.457 Y103.417
G1 X76.209 Y125.665 E.96678
; WIPE_START
M204 S6000
G1 X77.623 Y124.251 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X73.417 Y127.924 Z2.4 F42000
G1 Z2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X97.924 Y103.417 E1.06492
G1 X97.39 Y103.417
G1 X73.417 Y127.39 E1.04174
G1 X73.417 Y126.857
G1 X96.857 Y103.417 E1.01857
G1 X96.324 Y103.417
G1 X73.417 Y126.324 E.9954
G1 X73.417 Y125.791
G1 X95.791 Y103.417 E.97223
G1 X95.257 Y103.417
G1 X73.417 Y125.257 E.94905
G1 X73.417 Y124.724
G1 X94.724 Y103.417 E.92588
G1 X94.191 Y103.417
G1 X73.417 Y124.191 E.90271
G1 X73.417 Y123.658
G1 X93.658 Y103.417 E.87954
G1 X93.124 Y103.417
G1 X73.417 Y123.124 E.85636
G1 X73.417 Y122.591
G1 X92.591 Y103.417 E.83319
G1 X92.058 Y103.417
G1 X73.417 Y122.058 E.81002
G1 X73.417 Y121.525
G1 X91.525 Y103.417 E.78684
G1 X90.991 Y103.417
G1 X73.417 Y120.991 E.76367
G1 X73.417 Y120.458
G1 X90.458 Y103.417 E.7405
G1 X89.925 Y103.417
G1 X73.417 Y119.925 E.71733
G1 X73.417 Y119.392
G1 X89.392 Y103.417 E.69415
G1 X88.858 Y103.417
G1 X73.417 Y118.858 E.67098
G1 X73.417 Y118.325
G1 X88.325 Y103.417 E.64781
G1 X87.792 Y103.417
G1 X73.417 Y117.792 E.62464
G1 X73.417 Y117.258
G1 X87.259 Y103.417 E.60146
G1 X86.725 Y103.417
G1 X73.417 Y116.725 E.57829
G1 X73.417 Y116.192
G1 X86.192 Y103.417 E.55512
G1 X85.659 Y103.417
G1 X73.417 Y115.659 E.53195
G1 X73.417 Y115.125
G1 X85.125 Y103.417 E.50877
G1 X84.592 Y103.417
G1 X73.417 Y114.592 E.4856
G1 X73.417 Y114.059
G1 X84.059 Y103.417 E.46243
G1 X83.526 Y103.417
G1 X73.417 Y113.526 E.43926
G1 X73.419 Y112.99
G1 X82.99 Y103.419 E.4159
G1 X82.412 Y103.465
G1 X73.465 Y112.412 E.38877
G1 X73.511 Y111.833
G1 X81.833 Y103.511 E.36164
G1 X81.201 Y103.609
G1 X73.609 Y111.201 E.32995
G1 X73.777 Y110.5
G1 X80.5 Y103.777 E.29213
G1 X79.726 Y104.017
G1 X74.017 Y109.726 E.24809
G1 X74.394 Y108.816
G1 X78.816 Y104.394 E.19214
M204 S10000
G1 X78.136 Y104.78 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.108723
G1 F15000
M204 S6000
G1 X77.995 Y104.891 E.00096
; LINE_WIDTH: 0.149846
G1 X77.854 Y105.002 E.00156
; LINE_WIDTH: 0.19097
G1 X77.713 Y105.113 E.00216
; LINE_WIDTH: 0.232093
G1 X77.572 Y105.224 E.00277
; LINE_WIDTH: 0.273216
G1 X77.431 Y105.335 E.00337
; LINE_WIDTH: 0.313197
G1 X77.068 Y105.671 E.01089
; LINE_WIDTH: 0.352016
G1 X76.705 Y106.006 E.01245
; LINE_WIDTH: 0.390834
G1 F13796.509
G1 X76.342 Y106.342 E.01402
; LINE_WIDTH: 0.390825
G1 X76.006 Y106.705 E.01402
; LINE_WIDTH: 0.352006
G1 F15000
G1 X75.671 Y107.068 E.01245
; LINE_WIDTH: 0.313187
G1 X75.335 Y107.431 E.01089
; LINE_WIDTH: 0.273212
G1 X75.224 Y107.572 E.00337
; LINE_WIDTH: 0.23209
G1 X75.113 Y107.713 E.00277
; LINE_WIDTH: 0.190968
G1 X75.002 Y107.854 E.00216
; LINE_WIDTH: 0.149845
G1 X74.891 Y107.995 E.00156
; LINE_WIDTH: 0.108723
G1 X74.78 Y108.136 E.00096
; WIPE_START
M73 P81 R5
G1 X74.891 Y107.995 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X79.228 Y104.223 Z2.4 F42000
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.108514
G1 F15000
M204 S6000
G1 X79.112 Y104.301 E.00075
; LINE_WIDTH: 0.149193
G1 X78.995 Y104.379 E.00121
; LINE_WIDTH: 0.189871
G1 X78.878 Y104.457 E.00168
; WIPE_START
G1 X78.995 Y104.379 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X86.627 Y104.345 Z2.4 F42000
G1 X176.043 Y103.953 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.105645
G1 F15000
M204 S6000
G1 X175.893 Y103.869 E.00088
; WIPE_START
G1 X176.043 Y103.953 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X176.937 Y111.533 Z2.4 F42000
G1 X181.221 Y147.864 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.108732
G1 F15000
M204 S6000
G1 X181.11 Y148.005 E.00096
; LINE_WIDTH: 0.149875
G1 X180.998 Y148.146 E.00156
; LINE_WIDTH: 0.191017
G1 X180.887 Y148.287 E.00217
; LINE_WIDTH: 0.232159
G1 X180.776 Y148.428 E.00277
; LINE_WIDTH: 0.273301
G1 X180.665 Y148.569 E.00337
; LINE_WIDTH: 0.313274
G1 X180.329 Y148.932 E.01089
; LINE_WIDTH: 0.352097
G1 X179.994 Y149.295 E.01246
; LINE_WIDTH: 0.390921
G1 F13793.074
G1 X179.658 Y149.658 E.01402
; LINE_WIDTH: 0.390919
G1 X179.295 Y149.994 E.01402
; LINE_WIDTH: 0.3521
G1 F15000
G1 X178.932 Y150.329 E.01246
; LINE_WIDTH: 0.313282
G1 X178.569 Y150.665 E.01089
; LINE_WIDTH: 0.273306
G1 X178.428 Y150.776 E.00337
; LINE_WIDTH: 0.232163
G1 X178.287 Y150.887 E.00277
; LINE_WIDTH: 0.191019
G1 X178.146 Y150.998 E.00217
; LINE_WIDTH: 0.149876
G1 X178.005 Y151.109 E.00156
; LINE_WIDTH: 0.108733
G1 X177.864 Y151.221 E.00096
M204 S10000
G1 X177.121 Y151.543 F42000
; LINE_WIDTH: 0.189876
G1 F15000
M204 S6000
G1 X177.005 Y151.621 E.00168
; LINE_WIDTH: 0.149195
G1 X176.888 Y151.699 E.00121
; LINE_WIDTH: 0.108515
G1 X176.772 Y151.777 E.00075
; WIPE_START
G1 X176.888 Y151.699 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X169.821 Y148.818 Z2.4 F42000
G1 X74.08 Y109.789 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.188353
G1 F15000
M204 S6000
G1 X73.97 Y109.953 E.00235
; LINE_WIDTH: 0.144665
G1 X73.86 Y110.118 E.00164
; WIPE_START
G1 X73.97 Y109.953 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X76.37 Y117.199 Z2.4 F42000
G1 X78.671 Y124.147 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.20094
G1 F15000
M204 S6000
G1 X78.504 Y124.276 E.00271
; LINE_WIDTH: 0.155834
G1 X78.337 Y124.404 E.00194
; LINE_WIDTH: 0.110728
G1 X78.17 Y124.532 E.00116
; WIPE_START
G1 X78.337 Y124.404 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X79.933 Y123.419 Z2.4 F42000
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.200922
G1 F15000
M204 S6000
G1 X79.766 Y123.547 E.00271
; LINE_WIDTH: 0.155823
G1 X79.599 Y123.676 E.00194
; LINE_WIDTH: 0.110724
G1 X79.432 Y123.804 E.00116
; WIPE_START
G1 X79.599 Y123.676 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X83.014 Y130.501 Z2.4 F42000
G1 X83.124 Y130.721 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.110727
G1 F15000
M204 S6000
G1 X82.957 Y130.849 E.00116
; LINE_WIDTH: 0.15583
G1 X82.789 Y130.977 E.00194
; LINE_WIDTH: 0.200933
G1 X82.622 Y131.106 E.00271
M204 S10000
G1 X81.862 Y131.449 F42000
; LINE_WIDTH: 0.110728
G1 F15000
M204 S6000
G1 X81.695 Y131.578 E.00116
; LINE_WIDTH: 0.155833
G1 X81.528 Y131.706 E.00194
; LINE_WIDTH: 0.200938
G1 X81.361 Y131.834 E.00271
M204 S10000
G1 X80.6 Y132.178 F42000
; LINE_WIDTH: 0.110728
G1 F15000
M204 S6000
G1 X80.433 Y132.306 E.00116
; LINE_WIDTH: 0.155834
G1 X80.266 Y132.434 E.00194
; LINE_WIDTH: 0.200939
G1 X80.099 Y132.562 E.00271
; WIPE_START
G1 X80.266 Y132.434 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X77.568 Y125.295 Z2.4 F42000
G1 X77.41 Y124.876 Z2.4
G1 Z2
G1 E.8 F1800
G1 F15000
M204 S6000
G1 X77.242 Y125.004 E.00271
; LINE_WIDTH: 0.155834
G1 X77.075 Y125.132 E.00194
; LINE_WIDTH: 0.110728
G1 X76.908 Y125.261 E.00116
; WIPE_START
G1 X77.075 Y125.132 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X84.704 Y124.882 Z2.4 F42000
G1 X98.916 Y124.416 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.107642
G1 F15000
M204 S6000
G1 X98.94 Y124.486 E.00039
G1 X98.824 Y124.588 E.00082
; WIPE_START
G1 X98.94 Y124.486 E-.51433
G1 X98.916 Y124.416 E-.24567
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X99.788 Y130.585 Z2.4 F42000
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.104158
G1 F15000
M204 S6000
G2 X99.231 Y131.141 I3.108 J3.674 E.00393
M204 S10000
G1 X100.245 Y129.77 F42000
; LINE_WIDTH: 0.206713
G1 F15000
M204 S6000
G1 X100.103 Y129.881 E.0024
; LINE_WIDTH: 0.170234
G1 X99.962 Y129.991 E.00187
; LINE_WIDTH: 0.133088
G1 X99.815 Y130.106 E.00137
; LINE_WIDTH: 0.104045
G1 X99.527 Y130.377 E.00197
G1 X99.307 Y130.62 E.00163
; LINE_WIDTH: 0.144427
G1 X99.203 Y130.755 E.00141
; LINE_WIDTH: 0.184371
G1 X99.099 Y130.89 E.00197
G2 X99.122 Y131.033 I1.897 J-.238 E.00166
M204 S10000
G1 X105.59 Y128.519 F42000
; LINE_WIDTH: 0.102939
G1 F15000
M204 S6000
G1 X105.5 Y128.586 E.00055
; LINE_WIDTH: 0.143131
G3 X105.231 Y128.775 I-2.693 J-3.535 E.00269
; WIPE_START
G1 X105.5 Y128.586 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X113.052 Y129.691 Z2.4 F42000
G1 X138.292 Y133.385 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.108384
G1 F15000
M204 S6000
G1 X138.186 Y133.279 E.0008
M204 S10000
G1 X138.591 Y134.446 F42000
; LINE_WIDTH: 0.0964756
G1 F15000
M204 S6000
G1 X138.368 Y134.651 E.00132
; WIPE_START
G1 X138.591 Y134.446 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X145.753 Y131.809 Z2.4 F42000
G1 X157.203 Y127.592 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.123386
G1 F15000
M204 S6000
G1 X157.144 Y127.363 E.00156
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X157.203 Y127.592 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 11/25
; update layer progress
M73 L11
M991 S0 P10 ;notify layer change
M106 S201.45
; OBJECT_ID: 91
M204 S10000
G17
G3 Z2.4 I.493 J-1.112 P1  F42000
G1 X150.266 Y124.516 Z2.4
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11165
M204 S6000
G1 X150.467 Y124.693 E.00887
G2 X151.073 Y125.01 I2.816 J-4.635 E.02273
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.67 J.127 E.02283
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09207
G1 X150.604 Y124.785 E-.06291
G1 X151.073 Y125.01 E-.19774
G1 X151.148 Y125.063 E-.03496
G1 X151.188 Y125.226 E-.06382
G1 X151.193 Y125.335 E-.04112
G1 X151.156 Y125.613 E-.1069
G1 X151.082 Y125.753 E-.05986
G1 X150.983 Y125.853 E-.05371
G1 X150.868 Y125.899 E-.04692
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05565
G1 X156.332 Y129.143 E.00994
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05104
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21639
G1 X157.113 Y124.547 E-.22773
G1 X157.334 Y125.082 E-.2199
G1 X157.34 Y125.107 E-.00988
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z2.6 F42000
G1 X151.408 Y134.226 Z2.6
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.312 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11165
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.409 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.101 J3.676 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01737
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.474 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.374 J1.31 E.06571
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01684
G3 X151.438 Y124.802 I-.844 J2.254 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G1 X153.4 Y122.031 E.0231
G1 X154.334 Y122.115 E.02882
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07718
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.952 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.997 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.6 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2.6
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2.6 F4000
            G39.3 S1
            G0 Z2.6 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288664
G1 F11165
M204 S6000
G2 X150.503 Y128.334 I-67.308 J20.563 E.01389
; LINE_WIDTH: 0.240746
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196968
G1 X150.466 Y128.27 E.00042
; LINE_WIDTH: 0.158763
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122907
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.12307
G1 F11165
M204 S6000
G3 X150.289 Y123.904 I1.884 J.248 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.783 Y122.454 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.118034
G1 F11165
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148768
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179222
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221067
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261707
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306029
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349879
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390997
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416987
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487693
G1 F10792.03
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.114347
G1 F11165
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149192
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.184038
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.628 J.969 E.00311
; LINE_WIDTH: 0.258736
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306094
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350098
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.403768
G3 X157.137 Y126.405 I-6.957 J1.132 E.02754
; LINE_WIDTH: 0.420586
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.448 J.056 E.01352
; LINE_WIDTH: 0.404885
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.36845
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333578
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287711
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.240001
G1 X156.87 Y128.002 E.0023
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163841
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121723
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458245
G1 F11165
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.49287
G1 F10667.863
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492632
G1 F10673.503
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453244
G1 F11165
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410294
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362667
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317817
G1 X155.306 Y129.876 E.00362
; LINE_WIDTH: 0.270716
G3 X155.153 Y129.966 I-1.203 J-1.863 E.00331
; LINE_WIDTH: 0.242568
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213434
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164563
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.1202
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.845 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74104
G1 X154.756 Y130.129 E-.01896
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11165
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.429329
G1 F11165
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401414
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359232
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z2.6 F42000
G1 X141.597 Y130.591 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11165
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00607
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.279 E.02461
G1 X140.907 Y132.132 E.01529
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.09106
G1 X141.987 Y130.622 E-.08137
G1 X142.082 Y130.683 E-.04296
G1 X142.161 Y130.77 E-.04454
G1 X142.238 Y130.969 E-.08098
G1 X142.242 Y131.177 E-.07924
G1 X142.224 Y131.286 E-.04176
G1 X142.17 Y131.407 E-.05041
G1 X142.111 Y131.472 E-.03339
G1 X141.949 Y131.564 E-.07096
G1 X141.592 Y131.686 E-.14335
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G1 X146.536 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.274 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.805 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.581 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.536 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24042
G1 X147.611 Y130.255 E-.05259
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.492 Y124.594 Z2.6 F42000
G1 X141.497 Y123.494 Z2.6
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G1 X140.687 Y122.602 E.03997
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.393 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.675 E.08799
G1 X142.476 Y123.044 E.04224
G2 X141.704 Y123.32 I.254 J1.93 E.0274
G1 X141.543 Y123.455 E.00697
M204 S250
G1 X141.812 Y123.777 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11165
M204 S5000
G2 X141.854 Y124.138 I.303 J.147 E.01179
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02112
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04923
G3 X142.359 Y131.777 I-.714 J.647 E.04533
G3 X141.865 Y132.001 I-.763 J-1.021 E.01679
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.572 Y133.741 I1.599 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.389 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.377 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.598 Y125.774 E.10991
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.35 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.873 Y123.69 I.171 J1.439 E.02232
G2 X141.843 Y123.726 I.242 J.234 E.00144
M204 S10000
G1 X141.969 Y122.881 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.19494
G1 F11165
M204 S6000
G1 X141.312 Y122.987 E.00825
M204 S10000
G1 X141.343 Y123.021 F42000
; LINE_WIDTH: 0.309709
G1 F11165
M204 S6000
G1 X142.231 Y122.806 E.01986
M204 S10000
G1 X142.395 Y122.829 F42000
; LINE_WIDTH: 0.120924
G1 F11165
M204 S6000
G1 X142.182 Y122.855 E.00136
; LINE_WIDTH: 0.168935
G1 X141.969 Y122.881 E.0022
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.114803
G1 F11165
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228092
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.275804
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323299
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370795
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.41829
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458213
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490547
G1 F10723.23
G1 X146.015 Y128.41 E.01178
; LINE_WIDTH: 0.509869
G1 F10279.506
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536685
G1 F9721.24
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.116685
G1 F11165
M204 S6000
G1 X147.211 Y130.077 E.00131
; LINE_WIDTH: 0.15623
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.190146
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235131
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.29 E.02401
; LINE_WIDTH: 0.199121
G3 X147.69 Y132.483 I-2.491 J-.125 E.00444
; LINE_WIDTH: 0.159244
G1 X147.665 Y132.605 E.00118
; LINE_WIDTH: 0.123621
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101126
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.481842
G1 F10935.883
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408375
G1 F11165
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380987
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337783
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291688
G3 X146.552 Y134.367 I-1.308 J-1.379 E.00313
; LINE_WIDTH: 0.26378
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164869
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.12127
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.110973
G1 F11165
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.147098
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185475
G1 X140.92 Y132.671 E.00137
; LINE_WIDTH: 0.218679
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247196
G1 X140.905 Y132.39 E.00324
M204 S10000
G1 X140.82 Y132.611 F42000
; LINE_WIDTH: 0.121167
G1 F11165
M204 S6000
G3 X141.111 Y132.246 I4.079 J2.951 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197928
G1 F11165
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z2.6 F42000
G1 X148.316 Y125.064 Z2.6
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.120198
G1 F11165
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.16849
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218018
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267546
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.839 Y123.724 F42000
; LINE_WIDTH: 0.119667
G1 F11165
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165149
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189842
G1 X148.28 Y124.355 E.00562
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.168972
G1 F11165
M204 S6000
G1 X147.41 Y122.819 E.00369
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.344 Z2.6 F42000
G1 X138.362 Y132.423 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11165
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.464 Y132.642 E.00739
G3 X138.732 Y134.417 I-16.322 J3.372 E.05957
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.036 J-.258 E.0123
G3 X137.949 Y134.235 I1.735 J-.307 E.00998
G3 X138.22 Y132.423 I18.45 J1.837 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.464 Y132.642 E-.08461
G1 X138.635 Y133.581 E-.36279
G1 X138.716 Y134.279 E-.26696
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11165
M204 S5000
G1 X138.849 Y132.571 E.08049
G3 X139.122 Y134.451 I-13.72 J2.954 E.05842
G3 X138.145 Y135.179 I-.8 J-.054 E.04254
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120841
G1 F11165
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168681
G1 X138.321 Y131.271 E.00163
; LINE_WIDTH: 0.216521
G1 X138.321 Y131.431 E.00225
; LINE_WIDTH: 0.264361
G1 X138.321 Y131.59 E.00287
; LINE_WIDTH: 0.312201
G1 X138.321 Y131.749 E.0035
; LINE_WIDTH: 0.360041
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.407881
G1 X138.321 Y132.068 E.00474
; LINE_WIDTH: 0.455721
G1 X138.321 Y132.227 E.00536
M204 S10000
G1 X138.322 Y133.125 F42000
; LINE_WIDTH: 0.119915
G1 F11165
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165896
G1 X138.323 Y133.405 E.0014
; LINE_WIDTH: 0.211878
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.246737
G1 X138.327 Y133.628 E.00138
; LINE_WIDTH: 0.2821
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329078
G1 X138.33 Y134.04 E.0048
; LINE_WIDTH: 0.376056
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404899
G3 X138.347 Y134.591 I-2.285 J.277 E.01023
; WIPE_START
G1 F13260.443
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z2.6 F42000
G1 X130.165 Y128.941 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11165
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.54 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07459
G1 X129.589 Y128.418 E-.20699
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.1693
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11165
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.0436
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.583 J.981 E.02847
G3 X132.549 Y122.346 I1.797 J1.443 E.05492
G3 X133.879 Y122.579 I.256 J2.458 E.04203
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.269 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17177
G1 X130.87 Y129.484 E-.18909
G1 X130.611 Y129.024 E-.20072
G1 X130.436 Y128.532 E-.19843
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11165
M204 S6000
G1 X135.718 Y128.329 E.01884
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00775
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.615 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21996
G1 X135.838 Y127.552 E-.29887
G1 X135.861 Y126.918 E-.24117
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11165
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01978
G3 X132.054 Y122.087 I2.312 J3.282 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.468 Y122.088 E.02188
G1 X134.11 Y122.249 E.02033
G3 X135.81 Y123.337 I-1.344 J3.968 E.06263
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02264
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01954
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231591
G1 F11165
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.157419
G3 X129.663 Y124.948 I4.238 J.72 E.00388
; LINE_WIDTH: 0.113013
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11165
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120933
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.505437
G1 F10378.014
M204 S6000
G1 X130.3 Y129.361 E.0127
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448144
G1 F11165
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403265
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361945
G2 X130.709 Y129.835 I1.863 J-1.64 E.00554
; LINE_WIDTH: 0.326593
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289357
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252121
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218536
G2 X131.122 Y130.176 I1.358 J-1.68 E.00264
; LINE_WIDTH: 0.185252
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146087
G1 X131.343 Y130.313 E.00109
; LINE_WIDTH: 0.1114
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.313 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.116566
G1 F11165
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.155866
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183743
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211099
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249545
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286364
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327161
G2 X135.106 Y129.695 I-1.109 J-1.138 E.00452
; LINE_WIDTH: 0.374463
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416508
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.44333
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492704
G1 F10671.801
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11165
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.144281
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216423
G2 X136.18 Y126.581 I-15.984 J-1.601 E.01171
; LINE_WIDTH: 0.243733
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232294
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193679
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149197
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.487652
G1 F10793.014
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445965
G1 F11165
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401288
G2 X135.075 Y123.17 I-2.194 J1.708 E.0068
; LINE_WIDTH: 0.370002
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344931
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307422
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269913
G1 X134.754 Y122.886 E.00217
; LINE_WIDTH: 0.230226
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201492
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170268
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124756
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994647
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.0995103
G1 F11165
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127456
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.17727
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204257
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224469
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260959
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300058
G2 X130.759 Y122.986 I1.394 J1.823 E.00351
M204 S10000
G1 X130.741 Y122.833 F42000
; LINE_WIDTH: 0.513097
G1 F10208.919
M204 S6000
G1 X130.191 Y123.685 E.03887
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444811
G1 F11165
M204 S6000
G3 X130.649 Y123.102 I6.921 J5.505 E.02451
; LINE_WIDTH: 0.396816
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361839
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11165
M204 S6000
G1 X126.511 Y122.956 E.00451
G2 X126.456 Y123.302 I1.263 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.383 J-.863 E.03159
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03092
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11165
M204 S5000
G2 X126.848 Y123.318 I.823 J.356 E.0109
G1 X126.848 Y136.086 E.3923
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02984
G2 X125.638 Y134.406 I-1.364 J-.568 E.01832
G1 X125.638 Y123.519 E.33453
G2 X124.736 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.762 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.676 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.100155
G1 F11165
M204 S6000
G3 X127.108 Y122.406 I1.882 J1.453 E.00121
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101502
G1 F11165
M204 S6000
G2 X126.981 Y122.483 I.461 J2.572 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.120568
G1 F11165
M204 S6000
G1 X126.207 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.655 F42000
; LINE_WIDTH: 0.118087
G1 F11165
M204 S6000
G2 X125.339 Y122.406 I-3.261 J2.343 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162116
G1 F11165
M204 S6000
G3 X125.481 Y122.505 I-.968 J3.734 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z2.6 F42000
G1 X126.229 Y134.783 Z2.6
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.121602
G1 F11165
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.16952
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215622
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255219
G1 X126.11 Y135.45 E.00305
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.09918
G1 F11165
M204 S6000
G1 X125.253 Y135.591 E.00024
; LINE_WIDTH: 0.121678
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162886
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149314
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114386
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z2.6 F42000
M73 P82 R5
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11165
M204 S6000
G1 X121.949 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.214 J-1.122 E.01652
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02034
; WIPE_START
G1 F11791.304
G1 X121.949 Y130.272 E-.02629
G1 X122.103 Y130.078 E-.10816
G1 X122.227 Y129.861 E-.10894
G1 X122.348 Y130.013 E-.08483
G1 X122.622 Y130.272 E-.16431
G1 X122.009 Y130.272 E-.26747
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.494 J-1.547 E.0228
G1 X119.209 Y122.767 E.25567
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.212 J-.26 E.01414
G1 X115.542 Y130.272 E.04437
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02309
G1 X115.742 Y129.968 E-.15236
G1 X115.891 Y129.724 E-.10857
G1 X116.431 Y128.593 E-.47599
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z2.6 F42000
G1 X115.146 Y120.124 Z2.6
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02174
G3 X115.054 Y119.165 I.729 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01656
G3 X115.338 Y120.007 I-.694 J.19 E.00585
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07711
G1 X114.92 Y120.097 E-.03258
G1 X114.825 Y120.029 E-.04443
G1 X114.777 Y119.962 E-.03118
G1 X114.732 Y119.747 E-.08368
G1 X114.744 Y119.605 E-.05391
G1 X114.804 Y119.434 E-.06884
G1 X114.934 Y119.264 E-.08154
G1 X115.054 Y119.165 E-.05911
G1 X115.378 Y118.976 E-.14243
G1 X115.317 Y119.192 E-.08517
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z2.6 F42000
G1 X110.311 Y130.57 Z2.6
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G1 X110.311 Y124.008 E.21767
G3 X110.778 Y122.825 I1.61 J-.049 E.04339
G3 X111.024 Y122.655 I.648 J.673 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.203 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.49 J1.893 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11165
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05006
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.369 J.9 E.02871
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.322 J-3.234 E.02985
G2 X115.546 Y129.537 I-.692 J-1.249 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.345 J.36 E.01893
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.04541
G3 X116.238 Y118.625 I.624 J2.483 E.03217
G3 X117.568 Y119.2 I-.683 J3.402 E.04487
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.65 Y130.298 I1.574 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20009
G3 X117.08 Y129.654 I-.534 J.963 E.00785
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.832 E.01819
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.10262
G1 F11165
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124331
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.15516
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11165
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209474
G2 X110.837 Y132.758 I-2.963 J.173 E.00342
; LINE_WIDTH: 0.255818
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.29829
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340761
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383233
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425705
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225198
G1 F11165
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11165
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.13262
G1 F11165
M204 S6000
G2 X115.218 Y130.242 I-2.704 J-3.566 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.114071
G1 F11165
M204 S6000
G2 X117.278 Y130.468 I2.256 J-1.677 E.00132
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112472
G1 F11165
M204 S6000
G3 X117.164 Y130.396 I.572 J-2.752 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.130483
G1 F11165
M204 S6000
G2 X121.609 Y130.384 I-.567 J-4.799 E.00274
M204 S10000
G1 X121.689 Y130.247 F42000
; LINE_WIDTH: 0.117442
G1 F11165
M204 S6000
G3 X121.435 Y130.468 I-2.946 J-3.139 E.00204
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115509
G1 F11165
M204 S6000
G3 X122.174 Y129.56 I-3.497 J.846 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107572
G1 F11165
M204 S6000
G2 X122.185 Y129.406 I-3.516 J-1.372 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115581
G1 F11165
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152901
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11165
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.42 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z2.6 F42000
G1 X116.263 Y118.858 Z2.6
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.106041
G1 F11165
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.134288
G1 X115.927 Y118.851 E.00107
; LINE_WIDTH: 0.175063
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.209991
G2 X115.601 Y118.909 I.297 J1.81 E.00275
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.167822
G1 F11165
M204 S6000
G1 X115.775 Y118.785 E.00388
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.173072
G1 F11165
M204 S6000
G2 X115.008 Y119.749 I1.82 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146585
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.110394
G1 F11165
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139243
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166711
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200519
G2 X111.979 Y122.317 I.107 J1.466 E.002
; LINE_WIDTH: 0.238887
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282908
G2 X111.737 Y122.375 I.318 J1.59 E.00265
; LINE_WIDTH: 0.321791
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354812
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394161
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.43322
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.44062
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413524
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12951.857
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z2.6 F42000
G1 Z2.2
M73 P82 R4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11165
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.863 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.02339
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.539 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.736 J143.296 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16427
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17942
G1 X107.392 Y126.398 E-.09723
G1 X107.334 Y126.831 E-.16577
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z2.6 F42000
G1 X99.457 Y123.958 Z2.6
G1 Z2.2
G1 E.8 F1800
G1 F11165
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16577
G1 X98.647 Y125.201 E-.40512
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z2.6 F42000
G1 X105.735 Y134.549 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11165
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.0221
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.79 J143.439 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.001 E.04759
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02604
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.887 Y122.047 E.01372
G1 X104.633 Y122.156 E.02316
G1 X105.254 Y122.343 E.01992
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.35 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.07 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01715
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04056
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115012
G1 F11165
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133197
G1 F11165
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70026
G1 X105.695 Y134.21 E-.05974
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11165
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.10673
G1 F11165
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131363
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159975
G1 X99.768 Y134.976 E.00117
; LINE_WIDTH: 0.191713
G3 X99.549 Y134.747 I1.565 J-1.71 E.00384
; LINE_WIDTH: 0.240283
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288569
G3 X99.236 Y134.303 I1.661 J-1.142 E.00336
; LINE_WIDTH: 0.33669
G3 X99.087 Y134.016 I3.593 J-2.034 E.00776
; LINE_WIDTH: 0.374662
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400401
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478967
G1 F11007.984
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516466
G1 F10136.307
G1 X98.864 Y133.31 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.916
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.31 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.114966
G1 F11165
M204 S6000
G1 X98.932 Y131.648 E.00084
; LINE_WIDTH: 0.153117
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197168
G1 X99.03 Y131.383 E.0013
; LINE_WIDTH: 0.230954
G1 X99.068 Y131.287 E.00158
; LINE_WIDTH: 0.261687
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291523
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322972
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351171
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379441
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.41543
G3 X99.539 Y130.599 I.679 J.512 E.00581
; LINE_WIDTH: 0.447773
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.46498
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494307
G1 F10633.898
G3 X100.388 Y129.998 I2.92 J4.151 E.02484
; LINE_WIDTH: 0.542813
G1 F9602.065
G3 X101.286 Y129.65 I3.46 J7.593 E.03925
G2 X104.541 Y128.735 I-51.597 J-189.731 E.13774
; LINE_WIDTH: 0.49371
G1 F10647.994
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471704
G1 F11165
G2 X105.695 Y128.292 I-2.401 J-6.616 E.02706
; LINE_WIDTH: 0.433676
G2 X106.262 Y127.934 I-2.208 J-4.128 E.02137
; LINE_WIDTH: 0.383732
G2 X106.523 Y127.695 I-2.948 J-3.476 E.00983
; LINE_WIDTH: 0.348851
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320203
G2 X106.735 Y127.443 I-1.832 J-1.573 E.00443
; LINE_WIDTH: 0.292291
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.25599
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220473
G2 X106.983 Y127.022 I-1.062 J-.632 E.00295
; LINE_WIDTH: 0.180148
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.146805
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.112566
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.258 Y125.476 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.563057
G1 F9228.345
M204 S6000
G2 X107.177 Y124.94 I-7.344 J.847 E.02298
; LINE_WIDTH: 0.522393
G1 F10010.999
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486123
G1 F10830.258
G2 X107.11 Y124.691 I-1.79 J.407 E.00528
; LINE_WIDTH: 0.4477
G1 F11165
G1 X107.004 Y124.385 E.01066
; LINE_WIDTH: 0.402694
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374813
G1 X106.924 Y124.208 E.00074
; LINE_WIDTH: 0.358815
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.32626
G2 X106.694 Y123.803 I-1.504 J.717 E.00622
; LINE_WIDTH: 0.296002
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276536
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240872
G2 X106.371 Y123.389 I-2.494 J1.785 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184717
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153188
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120214
G2 X105.616 Y122.762 I-1.87 J2.162 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z2.6 F42000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.122043
G1 F11165
M204 S6000
G2 X99.912 Y123.647 I9.345 J11.941 E.00482
; LINE_WIDTH: 0.147271
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173381
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428294
G1 F11165
M204 S6000
G1 X98.671 Y124.661 E.03158
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11165
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 12/25
; update layer progress
M73 L12
M991 S0 P11 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z2.6 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11454
M204 S6000
G1 X150.467 Y124.693 E.00887
G2 X151.073 Y125.01 I2.816 J-4.635 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.67 J.127 E.02282
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09207
G1 X150.604 Y124.785 E-.06291
G1 X151.073 Y125.01 E-.19773
G1 X151.148 Y125.063 E-.03496
G1 X151.188 Y125.226 E-.06384
G1 X151.193 Y125.335 E-.04109
G1 X151.156 Y125.613 E-.1069
G1 X151.082 Y125.753 E-.05987
G1 X150.983 Y125.853 E-.05373
G1 X150.868 Y125.899 E-.04691
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21643
G1 X157.113 Y124.547 E-.22769
G1 X157.334 Y125.082 E-.21992
G1 X157.34 Y125.107 E-.00986
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z2.8 F42000
G1 X151.408 Y134.226 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.56 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11454
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.409 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.101 J3.676 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01737
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.474 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.373 J1.31 E.06572
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01684
G3 X151.438 Y124.802 I-.844 J2.254 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G1 X153.393 Y122.031 E.02289
G1 X154.334 Y122.116 E.02903
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.8 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2.8
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2.8 F4000
            G39.3 S1
            G0 Z2.8 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288649
G1 F11454
M204 S6000
G2 X150.503 Y128.334 I-63.577 J19.39 E.01388
; LINE_WIDTH: 0.240753
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.197007
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158725
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122777
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.216 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.123083
G1 F11454
M204 S6000
G3 X150.289 Y123.904 I1.878 J.246 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.216 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.118039
G1 F11454
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148768
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179224
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221068
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261707
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306024
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349864
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390973
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416958
G1 X156.253 Y123.483 E.01433
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487701
G1 F10791.828
M204 S6000
G1 X155.547 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.114348
G1 F11454
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149195
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.184042
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.63 J.969 E.00311
; LINE_WIDTH: 0.258737
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306094
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350094
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.403772
G3 X157.137 Y126.405 I-6.962 J1.133 E.02755
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368453
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458157
G1 F11454
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492799
G1 F10669.548
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492631
G1 F10673.519
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453249
G1 F11454
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410311
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362696
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317833
G1 X155.306 Y129.876 E.00363
; LINE_WIDTH: 0.270718
G3 X155.153 Y129.966 I-1.209 J-1.873 E.00331
; LINE_WIDTH: 0.24256
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213434
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164563
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120201
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.843 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74104
G1 X154.756 Y130.129 E-.01896
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11454
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.429348
G1 F11454
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401446
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359257
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z2.8 F42000
G1 X141.597 Y130.591 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11454
M204 S6000
G3 X141.778 Y130.574 I.14 J.518 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.28 E.02461
G1 X140.907 Y132.132 E.01529
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.392 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.09111
G1 X141.987 Y130.622 E-.08134
G1 X142.082 Y130.683 E-.04298
G1 X142.16 Y130.77 E-.04451
G1 X142.238 Y130.969 E-.081
G1 X142.242 Y131.177 E-.07921
G1 X142.207 Y131.337 E-.0623
G1 X142.148 Y131.436 E-.04359
G1 X142.033 Y131.525 E-.05565
G1 X141.949 Y131.564 E-.03503
G1 X141.592 Y131.686 E-.14328
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.769 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.204 E.01161
G2 X147.438 Y132.149 I-3.805 J-1.011 E.03535
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37646
G1 X147.551 Y130.131 E-.24041
G1 X147.611 Y130.255 E-.05259
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.528 Y124.562 Z2.8 F42000
G1 X141.547 Y123.464 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G1 X141.506 Y123.503 E.0019
G1 X140.687 Y122.602 E.04038
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.08799
G1 X142.476 Y123.044 E.04224
G2 X141.688 Y123.329 I.256 J1.936 E.02801
G1 X141.59 Y123.422 E.00446
M204 S250
G1 X141.837 Y123.733 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11454
M204 S5000
G2 X141.854 Y124.138 I.282 J.191 E.01335
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.811 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.959 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.022 E.0168
G2 X141.353 Y132.269 I.244 J1.09 E.01797
G2 X141.199 Y132.887 I.638 J.487 E.02012
G2 X141.572 Y133.741 I1.599 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.389 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.583 Y125.604 E.10465
G1 X148.598 Y125.774 E.00526
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.116 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.928 Y123.642 I.182 J1.533 E.02013
G2 X141.875 Y123.686 I.192 J.282 E.00213
M204 S10000
G1 X141.605 Y123.71 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.112834
G1 F11454
M204 S6000
G1 X141.551 Y123.786 E.00053
G1 X141.574 Y123.87 E.0005
; WIPE_START
G1 F15000
G1 X141.551 Y123.786 E-.36669
G1 X141.605 Y123.71 E-.39331
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.232 Y122.806 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.30963
G1 F11454
M204 S6000
G1 X141.343 Y123.021 E.01988
M204 S10000
G1 X141.312 Y122.987 F42000
; LINE_WIDTH: 0.19494
G1 F11454
M204 S6000
G1 X141.969 Y122.881 E.00825
; LINE_WIDTH: 0.168935
G1 X142.182 Y122.855 E.0022
; LINE_WIDTH: 0.120925
G1 X142.395 Y122.829 E.00136
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11454
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.116685
G1 F11454
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.15623
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.190147
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235137
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.25794
G3 X147.731 Y132.137 I-3.904 J1.291 E.02401
; LINE_WIDTH: 0.19914
G3 X147.69 Y132.483 I-2.524 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123626
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.481836
G1 F10936.041
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11454
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380986
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337783
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.29169
G3 X146.552 Y134.367 I-1.32 J-1.392 E.00313
; LINE_WIDTH: 0.263788
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164869
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121272
G1 X145.883 Y134.759 E.00226
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.110973
G1 F11454
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.14709
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.1855
G1 X140.92 Y132.671 E.00137
; LINE_WIDTH: 0.218745
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247235
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.612 F42000
; LINE_WIDTH: 0.121141
G1 F11454
M204 S6000
G3 X141.111 Y132.246 I3.977 J2.863 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197767
G1 F11454
M204 S6000
G1 X140.829 Y132.644 E.00619
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z2.8 F42000
G1 X148.316 Y125.064 Z2.8
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.120211
G1 F11454
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168502
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218015
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267529
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119653
G1 F11454
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165114
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189773
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.168866
G1 F11454
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.391 Y128.342 Z2.8 F42000
G1 X138.355 Y132.425 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11454
M204 S6000
G1 X138.423 Y132.425 E.00223
G3 X138.732 Y134.417 I-17.25 J3.695 E.06692
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.037 J-.259 E.0123
G3 X137.949 Y134.235 I1.739 J-.307 E.00998
G3 X138.22 Y132.424 I18.449 J1.837 E.06076
G1 X138.295 Y132.424 E.00251
; WIPE_START
G1 F11791.304
G1 X138.423 Y132.425 E-.04839
G1 X138.635 Y133.582 E-.44696
G1 X138.715 Y134.273 E-.26465
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11454
M204 S5000
G1 X138.813 Y132.382 E.07458
G3 X139.122 Y134.451 I-14.449 J3.216 E.06434
G3 X138.145 Y135.179 I-.8 J-.054 E.04254
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120862
G1 F11454
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168744
G1 X138.321 Y131.272 E.00163
; LINE_WIDTH: 0.216626
G1 X138.321 Y131.431 E.00226
; LINE_WIDTH: 0.264508
G1 X138.321 Y131.591 E.00288
; LINE_WIDTH: 0.31239
G1 X138.321 Y131.75 E.0035
; LINE_WIDTH: 0.360272
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.408154
G1 X138.321 Y132.069 E.00475
; LINE_WIDTH: 0.456036
G1 X138.321 Y132.228 E.00537
M204 S10000
G1 X138.322 Y133.127 F42000
; LINE_WIDTH: 0.119891
G1 F11454
M204 S6000
G1 X138.322 Y133.266 E.00088
; LINE_WIDTH: 0.165833
G1 X138.323 Y133.406 E.0014
; LINE_WIDTH: 0.211776
G1 X138.324 Y133.545 E.00192
; LINE_WIDTH: 0.246744
G1 X138.327 Y133.629 E.00139
; LINE_WIDTH: 0.282213
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329145
G1 X138.33 Y134.04 E.00479
; LINE_WIDTH: 0.376077
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404899
G3 X138.347 Y134.591 I-2.283 J.276 E.01024
; WIPE_START
G1 F13260.458
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z2.8 F42000
G1 X130.165 Y128.941 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11454
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11454
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.583 J.981 E.02847
G3 X132.578 Y122.345 I1.78 J1.416 E.05584
G3 X133.879 Y122.579 I.238 J2.408 E.04113
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17182
G1 X130.87 Y129.484 E-.18907
G1 X130.611 Y129.024 E-.20074
G1 X130.436 Y128.532 E-.19837
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11454
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21994
G1 X135.838 Y127.552 E-.29889
G1 X135.861 Y126.918 E-.24117
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11454
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.418 Y122.084 E.02033
G1 X134.11 Y122.249 E.02185
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
M73 P83 R4
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01954
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11454
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11454
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120934
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.505469
G1 F10377.293
M204 S6000
G1 X130.3 Y129.361 E.01271
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448161
G1 F11454
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403273
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361946
G2 X130.709 Y129.835 I1.864 J-1.641 E.00554
; LINE_WIDTH: 0.326595
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289369
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252143
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218556
G2 X131.122 Y130.176 I1.348 J-1.666 E.00264
; LINE_WIDTH: 0.185252
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146054
G1 X131.343 Y130.314 E.00109
; LINE_WIDTH: 0.111378
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.314 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.116572
G1 F11454
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183751
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211121
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327163
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.374472
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.41653
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.443388
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492719
G1 F10671.449
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11454
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216419
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149197
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.487667
G1 F10792.672
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445969
G1 F11454
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401282
G2 X135.075 Y123.17 I-2.199 J1.712 E.0068
; LINE_WIDTH: 0.36999
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344927
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307413
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269899
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230205
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201462
G1 X134.563 Y122.735 E.00145
; LINE_WIDTH: 0.170243
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124754
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994647
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.0994988
G1 F11454
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127455
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177269
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204249
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224469
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.26096
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300059
G2 X130.759 Y122.986 I1.397 J1.826 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513081
G1 F10209.275
M204 S6000
G1 X130.191 Y123.685 E.03889
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444811
G1 F11454
M204 S6000
G3 X130.649 Y123.102 I6.952 J5.533 E.02451
; LINE_WIDTH: 0.396809
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361823
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11454
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.264 J.379 E.01168
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03159
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03093
G1 X126.584 Y122.774 E.00661
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11454
M204 S5000
G2 X126.848 Y123.319 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.474 E.02911
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.764 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.676 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02504
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0998805
G1 F11454
M204 S6000
G3 X127.108 Y122.406 I1.845 J1.424 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101412
G1 F11454
M204 S6000
G2 X126.982 Y122.483 I.455 J2.551 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.120461
G1 F11454
M204 S6000
G1 X126.213 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.118131
G1 F11454
M204 S6000
G2 X125.34 Y122.406 I-3.391 J2.44 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.16208
G1 F11454
M204 S6000
G3 X125.481 Y122.505 I-1.019 J3.892 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z2.8 F42000
G1 X126.229 Y134.784 Z2.8
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.121655
G1 F11454
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169643
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215769
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255296
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991966
G1 F11454
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121697
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162908
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149323
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114388
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11454
M204 S6000
G1 X121.949 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.207 J-1.119 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02034
; WIPE_START
G1 F11791.304
G1 X121.949 Y130.272 E-.02628
G1 X122.103 Y130.078 E-.10818
G1 X122.227 Y129.861 E-.10895
G1 X122.348 Y130.013 E-.08482
G1 X122.622 Y130.272 E-.16427
G1 X122.009 Y130.272 E-.26749
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25568
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.208 J-.259 E.01414
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02309
G1 X115.742 Y129.968 E-.15236
G1 X115.891 Y129.724 E-.10852
G1 X116.431 Y128.593 E-.47604
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z2.8 F42000
G1 X115.146 Y120.124 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.379 Y118.975 E.01248
G1 X115.276 Y119.333 E.01236
G2 X115.313 Y119.833 I1.14 J.168 E.01674
G3 X115.338 Y120.007 I-.694 J.19 E.00586
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07709
G1 X114.92 Y120.097 E-.03256
G1 X114.825 Y120.029 E-.04444
G1 X114.777 Y119.962 E-.03126
G1 X114.732 Y119.747 E-.08365
G1 X114.744 Y119.606 E-.05385
G1 X114.804 Y119.434 E-.06888
G1 X114.934 Y119.264 E-.08158
G1 X115.054 Y119.165 E-.05906
G1 X115.379 Y118.975 E-.14292
G1 X115.318 Y119.19 E-.08469
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.244 Y126.176 Z2.8 F42000
G1 X110.311 Y130.57 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.648 J.673 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.943 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.491 J1.894 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11454
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.323 J-3.237 E.02985
G2 X115.546 Y129.537 I-.692 J-1.248 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06387
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.344 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X116.205 Y118.622 I.615 J2.425 E.03115
G1 X116.238 Y118.624 E.00102
G3 X117.568 Y119.2 I-.683 J3.402 E.04487
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20008
G3 X117.08 Y129.654 I-.536 J.966 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.83 E.01819
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03275
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102614
G1 F11454
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124351
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155185
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11454
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225174
G1 F11454
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11454
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132621
G1 F11454
M204 S6000
G2 X115.218 Y130.242 I-2.654 J-3.508 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.11399
G1 F11454
M204 S6000
G2 X117.278 Y130.468 I2.253 J-1.674 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112476
G1 F11454
M204 S6000
G3 X117.164 Y130.397 I.579 J-2.783 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.130468
G1 F11454
M204 S6000
G2 X121.608 Y130.384 I-.567 J-4.796 E.00274
M204 S10000
G1 X121.688 Y130.248 F42000
; LINE_WIDTH: 0.117184
G1 F11454
M204 S6000
G3 X121.435 Y130.468 I-3.034 J-3.238 E.00203
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115538
G1 F11454
M204 S6000
G3 X122.174 Y129.559 I-3.719 J.896 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107563
G1 F11454
M204 S6000
G2 X122.185 Y129.406 I-3.587 J-1.4 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115584
G1 F11454
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152912
G1 X123.235 Y130.468 E.00171
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11454
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.419 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z2.8 F42000
G1 X116.263 Y118.858 Z2.8
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.105578
G1 F11454
M204 S6000
G1 X116.071 Y118.846 E.00098
; LINE_WIDTH: 0.134314
G1 X115.927 Y118.851 E.00108
; LINE_WIDTH: 0.175128
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210043
G2 X115.602 Y118.909 I.288 J1.762 E.00273
M204 S10000
G1 X115.56 Y119.098 F42000
; LINE_WIDTH: 0.16675
G1 F11454
M204 S6000
G1 X115.776 Y118.785 E.00384
; WIPE_START
G1 F15000
G1 X115.56 Y119.098 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.173078
G1 F11454
M204 S6000
G2 X115.008 Y119.749 I1.817 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146559
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.110385
G1 F11454
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139227
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.20051
G2 X111.979 Y122.317 I.107 J1.471 E.002
; LINE_WIDTH: 0.238869
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.28287
G2 X111.737 Y122.375 I.318 J1.588 E.00265
; LINE_WIDTH: 0.321788
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354814
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394165
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433223
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440601
G1 X111.263 Y122.448 E.00551
; LINE_WIDTH: 0.413476
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12953.534
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11454
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.716 J143.222 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16431
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09725
G1 X107.334 Y126.83 E-.16571
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z2.8 F42000
G1 X99.457 Y123.958 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F11454
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z2.8 F42000
G1 X105.735 Y134.549 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11454
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.778 J143.394 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.208 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.866 Y122.046 E.01307
G1 X104.633 Y122.156 E.02381
G1 X105.254 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11454
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11454
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11454
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.106736
G1 F11454
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131365
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159974
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.19171
G3 X99.549 Y134.747 I1.56 J-1.705 E.00384
; LINE_WIDTH: 0.240256
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288573
G3 X99.236 Y134.303 I1.669 J-1.147 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.589 J-2.033 E.00775
; LINE_WIDTH: 0.374654
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400403
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435371
G3 X98.92 Y133.548 I3.525 J-1.313 E.01039
; LINE_WIDTH: 0.478969
G1 F11007.936
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516476
G1 F10136.086
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.914
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.11498
G1 F11454
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153123
G1 X98.992 Y131.479 E.00162
; LINE_WIDTH: 0.197159
G1 X99.03 Y131.383 E.0013
; LINE_WIDTH: 0.230946
G1 X99.068 Y131.287 E.00158
; LINE_WIDTH: 0.261691
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291534
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322969
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351167
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379431
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415412
G3 X99.539 Y130.599 I.679 J.512 E.00581
; LINE_WIDTH: 0.447761
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464988
G1 F11372.588
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494308
G1 F10633.867
G3 X100.388 Y129.998 I2.921 J4.152 E.02484
; LINE_WIDTH: 0.542817
G1 F9601.976
G3 X101.286 Y129.65 I3.455 J7.579 E.03925
G2 X104.541 Y128.735 I-51.669 J-189.987 E.13774
; LINE_WIDTH: 0.493705
G1 F10648.094
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.515
G2 X105.695 Y128.292 I-2.402 J-6.618 E.02706
; LINE_WIDTH: 0.433691
G1 F11454
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02136
; LINE_WIDTH: 0.383735
G2 X106.523 Y127.695 I-2.956 J-3.484 E.00984
; LINE_WIDTH: 0.348862
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320224
G2 X106.735 Y127.443 I-1.83 J-1.572 E.00443
; LINE_WIDTH: 0.292304
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255996
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220471
G2 X106.983 Y127.022 I-1.064 J-.633 E.00295
; LINE_WIDTH: 0.180144
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.146803
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.11256
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.563063
G1 F9228.23
M204 S6000
G1 X107.223 Y125.208 E.01146
G2 X107.177 Y124.94 I-6.75 J1.019 E.01152
; LINE_WIDTH: 0.522377
G1 F10011.325
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486103
G1 F10830.743
G2 X107.111 Y124.691 I-1.783 J.405 E.00528
; LINE_WIDTH: 0.44768
G1 F11454
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402681
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374808
G1 X106.924 Y124.208 E.00074
; LINE_WIDTH: 0.358833
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326265
G2 X106.694 Y123.803 I-1.507 J.719 E.00622
; LINE_WIDTH: 0.296002
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276528
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240882
G2 X106.371 Y123.389 I-2.555 J1.832 E.00419
; LINE_WIDTH: 0.211795
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184708
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153184
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120216
G2 X105.616 Y122.762 I-1.869 J2.159 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z2.8 F42000
G1 Z2.4
G1 E.8 F1800
; LINE_WIDTH: 0.122039
G1 F11454
M204 S6000
G2 X99.912 Y123.647 I9.346 J11.941 E.00482
; LINE_WIDTH: 0.147282
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173383
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11454
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11454
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 13/25
; update layer progress
M73 L13
M991 S0 P12 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z2.8 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z2.8
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X150.467 Y124.693 E.00888
G2 X151.073 Y125.01 I2.816 J-4.635 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.669 J.127 E.02282
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09209
G1 X150.604 Y124.785 E-.06284
G1 X151.073 Y125.01 E-.19778
G1 X151.148 Y125.063 E-.03496
G1 X151.188 Y125.226 E-.06385
G1 X151.193 Y125.334 E-.04108
G1 X151.156 Y125.613 E-.1069
G1 X151.082 Y125.753 E-.05985
G1 X150.983 Y125.853 E-.05375
G1 X150.868 Y125.899 E-.0469
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z3 F42000
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21643
G1 X157.113 Y124.547 E-.22769
G1 X157.334 Y125.082 E-.21992
G1 X157.34 Y125.107 E-.00986
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z3 F42000
G1 X151.408 Y134.226 Z3
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.098 J3.674 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01736
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.374 J1.31 E.06571
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.049 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01683
G3 X151.438 Y124.802 I-.844 J2.254 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.02551
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.972 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G1 X153.386 Y122.03 E.02267
G1 X154.334 Y122.116 E.02924
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z3
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z3 F4000
            G39.3 S1
            G0 Z3 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288662
G1 F11455
M204 S6000
G2 X150.503 Y128.334 I-62.803 J19.154 E.01389
; LINE_WIDTH: 0.24073
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196993
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.15878
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122846
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.12308
G1 F11455
M204 S6000
G3 X150.289 Y123.904 I1.881 J.247 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.118037
G1 F11455
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148791
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179233
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221068
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261699
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306028
G1 X155.669 Y122.961 E.0038
; LINE_WIDTH: 0.349873
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390985
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416976
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.48769
G1 F10792.1
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.114348
G1 F11455
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149195
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.184042
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.63 J.969 E.00311
; LINE_WIDTH: 0.258737
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306094
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458214
G1 F11455
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492851
G1 F10668.312
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492631
G1 F10673.519
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453249
G1 F11455
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410311
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362699
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317841
G1 X155.306 Y129.876 E.00363
; LINE_WIDTH: 0.27073
G3 X155.153 Y129.966 I-1.195 J-1.849 E.00331
; LINE_WIDTH: 0.242576
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213449
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164568
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120202
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.843 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74104
G1 X154.756 Y130.129 E-.01896
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11455
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11455
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401435
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359233
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z3 F42000
G1 X141.597 Y130.591 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.281 E.02461
G1 X140.907 Y132.132 E.01529
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.09112
G1 X141.987 Y130.622 E-.08132
G1 X142.082 Y130.683 E-.04298
G1 X142.16 Y130.77 E-.0445
G1 X142.238 Y130.969 E-.081
G1 X142.242 Y131.177 E-.07925
G1 X142.224 Y131.286 E-.04176
G1 X142.17 Y131.407 E-.05036
G1 X142.111 Y131.471 E-.03342
G1 X141.949 Y131.564 E-.07096
G1 X141.592 Y131.686 E-.14332
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z3 F42000
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.804 J-1.011 E.03535
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24043
G1 X147.611 Y130.255 E-.05258
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.528 Y124.561 Z3 F42000
G1 X141.548 Y123.463 Z3
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X141.506 Y123.503 E.00193
G1 X140.687 Y122.602 E.04037
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.08799
G1 X142.476 Y123.044 E.04224
G2 X141.688 Y123.329 I.256 J1.936 E.028
G1 X141.591 Y123.421 E.00445
M204 S250
G1 X141.838 Y123.732 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X141.854 Y124.138 I.282 J.191 E.01336
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.959 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.022 E.0168
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.572 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.388 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.561 Y125.338 E.09646
G1 X148.598 Y125.774 E.01345
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.349 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.928 Y123.642 I.182 J1.533 E.02012
G2 X141.876 Y123.686 I.191 J.282 E.00212
M204 S10000
G1 X141.606 Y123.709 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.112982
G1 F11455
M204 S6000
G1 X141.551 Y123.785 E.00054
G1 X141.574 Y123.87 E.0005
; WIPE_START
G1 F15000
G1 X141.551 Y123.785 E-.36579
G1 X141.606 Y123.709 E-.39421
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.231 Y122.806 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.309584
G1 F11455
M204 S6000
G1 X141.343 Y123.021 E.01985
M204 S10000
G1 X141.312 Y122.987 F42000
; LINE_WIDTH: 0.19494
G1 F11455
M204 S6000
G1 X141.969 Y122.881 E.00825
; LINE_WIDTH: 0.16895
G1 X142.182 Y122.855 E.0022
; LINE_WIDTH: 0.12093
G1 X142.395 Y122.829 E.00136
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11455
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11455
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156227
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.19015
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235123
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199156
G3 X147.69 Y132.483 I-2.524 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.481835
M73 P84 R4
G1 F10936.058
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11455
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380991
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337797
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291709
G3 X146.552 Y134.367 I-1.297 J-1.366 E.00313
; LINE_WIDTH: 0.2638
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164869
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121267
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.110973
G1 F11455
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.147098
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185489
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218713
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247223
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.612 F42000
; LINE_WIDTH: 0.121137
G1 F11455
M204 S6000
G3 X141.111 Y132.246 I3.996 J2.879 E.00298
M204 S10000
G1 X141.096 Y132.233 F42000
; LINE_WIDTH: 0.19786
G1 F11455
M204 S6000
G1 X140.829 Y132.644 E.00619
; WIPE_START
G1 F15000
G1 X141.096 Y132.233 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z3 F42000
G1 X148.316 Y125.064 Z3
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.120203
G1 F11455
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168495
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.217995
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267495
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119639
G1 F11455
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.16508
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189715
G1 X148.28 Y124.356 E.00564
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.168866
G1 F11455
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.343 Z3 F42000
G1 X138.356 Y132.427 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X138.422 Y132.427 E.00218
G3 X138.732 Y134.417 I-17.053 J3.671 E.06684
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.036 J-.258 E.0123
G3 X137.949 Y134.235 I1.739 J-.307 E.00998
G3 X138.219 Y132.427 I18.431 J1.835 E.06068
G1 X138.296 Y132.427 E.00255
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.427 E-.04782
G1 X138.635 Y133.582 E-.44625
G1 X138.715 Y134.277 E-.26592
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X138.778 Y132.193 E.06866
G1 X139.023 Y133.522 E.04154
G1 X139.126 Y134.368 E.02618
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.256 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120908
G1 F11455
M204 S6000
G1 X138.321 Y131.112 E.00102
; LINE_WIDTH: 0.168884
G1 X138.321 Y131.272 E.00164
; LINE_WIDTH: 0.216859
G1 X138.321 Y131.432 E.00226
; LINE_WIDTH: 0.264834
G1 X138.321 Y131.592 E.00289
; LINE_WIDTH: 0.312809
G1 X138.321 Y131.751 E.00351
; LINE_WIDTH: 0.360784
G1 X138.321 Y131.911 E.00414
; LINE_WIDTH: 0.40876
G1 X138.321 Y132.071 E.00476
; LINE_WIDTH: 0.456735
G1 X138.321 Y132.231 E.00539
M204 S10000
G1 X138.322 Y133.128 F42000
; LINE_WIDTH: 0.119879
G1 F11455
M204 S6000
G1 X138.322 Y133.267 E.00087
; LINE_WIDTH: 0.165793
G1 X138.323 Y133.406 E.00139
; LINE_WIDTH: 0.211707
G1 X138.324 Y133.545 E.00191
; LINE_WIDTH: 0.246744
G1 X138.327 Y133.629 E.00139
; LINE_WIDTH: 0.282272
G1 X138.328 Y133.835 E.004
; LINE_WIDTH: 0.329181
G1 X138.33 Y134.04 E.00479
; LINE_WIDTH: 0.376089
G1 X138.331 Y134.245 E.00557
; LINE_WIDTH: 0.404904
G3 X138.347 Y134.591 I-2.299 J.278 E.01024
; WIPE_START
G1 F13260.259
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z3 F42000
G1 X130.165 Y128.941 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.582 J.981 E.02847
G3 X132.594 Y122.344 I1.778 J1.414 E.05633
G3 X133.879 Y122.579 I.229 J2.38 E.04064
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04258
G3 X135.447 Y127.513 I-9.276 J.215 E.03407
G1 X135.334 Y128.245 E.02278
G1 X135.17 Y128.825 E.0185
G1 X134.973 Y129.26 E.01468
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17179
G1 X130.87 Y129.484 E-.18908
G1 X130.611 Y129.024 E-.20073
G1 X130.436 Y128.532 E-.1984
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X135.718 Y128.329 E.01884
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03865
G1 X135.769 Y124.963 E.0474
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21997
G1 X135.838 Y127.552 E-.29886
G1 X135.861 Y126.918 E-.24117
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.368 Y122.08 E.01879
G1 X133.476 Y122.089 E.00333
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01954
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11455
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11455
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120934
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.505471
G1 F10377.247
M204 S6000
G1 X130.3 Y129.361 E.01271
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448152
G1 F11455
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403261
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.36194
G2 X130.709 Y129.835 I1.865 J-1.641 E.00554
; LINE_WIDTH: 0.32659
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289356
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252121
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.21855
G2 X131.122 Y130.176 I1.358 J-1.68 E.00264
; LINE_WIDTH: 0.185243
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146053
G1 X131.343 Y130.314 E.00109
; LINE_WIDTH: 0.111382
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.314 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11455
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.18376
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327159
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.37446
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.41651
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.443353
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492704
G1 F10671.8
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11455
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216417
G2 X136.18 Y126.582 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243733
G2 X136.138 Y125.739 I-5.075 J-.172 E.01383
; LINE_WIDTH: 0.232295
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193679
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149198
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.487667
G1 F10792.664
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445976
G1 F11455
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401295
G2 X135.075 Y123.17 I-2.199 J1.712 E.0068
; LINE_WIDTH: 0.369996
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344919
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307406
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269892
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230201
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.20146
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.17024
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124741
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.099456
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.0995059
G1 F11455
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127458
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177277
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204261
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224469
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.26096
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300059
G2 X130.759 Y122.986 I1.394 J1.823 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513084
G1 F10209.209
M204 S6000
G1 X130.191 Y123.685 E.03888
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444828
G1 F11455
M204 S6000
G3 X130.648 Y123.102 I6.957 J5.538 E.02451
; LINE_WIDTH: 0.396835
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361851
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.263 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03159
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03092
G1 X126.584 Y122.774 E.00661
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X126.848 Y123.318 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.3923
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.473 E.02911
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01832
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.763 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.674 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.100035
G1 F11455
M204 S6000
G3 X127.108 Y122.406 I1.907 J1.474 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101433
G1 F11455
M204 S6000
G2 X126.981 Y122.483 I.456 J2.553 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.120475
G1 F11455
M204 S6000
G1 X126.214 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.118111
G1 F11455
M204 S6000
G2 X125.339 Y122.406 I-3.251 J2.335 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162113
G1 F11455
M204 S6000
G3 X125.481 Y122.505 I-.965 J3.727 E.00282
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z3 F42000
G1 X126.229 Y134.784 Z3
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.121655
G1 F11455
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169636
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215749
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255284
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0992079
G1 F11455
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121695
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162895
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149308
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114377
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X121.949 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.204 J-1.117 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02035
; WIPE_START
G1 F11791.304
G1 X121.949 Y130.272 E-.02628
G1 X122.103 Y130.078 E-.10822
G1 X122.227 Y129.861 E-.10892
G1 X122.348 Y130.013 E-.08481
G1 X122.622 Y130.272 E-.16425
G1 X122.009 Y130.272 E-.26752
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z3 F42000
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.547 E.0228
G1 X119.209 Y122.767 E.25568
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.209 J-.259 E.01414
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02308
G1 X115.742 Y129.968 E-.15235
G1 X115.891 Y129.724 E-.10854
G1 X116.431 Y128.593 E-.47603
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z3 F42000
G1 X115.146 Y120.124 Z3
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01252
G2 X115.313 Y119.833 I1.151 J.161 E.01656
G3 X115.338 Y120.007 I-.692 J.189 E.00585
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07708
G1 X114.92 Y120.097 E-.03258
G1 X114.825 Y120.029 E-.04448
G1 X114.777 Y119.962 E-.03115
G1 X114.732 Y119.747 E-.08373
G1 X114.744 Y119.605 E-.05385
G1 X114.804 Y119.434 E-.06887
G1 X114.934 Y119.264 E-.08155
G1 X115.054 Y119.165 E-.05911
G1 X115.378 Y118.976 E-.14242
G1 X115.317 Y119.192 E-.08517
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z3 F42000
G1 X110.311 Y130.57 Z3
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.647 J.672 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.02279
G2 X109.527 Y130.57 I-2.491 J1.894 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.323 J-3.237 E.02984
G2 X115.546 Y129.537 I-.692 J-1.249 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.345 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X116.172 Y118.619 I.606 J2.37 E.03012
G1 X116.238 Y118.625 E.00204
G3 X117.568 Y119.2 I-.683 J3.402 E.04487
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.129 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20008
G3 X117.08 Y129.654 I-.537 J.967 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102629
G1 F11455
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124351
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155185
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11455
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209473
G2 X110.837 Y132.758 I-3.007 J.177 E.00342
; LINE_WIDTH: 0.25582
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298296
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340771
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383247
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425722
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225174
G1 F11455
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11455
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132626
G1 F11455
M204 S6000
G2 X115.218 Y130.242 I-2.651 J-3.504 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.113968
G1 F11455
M204 S6000
G2 X117.278 Y130.468 I2.316 J-1.723 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112457
G1 F11455
M204 S6000
G3 X117.164 Y130.397 I.578 J-2.781 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.130454
G1 F11455
M204 S6000
G2 X121.608 Y130.384 I-.568 J-4.811 E.00274
M204 S10000
G1 X121.687 Y130.248 F42000
; LINE_WIDTH: 0.117054
G1 F11455
M204 S6000
G3 X121.434 Y130.468 I-2.924 J-3.119 E.00203
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115533
G1 F11455
M204 S6000
G3 X122.174 Y129.56 I-3.503 J.847 E.00146
M204 S10000
G1 X122.104 Y129.637 F42000
; LINE_WIDTH: 0.107585
G1 F11455
M204 S6000
G2 X122.185 Y129.406 I-3.495 J-1.365 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115581
G1 F11455
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152902
G1 X123.236 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.122869
G1 F11455
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.419 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z3 F42000
G1 X116.263 Y118.858 Z3
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.106049
G1 F11455
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.134339
G1 X115.927 Y118.851 E.00108
; LINE_WIDTH: 0.175118
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210028
G2 X115.601 Y118.909 I.291 J1.779 E.00275
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.168001
G1 F11455
M204 S6000
G1 X115.775 Y118.785 E.00389
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.173084
G1 F11455
M204 S6000
G2 X115.008 Y119.749 I1.818 J.193 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146612
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.110389
G1 F11455
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139233
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166716
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.20052
G2 X111.979 Y122.317 I.108 J1.476 E.002
; LINE_WIDTH: 0.238851
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282835
G2 X111.737 Y122.375 I.315 J1.576 E.00265
; LINE_WIDTH: 0.321765
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354813
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394144
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433209
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440621
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413511
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12952.3
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.729 J143.27 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16429
G1 X107.141 Y125.672 E-.067
G1 X107.368 Y125.672 E-.08633
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09725
G1 X107.334 Y126.831 E-.16572
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z3 F42000
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z3 F42000
G1 X99.457 Y123.958 Z3
G1 Z2.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z3 F42000
G1 X105.735 Y134.549 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.785 J143.421 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.833 Y122.045 E.01207
G1 X104.633 Y122.156 E.0248
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.068 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11455
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11455
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11455
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.106736
G1 F11455
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131365
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159974
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.19171
G3 X99.549 Y134.747 I1.56 J-1.705 E.00384
; LINE_WIDTH: 0.240256
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288573
G3 X99.236 Y134.303 I1.669 J-1.147 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.589 J-2.033 E.00775
; LINE_WIDTH: 0.374654
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400403
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435371
G3 X98.92 Y133.548 I3.525 J-1.313 E.01039
; LINE_WIDTH: 0.478969
G1 F11007.936
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516476
G1 F10136.086
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548784
G1 F9488.721
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.11498
G1 F11455
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153128
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197176
G1 X99.03 Y131.383 E.0013
; LINE_WIDTH: 0.230973
G1 X99.068 Y131.287 E.00158
; LINE_WIDTH: 0.261706
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.29154
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322959
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.35117
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.37944
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415413
G3 X99.539 Y130.599 I.68 J.512 E.00581
; LINE_WIDTH: 0.447755
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464987
G1 F11372.616
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494307
G1 F10633.888
G3 X100.388 Y129.998 I2.92 J4.151 E.02484
; LINE_WIDTH: 0.542807
G1 F9602.186
G3 X101.286 Y129.65 I3.455 J7.58 E.03925
G2 X104.541 Y128.735 I-51.669 J-189.987 E.13773
; LINE_WIDTH: 0.493708
G1 F10648.034
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.515
G2 X105.695 Y128.292 I-2.402 J-6.618 E.02706
; LINE_WIDTH: 0.433691
G1 F11455
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02136
; LINE_WIDTH: 0.383736
G2 X106.523 Y127.695 I-2.962 J-3.492 E.00984
; LINE_WIDTH: 0.348854
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320203
G2 X106.735 Y127.443 I-1.847 J-1.586 E.00443
; LINE_WIDTH: 0.292288
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255996
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220471
G2 X106.983 Y127.022 I-1.062 J-.632 E.00295
; LINE_WIDTH: 0.180147
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.146804
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.11256
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.258 Y125.476 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.563059
G1 F9228.301
M204 S6000
G2 X107.177 Y124.94 I-7.036 J.794 E.02298
; LINE_WIDTH: 0.522382
G1 F10011.233
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486107
G1 F10830.644
G2 X107.111 Y124.691 I-1.783 J.405 E.00528
; LINE_WIDTH: 0.44768
G1 F11455
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402679
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374815
G1 X106.923 Y124.208 E.00074
; LINE_WIDTH: 0.358819
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.32626
G2 X106.694 Y123.803 I-1.507 J.719 E.00622
; LINE_WIDTH: 0.29599
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276525
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240873
G2 X106.371 Y123.389 I-2.527 J1.81 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184722
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.1532
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120221
G2 X105.616 Y122.762 I-1.869 J2.16 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z3 F42000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.122044
G1 F11455
M204 S6000
G2 X99.912 Y123.647 I9.341 J11.935 E.00482
; LINE_WIDTH: 0.147282
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173385
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11455
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11455
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 14/25
; update layer progress
M73 L14
M991 S0 P13 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z3 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X150.467 Y124.693 E.00888
G2 X151.073 Y125.01 I2.815 J-4.633 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00857
G3 X150.983 Y125.853 I-.67 J.127 E.02283
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.929 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09212
G1 X150.604 Y124.785 E-.06285
G1 X151.073 Y125.01 E-.1977
G1 X151.148 Y125.063 E-.03498
G1 X151.188 Y125.226 E-.06386
G1 X151.193 Y125.334 E-.04108
G1 X151.156 Y125.613 E-.10692
G1 X151.082 Y125.753 E-.05987
G1 X150.983 Y125.853 E-.05373
G1 X150.868 Y125.899 E-.0469
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01405
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21642
G1 X157.113 Y124.547 E-.22769
G1 X157.334 Y125.082 E-.21992
G1 X157.34 Y125.107 E-.00987
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z3.2 F42000
G1 X151.408 Y134.226 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.56 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.409 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.094 J3.671 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01736
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.911 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.373 J1.31 E.06571
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01684
G3 X151.438 Y124.802 I-.844 J2.255 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G1 X153.379 Y122.03 E.02246
G1 X154.334 Y122.116 E.02946
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z3.2
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z3.2 F4000
            G39.3 S1
            G0 Z3.2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288676
G1 F11455
M204 S6000
G2 X150.503 Y128.334 I-61.154 J18.627 E.01388
; LINE_WIDTH: 0.240714
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196908
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158728
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122878
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.123059
G1 F11455
M204 S6000
G3 X150.289 Y123.904 I1.885 J.248 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.118044
G1 F11455
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148777
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179215
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221058
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261696
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306022
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349875
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390996
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.41697
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.48769
G1 F10792.101
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.114347
G1 F11455
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149194
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.18404
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.631 J.97 E.00311
; LINE_WIDTH: 0.258743
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306097
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458245
G1 F11455
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492878
G1 F10667.676
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492637
G1 F10673.398
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453252
G1 F11455
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410311
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362692
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317837
G1 X155.307 Y129.876 E.00363
; LINE_WIDTH: 0.270729
G3 X155.153 Y129.966 I-1.196 J-1.851 E.00331
; LINE_WIDTH: 0.242576
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213449
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164568
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120192
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.845 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74104
G1 X154.756 Y130.129 E-.01896
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11455
M204 S6000
M73 P85 R4
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11455
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401435
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359233
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z3.2 F42000
G1 X141.597 Y130.591 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.891 J3.284 E.02461
G1 X140.907 Y132.132 E.0153
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.09111
G1 X141.987 Y130.622 E-.08131
G1 X142.082 Y130.683 E-.04297
G1 X142.16 Y130.77 E-.04452
G1 X142.238 Y130.969 E-.08098
G1 X142.242 Y131.177 E-.0793
G1 X142.224 Y131.286 E-.04173
G1 X142.17 Y131.407 E-.05036
G1 X142.111 Y131.472 E-.03343
G1 X141.949 Y131.564 E-.07094
G1 X141.592 Y131.686 E-.14335
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.805 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24043
G1 X147.611 Y130.255 E-.05258
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.528 Y124.562 Z3.2 F42000
G1 X141.547 Y123.464 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X141.506 Y123.503 E.00189
G1 X140.687 Y122.602 E.04038
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.674 E.088
G1 X142.476 Y123.044 E.04224
G2 X141.688 Y123.329 I.256 J1.936 E.02801
G1 X141.59 Y123.422 E.00447
M204 S250
G1 X141.837 Y123.733 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X141.854 Y124.138 I.283 J.191 E.01335
G1 X142.546 Y124.878 E.03112
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.022 E.0168
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.572 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.389 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.538 Y125.072 E.08827
G1 X148.598 Y125.774 E.02164
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.118 J2.03 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.928 Y123.642 I.182 J1.533 E.02013
G2 X141.875 Y123.686 I.192 J.282 E.00213
M204 S10000
G1 X141.605 Y123.71 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.113016
G1 F11455
M204 S6000
G1 X141.551 Y123.786 E.00053
G1 X141.575 Y123.87 E.0005
; WIPE_START
G1 F15000
G1 X141.551 Y123.786 E-.369
G1 X141.605 Y123.71 E-.391
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.232 Y122.806 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.309632
G1 F11455
M204 S6000
G1 X141.343 Y123.021 E.01988
M204 S10000
G1 X141.312 Y122.987 F42000
; LINE_WIDTH: 0.19494
G1 F11455
M204 S6000
G1 X141.969 Y122.881 E.00825
; LINE_WIDTH: 0.16895
G1 X142.182 Y122.855 E.0022
; LINE_WIDTH: 0.120931
G1 X142.395 Y122.829 E.00136
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11455
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11455
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156227
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.19015
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235123
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199157
G3 X147.69 Y132.483 I-2.524 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101125
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.481843
G1 F10935.867
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11455
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380991
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337797
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291709
G3 X146.552 Y134.367 I-1.297 J-1.366 E.00313
; LINE_WIDTH: 0.2638
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164869
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121267
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.110983
G1 F11455
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.147104
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185498
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218701
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247203
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.612 F42000
; LINE_WIDTH: 0.121113
G1 F11455
M204 S6000
G3 X141.111 Y132.246 I3.984 J2.868 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197847
G1 F11455
M204 S6000
G1 X140.829 Y132.644 E.00619
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z3.2 F42000
G1 X148.316 Y125.064 Z3.2
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.120211
G1 F11455
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168499
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218006
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267514
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119653
G1 F11455
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165114
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189781
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.168848
G1 F11455
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.344 Z3.2 F42000
G1 X138.362 Y132.423 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.737 E.01058
G3 X138.732 Y134.417 I-15.991 J3.239 E.05638
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.037 J-.259 E.0123
G3 X137.949 Y134.235 I1.736 J-.307 E.00997
G3 X138.22 Y132.423 I18.447 J1.837 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.737 E-.12118
G1 X138.635 Y133.581 E-.32618
G1 X138.716 Y134.279 E-.26701
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X138.742 Y132.004 E.06277
G3 X139.126 Y134.368 I-27.53 J5.69 E.0736
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120841
G1 F11455
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168682
G1 X138.321 Y131.271 E.00163
; LINE_WIDTH: 0.216522
G1 X138.321 Y131.431 E.00225
; LINE_WIDTH: 0.264362
G1 X138.321 Y131.59 E.00287
; LINE_WIDTH: 0.312203
G1 X138.321 Y131.749 E.0035
; LINE_WIDTH: 0.360043
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.407884
G1 X138.321 Y132.068 E.00474
; LINE_WIDTH: 0.455724
G1 X138.321 Y132.227 E.00536
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11455
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.24674
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.28204
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329042
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376045
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404894
G3 X138.347 Y134.591 I-2.285 J.277 E.01023
; WIPE_START
G1 F13260.629
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z3.2 F42000
G1 X130.165 Y128.941 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.0436
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.582 J.981 E.02847
G3 X132.61 Y122.343 I1.776 J1.412 E.05682
G3 X133.879 Y122.579 I.219 J2.352 E.04016
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17181
G1 X130.87 Y129.484 E-.18907
G1 X130.611 Y129.024 E-.20071
G1 X130.436 Y128.532 E-.19841
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21993
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24118
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.318 Y122.076 E.01724
G1 X133.476 Y122.089 E.00488
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01954
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11455
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11455
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120931
G1 X129.704 Y128.079 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.50546
G1 F10377.481
M204 S6000
G1 X130.3 Y129.361 E.0127
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448156
G1 F11455
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.40328
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361945
G2 X130.709 Y129.835 I1.854 J-1.631 E.00554
; LINE_WIDTH: 0.326591
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289362
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252132
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.21855
G2 X131.122 Y130.176 I1.343 J-1.66 E.00264
; LINE_WIDTH: 0.185255
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.14608
G1 X131.343 Y130.314 E.00109
; LINE_WIDTH: 0.111399
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.314 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11455
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183756
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211112
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249552
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286367
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327166
G2 X135.106 Y129.695 I-1.113 J-1.142 E.00452
; LINE_WIDTH: 0.374478
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416541
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.443379
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492715
G1 F10671.527
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11455
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216419
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149196
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.487683
G1 F10792.282
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445982
G1 F11455
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401294
G2 X135.075 Y123.17 I-2.186 J1.701 E.0068
; LINE_WIDTH: 0.37001
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344918
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307408
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269898
G1 X134.754 Y122.886 E.00217
; LINE_WIDTH: 0.23021
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170233
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124721
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994462
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.0995047
G1 F11455
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127457
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177275
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204259
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.22448
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260963
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300054
G2 X130.759 Y122.986 I1.394 J1.823 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513081
G1 F10209.28
M204 S6000
G1 X130.191 Y123.685 E.03889
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444823
G1 F11455
M204 S6000
G3 X130.649 Y123.102 I6.957 J5.538 E.02451
; LINE_WIDTH: 0.396825
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361837
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.263 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03158
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03093
G1 X126.584 Y122.774 E.00661
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X126.848 Y123.318 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.3923
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01832
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.764 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0998531
G1 F11455
M204 S6000
G3 X127.108 Y122.406 I1.873 J1.446 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101432
G1 F11455
M204 S6000
G2 X126.982 Y122.483 I.455 J2.55 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.12047
G1 F11455
M204 S6000
G1 X126.213 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.118111
G1 F11455
M204 S6000
G2 X125.339 Y122.406 I-3.361 J2.417 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162122
G1 F11455
M204 S6000
G3 X125.481 Y122.505 I-1.012 J3.874 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z3.2 F42000
G1 X126.229 Y134.784 Z3.2
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.121655
G1 F11455
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169638
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215755
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255285
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0992256
G1 F11455
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121728
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162933
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149321
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114388
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X121.948 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.2 J-1.115 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02035
; WIPE_START
G1 F11791.304
G1 X121.948 Y130.272 E-.02628
G1 X122.103 Y130.078 E-.10828
G1 X122.227 Y129.861 E-.10886
G1 X122.348 Y130.013 E-.0848
G1 X122.622 Y130.272 E-.16423
G1 X122.009 Y130.272 E-.26755
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25568
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01398
G2 X116.88 Y130.272 I1.208 J-.259 E.01414
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02308
G1 X115.742 Y129.968 E-.15236
G1 X115.891 Y129.724 E-.10852
G1 X116.431 Y128.593 E-.47604
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z3.2 F42000
G1 X115.146 Y120.124 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01244
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01656
G3 X115.338 Y120.007 I-.689 J.189 E.00586
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07709
G1 X114.92 Y120.097 E-.03258
G1 X114.825 Y120.029 E-.04443
G1 X114.777 Y119.962 E-.03122
G1 X114.732 Y119.747 E-.08371
G1 X114.744 Y119.605 E-.05384
G1 X114.804 Y119.434 E-.06886
G1 X114.934 Y119.264 E-.08158
G1 X115.054 Y119.165 E-.05907
G1 X115.378 Y118.976 E-.14248
G1 X115.317 Y119.191 E-.08514
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z3.2 F42000
G1 X110.311 Y130.57 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.646 J.671 E.00996
G1 X111.153 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.203 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.49 J1.893 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.323 J-3.238 E.02985
G2 X115.546 Y129.537 I-.692 J-1.248 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.344 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X116.139 Y118.617 I.597 J2.318 E.0291
G1 X116.238 Y118.624 E.00306
G3 X117.568 Y119.2 I-.683 J3.402 E.04487
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.574 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20008
G3 X117.08 Y129.654 I-.537 J.968 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.83 E.01819
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102614
G1 F11455
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124333
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155169
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11455
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225198
G1 F11455
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11455
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132615
G1 F11455
M204 S6000
G2 X115.218 Y130.242 I-2.662 J-3.517 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.113938
G1 F11455
M204 S6000
G2 X117.278 Y130.468 I2.211 J-1.642 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112451
G1 F11455
M204 S6000
G3 X117.164 Y130.396 I.543 J-2.623 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.130447
G1 F11455
M204 S6000
G2 X121.608 Y130.384 I-.565 J-4.783 E.00273
M204 S10000
G1 X121.687 Y130.249 F42000
; LINE_WIDTH: 0.11686
G1 F11455
M204 S6000
G3 X121.434 Y130.468 I-2.925 J-3.122 E.00202
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115537
G1 F11455
M204 S6000
G3 X122.174 Y129.559 I-3.721 J.896 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107527
G1 F11455
M204 S6000
G2 X122.185 Y129.406 I-3.664 J-1.428 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115586
G1 F11455
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152904
G1 X123.235 Y130.468 E.00171
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11455
M204 S6000
G3 X123.03 Y130.387 I.572 J-4.449 E.00227
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z3.2 F42000
G1 X116.263 Y118.858 Z3.2
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.106042
G1 F11455
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.134298
G1 X115.927 Y118.851 E.00108
; LINE_WIDTH: 0.175118
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210029
G2 X115.601 Y118.909 I.294 J1.797 E.00275
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.167927
G1 F11455
M204 S6000
G1 X115.775 Y118.785 E.00388
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.173089
G1 F11455
M204 S6000
G2 X115.008 Y119.749 I1.821 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146628
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.11038
G1 F11455
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139217
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166702
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200521
G2 X111.979 Y122.317 I.107 J1.47 E.002
; LINE_WIDTH: 0.238869
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282869
G2 X111.737 Y122.375 I.317 J1.586 E.00265
; LINE_WIDTH: 0.321782
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354825
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394159
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433216
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440601
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413479
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12953.416
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.703 J143.178 E.13155
G1 X105.53 Y127.924 E.0239
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.1643
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09725
G1 X107.334 Y126.831 E-.16573
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z3.2 F42000
G1 X99.457 Y123.958 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z3.2 F42000
G1 X105.735 Y134.549 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.0467
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.822 I41.77 J143.367 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.801 Y122.044 E.01107
G1 X104.633 Y122.156 E.02579
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04254
G1 X106.33 Y128.854 E.01715
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11455
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11455
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11455
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
M73 P85 R3
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.106736
G1 F11455
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131365
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159974
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.19171
G3 X99.549 Y134.747 I1.56 J-1.705 E.00384
; LINE_WIDTH: 0.240256
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288573
G3 X99.236 Y134.303 I1.669 J-1.147 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.589 J-2.033 E.00775
; LINE_WIDTH: 0.374649
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400388
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478966
G1 F11008.028
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516474
G1 F10136.135
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.913
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.11498
G1 F11455
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153128
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197173
G1 X99.03 Y131.383 E.0013
; LINE_WIDTH: 0.230969
G1 X99.068 Y131.287 E.00158
; LINE_WIDTH: 0.261701
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291535
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322955
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351167
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379431
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415403
G3 X99.539 Y130.599 I.679 J.511 E.00581
; LINE_WIDTH: 0.447766
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464995
G1 F11372.4
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494315
G1 F10633.713
G3 X100.388 Y129.998 I2.919 J4.149 E.02484
; LINE_WIDTH: 0.542806
G1 F9602.189
G3 X101.286 Y129.65 I3.455 J7.579 E.03925
G2 X104.541 Y128.735 I-51.686 J-190.048 E.13773
; LINE_WIDTH: 0.493698
G1 F10648.259
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471697
G1 F11194.64
G2 X105.695 Y128.292 I-2.404 J-6.623 E.02706
; LINE_WIDTH: 0.433679
G1 F11455
G2 X106.262 Y127.934 I-2.207 J-4.126 E.02136
; LINE_WIDTH: 0.383746
G2 X106.523 Y127.695 I-2.919 J-3.444 E.00983
; LINE_WIDTH: 0.348857
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320216
G2 X106.735 Y127.443 I-1.831 J-1.572 E.00443
; LINE_WIDTH: 0.292301
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255995
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.22048
G2 X106.983 Y127.022 I-1.063 J-.632 E.00295
; LINE_WIDTH: 0.180157
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.14682
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.112565
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.563052
G1 F9228.437
M204 S6000
G2 X107.177 Y124.94 I-7.421 J.86 E.02298
; LINE_WIDTH: 0.522388
G1 F10011.104
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486111
G1 F10830.557
G2 X107.111 Y124.691 I-1.791 J.408 E.00528
; LINE_WIDTH: 0.447687
G1 F11455
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402673
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374804
G1 X106.924 Y124.208 E.00074
; LINE_WIDTH: 0.358819
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326258
G2 X106.694 Y123.803 I-1.508 J.72 E.00622
; LINE_WIDTH: 0.295994
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276525
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240873
G2 X106.371 Y123.389 I-2.527 J1.81 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184713
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153187
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120221
G2 X105.616 Y122.762 I-1.869 J2.16 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.122044
G1 F11455
M204 S6000
G2 X99.912 Y123.647 I9.341 J11.935 E.00482
; LINE_WIDTH: 0.147282
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173385
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11455
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11455
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 15/25
; update layer progress
M73 L15
M991 S0 P14 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z3.2 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z3.2
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X150.467 Y124.693 E.00887
G2 X151.073 Y125.01 I2.816 J-4.635 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.669 J.127 E.02283
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09207
G1 X150.604 Y124.785 E-.06289
G1 X151.073 Y125.01 E-.19774
G1 X151.148 Y125.063 E-.03497
G1 X151.188 Y125.226 E-.06384
G1 X151.193 Y125.334 E-.04108
G1 X151.156 Y125.613 E-.10692
G1 X151.082 Y125.753 E-.05986
G1 X150.983 Y125.853 E-.05374
G1 X150.868 Y125.899 E-.04688
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z3.4 F42000
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.01919
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21639
G1 X157.113 Y124.547 E-.22777
G1 X157.334 Y125.082 E-.21988
G1 X157.34 Y125.107 E-.00985
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z3.4 F42000
G1 X151.408 Y134.226 Z3.4
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.099 J3.674 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01736
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00611
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.373 J1.31 E.06572
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01684
G3 X151.438 Y124.802 I-.844 J2.254 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G1 X153.372 Y122.03 E.02225
G1 X154.334 Y122.116 E.02968
G1 X155.036 Y122.291 E.0222
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.535 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.4 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z3.4
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z3.4 F4000
            G39.3 S1
            G0 Z3.4 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288662
G1 F11455
M204 S6000
G2 X150.503 Y128.334 I-69.173 J21.155 E.0139
; LINE_WIDTH: 0.240657
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196928
G1 X150.466 Y128.27 E.00042
; LINE_WIDTH: 0.158816
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122882
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.123077
G1 F11455
M204 S6000
G3 X150.289 Y123.904 I1.881 J.247 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.118036
G1 F11455
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148768
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179227
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221071
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261708
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306033
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.34987
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390975
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416958
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487715
G1 F10791.497
M204 S6000
G1 X155.546 Y122.723 E.03736
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.11435
G1 F11455
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.1492
G1 X156.813 Y124.563 E.00106
; LINE_WIDTH: 0.184051
G1 X156.86 Y124.676 E.00141
; LINE_WIDTH: 0.21775
G3 X156.928 Y124.883 I-2.63 J.969 E.00311
; LINE_WIDTH: 0.258749
M73 P86 R3
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306099
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.447 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458138
G1 F11455
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492769
G1 F10670.267
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492629
G1 F10673.572
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453242
G1 F11455
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410299
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362692
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317837
G1 X155.307 Y129.876 E.00363
; LINE_WIDTH: 0.270729
G3 X155.153 Y129.966 I-1.196 J-1.851 E.00331
; LINE_WIDTH: 0.242567
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213449
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164568
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120199
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.843 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74104
G1 X154.756 Y130.129 E-.01896
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11455
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11455
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401435
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359233
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z3.4 F42000
G1 X141.597 Y130.591 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01728
G2 X141.26 Y131.835 I.891 J3.282 E.02461
G1 X140.907 Y132.132 E.0153
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.0911
G1 X141.987 Y130.622 E-.0813
G1 X142.082 Y130.683 E-.043
G1 X142.161 Y130.77 E-.04454
G1 X142.238 Y130.969 E-.08096
G1 X142.242 Y131.177 E-.07927
G1 X142.224 Y131.286 E-.04175
G1 X142.17 Y131.407 E-.05036
G1 X142.111 Y131.472 E-.03344
G1 X141.949 Y131.564 E-.07091
G1 X141.592 Y131.686 E-.14338
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z3.4 F42000
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.804 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24043
G1 X147.611 Y130.255 E-.05258
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.527 Y124.562 Z3.4 F42000
G1 X141.547 Y123.464 Z3.4
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X141.506 Y123.503 E.00188
G1 X140.687 Y122.602 E.04039
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.088
G1 X142.476 Y123.044 E.04224
G2 X141.688 Y123.329 I.256 J1.936 E.02801
G1 X141.59 Y123.423 E.00448
M204 S250
G1 X141.837 Y123.733 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X141.854 Y124.138 I.283 J.191 E.01334
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.021 E.0168
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.573 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.388 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.515 Y124.807 E.08008
G1 X148.598 Y125.774 E.02983
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.349 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.928 Y123.642 I.182 J1.533 E.02013
G2 X141.875 Y123.686 I.192 J.282 E.00213
M204 S10000
G1 X141.605 Y123.71 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.112702
G1 F11455
M204 S6000
G1 X141.551 Y123.786 E.00053
G1 X141.574 Y123.869 E.00049
; WIPE_START
G1 F15000
G1 X141.551 Y123.786 E-.36616
G1 X141.605 Y123.71 E-.39384
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.231 Y122.806 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.309649
G1 F11455
M204 S6000
G1 X141.343 Y123.021 E.01986
M204 S10000
G1 X141.312 Y122.987 F42000
; LINE_WIDTH: 0.19494
G1 F11455
M204 S6000
G1 X141.969 Y122.881 E.00825
; LINE_WIDTH: 0.168935
G1 X142.182 Y122.855 E.0022
; LINE_WIDTH: 0.120925
G1 X142.395 Y122.829 E.00136
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11455
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11455
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156227
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.19015
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235123
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199154
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.481835
G1 F10936.058
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11455
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380986
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337783
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291689
G3 X146.552 Y134.367 I-1.307 J-1.378 E.00313
; LINE_WIDTH: 0.263784
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164868
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121266
G1 X145.883 Y134.759 E.00226
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.110973
G1 F11455
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.147098
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185498
G1 X140.92 Y132.671 E.00137
; LINE_WIDTH: 0.218722
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247221
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.612 F42000
; LINE_WIDTH: 0.12113
G1 F11455
M204 S6000
G3 X141.111 Y132.246 I3.996 J2.879 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197896
G1 F11455
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z3.4 F42000
G1 X148.316 Y125.064 Z3.4
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.120204
G1 F11455
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168498
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218006
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267513
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119649
G1 F11455
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165101
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189773
G1 X148.28 Y124.355 E.00562
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.16889
G1 F11455
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.343 Z3.4 F42000
G1 X138.362 Y132.423 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.737 E.01058
G3 X138.732 Y134.417 I-15.99 J3.238 E.05638
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.037 J-.259 E.0123
G3 X137.949 Y134.235 I1.735 J-.307 E.00998
G3 X138.22 Y132.423 I18.447 J1.837 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.737 E-.12118
G1 X138.635 Y133.581 E-.32618
G1 X138.716 Y134.279 E-.26701
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X138.706 Y131.815 E.05685
G3 X139.126 Y134.368 I-29.431 J6.155 E.07953
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.121044
G1 F11455
M204 S6000
G1 X138.321 Y131.086 E.00085
; LINE_WIDTH: 0.169292
G1 X138.321 Y131.22 E.00138
; LINE_WIDTH: 0.217539
G1 X138.321 Y131.353 E.0019
; LINE_WIDTH: 0.265786
G1 X138.321 Y131.487 E.00243
; LINE_WIDTH: 0.314033
G1 X138.321 Y131.621 E.00295
; LINE_WIDTH: 0.36228
G1 X138.321 Y131.754 E.00348
; LINE_WIDTH: 0.410527
G1 X138.321 Y131.888 E.004
; LINE_WIDTH: 0.457148
G1 X138.321 Y132.227 E.01145
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11455
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.24674
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.282037
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329032
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376028
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404896
G3 X138.347 Y134.591 I-2.296 J.278 E.01023
; WIPE_START
G1 F13260.563
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z3.4 F42000
G1 X130.165 Y128.941 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.582 J.981 E.02847
G3 X132.627 Y122.342 I1.775 J1.411 E.05732
G3 X133.879 Y122.579 I.209 J2.324 E.03966
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17177
G1 X130.87 Y129.484 E-.18908
G1 X130.611 Y129.024 E-.20075
G1 X130.436 Y128.532 E-.1984
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21993
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24118
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.268 Y122.071 E.0157
G1 X133.476 Y122.089 E.00642
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01954
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11455
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.241 J.721 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11455
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120931
G1 X129.704 Y128.079 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.505454
G1 F10377.613
M204 S6000
G1 X130.3 Y129.361 E.01271
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448151
G1 F11455
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403269
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361938
G2 X130.709 Y129.835 I1.854 J-1.631 E.00554
; LINE_WIDTH: 0.326588
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289353
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252119
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218536
G2 X131.122 Y130.176 I1.358 J-1.68 E.00264
; LINE_WIDTH: 0.185246
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146075
G1 X131.343 Y130.313 E.00109
; LINE_WIDTH: 0.111395
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.313 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.11657
G1 F11455
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183764
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327159
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.37446
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.41651
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.443353
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492713
G1 F10671.576
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11455
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216419
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149196
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.48767
G1 F10792.58
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445978
G1 F11455
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401296
G2 X135.075 Y123.17 I-2.199 J1.712 E.0068
; LINE_WIDTH: 0.369996
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344921
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307411
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269901
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230212
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170237
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124735
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994563
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.0995121
G1 F11455
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.12747
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177281
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204262
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.22448
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260966
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.30006
G2 X130.759 Y122.986 I1.396 J1.826 E.00351
M204 S10000
G1 X130.742 Y122.833 F42000
; LINE_WIDTH: 0.513097
G1 F10208.937
M204 S6000
G1 X130.191 Y123.685 E.03887
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444827
G1 F11455
M204 S6000
G3 X130.649 Y123.102 I6.949 J5.531 E.02451
; LINE_WIDTH: 0.39683
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361847
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.263 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.324 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03158
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03092
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X126.848 Y123.319 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.763 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0999795
G1 F11455
M204 S6000
G3 X127.108 Y122.406 I1.869 J1.442 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101433
G1 F11455
M204 S6000
G2 X126.981 Y122.483 I.455 J2.552 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.120468
G1 F11455
M204 S6000
G1 X126.216 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.118138
G1 F11455
M204 S6000
G2 X125.339 Y122.406 I-3.253 J2.336 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162127
G1 F11455
M204 S6000
G3 X125.481 Y122.505 I-.962 J3.716 E.00282
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z3.4 F42000
G1 X126.229 Y134.784 Z3.4
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.121643
G1 F11455
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169621
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.21575
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255288
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991955
G1 F11455
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121688
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162893
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149324
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.11439
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X121.948 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.201 J-1.116 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02035
; WIPE_START
G1 F11791.304
G1 X121.948 Y130.272 E-.02627
G1 X122.103 Y130.078 E-.10826
G1 X122.227 Y129.861 E-.10889
G1 X122.348 Y130.013 E-.08479
G1 X122.622 Y130.272 E-.16424
G1 X122.009 Y130.272 E-.26755
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z3.4 F42000
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25567
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.2341
G1 X116.721 Y129.878 E.01398
G2 X116.879 Y130.272 I1.211 J-.26 E.01414
G1 X115.542 Y130.272 E.04437
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02309
G1 X115.742 Y129.968 E-.15233
G1 X115.891 Y129.724 E-.1086
G1 X116.431 Y128.593 E-.47598
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z3.4 F42000
G1 X115.146 Y120.124 Z3.4
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G3 X114.732 Y119.747 I-.073 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01657
G3 X115.338 Y120.007 I-.69 J.189 E.00584
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07709
G1 X114.92 Y120.097 E-.03256
G1 X114.825 Y120.029 E-.04448
G1 X114.777 Y119.962 E-.03115
G1 X114.732 Y119.747 E-.08375
G1 X114.744 Y119.606 E-.05383
G1 X114.804 Y119.434 E-.06887
G1 X114.934 Y119.264 E-.08158
G1 X115.054 Y119.165 E-.05908
G1 X115.378 Y118.976 E-.14244
G1 X115.317 Y119.192 E-.08518
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z3.4 F42000
G1 X110.311 Y130.57 Z3.4
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.649 J.674 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.203 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.492 J1.895 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00618
G2 X114.964 Y130.142 I-.321 J-3.233 E.02985
G2 X115.546 Y129.537 I-.692 J-1.248 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.344 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X116.105 Y118.614 I.589 J2.267 E.02808
G3 X117.064 Y118.892 I-.356 J3.018 E.0308
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.574 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20008
G3 X117.08 Y129.654 I-.536 J.966 E.00785
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.832 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102624
G1 F11455
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124351
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155183
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11455
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225198
G1 F11455
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11455
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132599
G1 F11455
M204 S6000
G2 X115.218 Y130.242 I-2.649 J-3.502 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.114026
G1 F11455
M204 S6000
G2 X117.278 Y130.468 I2.305 J-1.713 E.00132
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112456
G1 F11455
M204 S6000
G3 X117.164 Y130.396 I.566 J-2.73 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.130447
G1 F11455
M204 S6000
G2 X121.608 Y130.384 I-.565 J-4.784 E.00273
M204 S10000
G1 X121.687 Y130.249 F42000
; LINE_WIDTH: 0.116878
G1 F11455
M204 S6000
G3 X121.434 Y130.468 I-3.013 J-3.218 E.00202
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115525
G1 F11455
M204 S6000
G3 X122.174 Y129.559 I-3.722 J.897 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107605
G1 F11455
M204 S6000
G2 X122.185 Y129.406 I-3.599 J-1.404 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115586
G1 F11455
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152903
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11455
M204 S6000
G3 X123.03 Y130.387 I.572 J-4.447 E.00227
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z3.4 F42000
G1 X116.263 Y118.858 Z3.4
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.106041
G1 F11455
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.134317
G1 X115.927 Y118.851 E.00108
; LINE_WIDTH: 0.175118
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210023
G2 X115.601 Y118.909 I.293 J1.791 E.00275
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.168013
G1 F11455
M204 S6000
G1 X115.775 Y118.785 E.00389
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.173078
G1 F11455
M204 S6000
G2 X115.008 Y119.749 I1.82 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146618
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.110381
G1 F11455
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139218
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166702
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.20052
G2 X111.979 Y122.317 I.107 J1.471 E.002
; LINE_WIDTH: 0.238866
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282862
G2 X111.737 Y122.375 I.32 J1.596 E.00265
; LINE_WIDTH: 0.321789
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354829
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394174
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433226
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440597
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413461
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12954.04
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.729 J143.27 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.1643
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09723
G1 X107.334 Y126.83 E-.16575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z3.4 F42000
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z3.4 F42000
G1 X99.457 Y123.958 Z3.4
G1 Z3
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z3.4 F42000
G1 X105.735 Y134.549 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.785 J143.421 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.208 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.768 Y122.042 E.01008
G1 X103.903 Y122.048 E.00413
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11455
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11455
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11455
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.106736
G1 F11455
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131365
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159974
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.191715
G3 X99.549 Y134.747 I1.562 J-1.707 E.00384
; LINE_WIDTH: 0.240277
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288561
G3 X99.236 Y134.304 I1.68 J-1.154 E.00336
; LINE_WIDTH: 0.336667
G3 X99.087 Y134.016 I3.593 J-2.034 E.00776
; LINE_WIDTH: 0.37465
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400411
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.524 J-1.313 E.01038
; LINE_WIDTH: 0.478968
G1 F11007.974
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516474
G1 F10136.119
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.913
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.114965
G1 F11455
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153131
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197194
G1 X99.03 Y131.382 E.0013
; LINE_WIDTH: 0.230996
G1 X99.068 Y131.286 E.00158
; LINE_WIDTH: 0.261736
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.29155
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322954
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.35113
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379408
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415399
G3 X99.539 Y130.599 I.679 J.512 E.00581
; LINE_WIDTH: 0.447769
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.465003
G1 F11372.193
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494313
G1 F10633.753
G3 X100.388 Y129.998 I2.92 J4.151 E.02484
; LINE_WIDTH: 0.542806
G1 F9602.189
G3 X101.286 Y129.65 I3.455 J7.579 E.03925
G2 X104.541 Y128.735 I-51.669 J-189.987 E.13773
; LINE_WIDTH: 0.493708
G1 F10648.034
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.515
G2 X105.695 Y128.292 I-2.402 J-6.618 E.02706
; LINE_WIDTH: 0.433691
G1 F11455
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02136
; LINE_WIDTH: 0.383735
G2 X106.523 Y127.695 I-2.956 J-3.484 E.00984
; LINE_WIDTH: 0.348861
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320216
G2 X106.735 Y127.443 I-1.831 J-1.572 E.00443
; LINE_WIDTH: 0.292301
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255995
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.233501
G1 X106.928 Y127.143 E.0011
; LINE_WIDTH: 0.205151
G1 X107.01 Y126.961 E.00263
; LINE_WIDTH: 0.155152
G1 X107.091 Y126.78 E.00182
; LINE_WIDTH: 0.112571
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.563065
G1 F9228.201
M204 S6000
G1 X107.223 Y125.208 E.01146
G2 X107.177 Y124.94 I-6.755 J1.02 E.01152
; LINE_WIDTH: 0.522381
G1 F10011.249
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486107
G1 F10830.65
G2 X107.111 Y124.691 I-1.783 J.405 E.00528
; LINE_WIDTH: 0.44768
G1 F11455
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402679
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374815
G1 X106.923 Y124.208 E.00074
; LINE_WIDTH: 0.358819
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.32626
G2 X106.694 Y123.803 I-1.507 J.719 E.00622
; LINE_WIDTH: 0.29599
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276525
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240873
G2 X106.371 Y123.389 I-2.527 J1.81 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184713
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153187
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.12022
G2 X105.616 Y122.762 I-1.871 J2.162 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z3.4 F42000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.122045
G1 F11455
M204 S6000
G2 X99.912 Y123.647 I9.336 J11.93 E.00482
; LINE_WIDTH: 0.147282
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173383
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11455
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11455
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 16/25
; update layer progress
M73 L16
M991 S0 P15 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z3.4 I.049 J1.216 P1  F42000
M73 P87 R3
G1 X150.266 Y124.516 Z3.4
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X150.467 Y124.693 E.00887
G2 X151.073 Y125.01 I2.817 J-4.637 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.669 J.127 E.02282
G3 X150.369 Y125.678 I-.237 J-.333 E.02429
G3 X150.255 Y124.575 I1.93 J-.757 E.03724
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09208
G1 X150.604 Y124.785 E-.0629
G1 X151.073 Y125.01 E-.19773
G1 X151.148 Y125.063 E-.03496
G1 X151.188 Y125.226 E-.06384
G1 X151.193 Y125.334 E-.04108
G1 X151.156 Y125.613 E-.10688
G1 X151.082 Y125.753 E-.0599
G1 X150.983 Y125.853 E-.05369
G1 X150.868 Y125.899 E-.04693
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.01919
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21639
G1 X157.113 Y124.547 E-.22777
G1 X157.334 Y125.082 E-.21988
G1 X157.34 Y125.107 E-.00985
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z3.6 F42000
G1 X151.408 Y134.226 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.093 J3.67 E.02088
G3 X150.24 Y128.113 I.702 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01736
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.911 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00611
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.373 J1.31 E.06571
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.049 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01683
G3 X151.438 Y124.802 I-.844 J2.255 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.02551
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G1 X153.373 Y122.03 E.02225
G1 X154.334 Y122.115 E.02966
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.535 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.6 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z3.6
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z3.6 F4000
            G39.3 S1
            G0 Z3.6 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.71 Y128.997 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288625
G1 F11455
M204 S6000
G2 X150.503 Y128.334 I-98.407 J30.231 E.0139
; LINE_WIDTH: 0.240764
G1 X150.486 Y128.298 E.00065
; LINE_WIDTH: 0.197101
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158805
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.123264
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.123071
G1 F11455
M204 S6000
G3 X150.289 Y123.904 I1.897 J.251 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.118041
G1 F11455
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148777
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179215
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221058
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261696
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306019
G1 X155.669 Y122.961 E.0038
; LINE_WIDTH: 0.349868
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390983
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416972
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.48768
G1 F10792.334
M204 S6000
G1 X155.547 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.11435
G1 F11455
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149202
G1 X156.813 Y124.563 E.00106
; LINE_WIDTH: 0.184053
G1 X156.86 Y124.676 E.00141
; LINE_WIDTH: 0.21775
G3 X156.928 Y124.883 I-2.629 J.969 E.00311
; LINE_WIDTH: 0.258742
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306096
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.447 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.45828
G1 F11455
M204 S6000
G1 X155.937 Y129.238 E.00552
; LINE_WIDTH: 0.492909
G1 F10666.944
G1 X155.958 Y129.401 E.00604
; LINE_WIDTH: 0.492632
G1 F10673.514
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453249
G1 F11455
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410309
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362692
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317837
G1 X155.307 Y129.876 E.00363
; LINE_WIDTH: 0.270729
G3 X155.153 Y129.966 I-1.196 J-1.851 E.00331
; LINE_WIDTH: 0.242575
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213449
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164568
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.1202
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.843 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74104
G1 X154.756 Y130.129 E-.01896
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11455
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11455
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401435
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359233
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z3.6 F42000
G1 X141.597 Y130.591 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.891 J3.283 E.02461
G1 X140.907 Y132.132 E.0153
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.0911
G1 X141.987 Y130.622 E-.08133
G1 X142.082 Y130.683 E-.04294
G1 X142.16 Y130.77 E-.04454
G1 X142.238 Y130.969 E-.081
G1 X142.242 Y131.177 E-.07924
G1 X142.224 Y131.286 E-.04176
G1 X142.17 Y131.407 E-.05037
G1 X142.111 Y131.472 E-.03343
G1 X141.949 Y131.564 E-.07094
G1 X141.592 Y131.686 E-.14334
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.805 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24043
G1 X147.611 Y130.255 E-.05258
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.527 Y124.562 Z3.6 F42000
G1 X141.547 Y123.464 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X141.506 Y123.503 E.00189
G1 X140.687 Y122.602 E.04038
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.08799
G1 X142.476 Y123.044 E.04224
G2 X141.688 Y123.329 I.256 J1.935 E.02801
G1 X141.59 Y123.422 E.00447
M204 S250
G1 X141.837 Y123.733 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X141.854 Y124.138 I.283 J.191 E.01334
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.811 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.959 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.022 E.0168
G2 X141.353 Y132.269 I.244 J1.09 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.573 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.389 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.493 Y124.541 E.07189
G1 X148.598 Y125.774 E.03803
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.928 Y123.642 I.182 J1.533 E.02012
G2 X141.875 Y123.686 I.192 J.282 E.00213
M204 S10000
G1 X141.605 Y123.709 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.112836
G1 F11455
M204 S6000
G1 X141.551 Y123.786 E.00053
G1 X141.574 Y123.87 E.00049
; WIPE_START
G1 F15000
G1 X141.551 Y123.786 E-.36612
G1 X141.605 Y123.709 E-.39388
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.231 Y122.806 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.30964
G1 F11455
M204 S6000
G1 X141.343 Y123.021 E.01986
M204 S10000
G1 X141.312 Y122.987 F42000
; LINE_WIDTH: 0.19494
G1 F11455
M204 S6000
G1 X141.969 Y122.881 E.00825
; LINE_WIDTH: 0.168935
G1 X142.182 Y122.855 E.0022
; LINE_WIDTH: 0.120925
G1 X142.395 Y122.829 E.00136
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11455
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11455
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156227
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.19015
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235123
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199155
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101125
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.481843
G1 F10935.867
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11455
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380991
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337797
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291709
G3 X146.552 Y134.367 I-1.297 J-1.366 E.00313
; LINE_WIDTH: 0.2638
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164869
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121267
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.110963
G1 F11455
M204 S6000
G1 X140.964 Y132.915 E.00075
; LINE_WIDTH: 0.147079
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185491
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218682
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247193
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.612 F42000
; LINE_WIDTH: 0.12114
G1 F11455
M204 S6000
G3 X141.111 Y132.246 I4.001 J2.883 E.00298
M204 S10000
G1 X141.096 Y132.233 F42000
; LINE_WIDTH: 0.19791
G1 F11455
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.233 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z3.6 F42000
G1 X148.316 Y125.064 Z3.6
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.120213
G1 F11455
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168498
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218006
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267513
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119653
G1 F11455
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165114
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189773
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.16889
G1 F11455
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.343 Z3.6 F42000
G1 X138.362 Y132.423 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.737 E.01058
G3 X138.732 Y134.417 I-15.99 J3.238 E.05638
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.036 J-.259 E.0123
G3 X137.949 Y134.235 I1.736 J-.307 E.00997
G3 X138.22 Y132.423 I18.447 J1.837 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.737 E-.12118
G1 X138.635 Y133.581 E-.32618
G1 X138.716 Y134.279 E-.26701
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X138.67 Y131.626 E.05092
G3 X139.126 Y134.368 I-31.375 J6.626 E.08545
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.118986
G1 F11455
M204 S6000
G1 X138.321 Y131.076 E.00076
; LINE_WIDTH: 0.163115
G1 X138.321 Y131.199 E.00121
; LINE_WIDTH: 0.207244
G1 X138.321 Y131.322 E.00165
; LINE_WIDTH: 0.251373
G1 X138.321 Y131.445 E.00209
; LINE_WIDTH: 0.295502
G1 X138.321 Y131.569 E.00253
; LINE_WIDTH: 0.339631
G1 X138.321 Y131.692 E.00298
; LINE_WIDTH: 0.381358
G1 X138.321 Y131.87 E.00492
; LINE_WIDTH: 0.420673
G1 X138.321 Y132.049 E.00549
; LINE_WIDTH: 0.459987
G1 X138.321 Y132.227 E.00607
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11455
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.24674
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.28204
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329042
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376045
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404895
G3 X138.347 Y134.591 I-2.285 J.277 E.01023
; WIPE_START
G1 F13260.585
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z3.6 F42000
G1 X130.165 Y128.941 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G3 X130.61 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.583 J.981 E.02847
G3 X132.643 Y122.341 I1.774 J1.41 E.05781
G3 X133.879 Y122.579 I.197 J2.313 E.03916
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.1718
G1 X130.87 Y129.485 E-.18905
G1 X130.61 Y129.024 E-.2008
G1 X130.436 Y128.532 E-.19834
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21993
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24118
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.218 Y122.067 E.01415
G1 X133.476 Y122.089 E.00797
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11455
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11455
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120932
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.505457
G1 F10377.562
M204 S6000
G1 X130.3 Y129.361 E.0127
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448148
G1 F11455
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403256
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361937
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326587
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289361
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252136
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218551
G2 X131.122 Y130.176 I1.359 J-1.682 E.00264
; LINE_WIDTH: 0.185252
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.14606
G1 X131.343 Y130.314 E.00109
; LINE_WIDTH: 0.111382
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.314 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11455
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183765
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327158
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.374457
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416506
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.44335
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492733
G1 F10671.114
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11455
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216419
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149196
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.48767
G1 F10792.58
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445978
G1 F11455
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401296
G2 X135.075 Y123.17 I-2.199 J1.712 E.0068
; LINE_WIDTH: 0.369996
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344922
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307411
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.2699
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.23021
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170245
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124757
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994646
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.0995173
G1 F11455
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127455
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177269
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204269
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224484
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260976
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300075
G2 X130.759 Y122.986 I1.394 J1.824 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513082
G1 F10209.252
M204 S6000
G1 X130.191 Y123.685 E.03889
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444818
G1 F11455
M204 S6000
G3 X130.649 Y123.102 I6.948 J5.53 E.02451
; LINE_WIDTH: 0.396818
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361835
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.264 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03159
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03093
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X126.848 Y123.319 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.764 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02505
M204 S10000
G1 X126.939 Y122.601 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0998625
G1 F11455
M204 S6000
G3 X127.108 Y122.406 I1.87 J1.443 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101453
G1 F11455
M204 S6000
G2 X126.982 Y122.483 I.451 J2.528 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.120476
G1 F11455
M204 S6000
G1 X126.215 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.11813
G1 F11455
M204 S6000
G2 X125.339 Y122.406 I-3.336 J2.397 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.16212
G1 F11455
M204 S6000
G3 X125.481 Y122.505 I-1.003 J3.845 E.00282
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z3.6 F42000
G1 X126.229 Y134.784 Z3.6
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.121653
G1 F11455
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169631
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215741
G1 X126.155 Y135.28 E.00171
; LINE_WIDTH: 0.255281
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991937
G1 F11455
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.12167
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162883
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149275
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114374
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X121.949 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.218 J-1.126 E.01652
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02033
; WIPE_START
G1 F11791.304
G1 X121.949 Y130.272 E-.02629
G1 X122.103 Y130.078 E-.10814
G1 X122.227 Y129.861 E-.10896
G1 X122.348 Y130.013 E-.08483
G1 X122.622 Y130.272 E-.16433
G1 X122.009 Y130.272 E-.26745
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25567
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23413
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.213 J-.261 E.01413
G1 X115.542 Y130.272 E.04437
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02308
G1 X115.742 Y129.968 E-.15233
G1 X115.891 Y129.724 E-.1086
G1 X116.431 Y128.593 E-.47599
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z3.6 F42000
G1 X115.146 Y120.124 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G3 X114.732 Y119.747 I-.073 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01244
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01657
G3 X115.338 Y120.007 I-.692 J.189 E.00585
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07709
G1 X114.92 Y120.097 E-.03253
G1 X114.825 Y120.029 E-.04447
G1 X114.777 Y119.962 E-.03122
G1 X114.732 Y119.747 E-.08371
G1 X114.744 Y119.606 E-.05382
G1 X114.804 Y119.434 E-.06888
G1 X114.934 Y119.264 E-.08159
G1 X115.054 Y119.165 E-.05906
G1 X115.378 Y118.976 E-.14246
G1 X115.317 Y119.192 E-.08518
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z3.6 F42000
G1 X110.311 Y130.57 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.646 J.67 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.49 J1.893 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05006
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.322 J-3.234 E.02985
G2 X115.546 Y129.537 I-.692 J-1.248 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.345 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X116.072 Y118.612 I.582 J2.221 E.02706
G3 X117.064 Y118.892 I-.304 J2.969 E.03182
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20009
G3 X117.08 Y129.654 I-.528 J.957 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03275
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.10261
G1 F11455
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124311
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155153
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11455
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225174
G1 F11455
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11455
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132613
G1 F11455
M204 S6000
G2 X115.218 Y130.242 I-2.654 J-3.508 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.11407
G1 F11455
M204 S6000
G2 X117.278 Y130.468 I2.284 J-1.697 E.00132
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112455
G1 F11455
M204 S6000
G3 X117.164 Y130.396 I.574 J-2.764 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.130489
G1 F11455
M204 S6000
G2 X121.609 Y130.384 I-.571 J-4.829 E.00275
M204 S10000
G1 X121.689 Y130.247 F42000
; LINE_WIDTH: 0.117595
G1 F11455
M204 S6000
G3 X121.435 Y130.468 I-3.038 J-3.239 E.00205
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115534
G1 F11455
M204 S6000
G3 X122.174 Y129.56 I-3.505 J.848 E.00146
M204 S10000
G1 X122.104 Y129.637 F42000
; LINE_WIDTH: 0.107617
G1 F11455
M204 S6000
G2 X122.185 Y129.406 I-3.503 J-1.368 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.11558
G1 F11455
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152902
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.122869
G1 F11455
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.42 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z3.6 F42000
G1 X116.263 Y118.858 Z3.6
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.107178
G1 F11455
M204 S6000
G1 X116.054 Y118.847 E.0011
; LINE_WIDTH: 0.136197
G1 X115.927 Y118.851 E.00097
; LINE_WIDTH: 0.175168
G1 X115.798 Y118.866 E.0014
; LINE_WIDTH: 0.210073
G2 X115.601 Y118.909 I.292 J1.787 E.00275
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.167924
G1 F11455
M204 S6000
G1 X115.775 Y118.785 E.00388
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.1731
G1 F11455
M204 S6000
G2 X115.008 Y119.749 I1.815 J.193 E.00287
G1 X115.045 Y119.861 E.00126
; LINE_WIDTH: 0.146628
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.11038
G1 F11455
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139216
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200511
G2 X111.979 Y122.317 I.107 J1.471 E.002
; LINE_WIDTH: 0.238864
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282857
G2 X111.737 Y122.375 I.319 J1.592 E.00265
; LINE_WIDTH: 0.321773
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354813
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394144
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433215
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440611
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413479
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12953.399
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.729 J143.27 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16429
G1 X107.141 Y125.672 E-.067
G1 X107.368 Y125.672 E-.08633
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09726
G1 X107.334 Y126.831 E-.16572
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z3.6 F42000
G1 X99.457 Y123.958 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z3.6 F42000
G1 X105.735 Y134.549 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.0467
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.785 J143.421 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
M73 P88 R3
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.736 Y122.041 E.00908
G1 X103.903 Y122.048 E.00513
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11455
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11455
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11455
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.106752
G1 F11455
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131352
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159959
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.191695
G3 X99.549 Y134.747 I1.56 J-1.705 E.00384
; LINE_WIDTH: 0.240256
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288575
G3 X99.236 Y134.303 I1.669 J-1.147 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.591 J-2.033 E.00775
; LINE_WIDTH: 0.374657
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400393
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478969
G1 F11007.936
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516476
G1 F10136.086
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.914
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.11498
G1 F11455
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153128
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197173
G1 X99.03 Y131.383 E.0013
; LINE_WIDTH: 0.230969
G1 X99.068 Y131.287 E.00158
; LINE_WIDTH: 0.2617
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291533
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322956
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.35115
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379415
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415417
G3 X99.539 Y130.599 I.68 J.513 E.00581
; LINE_WIDTH: 0.447773
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464988
G1 F11372.593
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494315
G1 F10633.704
G3 X100.388 Y129.998 I2.919 J4.149 E.02484
; LINE_WIDTH: 0.542806
G1 F9602.189
G3 X101.286 Y129.65 I3.455 J7.58 E.03925
G2 X104.541 Y128.735 I-51.669 J-189.987 E.13773
; LINE_WIDTH: 0.493708
G1 F10648.034
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.515
G2 X105.695 Y128.292 I-2.402 J-6.618 E.02706
; LINE_WIDTH: 0.433695
G1 F11455
G2 X106.262 Y127.934 I-2.208 J-4.126 E.02137
; LINE_WIDTH: 0.383736
G2 X106.523 Y127.695 I-2.957 J-3.486 E.00984
; LINE_WIDTH: 0.348869
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320224
G2 X106.735 Y127.443 I-1.831 J-1.573 E.00443
; LINE_WIDTH: 0.292296
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255993
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220466
G2 X106.983 Y127.022 I-1.065 J-.633 E.00295
; LINE_WIDTH: 0.180142
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.146802
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.112559
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.258 Y125.476 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.563061
G1 F9228.268
M204 S6000
G2 X107.177 Y124.94 I-7.346 J.847 E.02298
; LINE_WIDTH: 0.522387
G1 F10011.12
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486115
G1 F10830.456
G2 X107.111 Y124.691 I-1.79 J.407 E.00528
; LINE_WIDTH: 0.447687
G1 F11455
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402673
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374804
G1 X106.924 Y124.208 E.00074
; LINE_WIDTH: 0.358819
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326258
G2 X106.694 Y123.803 I-1.508 J.72 E.00622
; LINE_WIDTH: 0.295994
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276525
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240873
G2 X106.371 Y123.389 I-2.527 J1.81 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184722
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.1532
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120221
G2 X105.616 Y122.762 I-1.869 J2.16 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z3.6 F42000
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.122044
G1 F11455
M204 S6000
G2 X99.912 Y123.647 I9.341 J11.935 E.00482
; LINE_WIDTH: 0.147282
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173385
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11455
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449904
G1 F11455
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402734
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355565
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308395
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235529
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 17/25
; update layer progress
M73 L17
M991 S0 P16 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z3.6 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z3.6
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X150.467 Y124.693 E.00888
G2 X151.073 Y125.01 I2.817 J-4.637 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.67 J.127 E.02283
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09208
G1 X150.604 Y124.785 E-.06288
G1 X151.073 Y125.01 E-.19774
G1 X151.148 Y125.063 E-.03498
G1 X151.188 Y125.226 E-.06384
G1 X151.193 Y125.334 E-.04108
G1 X151.156 Y125.613 E-.10694
G1 X151.082 Y125.753 E-.05984
G1 X150.983 Y125.853 E-.05375
G1 X150.868 Y125.899 E-.04687
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21642
G1 X157.113 Y124.547 E-.22769
G1 X157.334 Y125.082 E-.21992
G1 X157.34 Y125.107 E-.00987
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z3.8 F42000
G1 X151.408 Y134.226 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.409 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.103 J3.677 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01737
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00611
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.373 J1.31 E.06572
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01684
G3 X151.438 Y124.802 I-.844 J2.255 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06369
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G1 X153.366 Y122.03 E.02204
G1 X154.334 Y122.115 E.02988
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.8 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z3.8
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z3.8 F4000
            G39.3 S1
            G0 Z3.8 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.28863
G1 F11455
M204 S6000
G2 X150.503 Y128.334 I-82.637 J25.29 E.01388
; LINE_WIDTH: 0.240762
G1 X150.486 Y128.298 E.00065
; LINE_WIDTH: 0.197046
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158769
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.123082
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.123026
G1 F11455
M204 S6000
G3 X150.289 Y123.904 I1.888 J.249 E.00208
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.118044
G1 F11455
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148777
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179217
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221064
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261706
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306033
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.34987
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390975
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.41696
G1 X156.253 Y123.483 E.01433
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487692
G1 F10792.067
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.114347
G1 F11455
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149194
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.18404
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.631 J.97 E.00311
; LINE_WIDTH: 0.258743
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306097
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.447 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458138
G1 F11455
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492769
G1 F10670.267
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492629
G1 F10673.572
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453242
G1 F11455
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410299
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362692
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317837
G1 X155.307 Y129.876 E.00363
; LINE_WIDTH: 0.270729
G3 X155.153 Y129.966 I-1.196 J-1.851 E.00331
; LINE_WIDTH: 0.242577
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213453
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164581
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120194
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.844 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74105
G1 X154.756 Y130.129 E-.01895
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11455
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11455
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401435
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359233
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z3.8 F42000
G1 X141.597 Y130.591 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.02889
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.281 E.02461
G1 X140.907 Y132.132 E.01529
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.09112
G1 X141.987 Y130.622 E-.0813
G1 X142.082 Y130.683 E-.043
G1 X142.16 Y130.77 E-.04452
G1 X142.238 Y130.969 E-.08098
G1 X142.242 Y131.177 E-.07925
G1 X142.207 Y131.337 E-.0623
G1 X142.148 Y131.436 E-.04355
G1 X142.033 Y131.525 E-.05565
G1 X141.949 Y131.564 E-.03505
G1 X141.592 Y131.686 E-.1433
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.804 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24043
G1 X147.611 Y130.255 E-.05258
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.527 Y124.562 Z3.8 F42000
G1 X141.547 Y123.464 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X141.506 Y123.503 E.00189
G1 X140.687 Y122.602 E.04038
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.088
G1 X142.475 Y123.044 E.04224
G2 X141.688 Y123.329 I.256 J1.934 E.02801
G1 X141.59 Y123.422 E.00447
M204 S250
G1 X141.837 Y123.733 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X141.854 Y124.138 I.283 J.191 E.01334
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.959 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.021 E.0168
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.572 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.388 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.47 Y124.276 E.0637
G1 X148.598 Y125.774 E.04622
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.928 Y123.642 I.182 J1.532 E.02013
G2 X141.875 Y123.686 I.191 J.282 E.00213
M204 S10000
G1 X141.605 Y123.71 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.112866
G1 F11455
M204 S6000
G1 X141.551 Y123.786 E.00053
G1 X141.574 Y123.87 E.0005
; WIPE_START
G1 F15000
G1 X141.551 Y123.786 E-.3668
G1 X141.605 Y123.71 E-.3932
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.231 Y122.806 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.309694
G1 F11455
M204 S6000
G1 X141.343 Y123.021 E.01988
M204 S10000
G1 X141.312 Y122.987 F42000
; LINE_WIDTH: 0.19492
G1 F11455
M204 S6000
G1 X141.969 Y122.881 E.00825
; LINE_WIDTH: 0.168935
G1 X142.182 Y122.855 E.0022
; LINE_WIDTH: 0.120925
G1 X142.395 Y122.829 E.00136
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11455
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11455
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156227
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.19015
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235123
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199154
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.481835
G1 F10936.058
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11455
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380991
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337797
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291709
G3 X146.552 Y134.367 I-1.297 J-1.366 E.00313
; LINE_WIDTH: 0.2638
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164869
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121267
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.110972
G1 F11455
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.147095
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185478
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218683
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247207
G1 X140.905 Y132.39 E.00324
M204 S10000
G1 X140.82 Y132.611 F42000
; LINE_WIDTH: 0.12117
G1 F11455
M204 S6000
G3 X141.111 Y132.246 I4.014 J2.894 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197967
G1 F11455
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z3.8 F42000
G1 X148.316 Y125.064 Z3.8
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.120211
G1 F11455
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168495
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.217995
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267496
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119637
G1 F11455
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165073
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189722
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.168842
G1 F11455
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.344 Z3.8 F42000
G1 X138.362 Y132.423 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.737 E.01058
G3 X138.732 Y134.417 I-15.99 J3.238 E.05638
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.037 J-.259 E.0123
G3 X137.949 Y134.235 I1.736 J-.307 E.00997
G3 X138.22 Y132.423 I18.453 J1.838 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.737 E-.12118
G1 X138.635 Y133.581 E-.32618
G1 X138.716 Y134.279 E-.267
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X138.634 Y131.436 E.045
G3 X139.126 Y134.368 I-33.347 J7.102 E.09137
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120897
G1 F11455
M204 S6000
G1 X138.321 Y131.088 E.00086
; LINE_WIDTH: 0.16885
G1 X138.321 Y131.224 E.00139
; LINE_WIDTH: 0.216803
G1 X138.321 Y131.36 E.00192
; LINE_WIDTH: 0.264756
G1 X138.321 Y131.496 E.00245
; LINE_WIDTH: 0.312608
G1 X138.321 Y131.678 E.00402
; LINE_WIDTH: 0.360334
G1 X138.321 Y131.861 E.00473
; LINE_WIDTH: 0.40806
G1 X138.321 Y132.044 E.00544
; LINE_WIDTH: 0.455786
G1 X138.321 Y132.227 E.00615
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11455
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.24674
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.28204
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329042
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376045
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404898
G3 X138.347 Y134.591 I-2.285 J.277 E.01023
; WIPE_START
G1 F13260.506
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z3.8 F42000
G1 X130.165 Y128.941 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G3 X130.61 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.583 J.981 E.02847
G3 X132.659 Y122.341 I1.773 J1.409 E.05831
G3 X133.879 Y122.579 I.182 J2.31 E.03867
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17183
G1 X130.87 Y129.485 E-.18904
G1 X130.61 Y129.024 E-.20079
G1 X130.436 Y128.532 E-.19834
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21994
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24117
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.168 Y122.063 E.01261
G1 X133.476 Y122.089 E.00951
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11455
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.20856
G1 F11455
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.160679
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120931
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.505452
G1 F10377.677
M204 S6000
G1 X130.3 Y129.361 E.0127
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448146
G1 F11455
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403256
G1 X130.561 Y129.681 E.00405
; LINE_WIDTH: 0.361937
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326586
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289364
G1 X130.886 Y129.989 E.00235
; LINE_WIDTH: 0.252142
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218557
G2 X131.122 Y130.176 I1.36 J-1.682 E.00264
; LINE_WIDTH: 0.185257
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.14606
G1 X131.343 Y130.314 E.00109
; LINE_WIDTH: 0.111381
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.314 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.11657
G1 F11455
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183764
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327158
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.374457
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416506
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.44335
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492715
G1 F10671.546
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11455
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216419
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149199
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.487671
G1 F10792.571
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445975
G1 F11455
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401291
G2 X135.075 Y123.17 I-2.185 J1.701 E.0068
; LINE_WIDTH: 0.37001
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344917
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307405
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269894
G1 X134.754 Y122.886 E.00217
; LINE_WIDTH: 0.230205
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170241
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124736
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994563
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.0995173
G1 F11455
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127455
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177269
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204269
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224481
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260967
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.30006
G2 X130.759 Y122.986 I1.381 J1.807 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513079
G1 F10209.328
M204 S6000
G1 X130.191 Y123.685 E.0389
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444822
G1 F11455
M204 S6000
G3 X130.649 Y123.102 I6.947 J5.529 E.02451
; LINE_WIDTH: 0.396829
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361846
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.264 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.324 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03158
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03093
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X126.848 Y123.319 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.764 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.963 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0998637
G1 F11455
M204 S6000
G3 X127.108 Y122.406 I1.871 J1.443 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101432
G1 F11455
M204 S6000
G2 X126.982 Y122.483 I.455 J2.55 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.120459
G1 F11455
M204 S6000
G1 X126.216 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.118139
G1 F11455
M204 S6000
G2 X125.339 Y122.406 I-3.25 J2.334 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162118
G1 F11455
M204 S6000
G3 X125.481 Y122.505 I-1.006 J3.855 E.00282
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z3.8 F42000
G1 X126.229 Y134.784 Z3.8
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.121665
G1 F11455
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169643
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215769
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255292
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.099204
G1 F11455
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121694
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162898
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149306
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114382
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X121.948 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.201 J-1.116 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02035
; WIPE_START
G1 F11791.304
G1 X121.948 Y130.272 E-.02627
G1 X122.103 Y130.078 E-.10826
G1 X122.227 Y129.861 E-.10889
G1 X122.348 Y130.013 E-.08479
G1 X122.622 Y130.272 E-.16424
G1 X122.009 Y130.272 E-.26755
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25567
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.2341
G1 X116.721 Y129.878 E.01398
G2 X116.879 Y130.272 I1.21 J-.26 E.01414
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02309
G1 X115.742 Y129.968 E-.15233
G1 X115.891 Y129.724 E-.1086
G1 X116.431 Y128.593 E-.47598
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z3.8 F42000
G1 X115.146 Y120.124 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.729 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01657
G3 X115.338 Y120.007 I-.691 J.189 E.00584
G3 X115.204 Y120.106 I-.265 J-.219 E.00558
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.0771
G1 X114.92 Y120.097 E-.03255
G1 X114.825 Y120.029 E-.04446
G1 X114.777 Y119.962 E-.03123
G1 X114.732 Y119.747 E-.0837
G1 X114.744 Y119.606 E-.05383
G1 X114.804 Y119.434 E-.06888
G1 X114.934 Y119.264 E-.08159
G1 X115.054 Y119.165 E-.05903
G1 X115.378 Y118.976 E-.1424
G1 X115.317 Y119.192 E-.0852
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z3.8 F42000
G1 X110.311 Y130.57 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.647 J.672 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.49 J1.893 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.322 J-3.234 E.02985
G2 X115.546 Y129.537 I-.692 J-1.248 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.345 J.36 E.01895
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X116.039 Y118.609 I.575 J2.179 E.02604
G3 X117.064 Y118.892 I-.262 J2.946 E.03284
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.129 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20008
G3 X117.08 Y129.654 I-.537 J.968 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.10261
G1 F11455
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124311
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155153
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11455
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225174
G1 F11455
M204 S6000
M73 P89 R3
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11455
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132602
G1 F11455
M204 S6000
G2 X115.218 Y130.242 I-2.717 J-3.581 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.113987
G1 F11455
M204 S6000
G2 X117.278 Y130.468 I2.3 J-1.711 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112457
G1 F11455
M204 S6000
G3 X117.164 Y130.396 I.564 J-2.716 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.130447
G1 F11455
M204 S6000
G2 X121.608 Y130.384 I-.565 J-4.783 E.00273
M204 S10000
G1 X121.687 Y130.249 F42000
; LINE_WIDTH: 0.11688
G1 F11455
M204 S6000
G3 X121.434 Y130.468 I-3.012 J-3.217 E.00202
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115533
G1 F11455
M204 S6000
G3 X122.174 Y129.56 I-3.504 J.847 E.00146
M204 S10000
G1 X122.104 Y129.637 F42000
; LINE_WIDTH: 0.107587
G1 F11455
M204 S6000
G2 X122.185 Y129.406 I-3.497 J-1.366 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.11558
G1 F11455
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152901
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11455
M204 S6000
G3 X123.03 Y130.387 I.572 J-4.447 E.00227
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z3.8 F42000
G1 X116.263 Y118.858 Z3.8
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.109722
G1 F11455
M204 S6000
G1 X116.021 Y118.848 E.00132
; LINE_WIDTH: 0.139904
G1 X115.927 Y118.851 E.00074
; LINE_WIDTH: 0.175132
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210043
G2 X115.6 Y118.909 I.293 J1.787 E.00276
M204 S10000
G1 X115.558 Y119.099 F42000
; LINE_WIDTH: 0.16811
G1 F11455
M204 S6000
G1 X115.775 Y118.785 E.00389
; WIPE_START
G1 F15000
G1 X115.558 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.17308
G1 F11455
M204 S6000
G2 X115.008 Y119.749 I1.823 J.194 E.00287
G1 X115.045 Y119.861 E.00126
; LINE_WIDTH: 0.146591
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.110386
G1 F11455
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139229
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.20051
G2 X111.979 Y122.317 I.107 J1.471 E.002
; LINE_WIDTH: 0.238861
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282849
G2 X111.737 Y122.375 I.315 J1.575 E.00265
; LINE_WIDTH: 0.321765
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354819
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394149
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433218
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440643
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413544
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12951.135
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.213 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.707 J143.193 E.13155
G1 X105.53 Y127.924 E.0239
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16434
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09726
G1 X107.334 Y126.83 E-.16567
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25822
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25574
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z3.8 F42000
G1 X99.457 Y123.958 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z3.8 F42000
G1 X105.735 Y134.549 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.0467
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.822 I41.772 J143.375 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.704 Y122.04 E.00809
G1 X103.903 Y122.048 E.00613
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115055
G1 F11455
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133216
G1 F11455
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70026
G1 X105.695 Y134.21 E-.05974
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11455
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.106736
G1 F11455
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131365
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159974
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.19171
G3 X99.549 Y134.747 I1.56 J-1.705 E.00384
; LINE_WIDTH: 0.240256
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288573
G3 X99.236 Y134.303 I1.669 J-1.147 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.589 J-2.033 E.00775
; LINE_WIDTH: 0.374649
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400388
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478966
G1 F11008.028
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516474
G1 F10136.135
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.913
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.11498
G1 F11455
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153128
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197176
G1 X99.03 Y131.383 E.0013
; LINE_WIDTH: 0.230973
G1 X99.068 Y131.287 E.00158
; LINE_WIDTH: 0.261706
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291537
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322959
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351153
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379426
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415408
G3 X99.539 Y130.599 I.68 J.512 E.00581
; LINE_WIDTH: 0.447752
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.46498
G1 F11372.805
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494305
G1 F10633.943
G3 X100.388 Y129.998 I2.919 J4.15 E.02484
; LINE_WIDTH: 0.542803
G1 F9602.251
G3 X101.286 Y129.65 I3.457 J7.584 E.03925
G2 X104.541 Y128.735 I-51.686 J-190.048 E.13773
; LINE_WIDTH: 0.493699
G1 F10648.237
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471703
G1 F11194.486
G2 X105.695 Y128.292 I-2.402 J-6.62 E.02706
; LINE_WIDTH: 0.433689
G1 F11455
G2 X106.262 Y127.934 I-2.207 J-4.125 E.02136
; LINE_WIDTH: 0.383729
G2 X106.523 Y127.695 I-2.954 J-3.483 E.00984
; LINE_WIDTH: 0.348852
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320216
G2 X106.735 Y127.443 I-1.846 J-1.585 E.00443
; LINE_WIDTH: 0.292293
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255997
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220472
G2 X106.983 Y127.022 I-1.06 J-.631 E.00295
; LINE_WIDTH: 0.180153
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.146819
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.112566
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.563065
G1 F9228.208
M204 S6000
G1 X107.223 Y125.208 E.01146
G2 X107.177 Y124.94 I-6.752 J1.019 E.01152
; LINE_WIDTH: 0.522391
G1 F10011.046
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486118
G1 F10830.376
G2 X107.111 Y124.691 I-1.795 J.409 E.00528
; LINE_WIDTH: 0.447687
G1 F11455
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402673
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374804
G1 X106.924 Y124.208 E.00074
; LINE_WIDTH: 0.358819
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326258
G2 X106.694 Y123.803 I-1.508 J.72 E.00622
; LINE_WIDTH: 0.295994
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276525
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240873
G2 X106.371 Y123.389 I-2.527 J1.81 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184713
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153187
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.12022
G2 X105.616 Y122.762 I-1.871 J2.162 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z3.8 F42000
G1 Z3.4
G1 E.8 F1800
; LINE_WIDTH: 0.122044
G1 F11455
M204 S6000
G2 X99.912 Y123.647 I9.341 J11.935 E.00482
; LINE_WIDTH: 0.147282
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173385
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11455
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11455
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 18/25
; update layer progress
M73 L18
M991 S0 P17 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z3.8 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z3.8
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X150.467 Y124.693 E.00888
G2 X151.073 Y125.01 I2.816 J-4.634 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.67 J.127 E.02282
G3 X150.369 Y125.678 I-.237 J-.333 E.02429
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09209
G1 X150.604 Y124.785 E-.0629
G1 X151.073 Y125.01 E-.19774
G1 X151.148 Y125.063 E-.03496
G1 X151.188 Y125.226 E-.06382
G1 X151.193 Y125.334 E-.0411
G1 X151.156 Y125.613 E-.10693
G1 X151.082 Y125.753 E-.05986
G1 X150.983 Y125.853 E-.05369
G1 X150.868 Y125.899 E-.04692
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z4 F42000
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21642
G1 X157.113 Y124.547 E-.22769
G1 X157.334 Y125.082 E-.21992
G1 X157.34 Y125.107 E-.00986
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z4 F42000
G1 X151.408 Y134.226 Z4
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.101 J3.676 E.02088
M73 P89 R2
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01736
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00611
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.373 J1.31 E.06572
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.049 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01684
G3 X151.438 Y124.802 I-.844 J2.254 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06369
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G3 X153.404 Y122.031 I.621 J4.593 E.02323
G1 X154.334 Y122.115 E.02871
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z4
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z4 F4000
            G39.3 S1
            G0 Z4 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288633
G1 F11455
M204 S6000
G2 X150.503 Y128.334 I-87.29 J26.762 E.01389
; LINE_WIDTH: 0.240708
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.197068
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158804
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.123121
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.123057
G1 F11455
M204 S6000
G3 X150.289 Y123.904 I1.896 J.251 E.00208
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.118044
G1 F11455
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148777
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179217
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221064
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261706
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306033
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.34987
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390975
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416961
G1 X156.253 Y123.483 E.01433
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487701
G1 F10791.825
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.114346
G1 F11455
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149191
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.184036
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.631 J.97 E.00311
; LINE_WIDTH: 0.258743
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306097
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.447 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458138
G1 F11455
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492769
G1 F10670.267
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492629
G1 F10673.572
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453242
G1 F11455
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410299
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362692
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317837
G1 X155.307 Y129.876 E.00363
; LINE_WIDTH: 0.270729
G3 X155.153 Y129.966 I-1.196 J-1.851 E.00331
; LINE_WIDTH: 0.242577
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213453
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164581
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120194
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.844 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74105
G1 X154.756 Y130.129 E-.01895
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11455
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11455
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401444
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359236
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z4 F42000
G1 X141.597 Y130.591 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.281 E.02461
G1 X140.907 Y132.132 E.01529
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.0911
G1 X141.987 Y130.622 E-.08133
G1 X142.082 Y130.683 E-.04295
G1 X142.161 Y130.77 E-.04458
G1 X142.238 Y130.969 E-.08095
G1 X142.242 Y131.177 E-.07927
G1 X142.224 Y131.286 E-.04175
G1 X142.17 Y131.407 E-.05036
G1 X142.111 Y131.472 E-.03342
G1 X141.949 Y131.564 E-.07097
G1 X141.592 Y131.686 E-.14333
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z4 F42000
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.804 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24043
G1 X147.611 Y130.255 E-.05258
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.527 Y124.562 Z4 F42000
G1 X141.547 Y123.464 Z4
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X141.506 Y123.503 E.00188
G1 X140.687 Y122.602 E.04038
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.088
G1 X142.476 Y123.044 E.04224
G2 X141.688 Y123.329 I.256 J1.936 E.02801
G1 X141.59 Y123.423 E.00448
M204 S250
G1 X141.837 Y123.733 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X141.854 Y124.138 I.283 J.191 E.01334
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.021 E.0168
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.573 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.388 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.447 Y124.01 E.05551
G1 X148.598 Y125.774 E.05441
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.928 Y123.642 I.182 J1.533 E.02013
G2 X141.875 Y123.686 I.192 J.282 E.00213
M204 S10000
G1 X141.605 Y123.71 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.112777
G1 F11455
M204 S6000
G1 X141.551 Y123.786 E.00053
G1 X141.574 Y123.87 E.00049
; WIPE_START
G1 F15000
G1 X141.551 Y123.786 E-.36687
G1 X141.605 Y123.71 E-.39313
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.231 Y122.806 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.309584
G1 F11455
M204 S6000
G1 X141.343 Y123.021 E.01985
M204 S10000
G1 X141.312 Y122.987 F42000
; LINE_WIDTH: 0.19495
G1 F11455
M204 S6000
G1 X141.969 Y122.881 E.00825
; LINE_WIDTH: 0.168965
G1 X142.182 Y122.855 E.0022
; LINE_WIDTH: 0.120935
G1 X142.395 Y122.829 E.00136
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11455
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11455
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156227
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.19015
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235123
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199154
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.481835
G1 F10936.058
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11455
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380986
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337783
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291689
G3 X146.552 Y134.367 I-1.307 J-1.378 E.00313
; LINE_WIDTH: 0.263784
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164869
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.12127
G1 X145.883 Y134.759 E.00226
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.110972
G1 F11455
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.147096
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185488
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218685
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247193
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.612 F42000
; LINE_WIDTH: 0.121145
G1 F11455
M204 S6000
G3 X141.111 Y132.246 I4.001 J2.883 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197871
G1 F11455
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z4 F42000
G1 X148.316 Y125.064 Z4
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.120198
G1 F11455
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168486
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218006
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267526
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.839 Y123.724 F42000
; LINE_WIDTH: 0.119654
G1 F11455
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165114
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189784
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.168866
G1 F11455
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.343 Z4 F42000
G1 X138.362 Y132.423 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.736 E.01057
G3 X138.732 Y134.417 I-15.993 J3.239 E.05639
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.036 J-.258 E.0123
G3 X137.949 Y134.235 I1.736 J-.307 E.00997
G3 X138.22 Y132.423 I18.453 J1.838 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.736 E-.12108
G1 X138.635 Y133.581 E-.32628
G1 X138.716 Y134.279 E-.267
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X138.599 Y131.247 E.03908
G3 X139.126 Y134.368 I-35.334 J7.579 E.0973
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.116729
G1 F11455
M204 S6000
G1 X138.321 Y131.068 E.00069
; LINE_WIDTH: 0.156346
G1 X138.321 Y131.184 E.00107
; LINE_WIDTH: 0.195963
G1 X138.321 Y131.299 E.00144
; LINE_WIDTH: 0.237762
G1 X138.321 Y131.454 E.00246
; LINE_WIDTH: 0.281738
G1 X138.321 Y131.609 E.00301
; LINE_WIDTH: 0.325713
G1 X138.321 Y131.763 E.00356
; LINE_WIDTH: 0.369688
G1 X138.321 Y131.918 E.00412
; LINE_WIDTH: 0.413664
G1 X138.321 Y132.073 E.00467
; LINE_WIDTH: 0.457639
G1 X138.321 Y132.227 E.00523
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11455
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.246741
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.28204
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329042
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376045
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404898
G3 X138.347 Y134.591 I-2.285 J.277 E.01023
; WIPE_START
G1 F13260.503
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z4 F42000
G1 X130.165 Y128.941 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G3 X130.61 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.582 J.981 E.02847
G3 X132.675 Y122.34 I1.773 J1.409 E.0588
G3 X133.879 Y122.579 I.167 J2.307 E.03817
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.1718
G1 X130.87 Y129.485 E-.18905
G1 X130.61 Y129.024 E-.2008
G1 X130.436 Y128.532 E-.19835
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21993
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24118
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.118 Y122.059 E.01106
G1 X133.476 Y122.089 E.01106
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01954
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11455
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.241 J.721 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11455
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120932
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.505452
G1 F10377.659
M204 S6000
G1 X130.3 Y129.361 E.0127
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448142
G1 F11455
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403254
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361937
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326588
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289365
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252143
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218556
G2 X131.122 Y130.176 I1.348 J-1.666 E.00264
; LINE_WIDTH: 0.185256
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146058
G1 X131.343 Y130.314 E.00109
; LINE_WIDTH: 0.111377
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.314 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11455
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183758
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327159
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.37446
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.41651
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.443353
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492713
G1 F10671.576
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11455
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216418
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149196
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.48767
G1 F10792.58
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445978
G1 F11455
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401296
G2 X135.075 Y123.17 I-2.199 J1.712 E.0068
; LINE_WIDTH: 0.369996
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344924
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307416
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269908
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230221
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170244
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124739
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994516
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.0995167
G1 F11455
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.12747
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177281
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204261
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224484
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260976
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300076
G2 X130.759 Y122.986 I1.383 J1.81 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513098
G1 F10208.901
M204 S6000
G1 X130.191 Y123.685 E.03887
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444828
G1 F11455
M204 S6000
G3 X130.649 Y123.102 I6.951 J5.533 E.02451
; LINE_WIDTH: 0.396834
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361849
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.263 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03158
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03093
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G2 X126.848 Y123.319 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01832
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.764 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.676 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0998634
G1 F11455
M204 S6000
G3 X127.108 Y122.406 I1.871 J1.443 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101441
G1 F11455
M204 S6000
G2 X126.982 Y122.483 I.46 J2.571 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.120458
G1 F11455
M204 S6000
G1 X126.216 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.655 F42000
; LINE_WIDTH: 0.11811
G1 F11455
M204 S6000
G2 X125.339 Y122.406 I-3.291 J2.366 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162118
G1 F11455
M204 S6000
G3 X125.481 Y122.505 I-.992 J3.808 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z4 F42000
G1 X126.229 Y134.784 Z4
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.121653
G1 F11455
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169636
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.21576
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255291
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991928
G1 F11455
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121667
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162864
G3 X125.058 Y135.733 I-.131 J-.078 E.00133
; LINE_WIDTH: 0.149316
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114387
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X121.948 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.199 J-1.114 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02035
; WIPE_START
M73 P90 R2
G1 F11791.304
G1 X121.948 Y130.272 E-.02628
G1 X122.103 Y130.078 E-.1083
G1 X122.227 Y129.861 E-.10883
G1 X122.348 Y130.013 E-.08478
G1 X122.622 Y130.272 E-.16426
G1 X122.009 Y130.272 E-.26756
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z4 F42000
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25567
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.2341
G1 X116.721 Y129.878 E.01398
G2 X116.879 Y130.272 I1.212 J-.26 E.01414
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02308
G1 X115.742 Y129.968 E-.15233
G1 X115.891 Y129.724 E-.1086
G1 X116.431 Y128.593 E-.47599
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z4 F42000
G1 X115.146 Y120.124 Z4
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01658
G3 X115.338 Y120.007 I-.691 J.189 E.00584
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07711
G1 X114.92 Y120.097 E-.03255
G1 X114.825 Y120.029 E-.04445
G1 X114.777 Y119.962 E-.0312
G1 X114.732 Y119.747 E-.08371
G1 X114.744 Y119.606 E-.05384
G1 X114.804 Y119.434 E-.06888
G1 X114.934 Y119.264 E-.08159
G1 X115.054 Y119.165 E-.05906
G1 X115.378 Y118.976 E-.14241
G1 X115.317 Y119.192 E-.0852
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z4 F42000
G1 X110.311 Y130.57 Z4
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.647 J.672 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.203 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.49 J1.893 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.323 J-3.237 E.02985
G2 X115.546 Y129.537 I-.692 J-1.248 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06387
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.745 I.345 J.36 E.01895
G3 X115.072 Y120.522 I-.563 J.187 E.03631
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X116.006 Y118.607 I.569 J2.143 E.02502
G3 X117.064 Y118.892 I-.227 J2.941 E.03385
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.574 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20008
G3 X117.08 Y129.654 I-.538 J.969 E.00785
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.10262
G1 F11455
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124334
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155169
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11455
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209473
G2 X110.837 Y132.758 I-3.007 J.177 E.00342
; LINE_WIDTH: 0.255818
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.29829
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340761
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383233
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425705
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225198
G1 F11455
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11455
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132599
G1 F11455
M204 S6000
G2 X115.218 Y130.242 I-2.649 J-3.502 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.113987
G1 F11455
M204 S6000
G2 X117.277 Y130.468 I2.357 J-1.753 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112458
G1 F11455
M204 S6000
G3 X117.164 Y130.397 I.578 J-2.781 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.130447
G1 F11455
M204 S6000
G2 X121.608 Y130.384 I-.565 J-4.783 E.00273
M204 S10000
G1 X121.687 Y130.249 F42000
; LINE_WIDTH: 0.116859
G1 F11455
M204 S6000
G3 X121.434 Y130.468 I-2.926 J-3.123 E.00202
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115534
G1 F11455
M204 S6000
G3 X122.174 Y129.56 I-3.494 J.845 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107515
G1 F11455
M204 S6000
G2 X122.185 Y129.406 I-3.506 J-1.368 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115581
G1 F11455
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152903
G1 X123.235 Y130.468 E.00171
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11455
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.417 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z4 F42000
G1 X116.263 Y118.858 Z4
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.112549
G1 F11455
M204 S6000
G1 X115.988 Y118.849 E.00156
; LINE_WIDTH: 0.143597
G1 X115.927 Y118.851 E.0005
; LINE_WIDTH: 0.175155
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210064
G2 X115.6 Y118.909 I.295 J1.8 E.00275
M204 S10000
G1 X115.558 Y119.099 F42000
; LINE_WIDTH: 0.168069
G1 F11455
M204 S6000
G1 X115.775 Y118.785 E.00389
; WIPE_START
G1 F15000
G1 X115.558 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.173082
G1 F11455
M204 S6000
G2 X115.008 Y119.749 I1.822 J.194 E.00287
G1 X115.045 Y119.861 E.00126
; LINE_WIDTH: 0.14665
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.110386
G1 F11455
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139229
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.20051
G2 X111.979 Y122.317 I.107 J1.469 E.002
; LINE_WIDTH: 0.238866
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282859
G2 X111.737 Y122.375 I.317 J1.586 E.00265
; LINE_WIDTH: 0.321784
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354823
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.39416
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433228
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440622
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413524
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12951.832
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11455
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.729 J143.27 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.1643
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09725
G1 X107.334 Y126.83 E-.16572
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z4 F42000
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z4 F42000
G1 X99.457 Y123.958 Z4
G1 Z3.6
G1 E.8 F1800
G1 F11455
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z4 F42000
G1 X105.735 Y134.549 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11455
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.785 J143.421 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.671 Y122.038 E.00709
G1 X103.903 Y122.048 E.00712
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11455
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11455
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11455
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.106752
G1 F11455
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.13135
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159959
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.191695
G3 X99.549 Y134.747 I1.56 J-1.705 E.00384
; LINE_WIDTH: 0.240256
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288575
G3 X99.236 Y134.303 I1.669 J-1.147 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.591 J-2.033 E.00775
; LINE_WIDTH: 0.374657
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400393
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478969
G1 F11007.936
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516476
G1 F10136.086
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.914
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.114965
G1 F11455
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.15313
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197191
G1 X99.03 Y131.382 E.0013
; LINE_WIDTH: 0.230991
G1 X99.068 Y131.286 E.00158
; LINE_WIDTH: 0.261724
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291543
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.32296
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351154
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379426
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415408
G3 X99.539 Y130.599 I.68 J.512 E.00581
; LINE_WIDTH: 0.44776
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464995
G1 F11372.392
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494315
G1 F10633.703
G3 X100.388 Y129.998 I2.919 J4.149 E.02484
; LINE_WIDTH: 0.542806
G1 F9602.189
G3 X101.286 Y129.65 I3.455 J7.58 E.03925
G2 X104.541 Y128.735 I-51.669 J-189.987 E.13773
; LINE_WIDTH: 0.493708
G1 F10648.034
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.515
G2 X105.695 Y128.292 I-2.402 J-6.618 E.02706
; LINE_WIDTH: 0.433686
G1 F11455
G2 X106.262 Y127.934 I-2.208 J-4.128 E.02136
; LINE_WIDTH: 0.383723
G2 X106.523 Y127.695 I-3.012 J-3.546 E.00983
; LINE_WIDTH: 0.348843
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320209
G2 X106.735 Y127.443 I-1.83 J-1.572 E.00443
; LINE_WIDTH: 0.292298
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.256006
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220476
G2 X106.983 Y127.022 I-1.064 J-.633 E.00295
; LINE_WIDTH: 0.180153
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.146819
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.112565
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.258 Y125.476 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.56306
G1 F9228.292
M204 S6000
G2 X107.177 Y124.94 I-7.101 J.805 E.02298
; LINE_WIDTH: 0.522379
G1 F10011.293
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486104
G1 F10830.733
G2 X107.111 Y124.691 I-1.783 J.405 E.00528
; LINE_WIDTH: 0.44768
G1 F11455
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402679
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374815
G1 X106.923 Y124.208 E.00074
; LINE_WIDTH: 0.358819
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.32626
G2 X106.694 Y123.803 I-1.507 J.719 E.00622
; LINE_WIDTH: 0.29599
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276525
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240873
G2 X106.371 Y123.389 I-2.527 J1.81 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184722
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.1532
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120222
G2 X105.616 Y122.762 I-1.869 J2.159 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z4 F42000
G1 Z3.6
G1 E.8 F1800
; LINE_WIDTH: 0.122046
G1 F11455
M204 S6000
G2 X99.912 Y123.647 I9.327 J11.919 E.00482
; LINE_WIDTH: 0.147271
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173381
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11455
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11455
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 19/25
; update layer progress
M73 L19
M991 S0 P18 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z4 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z4
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X150.467 Y124.693 E.00887
G2 X151.073 Y125.01 I2.82 J-4.643 E.02273
G3 X151.188 Y125.227 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.669 J.127 E.02282
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09206
G1 X150.604 Y124.785 E-.06294
G1 X151.073 Y125.01 E-.19772
G1 X151.148 Y125.063 E-.03496
G1 X151.188 Y125.227 E-.06385
G1 X151.193 Y125.334 E-.04108
G1 X151.156 Y125.613 E-.10692
G1 X151.082 Y125.753 E-.05986
G1 X150.983 Y125.853 E-.05372
G1 X150.868 Y125.899 E-.0469
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21642
G1 X157.113 Y124.547 E-.22769
G1 X157.334 Y125.082 E-.21992
G1 X157.34 Y125.107 E-.00987
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z4.2 F42000
G1 X151.408 Y134.226 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.56 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.095 J3.672 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01737
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.373 J1.31 E.06571
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01684
G3 X151.438 Y124.802 I-.844 J2.254 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.329 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.0632
G1 X152.65 Y122.071 E.01856
G1 X153.352 Y122.03 E.02161
G1 X154.334 Y122.115 E.0303
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z4.2
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z4.2 F4000
            G39.3 S1
            G0 Z4.2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288627
G1 F11348
M204 S6000
G2 X150.503 Y128.334 I-78.643 J24.064 E.01389
; LINE_WIDTH: 0.240753
G1 X150.486 Y128.298 E.00065
; LINE_WIDTH: 0.196992
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158646
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.123109
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.123072
G1 F11348
M204 S6000
G3 X150.289 Y123.904 I1.881 J.247 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.118044
G1 F11348
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148777
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179215
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221058
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261696
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306022
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349875
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390996
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416969
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487671
G1 F10792.563
M204 S6000
G1 X155.547 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.114347
G1 F11348
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149194
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.18404
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.631 J.97 E.00311
; LINE_WIDTH: 0.258743
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306097
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458136
G1 F11348
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492769
G1 F10670.266
G1 X155.958 Y129.401 E.00604
; LINE_WIDTH: 0.492624
G1 F10673.692
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453239
G1 F11348
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410298
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362692
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317837
G1 X155.307 Y129.876 E.00363
; LINE_WIDTH: 0.270729
G3 X155.153 Y129.966 I-1.196 J-1.851 E.00331
; LINE_WIDTH: 0.242577
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213453
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164581
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120194
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.844 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74105
G1 X154.756 Y130.129 E-.01895
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11348
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11348
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401444
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359236
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z4.2 F42000
G1 X141.597 Y130.591 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.02889
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.28 E.02461
G1 X140.907 Y132.132 E.01529
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.09111
G1 X141.987 Y130.622 E-.08134
G1 X142.082 Y130.683 E-.04297
G1 X142.161 Y130.77 E-.04452
G1 X142.238 Y130.969 E-.08098
G1 X142.242 Y131.177 E-.07922
G1 X142.224 Y131.286 E-.04178
G1 X142.17 Y131.407 E-.05035
G1 X142.111 Y131.472 E-.03344
G1 X141.949 Y131.564 E-.07091
G1 X141.592 Y131.686 E-.14338
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.804 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24043
G1 X147.611 Y130.255 E-.05258
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.504 Y124.583 Z4.2 F42000
G1 X141.512 Y123.482 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X141.497 Y123.494 E.00063
G1 X140.687 Y122.602 E.03997
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.08799
G1 X142.476 Y123.044 E.04224
G2 X141.704 Y123.32 I.254 J1.929 E.0274
G1 X141.558 Y123.443 E.00634
M204 S250
G1 X141.816 Y123.77 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G2 X141.854 Y124.138 I.302 J.155 E.01204
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.021 E.0168
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.573 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.388 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.425 Y123.744 E.04732
G1 X148.598 Y125.774 E.0626
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.118 J2.03 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.873 Y123.69 I.17 J1.438 E.02232
G2 X141.848 Y123.719 I.246 J.234 E.00117
M204 S10000
G1 X141.969 Y122.881 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.19495
G1 F11348
M204 S6000
G1 X141.312 Y122.987 E.00825
M204 S10000
G1 X141.343 Y123.021 F42000
; LINE_WIDTH: 0.309634
G1 F11348
M204 S6000
G1 X142.232 Y122.806 E.01988
M204 S10000
G1 X142.395 Y122.829 F42000
; LINE_WIDTH: 0.120929
G1 F11348
M204 S6000
G1 X142.182 Y122.855 E.00136
; LINE_WIDTH: 0.16895
G1 X141.969 Y122.881 E.0022
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11348
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11348
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156227
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.19015
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235123
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199154
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.481841
G1 F10935.907
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408382
G1 F11348
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380994
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337783
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291678
G3 X146.552 Y134.367 I-1.308 J-1.379 E.00313
; LINE_WIDTH: 0.263766
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240451
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203322
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164852
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121263
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.110973
G1 F11348
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.14709
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185487
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218682
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247207
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.611 F42000
; LINE_WIDTH: 0.121167
G1 F11348
M204 S6000
G3 X141.111 Y132.246 I4.081 J2.952 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197959
G1 F11348
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z4.2 F42000
G1 X148.316 Y125.064 Z4.2
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.120212
G1 F11348
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168495
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.217995
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267495
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.11964
G1 F11348
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.16508
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189732
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.168884
G1 F11348
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.343 Z4.2 F42000
G1 X138.362 Y132.423 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.737 E.01058
G3 X138.732 Y134.417 I-15.991 J3.239 E.05638
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.036 J-.259 E.0123
G3 X137.949 Y134.235 I1.735 J-.307 E.00998
G3 X138.22 Y132.423 I18.447 J1.837 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.737 E-.12118
G1 X138.635 Y133.581 E-.32618
G1 X138.716 Y134.279 E-.26701
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X138.563 Y131.057 E.03315
G3 X139.022 Y133.522 I-163.827 J31.837 E.07704
G1 X139.126 Y134.368 E.02619
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.119873
G1 F11348
M204 S6000
G1 X138.321 Y131.103 E.00094
; LINE_WIDTH: 0.166882
G1 X138.321 Y131.264 E.00162
; LINE_WIDTH: 0.214999
G1 X138.321 Y131.424 E.00225
; LINE_WIDTH: 0.263117
G1 X138.321 Y131.585 E.00288
; LINE_WIDTH: 0.311234
G1 X138.321 Y131.745 E.00351
; LINE_WIDTH: 0.359351
G1 X138.321 Y131.906 E.00414
; LINE_WIDTH: 0.407468
G1 X138.321 Y132.067 E.00477
; LINE_WIDTH: 0.455586
G1 X138.321 Y132.227 E.0054
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11348
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.24674
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.28204
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329042
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376045
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404897
G3 X138.347 Y134.591 I-2.285 J.277 E.01023
; WIPE_START
G1 F13260.508
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z4.2 F42000
G1 X130.165 Y128.941 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.583 J.981 E.02847
G3 X132.691 Y122.339 I1.773 J1.409 E.0593
G3 X133.879 Y122.579 I.152 J2.305 E.03767
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17178
G1 X130.87 Y129.485 E-.18905
G1 X130.611 Y129.024 E-.20076
G1 X130.436 Y128.532 E-.19841
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21994
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24117
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.068 Y122.055 E.00952
G1 X133.476 Y122.089 E.0126
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
M73 P91 R2
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11348
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11348
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120932
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.505453
G1 F10377.657
M204 S6000
G1 X130.3 Y129.361 E.0127
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448148
G1 F11348
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403256
G1 X130.561 Y129.681 E.00405
; LINE_WIDTH: 0.361937
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326583
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289354
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252124
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.21855
G2 X131.122 Y130.176 I1.342 J-1.659 E.00264
; LINE_WIDTH: 0.185257
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.14609
G1 X131.343 Y130.313 E.00109
; LINE_WIDTH: 0.111399
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.313 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11348
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183758
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327158
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.374457
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416506
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.44335
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492715
G1 F10671.546
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11348
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216419
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149199
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.487673
G1 F10792.519
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.44598
G1 F11348
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401297
G2 X135.075 Y123.17 I-2.199 J1.712 E.0068
; LINE_WIDTH: 0.369996
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344921
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307411
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269901
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230212
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170237
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124737
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994516
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.0995173
G1 F11348
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127455
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177269
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204269
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224484
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260976
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300075
G2 X130.759 Y122.986 I1.394 J1.824 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513098
G1 F10208.901
M204 S6000
G1 X130.191 Y123.685 E.03888
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444829
G1 F11348
M204 S6000
G3 X130.649 Y123.102 I6.919 J5.504 E.02451
; LINE_WIDTH: 0.396823
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361836
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X126.511 Y122.956 E.00451
G2 X126.456 Y123.302 I1.264 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03159
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03093
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G2 X126.848 Y123.319 I.824 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.764 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.099874
G1 F11348
M204 S6000
G3 X127.108 Y122.406 I1.849 J1.425 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101412
G1 F11348
M204 S6000
G2 X126.982 Y122.483 I.455 J2.549 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.120459
G1 F11348
M204 S6000
G1 X126.216 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.655 F42000
; LINE_WIDTH: 0.118091
G1 F11348
M204 S6000
G2 X125.339 Y122.406 I-3.252 J2.336 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162107
G1 F11348
M204 S6000
G3 X125.481 Y122.505 I-1.003 J3.845 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z4.2 F42000
G1 X126.229 Y134.784 Z4.2
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.121653
G1 F11348
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169636
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215755
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255288
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991808
G1 F11348
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121663
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162879
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149307
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114377
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G2 X122.227 Y129.861 I-1.21 J-1.12 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02035
; WIPE_START
G1 F11791.304
G1 X122.103 Y130.078 E-.09937
G1 X122.227 Y129.861 E-.11506
G1 X122.348 Y130.013 E-.08957
G1 X122.622 Y130.272 E-.17347
G1 X122.009 Y130.272 E-.28253
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.481 Y130.272 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25568
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.2341
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.209 J-.259 E.01414
G1 X115.541 Y130.272 E.0444
; WIPE_START
G1 F11791.304
G1 X115.742 Y129.968 E-.13857
G1 X115.891 Y129.724 E-.10859
G1 X116.472 Y128.506 E-.51285
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.28 Y120.967 Z4.2 F42000
G1 X115.146 Y120.124 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01244
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01657
G3 X115.338 Y120.007 I-.691 J.189 E.00585
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07709
G1 X114.92 Y120.097 E-.03254
G1 X114.825 Y120.029 E-.04447
G1 X114.777 Y119.962 E-.03122
G1 X114.732 Y119.747 E-.08371
G1 X114.744 Y119.605 E-.05385
G1 X114.804 Y119.434 E-.06886
G1 X114.934 Y119.264 E-.08157
G1 X115.054 Y119.165 E-.05908
G1 X115.378 Y118.976 E-.14249
G1 X115.317 Y119.191 E-.08512
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z4.2 F42000
G1 X110.311 Y130.57 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.646 J.671 E.00996
G1 X111.153 Y122.806 E.00662
G2 X110.737 Y124.239 I1.943 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.02279
G2 X109.527 Y130.57 I-2.49 J1.893 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05705
G1 X114.513 Y124.559 E.02131
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.323 J-3.237 E.02985
G2 X115.546 Y129.537 I-.693 J-1.249 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.345 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X115.973 Y118.604 I.565 J2.117 E.024
G3 X117.064 Y118.892 I-.196 J2.95 E.03487
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.574 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20008
G3 X117.08 Y129.654 I-.539 J.971 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03275
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102625
G1 F11348
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124345
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155166
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11348
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225155
G1 F11348
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11348
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132612
G1 F11348
M204 S6000
G2 X115.218 Y130.242 I-2.651 J-3.504 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.114001
G1 F11348
M204 S6000
G2 X117.278 Y130.468 I2.326 J-1.731 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112461
G1 F11348
M204 S6000
G3 X117.164 Y130.397 I.585 J-2.812 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.130472
G1 F11348
M204 S6000
G2 X121.609 Y130.384 I-.57 J-4.822 E.00274
M204 S10000
G1 X121.688 Y130.248 F42000
; LINE_WIDTH: 0.117325
G1 F11348
M204 S6000
G3 X121.434 Y130.468 I-2.934 J-3.127 E.00204
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115525
G1 F11348
M204 S6000
G3 X122.174 Y129.559 I-3.723 J.897 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107567
G1 F11348
M204 S6000
G2 X122.185 Y129.406 I-3.535 J-1.378 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115586
G1 F11348
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152904
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11348
M204 S6000
G3 X123.03 Y130.387 I.572 J-4.447 E.00227
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z4.2 F42000
G1 X116.263 Y118.858 Z4.2
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.115552
G1 F11348
M204 S6000
G1 X115.954 Y118.85 E.00183
; LINE_WIDTH: 0.14735
G1 X115.927 Y118.851 E.00023
; LINE_WIDTH: 0.175116
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210034
G2 X115.601 Y118.909 I.293 J1.791 E.00275
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.167865
G1 F11348
M204 S6000
G1 X115.775 Y118.785 E.00388
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.173084
G1 F11348
M204 S6000
G2 X115.008 Y119.749 I1.821 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146542
G1 X115.116 Y119.921 E.00078
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.110385
G1 F11348
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139228
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.20051
G2 X111.979 Y122.317 I.107 J1.469 E.002
; LINE_WIDTH: 0.238866
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282859
G2 X111.737 Y122.375 I.317 J1.586 E.00265
; LINE_WIDTH: 0.321784
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354823
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394161
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433223
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440621
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413498
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12952.763
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.706 J143.187 E.13155
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16429
G1 X107.141 Y125.672 E-.067
G1 X107.368 Y125.672 E-.08633
G1 X107.404 Y126.143 E-.1794
G1 X107.392 Y126.398 E-.09727
G1 X107.334 Y126.831 E-.16571
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z4.2 F42000
G1 X99.457 Y123.958 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z4.2 F42000
G1 X105.735 Y134.549 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.822 I41.77 J143.367 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.639 Y122.037 E.00609
G1 X103.903 Y122.048 E.00812
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11348
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11348
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11348
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.106736
G1 F11348
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131365
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159974
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.191715
G3 X99.549 Y134.747 I1.562 J-1.707 E.00384
; LINE_WIDTH: 0.240277
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288563
G3 X99.236 Y134.304 I1.679 J-1.154 E.00336
; LINE_WIDTH: 0.336675
G3 X99.087 Y134.016 I3.592 J-2.034 E.00776
; LINE_WIDTH: 0.374658
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400416
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.524 J-1.313 E.01038
; LINE_WIDTH: 0.478968
G1 F11007.974
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516474
G1 F10136.119
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.913
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.114965
G1 F11348
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153131
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197194
G1 X99.03 Y131.382 E.0013
; LINE_WIDTH: 0.230996
G1 X99.068 Y131.286 E.00158
; LINE_WIDTH: 0.261736
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291553
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322961
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351143
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379413
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415407
G3 X99.539 Y130.599 I.679 J.512 E.00581
; LINE_WIDTH: 0.447774
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.465008
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494311
G1 F10633.809
G3 X100.388 Y129.998 I2.921 J4.153 E.02484
; LINE_WIDTH: 0.542805
G1 F9602.215
G3 X101.286 Y129.65 I3.455 J7.581 E.03925
G2 X104.541 Y128.735 I-51.695 J-190.08 E.13773
; LINE_WIDTH: 0.493704
G1 F10648.113
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.499
G2 X105.695 Y128.292 I-2.404 J-6.623 E.02706
; LINE_WIDTH: 0.433687
G1 F11348
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02136
; LINE_WIDTH: 0.383716
G2 X106.523 Y127.695 I-2.962 J-3.491 E.00984
; LINE_WIDTH: 0.348844
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.32021
G2 X106.735 Y127.443 I-1.846 J-1.584 E.00443
; LINE_WIDTH: 0.292298
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255993
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220475
G2 X106.983 Y127.022 I-1.061 J-.632 E.00295
; LINE_WIDTH: 0.180152
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.146819
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.112563
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.563064
G1 F9228.224
M204 S6000
G1 X107.223 Y125.208 E.01146
G2 X107.177 Y124.94 I-6.752 J1.019 E.01152
; LINE_WIDTH: 0.522391
G1 F10011.046
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486118
G1 F10830.376
G2 X107.111 Y124.691 I-1.795 J.409 E.00528
; LINE_WIDTH: 0.447687
G1 F11348
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402673
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374804
G1 X106.924 Y124.208 E.00074
; LINE_WIDTH: 0.358819
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326258
G2 X106.694 Y123.803 I-1.508 J.72 E.00622
; LINE_WIDTH: 0.295994
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276525
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240873
G2 X106.371 Y123.389 I-2.527 J1.81 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184722
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.1532
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120222
G2 X105.616 Y122.762 I-1.869 J2.159 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z4.2 F42000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.122044
G1 F11348
M204 S6000
G2 X99.912 Y123.647 I9.342 J11.937 E.00482
; LINE_WIDTH: 0.147271
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173381
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11348
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11348
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 20/25
; update layer progress
M73 L20
M991 S0 P19 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z4.2 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z4.2
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X150.467 Y124.693 E.00887
G2 X151.073 Y125.01 I2.815 J-4.632 E.02273
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.67 J.127 E.02283
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09205
G1 X150.604 Y124.785 E-.06292
G1 X151.073 Y125.01 E-.19773
G1 X151.148 Y125.063 E-.03496
G1 X151.188 Y125.226 E-.06384
G1 X151.193 Y125.335 E-.0411
G1 X151.156 Y125.613 E-.10692
G1 X151.082 Y125.753 E-.05985
G1 X150.983 Y125.853 E-.05373
G1 X150.868 Y125.899 E-.04689
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z4.4 F42000
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.2164
G1 X157.113 Y124.547 E-.22773
G1 X157.334 Y125.082 E-.2199
G1 X157.34 Y125.107 E-.00986
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z4.4 F42000
G1 X151.408 Y134.226 Z4.4
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.409 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.103 J3.677 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01737
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.374 J1.31 E.06572
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.078 E.01684
G3 X151.438 Y124.802 I-.844 J2.255 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.329 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.65 Y122.071 E.01856
G1 X153.345 Y122.03 E.0214
G1 X154.334 Y122.115 E.03052
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.535 J3.326 E.07718
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.4 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z4.4
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z4.4 F4000
            G39.3 S1
            G0 Z4.4 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288657
G1 F11348
M204 S6000
G2 X150.503 Y128.334 I-64.837 J19.785 E.01389
; LINE_WIDTH: 0.240742
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196996
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158762
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122948
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.123057
G1 F11348
M204 S6000
G3 X150.289 Y123.904 I1.887 J.249 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.118038
G1 F11348
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148791
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179238
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221083
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261723
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306035
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349876
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390986
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416955
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487701
G1 F10791.828
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.11435
G1 F11348
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149202
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.184054
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217738
G3 X156.928 Y124.883 I-2.632 J.97 E.00311
; LINE_WIDTH: 0.258746
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306098
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458154
G1 F11348
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.49279
G1 F10669.762
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492634
G1 F10673.46
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453256
G1 F11348
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.41032
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362708
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317841
G1 X155.306 Y129.876 E.00363
; LINE_WIDTH: 0.270724
G3 X155.153 Y129.966 I-1.203 J-1.862 E.00332
; LINE_WIDTH: 0.242568
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213453
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164581
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120193
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.844 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74105
G1 X154.756 Y130.129 E-.01895
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11348
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11348
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401437
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359239
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z4.4 F42000
G1 X141.597 Y130.591 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.891 J3.282 E.02461
G1 X140.907 Y132.132 E.01529
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.0911
G1 X141.987 Y130.622 E-.08132
G1 X142.082 Y130.683 E-.04296
G1 X142.161 Y130.77 E-.04455
G1 X142.238 Y130.969 E-.08099
G1 X142.242 Y131.177 E-.07924
G1 X142.224 Y131.286 E-.04177
G1 X142.17 Y131.407 E-.05034
G1 X142.111 Y131.472 E-.03346
G1 X141.949 Y131.564 E-.0709
G1 X141.592 Y131.686 E-.14337
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z4.4 F42000
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.804 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37644
G1 X147.551 Y130.131 E-.24043
G1 X147.611 Y130.255 E-.05258
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.504 Y124.583 Z4.4 F42000
G1 X141.512 Y123.482 Z4.4
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X141.497 Y123.494 E.00062
G1 X140.687 Y122.602 E.03997
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.08799
G1 X142.475 Y123.044 E.04224
G2 X141.704 Y123.32 I.254 J1.928 E.0274
G1 X141.558 Y123.443 E.00634
M204 S250
G1 X141.816 Y123.77 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G2 X141.854 Y124.138 I.302 J.154 E.01203
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01771
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04533
G3 X141.865 Y132.001 I-.763 J-1.022 E.0168
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.572 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.388 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.402 Y123.479 E.03913
G1 X148.598 Y125.774 E.07079
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.873 Y123.69 I.17 J1.438 E.02232
G2 X141.848 Y123.719 I.246 J.234 E.00117
M204 S10000
G1 X141.969 Y122.881 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.194918
G1 F11348
M204 S6000
G1 X141.312 Y122.987 E.00825
M204 S10000
G1 X141.343 Y123.021 F42000
; LINE_WIDTH: 0.309659
G1 F11348
M204 S6000
G1 X142.232 Y122.806 E.01988
M204 S10000
G1 X142.395 Y122.829 F42000
; LINE_WIDTH: 0.120924
G1 F11348
M204 S6000
G1 X142.182 Y122.855 E.00136
; LINE_WIDTH: 0.168935
G1 X141.969 Y122.881 E.0022
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11348
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11348
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156227
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.19015
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235123
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257937
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199154
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.481841
G1 F10935.911
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408379
G1 F11348
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.381003
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337788
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291681
G3 X146.552 Y134.367 I-1.308 J-1.379 E.00313
; LINE_WIDTH: 0.263775
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.24047
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203329
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164847
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121259
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.110962
G1 F11348
M204 S6000
G1 X140.964 Y132.915 E.00075
; LINE_WIDTH: 0.147089
M73 P92 R2
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185486
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218697
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.24722
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.611 F42000
; LINE_WIDTH: 0.121182
G1 F11348
M204 S6000
G3 X141.111 Y132.246 I4.082 J2.953 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.198008
G1 F11348
M204 S6000
G1 X140.829 Y132.645 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z4.4 F42000
G1 X148.316 Y125.064 Z4.4
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.120207
G1 F11348
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168502
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218016
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.26753
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119653
G1 F11348
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165114
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189777
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.168866
G1 F11348
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.344 Z4.4 F42000
G1 X138.362 Y132.423 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.737 E.01058
G3 X138.732 Y134.417 I-15.99 J3.238 E.05638
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.037 J-.259 E.0123
G3 X137.949 Y134.235 I1.736 J-.307 E.00997
G3 X138.22 Y132.423 I18.453 J1.838 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.737 E-.12118
G1 X138.635 Y133.581 E-.32618
G1 X138.716 Y134.279 E-.267
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X138.527 Y130.868 E.02723
G3 X139.022 Y133.522 I-176.459 J34.325 E.08297
G1 X139.126 Y134.368 E.02619
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120842
G1 F11348
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168682
G1 X138.321 Y131.271 E.00163
; LINE_WIDTH: 0.216523
G1 X138.321 Y131.431 E.00225
; LINE_WIDTH: 0.264364
G1 X138.321 Y131.59 E.00287
; LINE_WIDTH: 0.312205
G1 X138.321 Y131.749 E.0035
; LINE_WIDTH: 0.360046
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.407886
G1 X138.321 Y132.068 E.00474
; LINE_WIDTH: 0.455727
G1 X138.321 Y132.227 E.00536
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11348
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.24674
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.282037
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329032
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376028
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404895
G3 X138.347 Y134.591 I-2.282 J.276 E.01023
; WIPE_START
G1 F13260.615
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z4.4 F42000
G1 X130.165 Y128.941 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07458
G1 X129.589 Y128.418 E-.20698
G1 X129.379 Y127.867 E-.22412
G1 X129.285 Y127.431 E-.16931
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.583 J.981 E.02847
G3 X132.708 Y122.338 I1.773 J1.409 E.0598
G3 X133.879 Y122.579 I.137 J2.304 E.03717
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17178
G1 X130.87 Y129.484 E-.18908
G1 X130.611 Y129.024 E-.20075
G1 X130.436 Y128.532 E-.1984
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01105
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21993
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24118
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X133.017 Y122.051 E.00797
G1 X133.476 Y122.089 E.01415
G1 X134.11 Y122.248 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.152 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11348
M204 S6000
G3 X129.551 Y125.531 I6.308 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.152 F42000
; LINE_WIDTH: 0.208561
G1 F11348
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16068
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120934
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.505468
G1 F10377.318
M204 S6000
G1 X130.3 Y129.361 E.01271
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.44816
G1 F11348
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403273
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361944
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326578
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289349
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252121
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218551
G2 X131.122 Y130.176 I1.358 J-1.68 E.00264
; LINE_WIDTH: 0.185255
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146063
G1 X131.343 Y130.314 E.00109
; LINE_WIDTH: 0.111382
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.314 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11348
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.18376
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327158
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.374457
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416506
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.44335
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492733
G1 F10671.114
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11348
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216418
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149193
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.932 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.487673
G1 F10792.519
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.44598
G1 F11348
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401297
G2 X135.075 Y123.17 I-2.199 J1.712 E.0068
; LINE_WIDTH: 0.369996
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344924
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307416
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269908
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230221
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170243
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124738
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994511
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.0995131
G1 F11348
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127468
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177275
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204271
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.22448
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260966
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300059
G2 X130.759 Y122.986 I1.381 J1.807 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513079
G1 F10209.328
M204 S6000
G1 X130.191 Y123.685 E.0389
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444822
G1 F11348
M204 S6000
G3 X130.649 Y123.102 I6.947 J5.529 E.02451
; LINE_WIDTH: 0.396829
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361846
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.264 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03159
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03092
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G2 X126.848 Y123.319 I.824 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.764 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.963 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0999397
G1 F11348
M204 S6000
G3 X127.108 Y122.406 I1.932 J1.493 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101442
G1 F11348
M204 S6000
G2 X126.982 Y122.483 I.463 J2.586 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.120458
G1 F11348
M204 S6000
G1 X126.215 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.118114
G1 F11348
M204 S6000
G2 X125.339 Y122.406 I-3.277 J2.354 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.16211
G1 F11348
M204 S6000
G3 X125.481 Y122.505 I-.989 J3.799 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z4.4 F42000
G1 X126.229 Y134.784 Z4.4
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.121655
G1 F11348
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169649
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215788
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.25531
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991962
G1 F11348
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121692
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.1629
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149324
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114389
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G2 X122.227 Y129.861 I-1.204 J-1.117 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.0125
G1 X122.009 Y130.272 E.02036
; WIPE_START
G1 F11791.304
G1 X122.103 Y130.078 E-.09946
G1 X122.227 Y129.861 E-.11495
G1 X122.348 Y130.013 E-.08951
G1 X122.622 Y130.272 E-.17347
G1 X122.009 Y130.272 E-.28261
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z4.4 F42000
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25568
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01399
G2 X116.879 Y130.272 I1.207 J-.259 E.01413
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02308
G1 X115.742 Y129.968 E-.15238
G1 X115.891 Y129.724 E-.10853
G1 X116.431 Y128.593 E-.47602
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z4.4 F42000
G1 X115.146 Y120.124 Z4.4
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G3 X114.732 Y119.747 I-.073 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01656
G3 X115.338 Y120.007 I-.693 J.189 E.00585
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.0771
G1 X114.92 Y120.097 E-.03254
G1 X114.825 Y120.029 E-.04446
G1 X114.777 Y119.962 E-.03122
G1 X114.732 Y119.747 E-.0837
G1 X114.744 Y119.606 E-.05383
G1 X114.804 Y119.434 E-.06887
G1 X114.934 Y119.264 E-.0816
G1 X115.054 Y119.165 E-.05906
G1 X115.378 Y118.976 E-.14244
G1 X115.317 Y119.192 E-.08518
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z4.4 F42000
G1 X110.311 Y130.57 Z4.4
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.646 J.671 E.00996
G1 X111.153 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.49 J1.893 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05706
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.323 J-3.237 E.02984
G2 X115.546 Y129.537 I-.692 J-1.249 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06387
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.344 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X115.94 Y118.601 I.562 J2.102 E.02298
G3 X117.064 Y118.892 I-.169 J2.968 E.03589
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.129 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20009
G3 X117.08 Y129.654 I-.535 J.965 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03275
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102611
G1 F11348
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124331
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155161
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11348
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225174
G1 F11348
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11348
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132615
G1 F11348
M204 S6000
G2 X115.218 Y130.242 I-2.718 J-3.582 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.113985
G1 F11348
M204 S6000
G2 X117.278 Y130.468 I2.331 J-1.735 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112495
G1 F11348
M204 S6000
G3 X117.164 Y130.396 I.565 J-2.717 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.130449
G1 F11348
M204 S6000
G2 X121.608 Y130.384 I-.569 J-4.815 E.00274
M204 S10000
G1 X121.687 Y130.248 F42000
; LINE_WIDTH: 0.117022
G1 F11348
M204 S6000
G3 X121.434 Y130.468 I-2.922 J-3.118 E.00203
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115533
G1 F11348
M204 S6000
G3 X122.174 Y129.56 I-3.503 J.847 E.00146
M204 S10000
G1 X122.104 Y129.637 F42000
; LINE_WIDTH: 0.107616
G1 F11348
M204 S6000
G2 X122.185 Y129.406 I-3.366 J-1.315 E.00129
M204 S10000
G1 X122.922 Y130.253 F42000
; LINE_WIDTH: 0.115577
G1 F11348
M204 S6000
G1 X123.079 Y130.36 E.00113
; LINE_WIDTH: 0.152875
G1 X123.236 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.122867
G1 F11348
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.419 E.00227
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z4.4 F42000
G1 X116.263 Y118.858 Z4.4
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.106041
G1 F11348
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.135018
G1 X115.921 Y118.852 E.00113
; LINE_WIDTH: 0.176245
G1 X115.798 Y118.865 E.00134
; LINE_WIDTH: 0.210024
G2 X115.601 Y118.909 I.294 J1.801 E.00275
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.16801
G1 F11348
M204 S6000
G1 X115.775 Y118.785 E.00388
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.17306
G1 F11348
M204 S6000
G2 X115.008 Y119.749 I1.818 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146611
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.110386
G1 F11348
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139228
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200511
G2 X111.979 Y122.317 I.107 J1.469 E.002
; LINE_WIDTH: 0.238864
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282858
G2 X111.737 Y122.375 I.313 J1.57 E.00265
; LINE_WIDTH: 0.321773
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354831
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394161
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433218
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440611
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413482
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12953.304
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11348
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.805 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01554
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.729 J143.27 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16431
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09726
G1 X107.334 Y126.83 E-.16571
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z4.4 F42000
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z4.4 F42000
G1 X99.457 Y123.958 Z4.4
G1 Z4
G1 E.8 F1800
G1 F11348
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z4.4 F42000
G1 X105.735 Y134.549 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11348
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.785 J143.421 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02863
G1 X103.606 Y122.036 E.0051
G1 X103.903 Y122.048 E.00911
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.964 J-1.261 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11348
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11348
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11348
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.106736
G1 F11348
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131365
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159974
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.19171
G3 X99.549 Y134.747 I1.56 J-1.705 E.00384
; LINE_WIDTH: 0.240264
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288577
G3 X99.236 Y134.303 I1.668 J-1.147 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.591 J-2.033 E.00775
; LINE_WIDTH: 0.374657
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400393
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478966
G1 F11008.022
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516474
G1 F10136.122
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548779
G1 F9488.823
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.114971
G1 F11348
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153133
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197194
G1 X99.03 Y131.382 E.0013
; LINE_WIDTH: 0.230994
G1 X99.068 Y131.286 E.00158
; LINE_WIDTH: 0.261723
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291535
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322957
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351157
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379436
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415413
G3 X99.539 Y130.599 I.68 J.513 E.00581
; LINE_WIDTH: 0.44778
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464994
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494307
G1 F10633.908
G3 X100.388 Y129.998 I2.921 J4.152 E.02484
; LINE_WIDTH: 0.542807
G1 F9602.186
G3 X101.286 Y129.65 I3.455 J7.579 E.03925
G2 X104.541 Y128.735 I-51.669 J-189.987 E.13773
; LINE_WIDTH: 0.493708
G1 F10648.034
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.515
G2 X105.695 Y128.292 I-2.402 J-6.618 E.02706
; LINE_WIDTH: 0.433689
G1 F11348
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02137
; LINE_WIDTH: 0.383734
G2 X106.523 Y127.695 I-2.986 J-3.517 E.00984
; LINE_WIDTH: 0.348867
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320238
G2 X106.735 Y127.443 I-1.829 J-1.571 E.00443
; LINE_WIDTH: 0.292308
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255997
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220471
G2 X106.983 Y127.022 I-1.064 J-.633 E.00295
; LINE_WIDTH: 0.180144
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.146803
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.112559
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.563063
G1 F9228.23
M204 S6000
G1 X107.223 Y125.208 E.01146
G2 X107.177 Y124.94 I-6.75 J1.019 E.01152
; LINE_WIDTH: 0.522388
G1 F10011.104
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486113
G1 F10830.497
G2 X107.111 Y124.691 I-1.794 J.408 E.00528
; LINE_WIDTH: 0.447689
G1 F11348
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.40269
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.37481
G1 X106.923 Y124.208 E.00074
; LINE_WIDTH: 0.358835
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326272
G2 X106.694 Y123.803 I-1.508 J.719 E.00622
; LINE_WIDTH: 0.296007
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276527
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240878
G2 X106.371 Y123.389 I-2.554 J1.831 E.00419
; LINE_WIDTH: 0.211802
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184707
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153183
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120221
G2 X105.616 Y122.762 I-1.869 J2.16 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z4.4 F42000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.122044
G1 F11348
M204 S6000
G2 X99.912 Y123.647 I9.324 J11.915 E.00482
; LINE_WIDTH: 0.147282
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173384
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11348
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449904
G1 F11348
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402734
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355565
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308395
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235529
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 21/25
; update layer progress
M73 L21
M991 S0 P20 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z4.4 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z4.4
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X150.467 Y124.693 E.00888
G2 X151.073 Y125.01 I2.818 J-4.638 E.02272
G3 X151.188 Y125.227 I-.115 J.2 E.00857
G3 X150.983 Y125.853 I-.669 J.127 E.02282
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.0921
G1 X150.604 Y124.785 E-.06285
G1 X151.073 Y125.01 E-.19773
G1 X151.148 Y125.063 E-.035
G1 X151.188 Y125.227 E-.06384
G1 X151.193 Y125.335 E-.04108
G1 X151.156 Y125.613 E-.1069
G1 X151.082 Y125.753 E-.05986
G1 X150.983 Y125.853 E-.05373
G1 X150.868 Y125.899 E-.04691
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05564
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21642
G1 X157.113 Y124.547 E-.22769
G1 X157.334 Y125.082 E-.21992
G1 X157.34 Y125.107 E-.00987
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z4.6 F42000
G1 X151.408 Y134.226 Z4.6
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.1 J3.675 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.564 I-.571 J.601 E.01737
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.373 J1.31 E.06571
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01683
G3 X151.438 Y124.802 I-.844 J2.254 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.329 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.0632
G1 X152.649 Y122.071 E.01855
G1 X153.404 Y122.031 E.02321
G1 X154.334 Y122.115 E.02871
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.6 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z4.6
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z4.6 F4000
            G39.3 S1
            G0 Z4.6 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288642
G1 F11350
M204 S6000
G2 X150.503 Y128.334 I-72.836 J22.252 E.01388
; LINE_WIDTH: 0.240778
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196953
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158689
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.123019
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.123091
G1 F11350
M204 S6000
G3 X150.289 Y123.904 I1.88 J.247 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.118032
G1 F11350
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148768
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179209
G1 X155.267 Y122.689 E.00182
; LINE_WIDTH: 0.221059
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261704
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306023
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349875
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390996
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416972
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487667
G1 F10792.664
M204 S6000
G1 X155.547 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.114347
G1 F11350
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149194
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.18404
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.631 J.97 E.00311
; LINE_WIDTH: 0.258743
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306097
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287724
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198525
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163844
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458211
M73 P92 R1
G1 F11350
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492842
G1 F10668.527
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492634
G1 F10673.46
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453256
G1 F11350
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.41032
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362708
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317841
G1 X155.306 Y129.876 E.00363
; LINE_WIDTH: 0.270724
G3 X155.153 Y129.966 I-1.203 J-1.862 E.00332
; LINE_WIDTH: 0.242567
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213453
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164581
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.1202
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.843 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74105
G1 X154.756 Y130.129 E-.01895
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11350
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11350
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401444
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359236
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z4.6 F42000
G1 X141.597 Y130.591 Z4.6
G1 Z4.2
M73 P93 R1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.281 E.02461
G1 X140.907 Y132.132 E.0153
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.0911
G1 X141.987 Y130.622 E-.08131
G1 X142.082 Y130.683 E-.04295
G1 X142.161 Y130.77 E-.04457
G1 X142.238 Y130.969 E-.08098
G1 X142.242 Y131.177 E-.07925
G1 X142.224 Y131.286 E-.04177
G1 X142.17 Y131.407 E-.05034
G1 X142.111 Y131.472 E-.03346
G1 X141.949 Y131.564 E-.07091
G1 X141.592 Y131.686 E-.14335
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.805 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37646
G1 X147.551 Y130.131 E-.24041
G1 X147.611 Y130.255 E-.05259
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.504 Y124.583 Z4.6 F42000
G1 X141.512 Y123.482 Z4.6
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X141.497 Y123.494 E.00063
G1 X140.687 Y122.602 E.03997
G1 X147.934 Y122.602 E.24039
G1 X147.989 Y123.246 E.02145
G1 X148.018 Y123.593 E.01153
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.198 J1.604 E.04492
G2 X143.742 Y122.908 I.104 J61.673 E.08799
G1 X142.476 Y123.044 E.04224
G2 X141.704 Y123.32 I.254 J1.93 E.0274
G1 X141.558 Y123.443 E.00633
M204 S250
G1 X141.816 Y123.77 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G2 X141.854 Y124.138 I.302 J.155 E.01204
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02123
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01772
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04533
G3 X141.865 Y132.001 I-.763 J-1.021 E.0168
G2 X141.353 Y132.269 I.244 J1.09 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.573 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.389 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.379 Y123.213 E.03093
G1 X148.598 Y125.774 E.07898
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.873 Y123.69 I.171 J1.438 E.02232
G2 X141.848 Y123.719 I.246 J.234 E.00117
M204 S10000
G1 X141.969 Y122.881 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.19494
G1 F11350
M204 S6000
G1 X141.312 Y122.987 E.00825
M204 S10000
G1 X141.343 Y123.021 F42000
; LINE_WIDTH: 0.309674
G1 F11350
M204 S6000
G1 X142.232 Y122.806 E.01989
M204 S10000
G1 X142.395 Y122.829 F42000
; LINE_WIDTH: 0.12093
G1 F11350
M204 S6000
G1 X142.182 Y122.855 E.00136
; LINE_WIDTH: 0.16895
G1 X141.969 Y122.881 E.0022
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11350
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509875
G1 F10279.382
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536688
G1 F9721.181
G1 X146.325 Y128.78 E.01799
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.116685
G1 F11350
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.15623
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.190143
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235139
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257941
G3 X147.731 Y132.137 I-3.903 J1.29 E.02401
; LINE_WIDTH: 0.199155
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101125
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.481843
G1 F10935.867
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11350
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380986
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337783
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291689
G3 X146.552 Y134.367 I-1.307 J-1.378 E.00313
; LINE_WIDTH: 0.263784
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240475
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203343
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164869
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121274
G1 X145.883 Y134.759 E.00226
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.110963
G1 F11350
M204 S6000
G1 X140.964 Y132.915 E.00075
; LINE_WIDTH: 0.147089
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185501
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218715
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247207
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.612 F42000
; LINE_WIDTH: 0.12114
G1 F11350
M204 S6000
G3 X141.111 Y132.246 I3.996 J2.879 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197958
G1 F11350
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z4.6 F42000
G1 X148.316 Y125.064 Z4.6
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.120213
G1 F11350
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168498
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218006
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267513
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119649
G1 F11350
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165101
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189773
G1 X148.28 Y124.355 E.00562
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.16889
G1 F11350
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.343 Z4.6 F42000
G1 X138.362 Y132.423 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.737 E.01058
G3 X138.732 Y134.417 I-15.99 J3.238 E.05638
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.037 J-.259 E.0123
G3 X137.949 Y134.235 I1.739 J-.307 E.00998
G3 X138.22 Y132.423 I18.454 J1.838 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.737 E-.12118
G1 X138.635 Y133.581 E-.32618
G1 X138.716 Y134.279 E-.267
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X138.491 Y130.679 E.02131
G3 X139.022 Y133.522 I-189.089 J36.813 E.08889
G1 X139.126 Y134.368 E.02619
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02609
G3 X137.555 Y134.224 I2.259 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120842
G1 F11350
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168683
G1 X138.321 Y131.271 E.00163
; LINE_WIDTH: 0.216523
G1 X138.321 Y131.431 E.00225
; LINE_WIDTH: 0.264364
G1 X138.321 Y131.59 E.00287
; LINE_WIDTH: 0.312205
G1 X138.321 Y131.749 E.0035
; LINE_WIDTH: 0.360046
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.407887
G1 X138.321 Y132.068 E.00474
; LINE_WIDTH: 0.455728
G1 X138.321 Y132.227 E.00536
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11350
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.246741
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.282036
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329031
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376026
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404897
G3 X138.347 Y134.591 I-2.284 J.277 E.01024
; WIPE_START
G1 F13260.538
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z4.6 F42000
G1 X130.165 Y128.941 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07459
G1 X129.589 Y128.418 E-.20697
G1 X129.379 Y127.867 E-.22411
G1 X129.285 Y127.431 E-.16933
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.582 J.981 E.02847
G3 X132.724 Y122.337 I1.774 J1.41 E.0603
G3 X133.879 Y122.579 I.121 J2.304 E.03667
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17179
G1 X130.87 Y129.485 E-.18905
G1 X130.611 Y129.024 E-.20075
G1 X130.436 Y128.532 E-.19841
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01105
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21994
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24117
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X132.967 Y122.047 E.00643
G1 X133.476 Y122.089 E.01569
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.151 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11350
M204 S6000
G3 X129.551 Y125.531 I6.307 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.151 F42000
; LINE_WIDTH: 0.208558
G1 F11350
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.160675
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120919
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.505446
G1 F10377.793
M204 S6000
G1 X130.3 Y129.361 E.0127
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448141
G1 F11350
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403253
G1 X130.561 Y129.681 E.00405
; LINE_WIDTH: 0.361937
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326584
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289353
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252121
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218549
G2 X131.122 Y130.176 I1.342 J-1.658 E.00264
; LINE_WIDTH: 0.185246
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146077
G1 X131.343 Y130.313 E.00109
; LINE_WIDTH: 0.1114
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.313 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11350
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183761
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327158
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.374457
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416506
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.44335
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492715
G1 F10671.546
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11350
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216419
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243732
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232291
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193678
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149196
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110703
G1 X135.932 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.48768
G1 F10792.337
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445988
G1 F11350
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401303
G2 X135.075 Y123.17 I-2.211 J1.722 E.0068
; LINE_WIDTH: 0.37001
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344929
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307415
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269902
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230211
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170237
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124736
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994562
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.0995169
G1 F11350
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127468
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177275
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204271
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224482
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260971
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300068
G2 X130.759 Y122.986 I1.396 J1.825 E.00351
M204 S10000
G1 X130.741 Y122.833 F42000
; LINE_WIDTH: 0.513101
G1 F10208.836
M204 S6000
G1 X130.191 Y123.685 E.03886
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444833
G1 F11350
M204 S6000
G3 X130.649 Y123.102 I6.921 J5.506 E.02451
; LINE_WIDTH: 0.396832
G1 X130.87 Y122.859 E.00948
; LINE_WIDTH: 0.361847
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.264 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.324 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03158
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03092
G1 X126.584 Y122.774 E.00661
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G2 X126.848 Y123.319 I.824 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.764 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.963 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0999665
G1 F11350
M204 S6000
G3 X127.108 Y122.406 I1.839 J1.418 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101442
G1 F11350
M204 S6000
G2 X126.982 Y122.483 I.463 J2.586 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.120459
G1 F11350
M204 S6000
G1 X126.216 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.1181
G1 F11350
M204 S6000
G2 X125.34 Y122.406 I-3.443 J2.477 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162085
G1 F11350
M204 S6000
G3 X125.481 Y122.505 I-1.009 J3.865 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z4.6 F42000
G1 X126.229 Y134.784 Z4.6
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.121653
G1 F11350
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169628
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215769
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.2553
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.099212
G1 F11350
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121715
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162929
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149318
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114387
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X121.949 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.207 J-1.118 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02034
; WIPE_START
G1 F11791.304
G1 X121.949 Y130.272 E-.02628
G1 X122.103 Y130.078 E-.10818
G1 X122.227 Y129.861 E-.10894
G1 X122.348 Y130.013 E-.0848
G1 X122.622 Y130.272 E-.1643
G1 X122.009 Y130.272 E-.2675
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.0228
G1 X119.209 Y122.767 E.25568
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.21 J-.259 E.01414
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02308
G1 X115.742 Y129.968 E-.15238
G1 X115.891 Y129.724 E-.10853
G1 X116.431 Y128.593 E-.47602
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z4.6 F42000
G1 X115.146 Y120.124 Z4.6
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.151 J.161 E.01657
G3 X115.338 Y120.007 I-.692 J.189 E.00584
G3 X115.204 Y120.106 I-.265 J-.219 E.00558
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.0771
G1 X114.92 Y120.097 E-.03258
G1 X114.825 Y120.029 E-.04446
G1 X114.777 Y119.962 E-.03121
G1 X114.732 Y119.747 E-.08369
G1 X114.744 Y119.606 E-.05383
G1 X114.804 Y119.434 E-.06887
G1 X114.934 Y119.264 E-.08156
G1 X115.054 Y119.165 E-.0591
G1 X115.378 Y118.976 E-.14242
G1 X115.317 Y119.192 E-.08517
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z4.6 F42000
G1 X110.311 Y130.57 Z4.6
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.647 J.672 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.49 J1.893 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05006
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05705
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.322 J-3.234 E.02985
G2 X115.546 Y129.537 I-.692 J-1.249 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.345 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X115.907 Y118.599 I.563 J2.106 E.02196
G3 X117.064 Y118.892 I-.144 J2.994 E.03691
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.129 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.041 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20009
G3 X117.08 Y129.654 I-.535 J.965 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03275
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102611
G1 F11350
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124331
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155161
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11350
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225174
G1 F11350
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11350
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132599
G1 F11350
M204 S6000
G2 X115.218 Y130.242 I-2.649 J-3.502 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.11398
G1 F11350
M204 S6000
G2 X117.278 Y130.468 I2.332 J-1.736 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112452
G1 F11350
M204 S6000
G3 X117.164 Y130.397 I.574 J-2.764 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.130466
G1 F11350
M204 S6000
G2 X121.608 Y130.384 I-.567 J-4.796 E.00274
M204 S10000
G1 X121.688 Y130.248 F42000
; LINE_WIDTH: 0.117191
G1 F11350
M204 S6000
G3 X121.434 Y130.468 I-2.939 J-3.134 E.00203
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115533
G1 F11350
M204 S6000
G3 X122.174 Y129.56 I-3.498 J.846 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107541
G1 F11350
M204 S6000
G2 X122.185 Y129.406 I-3.513 J-1.371 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.11558
G1 F11350
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152901
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11350
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.417 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z4.6 F42000
G1 X116.263 Y118.858 Z4.6
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.106051
G1 F11350
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.139519
G1 X115.887 Y118.856 E.00145
; LINE_WIDTH: 0.201549
G1 X115.798 Y118.865 E.00116
G2 X115.601 Y118.909 I.298 J1.82 E.00261
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.167956
G1 F11350
M204 S6000
G1 X115.775 Y118.785 E.00388
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.173094
G1 F11350
M204 S6000
G2 X115.008 Y119.749 I1.818 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.14661
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.110386
G1 F11350
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139228
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200509
G2 X111.979 Y122.317 I.107 J1.468 E.002
; LINE_WIDTH: 0.238851
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282835
G2 X111.737 Y122.375 I.315 J1.576 E.00265
; LINE_WIDTH: 0.321765
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.35481
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394138
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433214
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440631
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413527
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12951.725
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.863 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.984 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.729 J143.27 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16431
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09725
G1 X107.334 Y126.83 E-.16572
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z4.6 F42000
G1 X99.457 Y123.958 Z4.6
G1 Z4.2
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z4.6 F42000
G1 X105.735 Y134.549 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.785 J143.421 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.441 Y122.029 E.02862
G1 X103.574 Y122.035 E.0041
G1 X103.903 Y122.048 E.01011
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.964 J-1.261 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04056
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11350
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11350
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11350
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.10673
G1 F11350
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131361
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159967
G1 X99.768 Y134.976 E.00117
; LINE_WIDTH: 0.19169
G3 X99.549 Y134.747 I1.563 J-1.708 E.00384
; LINE_WIDTH: 0.240249
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288558
G3 X99.236 Y134.303 I1.666 J-1.146 E.00336
; LINE_WIDTH: 0.336689
G3 X99.087 Y134.016 I3.589 J-2.033 E.00775
; LINE_WIDTH: 0.374652
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400399
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478969
G1 F11007.942
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516476
G1 F10136.087
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.914
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.114971
G1 F11350
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153133
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.197194
G1 X99.03 Y131.382 E.0013
; LINE_WIDTH: 0.230994
G1 X99.068 Y131.286 E.00158
; LINE_WIDTH: 0.261723
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291536
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322959
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351157
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379436
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415415
G3 X99.539 Y130.599 I.68 J.512 E.00581
; LINE_WIDTH: 0.447766
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464994
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494319
G1 F10633.609
G3 X100.388 Y129.998 I2.922 J4.155 E.02484
; LINE_WIDTH: 0.542807
G1 F9602.183
G3 X101.286 Y129.65 I3.455 J7.579 E.03925
G2 X104.541 Y128.735 I-51.669 J-189.987 E.13773
; LINE_WIDTH: 0.493708
G1 F10648.034
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.515
G2 X105.695 Y128.292 I-2.402 J-6.618 E.02706
; LINE_WIDTH: 0.433682
G1 F11350
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02137
; LINE_WIDTH: 0.383746
G2 X106.523 Y127.695 I-2.926 J-3.453 E.00984
; LINE_WIDTH: 0.348879
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320256
G2 X106.735 Y127.444 I-1.841 J-1.581 E.00442
; LINE_WIDTH: 0.292338
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.256004
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.233486
G1 X106.928 Y127.143 E.00111
; LINE_WIDTH: 0.205148
G1 X107.01 Y126.961 E.00263
; LINE_WIDTH: 0.155151
G1 X107.091 Y126.78 E.00182
; LINE_WIDTH: 0.112569
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.563063
G1 F9228.23
M204 S6000
G1 X107.223 Y125.208 E.01146
G2 X107.177 Y124.94 I-6.75 J1.019 E.01152
; LINE_WIDTH: 0.522388
G1 F10011.104
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486115
G1 F10830.451
G2 X107.111 Y124.691 I-1.79 J.407 E.00528
; LINE_WIDTH: 0.447687
G1 F11350
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402673
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374804
G1 X106.924 Y124.208 E.00074
; LINE_WIDTH: 0.358819
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326258
G2 X106.694 Y123.803 I-1.508 J.72 E.00622
; LINE_WIDTH: 0.295994
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276525
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240873
G2 X106.371 Y123.389 I-2.527 J1.81 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184713
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153187
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.12022
G2 X105.616 Y122.762 I-1.871 J2.162 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z4.6 F42000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.122046
G1 F11350
M204 S6000
G2 X99.912 Y123.647 I9.327 J11.919 E.00482
; LINE_WIDTH: 0.147271
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173381
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11350
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11350
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 22/25
; update layer progress
M73 L22
M991 S0 P21 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z4.6 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z4.6
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X150.467 Y124.693 E.00888
G2 X151.073 Y125.01 I2.815 J-4.633 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.67 J.127 E.02282
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09208
G1 X150.604 Y124.785 E-.0629
G1 X151.073 Y125.01 E-.19771
G1 X151.148 Y125.063 E-.03499
G1 X151.188 Y125.226 E-.06382
G1 X151.193 Y125.334 E-.04109
G1 X151.156 Y125.613 E-.10693
G1 X151.082 Y125.753 E-.05987
G1 X150.983 Y125.853 E-.05367
G1 X150.868 Y125.899 E-.04692
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05565
G1 X156.332 Y129.143 E.00994
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01405
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21642
G1 X157.113 Y124.547 E-.22769
G1 X157.334 Y125.082 E-.21992
G1 X157.34 Y125.107 E-.00987
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z4.8 F42000
G1 X151.408 Y134.226 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.561 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.102 J3.677 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01737
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.474 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.374 J1.31 E.06571
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.012 I.946 J1.127 E.0353
G2 X150.8 Y124.444 I.571 J-.078 E.01685
G3 X151.438 Y124.802 I-.844 J2.255 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.649 Y122.071 E.01856
G1 X153.404 Y122.031 E.02321
G1 X154.334 Y122.115 E.02871
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.997 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.22 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.8 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z4.8
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z4.8 F4000
            G39.3 S1
            G0 Z4.8 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.71 Y128.997 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288653
G1 F11350
M204 S6000
G2 X150.503 Y128.334 I-76.806 J23.565 E.01391
; LINE_WIDTH: 0.240762
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196914
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158664
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122885
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.12297
G1 F11350
M204 S6000
G3 X150.289 Y123.904 I1.892 J.25 E.00208
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.118038
G1 F11350
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148791
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179238
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221083
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261723
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306036
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349877
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390986
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416976
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.48769
G1 F10792.101
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.114347
G1 F11350
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149194
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.18404
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217737
G3 X156.928 Y124.883 I-2.631 J.97 E.00311
; LINE_WIDTH: 0.258743
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306097
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350095
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.40377
G3 X157.137 Y126.405 I-6.961 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333594
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287725
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.240006
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198538
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163867
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121723
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458181
G1 F11350
M204 S6000
M73 P94 R1
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492825
G1 F10668.938
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492623
G1 F10673.731
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453243
G1 F11350
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410309
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362698
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.31784
G1 X155.306 Y129.876 E.00363
; LINE_WIDTH: 0.27073
G3 X155.153 Y129.966 I-1.195 J-1.849 E.00331
; LINE_WIDTH: 0.242569
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213453
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164581
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.1202
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.843 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74105
G1 X154.756 Y130.129 E-.01895
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11350
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.429364
G1 F11350
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401437
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359239
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z4.8 F42000
G1 X141.597 Y130.591 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.02889
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.892 J3.285 E.02461
G1 X140.907 Y132.132 E.0153
G3 X141.054 Y131.135 I2.674 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.09109
G1 X141.987 Y130.622 E-.08132
G1 X142.082 Y130.683 E-.04296
G1 X142.16 Y130.77 E-.04455
G1 X142.238 Y130.969 E-.081
G1 X142.242 Y131.177 E-.07925
G1 X142.224 Y131.286 E-.04176
G1 X142.17 Y131.407 E-.05039
G1 X142.111 Y131.472 E-.03342
G1 X141.949 Y131.564 E-.07091
G1 X141.592 Y131.686 E-.14337
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02013
G1 X147.986 Y131.275 E.0206
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.804 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37647
G1 X147.551 Y130.131 E-.24045
G1 X147.611 Y130.255 E-.05253
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.504 Y124.583 Z4.8 F42000
G1 X141.512 Y123.482 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X141.497 Y123.494 E.00063
G1 X140.687 Y122.602 E.03997
G1 X147.934 Y122.602 E.24039
G1 X147.966 Y122.981 E.01261
G1 X148.018 Y123.593 E.02037
G1 X147.661 Y123.243 E.01657
G2 X146.7 Y122.866 I-1.145 J1.503 E.0347
G2 X146.068 Y122.848 I-.449 J4.716 E.02101
G1 X143.742 Y122.908 E.07718
G1 X142.476 Y123.044 E.04224
G2 X141.704 Y123.32 I.254 J1.929 E.0274
G1 X141.558 Y123.443 E.00634
M204 S250
G1 X141.816 Y123.77 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G2 X141.854 Y124.138 I.302 J.155 E.01203
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.471 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02112
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02124
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01772
G3 X140.975 Y130.546 I1.959 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.022 E.0168
G2 X141.353 Y132.269 I.244 J1.09 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.572 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.388 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.357 Y122.947 E.02274
G1 X148.598 Y125.774 E.08717
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.116 J2.029 E.05447
G2 X146.657 Y123.256 I-1.177 J.435 E.04496
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.873 Y123.69 I.171 J1.438 E.02232
G2 X141.848 Y123.719 I.246 J.234 E.00117
M204 S10000
G1 X141.969 Y122.881 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.19494
G1 F11350
M204 S6000
G1 X141.312 Y122.987 E.00825
M204 S10000
G1 X141.343 Y123.021 F42000
; LINE_WIDTH: 0.309663
G1 F11350
M204 S6000
G1 X142.231 Y122.806 E.01987
M204 S10000
G1 X142.395 Y122.829 F42000
; LINE_WIDTH: 0.120929
G1 F11350
M204 S6000
G1 X142.182 Y122.855 E.00136
; LINE_WIDTH: 0.16895
G1 X141.969 Y122.881 E.0022
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11350
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.27581
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323308
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370806
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418304
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509871
G1 F10279.47
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536685
G1 F9721.23
G1 X146.325 Y128.78 E.01798
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.116686
G1 F11350
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156236
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.190151
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.23513
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257933
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199154
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.48185
G1 F10935.694
M204 S6000
G1 X147.167 Y133.747 E.03485
M204 S10000
G1 X147.204 Y133.769 F42000
; LINE_WIDTH: 0.408401
G1 F11350
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.381024
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.3378
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291684
G3 X146.552 Y134.367 I-1.308 J-1.378 E.00314
; LINE_WIDTH: 0.263766
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.240472
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203335
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164856
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121258
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.110972
G1 F11350
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.14709
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185488
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218687
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247196
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.612 F42000
; LINE_WIDTH: 0.121138
G1 F11350
M204 S6000
G3 X141.111 Y132.246 I4.001 J2.883 E.00298
M204 S10000
G1 X141.096 Y132.233 F42000
; LINE_WIDTH: 0.197892
G1 F11350
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.233 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z4.8 F42000
G1 X148.316 Y125.064 Z4.8
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.120199
G1 F11350
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168479
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.217985
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267492
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119638
G1 F11350
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165079
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189735
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.16889
G1 F11350
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.343 Z4.8 F42000
G1 X138.362 Y132.423 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.736 E.01057
G3 X138.732 Y134.417 I-15.993 J3.239 E.05639
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.036 J-.259 E.0123
G3 X137.949 Y134.235 I1.736 J-.307 E.00997
G3 X138.22 Y132.423 I18.453 J1.838 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.736 E-.12108
G1 X138.635 Y133.581 E-.32628
G1 X138.716 Y134.279 E-.267
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X138.455 Y130.489 E.01538
G3 X139.022 Y133.522 I-201.62 J39.283 E.09481
G1 X139.126 Y134.368 E.02619
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.255 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120842
G1 F11350
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168682
G1 X138.321 Y131.271 E.00163
; LINE_WIDTH: 0.216523
G1 X138.321 Y131.431 E.00225
; LINE_WIDTH: 0.264364
G1 X138.321 Y131.59 E.00287
; LINE_WIDTH: 0.312205
G1 X138.321 Y131.749 E.0035
; LINE_WIDTH: 0.360046
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.407886
G1 X138.321 Y132.068 E.00474
; LINE_WIDTH: 0.455727
G1 X138.321 Y132.227 E.00536
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11350
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.246741
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.282037
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329032
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376028
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404897
G3 X138.347 Y134.591 I-2.296 J.278 E.01023
; WIPE_START
G1 F13260.53
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z4.8 F42000
G1 X130.165 Y128.941 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07459
G1 X129.589 Y128.418 E-.20697
G1 X129.379 Y127.867 E-.22411
G1 X129.285 Y127.431 E-.16933
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G3 X130.61 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.582 J.981 E.02847
G3 X132.74 Y122.336 I1.774 J1.41 E.0608
G3 X133.879 Y122.579 I.105 J2.305 E.03618
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17177
G1 X130.87 Y129.484 E-.18908
G1 X130.61 Y129.024 E-.20078
G1 X130.436 Y128.532 E-.19837
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01106
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21994
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24117
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X132.917 Y122.043 E.00488
G1 X133.476 Y122.089 E.01724
G1 X134.11 Y122.248 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06263
G1 X136.196 Y123.834 E.01934
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02264
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.151 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231592
G1 F11350
M204 S6000
G3 X129.551 Y125.531 I6.307 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.15742
G3 X129.663 Y124.948 I4.234 J.719 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.151 F42000
; LINE_WIDTH: 0.208556
G1 F11350
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.16067
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120928
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.505448
G1 F10377.748
M204 S6000
G1 X130.3 Y129.361 E.0127
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.44815
G1 F11350
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403268
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361944
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326577
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289346
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252115
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218536
G2 X131.122 Y130.176 I1.358 J-1.68 E.00264
; LINE_WIDTH: 0.185247
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.14608
G1 X131.343 Y130.313 E.00109
; LINE_WIDTH: 0.111399
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.313 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11350
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183765
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211122
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249559
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286369
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327158
G2 X135.106 Y129.695 I-1.114 J-1.142 E.00452
; LINE_WIDTH: 0.374457
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416506
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.44335
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492715
G1 F10671.546
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11350
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216418
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243733
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232287
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193663
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149193
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.487679
G1 F10792.366
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445982
G1 F11350
G1 X135.226 Y123.348 E.00672
; LINE_WIDTH: 0.401296
G2 X135.075 Y123.17 I-2.198 J1.711 E.00681
; LINE_WIDTH: 0.369996
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344924
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307416
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269908
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230221
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201469
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170243
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124735
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994557
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.0995169
G1 F11350
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127468
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177275
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204271
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224482
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260971
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300068
G2 X130.759 Y122.986 I1.396 J1.825 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513087
G1 F10209.149
M204 S6000
G1 X130.191 Y123.685 E.03888
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444827
G1 F11350
M204 S6000
G3 X130.649 Y123.102 I6.98 J5.559 E.02451
; LINE_WIDTH: 0.39683
G1 X130.87 Y122.859 E.00948
; LINE_WIDTH: 0.361838
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.264 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03158
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.689 J.022 E.03187
G1 X126.685 Y122.602 E.03092
G1 X126.584 Y122.774 E.00661
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G2 X126.848 Y123.319 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.736 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.767 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.674 E.03133
G2 X126.955 Y122.924 I.1 J.963 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0999422
G1 F11350
M204 S6000
G3 X127.108 Y122.406 I1.824 J1.406 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101441
G1 F11350
M204 S6000
G2 X126.982 Y122.483 I.459 J2.569 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.120468
G1 F11350
M204 S6000
G1 X126.215 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.656 F42000
; LINE_WIDTH: 0.118114
G1 F11350
M204 S6000
G2 X125.339 Y122.406 I-3.277 J2.354 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162123
G1 F11350
M204 S6000
G3 X125.481 Y122.505 I-.991 J3.804 E.00282
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z4.8 F42000
G1 X126.229 Y134.784 Z4.8
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.121653
G1 F11350
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169636
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.21576
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255281
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991957
G1 F11350
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.12169
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162906
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149321
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114389
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X121.949 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.206 J-1.118 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.0125
G1 X122.009 Y130.272 E.02035
; WIPE_START
G1 F11791.304
G1 X121.949 Y130.272 E-.02628
G1 X122.103 Y130.078 E-.10823
G1 X122.227 Y129.861 E-.1089
G1 X122.348 Y130.013 E-.08476
G1 X122.622 Y130.272 E-.16429
G1 X122.009 Y130.272 E-.26753
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.02281
G1 X119.209 Y122.767 E.25567
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.21 J-.26 E.01414
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02309
G1 X115.742 Y129.968 E-.15235
G1 X115.891 Y129.724 E-.1086
G1 X116.431 Y128.593 E-.47597
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z4.8 F42000
G1 X115.146 Y120.124 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.151 J.161 E.01658
G3 X115.338 Y120.007 I-.692 J.189 E.00584
G3 X115.204 Y120.106 I-.265 J-.219 E.00558
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07712
G1 X114.92 Y120.097 E-.03255
G1 X114.825 Y120.029 E-.04448
G1 X114.777 Y119.962 E-.03119
G1 X114.732 Y119.747 E-.08371
G1 X114.744 Y119.606 E-.05383
G1 X114.804 Y119.434 E-.0689
G1 X114.934 Y119.264 E-.08156
G1 X115.054 Y119.165 E-.05908
G1 X115.378 Y118.976 E-.14241
G1 X115.317 Y119.192 E-.08517
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z4.8 F42000
G1 X110.311 Y130.57 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.648 J.673 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.491 J1.894 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05007
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05705
G1 X114.513 Y124.559 E.0213
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.369 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.322 J-3.234 E.02985
G2 X115.546 Y129.537 I-.692 J-1.249 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.234 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.345 J.36 E.01895
G3 X115.072 Y120.522 I-.563 J.187 E.03631
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X115.874 Y118.596 I.568 J2.14 E.02094
G3 X117.064 Y118.892 I-.121 J3.026 E.03793
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.129 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.65 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.041 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20009
G3 X117.08 Y129.654 I-.536 J.967 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102629
G1 F11350
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124351
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155185
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11350
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225174
G1 F11350
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11350
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132601
G1 F11350
M204 S6000
G2 X115.218 Y130.242 I-2.717 J-3.58 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.113994
G1 F11350
M204 S6000
G2 X117.278 Y130.468 I2.256 J-1.677 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112467
G1 F11350
M204 S6000
G3 X117.164 Y130.396 I.546 J-2.637 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.130447
G1 F11350
M204 S6000
G2 X121.608 Y130.384 I-.566 J-4.791 E.00274
M204 S10000
G1 X121.687 Y130.248 F42000
; LINE_WIDTH: 0.117053
G1 F11350
M204 S6000
G3 X121.434 Y130.468 I-3.017 J-3.221 E.00202
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115539
G1 F11350
M204 S6000
G3 X122.174 Y129.559 I-3.723 J.897 E.00146
M204 S10000
G1 X122.104 Y129.637 F42000
; LINE_WIDTH: 0.107641
G1 F11350
M204 S6000
G2 X122.185 Y129.406 I-3.514 J-1.372 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.11558
G1 F11350
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152901
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F11350
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.423 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z4.8 F42000
G1 X116.263 Y118.858 Z4.8
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.106048
G1 F11350
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.134327
G1 X115.927 Y118.851 E.00108
; LINE_WIDTH: 0.175127
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210039
G2 X115.6 Y118.909 I.292 J1.786 E.00276
M204 S10000
G1 X115.558 Y119.099 F42000
; LINE_WIDTH: 0.168085
G1 F11350
M204 S6000
G1 X115.775 Y118.785 E.00389
; WIPE_START
G1 F15000
G1 X115.558 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.173076
G1 F11350
M204 S6000
G2 X115.008 Y119.749 I1.816 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146623
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.110385
G1 F11350
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139228
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200506
G2 X111.979 Y122.317 I.107 J1.469 E.002
; LINE_WIDTH: 0.23885
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282856
G2 X111.737 Y122.375 I.314 J1.574 E.00265
; LINE_WIDTH: 0.321789
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354824
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394169
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433227
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440608
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413468
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12953.804
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11350
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.71 J143.203 E.13155
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16427
G1 X107.141 Y125.672 E-.067
G1 X107.368 Y125.672 E-.08633
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09725
G1 X107.334 Y126.831 E-.16575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25822
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25574
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z4.8 F42000
G1 X99.457 Y123.958 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F11350
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z4.8 F42000
G1 X105.735 Y134.549 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11350
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.02209
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.822 I41.772 J143.375 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.209 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.542 Y122.033 E.03171
G1 X103.903 Y122.048 E.01111
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.262 E.04255
G1 X106.33 Y128.854 E.01715
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.114976
G1 F11350
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11350
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70019
G1 X105.695 Y134.21 E-.05981
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11350
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.106744
G1 F11350
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131356
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159971
G1 X99.768 Y134.976 E.00117
; LINE_WIDTH: 0.191705
G3 X99.549 Y134.747 I1.561 J-1.706 E.00384
; LINE_WIDTH: 0.240272
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288576
G3 X99.236 Y134.303 I1.667 J-1.146 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.59 J-2.033 E.00776
; LINE_WIDTH: 0.374657
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400393
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478969
G1 F11007.936
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516476
G1 F10136.086
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548774
G1 F9488.914
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.114961
G1 F11350
M204 S6000
G1 X98.932 Y131.648 E.00084
; LINE_WIDTH: 0.153112
G1 X98.992 Y131.478 E.00162
; LINE_WIDTH: 0.19718
G1 X99.03 Y131.382 E.0013
; LINE_WIDTH: 0.230991
G1 X99.068 Y131.286 E.00158
; LINE_WIDTH: 0.261715
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291538
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322957
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351157
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379419
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415407
G3 X99.539 Y130.599 I.679 J.512 E.00581
; LINE_WIDTH: 0.447756
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464988
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494311
G1 F10633.804
G3 X100.388 Y129.998 I2.921 J4.153 E.02483
; LINE_WIDTH: 0.542804
G1 F9602.243
G3 X101.286 Y129.65 I3.457 J7.584 E.03925
G2 X104.541 Y128.735 I-51.695 J-190.08 E.13773
; LINE_WIDTH: 0.4937
G1 F10648.221
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471693
G1 F11194.735
G2 X105.695 Y128.292 I-2.403 J-6.62 E.02706
; LINE_WIDTH: 0.433671
G1 F11350
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02136
; LINE_WIDTH: 0.383716
G2 X106.523 Y127.695 I-2.969 J-3.499 E.00983
; LINE_WIDTH: 0.348849
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320224
G2 X106.735 Y127.443 I-1.843 J-1.582 E.00443
; LINE_WIDTH: 0.292299
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.25599
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.233486
G1 X106.928 Y127.143 E.00111
; LINE_WIDTH: 0.205148
G1 X107.01 Y126.961 E.00263
; LINE_WIDTH: 0.155151
G1 X107.091 Y126.78 E.00182
; LINE_WIDTH: 0.112565
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.563064
G1 F9228.222
M204 S6000
G1 X107.223 Y125.208 E.01146
G2 X107.177 Y124.94 I-6.752 J1.019 E.01152
; LINE_WIDTH: 0.522391
G1 F10011.046
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486118
G1 F10830.376
G2 X107.111 Y124.691 I-1.795 J.409 E.00528
; LINE_WIDTH: 0.447687
G1 F11350
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.40268
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374809
G1 X106.924 Y124.208 E.00074
; LINE_WIDTH: 0.358822
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326265
G2 X106.694 Y123.803 I-1.508 J.719 E.00622
; LINE_WIDTH: 0.296001
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276527
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240878
G2 X106.371 Y123.389 I-2.554 J1.831 E.00419
; LINE_WIDTH: 0.211802
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184707
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153183
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120221
G2 X105.616 Y122.762 I-1.869 J2.16 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z4.8 F42000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.122042
G1 F11350
M204 S6000
G2 X99.912 Y123.647 I9.327 J11.918 E.00482
; LINE_WIDTH: 0.147282
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173384
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11350
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11350
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 23/25
; update layer progress
M73 L23
M991 S0 P22 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z4.8 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11244
M204 S6000
G1 X150.467 Y124.693 E.00888
G2 X151.073 Y125.01 I2.817 J-4.637 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.67 J.127 E.02283
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.255 Y124.575 I1.93 J-.757 E.03725
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.0921
G1 X150.604 Y124.785 E-.06286
G1 X151.073 Y125.01 E-.19774
G1 X151.148 Y125.063 E-.03498
G1 X151.188 Y125.226 E-.06382
G1 X151.193 Y125.335 E-.0411
G1 X151.156 Y125.613 E-.1069
G1 X151.082 Y125.753 E-.05986
G1 X150.983 Y125.853 E-.05373
G1 X150.868 Y125.899 E-.04691
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z5 F42000
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01988
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05565
G1 X156.332 Y129.143 E.00995
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01847
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01406
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
M73 P95 R1
G1 X156.8 Y124.036 E-.21641
G1 X157.113 Y124.547 E-.2277
G1 X157.334 Y125.082 E-.21993
G1 X157.34 Y125.107 E-.00985
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z5 F42000
G1 X151.408 Y134.226 Z5
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.311 J3.558 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11244
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.099 J3.675 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01457
G3 X150.911 Y128.563 I-.571 J.601 E.01736
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.277 J-3.473 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10886
G2 X156.206 Y127.844 I-2.912 J-2.077 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.374 J1.31 E.06572
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01683
G3 X151.438 Y124.802 I-.844 J2.255 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G3 X152.059 Y122.196 I2.573 J2.003 E.06319
G1 X152.649 Y122.071 E.01856
G1 X153.404 Y122.031 E.02321
G1 X154.334 Y122.115 E.02871
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.535 J3.326 E.07718
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01969
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z5
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z5 F4000
            G39.3 S1
            G0 Z5 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288673
G1 F11244
M204 S6000
G2 X150.503 Y128.334 I-67.808 J20.72 E.01389
; LINE_WIDTH: 0.240823
G1 X150.486 Y128.298 E.00065
; LINE_WIDTH: 0.197013
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158721
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122844
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.216 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.123087
G1 F11244
M204 S6000
G3 X150.289 Y123.904 I1.882 J.247 E.00209
; WIPE_START
G1 F15000
G1 X150.221 Y124.216 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.118035
G1 F11244
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148768
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179209
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221059
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261704
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306033
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.34987
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390975
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416946
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487706
G1 F10791.71
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.114352
G1 F11244
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149205
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.184058
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217741
G3 X156.928 Y124.883 I-2.632 J.97 E.00311
; LINE_WIDTH: 0.258746
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306094
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350109
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.403772
G3 X157.137 Y126.405 I-6.96 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368456
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333592
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287717
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239998
G1 X156.87 Y128.002 E.0023
; LINE_WIDTH: 0.198522
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163833
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121706
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458283
G1 F11244
M204 S6000
G1 X155.937 Y129.238 E.00552
; LINE_WIDTH: 0.492915
G1 F10666.783
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.492617
G1 F10673.868
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453246
G1 F11244
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410321
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.36273
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317859
G1 X155.306 Y129.876 E.00363
; LINE_WIDTH: 0.270737
G3 X155.153 Y129.966 I-1.194 J-1.848 E.00332
; LINE_WIDTH: 0.242575
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213449
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164568
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120201
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.842 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74104
G1 X154.756 Y130.129 E-.01896
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.111793
G1 F11244
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.429361
G1 F11244
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401441
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359229
G1 X156.653 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z5 F42000
G1 X141.597 Y130.591 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11244
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.0289
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.28 E.02461
G1 X140.907 Y132.132 E.01529
G3 X141.054 Y131.135 I2.675 J-.114 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.0911
G1 X141.987 Y130.622 E-.08132
G1 X142.082 Y130.683 E-.04296
G1 X142.16 Y130.77 E-.04453
G1 X142.238 Y130.969 E-.08101
G1 X142.242 Y131.177 E-.07925
G1 X142.224 Y131.286 E-.04178
G1 X142.17 Y131.407 E-.05035
G1 X142.111 Y131.471 E-.03339
G1 X141.949 Y131.564 E-.07094
G1 X141.592 Y131.686 E-.14338
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z5 F42000
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G1 X146.535 Y128.868 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.804 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.868 E-.09055
G1 X147.191 Y129.61 E-.37648
G1 X147.551 Y130.131 E-.2404
G1 X147.611 Y130.255 E-.05257
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.504 Y124.583 Z5 F42000
G1 X141.512 Y123.482 Z5
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G1 X141.497 Y123.494 E.00063
G1 X140.687 Y122.602 E.03997
G1 X147.934 Y122.602 E.24038
G1 X147.944 Y122.715 E.00376
G1 X148.018 Y123.593 E.02922
G1 X147.661 Y123.243 E.01657
G2 X146.7 Y122.866 I-1.145 J1.503 E.03469
G2 X146.068 Y122.848 I-.449 J4.716 E.02101
G1 X143.742 Y122.908 E.07718
G1 X142.476 Y123.044 E.04224
G2 X141.704 Y123.32 I.254 J1.93 E.0274
G1 X141.558 Y123.443 E.00634
M204 S250
G1 X141.816 Y123.77 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11244
M204 S5000
G2 X141.854 Y124.138 I.302 J.154 E.01203
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.47 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02111
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02123
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02402
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01772
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.021 E.0168
G2 X141.353 Y132.269 I.244 J1.09 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02012
G2 X141.572 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.388 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.584 J40.374 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.334 Y122.682 E.01455
G1 X148.598 Y125.774 E.09536
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.118 J2.03 E.05447
G2 X146.657 Y123.256 I-1.177 J.435 E.04496
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.873 Y123.69 I.171 J1.438 E.02232
G2 X141.848 Y123.719 I.246 J.234 E.00117
M204 S10000
G1 X141.969 Y122.881 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.19492
G1 F11244
M204 S6000
G1 X141.312 Y122.987 E.00825
M204 S10000
G1 X141.343 Y123.021 F42000
; LINE_WIDTH: 0.30958
G1 F11244
M204 S6000
G1 X142.232 Y122.806 E.01989
M204 S10000
G1 X142.395 Y122.829 F42000
; LINE_WIDTH: 0.120919
G1 F11244
M204 S6000
G1 X142.182 Y122.855 E.00136
; LINE_WIDTH: 0.16892
G1 X141.969 Y122.881 E.0022
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11244
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.241 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.2281
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.275809
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323303
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370797
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418291
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.959
G1 X146.015 Y128.41 E.01179
; LINE_WIDTH: 0.509863
G1 F10279.632
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536678
G1 F9721.367
G1 X146.325 Y128.78 E.01798
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.116681
G1 F11244
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156221
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.190141
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235138
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257939
G3 X147.731 Y132.137 I-3.904 J1.291 E.02401
; LINE_WIDTH: 0.199154
G3 X147.69 Y132.483 I-2.523 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123625
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101122
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.481835
G1 F10936.058
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408383
G1 F11244
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.380992
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337797
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.29171
G3 X146.552 Y134.367 I-1.297 J-1.366 E.00313
; LINE_WIDTH: 0.263803
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.24049
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203352
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164874
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121279
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.110973
G1 F11244
M204 S6000
G1 X140.963 Y132.915 E.00075
; LINE_WIDTH: 0.147099
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.18549
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218674
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.247187
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.611 F42000
; LINE_WIDTH: 0.121104
G1 F11244
M204 S6000
G3 X141.111 Y132.246 I4.055 J2.93 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.197914
G1 F11244
M204 S6000
G1 X140.829 Y132.645 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z5 F42000
G1 X148.316 Y125.064 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.120204
G1 F11244
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168495
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.217995
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267495
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119634
G1 F11244
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165066
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.189715
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.168884
G1 F11244
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.343 Z5 F42000
G1 X138.362 Y132.423 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11244
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.736 E.01057
G3 X138.732 Y134.417 I-15.995 J3.239 E.05639
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.037 J-.259 E.0123
G3 X137.949 Y134.235 I1.741 J-.307 E.00998
G3 X138.22 Y132.423 I18.454 J1.838 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.736 E-.12108
G1 X138.635 Y133.581 E-.32628
G1 X138.716 Y134.279 E-.267
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11244
M204 S5000
G1 X138.419 Y130.3 E.00946
G3 X139.022 Y133.522 I-214.248 J41.771 E.10074
G1 X139.126 Y134.368 E.02619
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.26 J-.4 E.012
G3 X137.775 Y132.666 I11.986 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120842
G1 F11244
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168682
G1 X138.321 Y131.271 E.00163
; LINE_WIDTH: 0.216523
G1 X138.321 Y131.431 E.00225
; LINE_WIDTH: 0.264364
G1 X138.321 Y131.59 E.00287
; LINE_WIDTH: 0.312205
G1 X138.321 Y131.749 E.0035
; LINE_WIDTH: 0.360046
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.407886
G1 X138.321 Y132.068 E.00474
; LINE_WIDTH: 0.455727
G1 X138.321 Y132.227 E.00536
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119929
G1 F11244
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165936
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211943
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.246742
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.28204
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329041
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376043
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404904
G3 X138.347 Y134.591 I-2.297 J.278 E.01024
; WIPE_START
G1 F13260.255
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z5 F42000
G1 X130.165 Y128.941 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11244
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02288
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07459
G1 X129.589 Y128.418 E-.20699
G1 X129.379 Y127.867 E-.22408
G1 X129.285 Y127.431 E-.16935
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11244
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.582 J.981 E.02847
G3 X132.756 Y122.336 I1.776 J1.412 E.0613
G3 X133.879 Y122.579 I.088 J2.307 E.03568
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.258 J.216 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17179
G1 X130.87 Y129.485 E-.18905
G1 X130.611 Y129.024 E-.20076
G1 X130.436 Y128.532 E-.1984
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11244
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01105
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.01989
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21993
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24118
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11244
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02124
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.759 Y122.03 E.02172
G1 X132.867 Y122.038 E.00334
G1 X133.476 Y122.089 E.01878
G1 X134.11 Y122.248 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01985
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.151 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231591
G1 F11244
M204 S6000
G3 X129.551 Y125.531 I6.307 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.157418
G3 X129.663 Y124.948 I4.235 J.72 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.151 F42000
; LINE_WIDTH: 0.208556
G1 F11244
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.160667
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.12093
G1 X129.704 Y128.079 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.325 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.505461
G1 F10377.467
M204 S6000
G1 X130.3 Y129.361 E.01271
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.44815
G1 F11244
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403262
G1 X130.561 Y129.681 E.00405
; LINE_WIDTH: 0.361944
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326589
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.28936
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252132
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.21855
G2 X131.122 Y130.176 I1.343 J-1.66 E.00264
; LINE_WIDTH: 0.185259
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146087
G1 X131.343 Y130.313 E.00109
; LINE_WIDTH: 0.1114
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.313 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.116571
G1 F11244
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.15588
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183759
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211119
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249551
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286355
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327139
G2 X135.106 Y129.695 I-1.114 J-1.143 E.00452
; LINE_WIDTH: 0.374449
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416503
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.443336
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.49274
G1 F10670.952
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.116402
G1 F11244
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.144292
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167906
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216423
G2 X136.18 Y126.581 I-15.989 J-1.601 E.01171
; LINE_WIDTH: 0.243734
G2 X136.138 Y125.739 I-5.076 J-.172 E.01382
; LINE_WIDTH: 0.23229
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193677
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149194
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110715
G1 X135.932 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.487677
G1 F10792.419
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445984
G1 F11244
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401301
G2 X135.075 Y123.17 I-2.198 J1.711 E.0068
; LINE_WIDTH: 0.369996
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344917
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307414
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.26991
G1 X134.754 Y122.886 E.00217
; LINE_WIDTH: 0.230227
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201492
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170256
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.12474
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994509
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.0995131
G1 F11244
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127468
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177275
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204271
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224482
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260971
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300068
G2 X130.759 Y122.986 I1.383 J1.809 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513087
G1 F10209.149
M204 S6000
G1 X130.191 Y123.685 E.03887
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444818
G1 F11244
M204 S6000
G3 X130.649 Y123.102 I6.916 J5.501 E.02451
; LINE_WIDTH: 0.396822
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361842
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11244
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.263 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03159
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.688 J.022 E.03187
G1 X126.685 Y122.602 E.03093
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11244
M204 S5000
G2 X126.848 Y123.319 I.824 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.474 E.02911
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.363 J-.568 E.01832
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.758 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.963 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0998808
G1 F11244
M204 S6000
G3 X127.108 Y122.406 I1.867 J1.44 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101446
G1 F11244
M204 S6000
G2 X126.982 Y122.483 I.458 J2.57 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.120452
G1 F11244
M204 S6000
G1 X126.216 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.655 F42000
; LINE_WIDTH: 0.118076
G1 F11244
M204 S6000
G2 X125.339 Y122.406 I-3.361 J2.417 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162067
G1 F11244
M204 S6000
G3 X125.481 Y122.505 I-.985 J3.784 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z5 F42000
G1 X126.229 Y134.784 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.121655
G1 F11244
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169617
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215725
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255277
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991724
G1 F11244
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121652
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162876
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.149304
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114376
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11244
M204 S6000
G1 X121.948 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.2 J-1.115 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02035
; WIPE_START
G1 F11791.304
G1 X121.948 Y130.272 E-.02627
G1 X122.103 Y130.078 E-.10825
G1 X122.227 Y129.861 E-.1089
G1 X122.348 Y130.013 E-.0848
G1 X122.622 Y130.272 E-.16424
G1 X122.009 Y130.272 E-.26754
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.482 Y130.272 Z5 F42000
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G1 X115.481 Y130.272 E.00002
G2 X115.891 Y129.724 I-1.493 J-1.546 E.02281
G1 X119.209 Y122.767 E.25567
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.21 J-.26 E.01414
G1 X115.542 Y130.272 E.04438
; WIPE_START
G1 F11791.304
G1 X115.481 Y130.272 E-.02309
G1 X115.742 Y129.968 E-.15235
G1 X115.891 Y129.724 E-.1086
G1 X116.431 Y128.593 E-.47597
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.286 Y121.047 Z5 F42000
G1 X115.146 Y120.124 Z5
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.729 J.024 E.02291
G1 X115.378 Y118.976 E.01243
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01657
G3 X115.338 Y120.007 I-.693 J.19 E.00585
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.07711
G1 X114.92 Y120.097 E-.03257
G1 X114.825 Y120.029 E-.04442
G1 X114.777 Y119.962 E-.03122
G1 X114.732 Y119.747 E-.0837
G1 X114.744 Y119.605 E-.05387
G1 X114.804 Y119.434 E-.06886
G1 X114.934 Y119.264 E-.08158
G1 X115.054 Y119.165 E-.05908
G1 X115.378 Y118.976 E-.14242
G1 X115.317 Y119.192 E-.08517
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z5 F42000
G1 X110.311 Y130.57 Z5
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.644 J.667 E.00996
G1 X111.153 Y122.806 E.00661
G2 X110.737 Y124.239 I1.942 J1.342 E.05038
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.204 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.492 J1.894 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11244
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05006
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05705
G1 X114.513 Y124.559 E.02131
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.322 J-3.235 E.02985
G2 X115.546 Y129.537 I-.692 J-1.249 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.847 Y119.148 I-.227 J.918 E.01905
G2 X115.695 Y119.744 I.288 J.391 E.02049
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X115.841 Y118.594 I.583 J2.229 E.01992
G3 X117.064 Y118.892 I-.099 J3.061 E.03895
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.129 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.041 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20009
G3 X117.08 Y129.654 I-.536 J.966 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.83 E.01819
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03275
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102625
G1 F11244
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124354
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155195
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11244
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225174
G1 F11244
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11244
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132611
G1 F11244
M204 S6000
G2 X115.218 Y130.242 I-2.649 J-3.501 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.114019
G1 F11244
M204 S6000
G2 X117.278 Y130.468 I2.225 J-1.652 E.00132
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112461
G1 F11244
M204 S6000
G3 X117.164 Y130.396 I.568 J-2.736 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.130432
G1 F11244
M204 S6000
G2 X121.608 Y130.384 I-.565 J-4.786 E.00273
M204 S10000
G1 X121.687 Y130.249 F42000
; LINE_WIDTH: 0.116818
G1 F11244
M204 S6000
G3 X121.434 Y130.468 I-2.913 J-3.108 E.00202
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115545
G1 F11244
M204 S6000
G3 X122.174 Y129.56 I-3.505 J.848 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107552
G1 F11244
M204 S6000
G2 X122.185 Y129.406 I-3.398 J-1.328 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115581
G1 F11244
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152901
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.122868
G1 F11244
M204 S6000
G3 X123.029 Y130.386 I.546 J-4.266 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z5 F42000
G1 X116.263 Y118.858 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.106046
G1 F11244
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.134294
G1 X115.927 Y118.851 E.00107
; LINE_WIDTH: 0.174534
G1 X115.801 Y118.866 E.00136
; LINE_WIDTH: 0.226623
G2 X115.705 Y118.892 I.062 J.412 E.0015
G1 X115.548 Y119.096 E.00386
M204 S10000
G1 X115.017 Y119.479 F42000
; LINE_WIDTH: 0.173085
G1 F11244
M204 S6000
G2 X115.008 Y119.749 I1.823 J.194 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146621
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.110385
G1 F11244
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139227
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166697
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200511
G2 X111.979 Y122.317 I.107 J1.473 E.002
; LINE_WIDTH: 0.238871
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.28286
G2 X111.737 Y122.375 I.318 J1.588 E.00265
; LINE_WIDTH: 0.321774
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354821
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394165
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433207
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440593
G1 X111.263 Y122.448 E.0055
; LINE_WIDTH: 0.413431
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12955.087
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11244
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.863 J.034 E.0637
G3 X106.118 Y128.523 I-2.316 J-1.984 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01554
G1 X98.915 Y132.667 E.00452
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.729 J143.27 E.13156
G1 X105.53 Y127.924 E.02389
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16427
G1 X107.141 Y125.672 E-.06702
G1 X107.368 Y125.672 E-.08633
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09723
G1 X107.334 Y126.83 E-.16575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z5 F42000
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.2582
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25576
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z5 F42000
G1 X99.457 Y123.958 Z5
G1 Z4.6
G1 E.8 F1800
G1 F11244
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07094
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z5 F42000
G1 X105.735 Y134.549 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11244
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.0221
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.785 J143.421 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02258
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.208 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.509 Y122.032 E.03072
G1 X103.903 Y122.048 E.0121
G1 X104.633 Y122.156 E.02267
G1 X105.254 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.964 J-1.261 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08917
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.5 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
M73 P96 R1
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11244
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11244
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11244
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.10676
G1 F11244
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.13138
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.15998
G1 X99.767 Y134.976 E.00117
; LINE_WIDTH: 0.191705
G3 X99.549 Y134.747 I1.565 J-1.71 E.00384
; LINE_WIDTH: 0.240291
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288573
G3 X99.236 Y134.303 I1.679 J-1.154 E.00336
; LINE_WIDTH: 0.336698
G3 X99.087 Y134.016 I3.589 J-2.032 E.00776
; LINE_WIDTH: 0.374655
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.400393
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435379
G3 X98.92 Y133.548 I3.522 J-1.312 E.01039
; LINE_WIDTH: 0.478972
G1 F11007.862
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516485
G1 F10135.882
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548785
G1 F9488.707
G1 X98.796 Y132.863 E.01861
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.114987
G1 F11244
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153137
G1 X98.992 Y131.479 E.00162
; LINE_WIDTH: 0.197177
G1 X99.03 Y131.383 E.0013
; LINE_WIDTH: 0.230978
G1 X99.068 Y131.287 E.00158
; LINE_WIDTH: 0.261741
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291566
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322957
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351143
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379414
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415398
G3 X99.539 Y130.599 I.68 J.512 E.00581
; LINE_WIDTH: 0.447753
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.464995
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494307
G1 F10633.888
G3 X100.388 Y129.998 I2.921 J4.153 E.02484
; LINE_WIDTH: 0.542806
G1 F9602.188
G3 X101.286 Y129.65 I3.455 J7.579 E.03925
G2 X104.541 Y128.735 I-51.669 J-189.987 E.13773
; LINE_WIDTH: 0.493708
G1 F10648.034
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471702
G1 F11194.515
G2 X105.695 Y128.292 I-2.402 J-6.618 E.02706
; LINE_WIDTH: 0.433684
G1 F11244
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02137
; LINE_WIDTH: 0.383752
G2 X106.523 Y127.695 I-2.957 J-3.486 E.00983
; LINE_WIDTH: 0.34888
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320255
G2 X106.735 Y127.444 I-1.825 J-1.568 E.00442
; LINE_WIDTH: 0.29233
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.255999
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.233486
G1 X106.928 Y127.143 E.00111
; LINE_WIDTH: 0.205152
G1 X107.01 Y126.961 E.00263
; LINE_WIDTH: 0.155152
G1 X107.091 Y126.78 E.00182
; LINE_WIDTH: 0.112557
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.258 Y125.476 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.563061
G1 F9228.272
M204 S6000
G2 X107.177 Y124.94 I-7.168 J.817 E.02298
; LINE_WIDTH: 0.522392
G1 F10011.023
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486119
G1 F10830.364
G2 X107.111 Y124.691 I-1.776 J.404 E.00528
; LINE_WIDTH: 0.447687
G1 F11244
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402689
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374812
G1 X106.923 Y124.208 E.00074
; LINE_WIDTH: 0.358822
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.326266
G2 X106.694 Y123.803 I-1.508 J.719 E.00622
; LINE_WIDTH: 0.296001
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276524
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240872
G2 X106.371 Y123.389 I-2.525 J1.809 E.00419
; LINE_WIDTH: 0.211781
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184719
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153188
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.12022
G2 X105.616 Y122.762 I-1.871 J2.162 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z5 F42000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.122044
G1 F11244
M204 S6000
G2 X99.912 Y123.647 I9.329 J11.921 E.00482
; LINE_WIDTH: 0.147271
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.17338
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428276
G1 F11244
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449914
G1 F11244
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402742
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.35557
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308398
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261226
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235529
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 4.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 24/25
; update layer progress
M73 L24
M991 S0 P23 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z5 I.049 J1.216 P1  F42000
G1 X150.266 Y124.516 Z5
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11349
M204 S6000
G1 X150.467 Y124.693 E.00888
G2 X151.073 Y125.01 I2.814 J-4.631 E.02272
G3 X151.188 Y125.226 I-.115 J.2 E.00856
G3 X150.983 Y125.853 I-.67 J.127 E.02283
G3 X150.369 Y125.678 I-.237 J-.333 E.02428
G3 X150.228 Y124.856 I1.642 J-.705 E.02791
G1 X150.259 Y124.576 E.00937
; WIPE_START
G1 F11791.304
G1 X150.467 Y124.693 E-.09052
G1 X150.604 Y124.785 E-.06287
G1 X151.073 Y125.01 E-.19777
G1 X151.148 Y125.063 E-.03496
G1 X151.188 Y125.226 E-.06384
G1 X151.193 Y125.334 E-.04109
G1 X151.156 Y125.613 E-.10691
G1 X151.082 Y125.753 E-.05986
G1 X150.983 Y125.853 E-.05375
G1 X150.865 Y125.901 E-.04844
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.25 Y123.717 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G1 X156.427 Y123.605 E.00695
G1 X156.8 Y124.036 E.01889
G1 X157.113 Y124.547 E.01987
G1 X157.334 Y125.082 E.0192
G1 X157.478 Y125.701 E.02108
G1 X157.532 Y126.428 E.02421
G1 X157.506 Y126.904 E.01579
G1 X157.388 Y127.503 E.02026
G3 X156.555 Y128.943 I-3.576 J-1.106 E.05565
G1 X156.332 Y129.143 E.00994
G1 X156.172 Y129.023 E.00665
G1 X156.413 Y128.521 E.01846
G1 X156.589 Y127.932 E.02041
G2 X156.745 Y126.404 I-6.44 J-1.431 E.05105
G1 X156.742 Y126.179 E.00747
G1 X156.631 Y124.925 E.04177
G1 X156.442 Y124.161 E.02612
G1 X156.274 Y123.772 E.01405
; WIPE_START
G1 F11791.304
G1 X156.427 Y123.605 E-.08611
G1 X156.8 Y124.036 E-.21643
G1 X157.113 Y124.547 E-.22766
G1 X157.334 Y125.082 E-.21994
G1 X157.34 Y125.107 E-.00987
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X153.178 Y131.505 Z5.2 F42000
G1 X151.408 Y134.226 Z5.2
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G1 X152.909 Y133.933 E.05072
G1 X154.163 Y133.831 E.04175
G1 X154.523 Y133.846 E.01195
G3 X155.636 Y134.128 I-.312 J3.562 E.03826
G1 X155.581 Y134.322 E.00669
G1 X154.802 Y134.254 E.02591
G1 X152.724 Y134.43 E.06919
G1 X151.42 Y134.678 E.04403
G1 X151.41 Y134.286 E.013
; WIPE_START
G1 F11791.304
G1 X152.909 Y133.933 E-.5852
G1 X153.367 Y133.896 E-.1748
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.021 Y129.586 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11349
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.409 J2.225 E.04766
G1 X156.667 Y134.911 E.01686
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.098 J3.674 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01456
G3 X150.911 Y128.563 I-.571 J.601 E.01737
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.278 J-3.475 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.076 E.04328
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.374 J1.31 E.06571
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.38 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01684
G3 X151.438 Y124.802 I-.844 J2.255 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.383 Y123.328 I2.529 J.071 E.04988
G1 X150.779 Y122.906 E.01781
G3 X152.059 Y122.196 I2.386 J2.793 E.04526
G1 X152.649 Y122.071 E.01856
G1 X153.404 Y122.031 E.02321
G1 X154.334 Y122.115 E.02871
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.536 J3.326 E.07719
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.953 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.998 J-1.237 E.05736
G1 X156.319 Y129.682 E.02157
G1 X155.779 Y130.027 E.01968
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.22 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
G1 F12000
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z5.2
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z5.2 F4000
            G39.3 S1
            G0 Z5.2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.709 Y128.996 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.288677
G1 F11349
M204 S6000
G2 X150.503 Y128.334 I-65.109 J19.866 E.01388
; LINE_WIDTH: 0.240799
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196892
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.158688
G1 X150.452 Y128.253 E.0002
; LINE_WIDTH: 0.123025
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 F15000
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.123051
G1 F11349
M204 S6000
G3 X150.289 Y123.904 I1.884 J.248 E.00208
; WIPE_START
G1 F15000
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.783 Y122.454 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.118032
G1 F11349
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.14875
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179208
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221059
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261704
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306029
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349879
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.390997
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.416973
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487693
G1 F10792.023
M204 S6000
G1 X155.546 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X156.719 Y124.336 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.114352
G1 F11349
M204 S6000
G1 X156.766 Y124.449 E.00071
; LINE_WIDTH: 0.149206
G1 X156.813 Y124.562 E.00106
; LINE_WIDTH: 0.18406
G1 X156.86 Y124.675 E.00141
; LINE_WIDTH: 0.217739
G3 X156.928 Y124.883 I-2.681 J.986 E.00311
; LINE_WIDTH: 0.25874
G1 X156.965 Y125.035 E.00276
; LINE_WIDTH: 0.306093
G1 X157.003 Y125.188 E.00337
; LINE_WIDTH: 0.350109
G1 X157.048 Y125.474 E.00724
; LINE_WIDTH: 0.403772
G3 X157.137 Y126.405 I-6.96 J1.133 E.02754
; LINE_WIDTH: 0.420577
G1 X157.137 Y126.416 E.00033
G3 X157.116 Y126.855 I-3.446 J.056 E.01352
; LINE_WIDTH: 0.404871
G1 X157.095 Y127.037 E.0054
; LINE_WIDTH: 0.368454
G1 X157.04 Y127.405 E.00987
; LINE_WIDTH: 0.333602
G1 X156.979 Y127.636 E.00566
; LINE_WIDTH: 0.287748
G1 X156.918 Y127.867 E.00476
; LINE_WIDTH: 0.239997
G1 X156.87 Y128.002 E.00231
; LINE_WIDTH: 0.198518
G1 X156.809 Y128.148 E.00201
; LINE_WIDTH: 0.163848
G1 X156.747 Y128.294 E.00156
; LINE_WIDTH: 0.121715
G1 X156.674 Y128.433 E.00101
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458145
G1 F11349
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492772
G1 F10670.196
G1 X155.958 Y129.401 E.00603
; LINE_WIDTH: 0.49264
G1 F10673.326
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453259
G1 F11349
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410322
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362718
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317841
G1 X155.306 Y129.876 E.00363
; LINE_WIDTH: 0.270714
G3 X155.153 Y129.966 I-1.219 J-1.889 E.00332
; LINE_WIDTH: 0.24255
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213434
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164563
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120199
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.843 E.00195
; WIPE_START
G1 F15000
G1 X154.748 Y130.132 E-.74104
G1 X154.756 Y130.129 E-.01896
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X152.74 Y134.199 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.111792
G1 F11349
M204 S6000
G1 X154.308 Y134.066 E.00883
; WIPE_START
G1 F15000
G1 X152.74 Y134.199 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.803 Y134.256 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.429358
G1 F11349
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.40143
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.35922
G1 X156.652 Y134.635 E.008
; WIPE_START
G1 F15000
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.993 Y132.55 Z5.2 F42000
G1 X141.597 Y130.591 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11349
M204 S6000
G3 X141.778 Y130.574 I.14 J.516 E.00608
G3 X142.242 Y131.177 I-.013 J.49 E.02889
G3 X141.949 Y131.564 I-.403 J0 E.01729
G2 X141.26 Y131.835 I.89 J3.28 E.02461
G1 X140.907 Y132.132 E.0153
G3 X141.054 Y131.135 I2.674 J-.113 E.03362
G3 X141.542 Y130.616 I.937 J.391 E.02415
; WIPE_START
G1 F11791.304
G1 X141.778 Y130.574 E-.0911
G1 X141.987 Y130.622 E-.08136
G1 X142.082 Y130.683 E-.04292
G1 X142.16 Y130.77 E-.04454
G1 X142.238 Y130.969 E-.08098
G1 X142.242 Y131.177 E-.07926
G1 X142.224 Y131.286 E-.04177
G1 X142.17 Y131.407 E-.05035
G1 X142.111 Y131.471 E-.0334
G1 X141.949 Y131.564 E-.07096
G1 X141.592 Y131.686 E-.14336
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.355 Y129.004 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G1 X146.535 Y128.867 E.0075
G1 X147.191 Y129.61 E.03286
G1 X147.551 Y130.131 E.02099
G1 X147.813 Y130.678 E.02014
G1 X147.986 Y131.275 E.02059
G1 X148.042 Y131.855 E.01936
G3 X147.364 Y133.634 I-2.768 J-.036 E.06445
G1 X147.183 Y133.531 E.00691
G1 X147.306 Y133.203 E.01161
G2 X147.438 Y132.149 I-3.805 J-1.011 E.03534
G1 X147.361 Y131.367 E.02607
G1 X147.131 Y130.517 E.02922
G1 X146.724 Y129.58 E.03388
G1 X146.387 Y129.054 E.02072
; WIPE_START
G1 F11791.304
G1 X146.535 Y128.867 E-.09055
G1 X147.191 Y129.61 E-.37647
G1 X147.551 Y130.131 E-.24044
G1 X147.611 Y130.255 E-.05253
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.504 Y124.583 Z5.2 F42000
G1 X141.512 Y123.482 Z5.2
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G1 X141.497 Y123.494 E.00063
G1 X140.687 Y122.602 E.03997
G1 X147.934 Y122.602 E.24039
G1 X148.018 Y123.593 E.03298
G1 X147.661 Y123.243 E.01657
G2 X146.394 Y122.847 I-1.207 J1.632 E.04489
G2 X143.742 Y122.908 I.104 J61.673 E.088
G1 X142.476 Y123.044 E.04224
G2 X141.703 Y123.32 I.254 J1.93 E.02741
G1 X141.558 Y123.443 E.00633
M204 S250
G1 X141.816 Y123.77 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11349
M204 S5000
G2 X141.854 Y124.138 I.302 J.155 E.01203
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.471 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02112
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02123
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02403
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01772
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.022 E.0168
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02013
G2 X141.573 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.217 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.389 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.376 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.588 J40.378 E.13208
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.312 Y122.416 E.00636
G1 X148.598 Y125.774 E.10355
G1 X148.266 Y125.774 E.0102
M73 P96 R0
G2 X147.77 Y124.074 I-10.117 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.42 E.04503
G2 X146.073 Y123.24 I-.41 J4.348 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.873 Y123.69 I.17 J1.437 E.02233
G2 X141.848 Y123.719 I.246 J.234 E.00116
M204 S10000
G1 X141.969 Y122.881 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.19494
G1 F11349
M204 S6000
G1 X141.312 Y122.987 E.00825
M204 S10000
G1 X141.343 Y123.021 F42000
; LINE_WIDTH: 0.309564
G1 F11349
M204 S6000
G1 X142.232 Y122.806 E.01987
M204 S10000
G1 X142.395 Y122.829 F42000
; LINE_WIDTH: 0.120924
G1 F11349
M204 S6000
G1 X142.182 Y122.855 E.00136
; LINE_WIDTH: 0.168935
G1 X141.969 Y122.881 E.0022
; WIPE_START
G1 F15000
G1 X142.182 Y122.855 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.114804
G1 F11349
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.241 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228099
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.275807
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.323299
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370791
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418283
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458213
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490547
G1 F10723.23
G1 X146.015 Y128.41 E.01178
; LINE_WIDTH: 0.509855
G1 F10279.811
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536676
G1 F9721.41
G1 X146.325 Y128.78 E.01798
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.105 Y129.887 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.116684
G1 F11349
M204 S6000
G1 X147.211 Y130.076 E.00131
; LINE_WIDTH: 0.156231
G1 X147.317 Y130.266 E.00201
; LINE_WIDTH: 0.190156
G1 X147.458 Y130.61 E.00445
; LINE_WIDTH: 0.235134
G1 X147.524 Y130.788 E.00298
; LINE_WIDTH: 0.257941
G3 X147.731 Y132.137 I-3.903 J1.291 E.02401
; LINE_WIDTH: 0.199141
G3 X147.69 Y132.483 I-2.524 J-.129 E.00444
; LINE_WIDTH: 0.159258
G1 X147.665 Y132.604 E.00118
; LINE_WIDTH: 0.123626
G1 X147.64 Y132.726 E.00082
; LINE_WIDTH: 0.101117
G1 X147.617 Y132.807 E.0004
; WIPE_START
G1 F15000
G1 X147.64 Y132.726 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.549 Y134.501 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.481827
G1 F10936.263
M204 S6000
G1 X147.167 Y133.747 E.03486
M204 S10000
G1 X147.204 Y133.768 F42000
; LINE_WIDTH: 0.408398
G1 F11349
M204 S6000
G1 X146.872 Y134.085 E.01366
; LINE_WIDTH: 0.381011
G1 X146.771 Y134.175 E.00374
; LINE_WIDTH: 0.337792
G1 X146.669 Y134.265 E.00326
; LINE_WIDTH: 0.291682
G3 X146.552 Y134.367 I-1.308 J-1.379 E.00313
; LINE_WIDTH: 0.263775
G1 X146.503 Y134.403 E.0011
; LINE_WIDTH: 0.24047
G1 X146.404 Y134.466 E.0019
; LINE_WIDTH: 0.203329
G1 X146.304 Y134.529 E.00154
; LINE_WIDTH: 0.164847
G1 X146.196 Y134.596 E.00126
; LINE_WIDTH: 0.121257
G1 X145.883 Y134.759 E.00225
; WIPE_START
G1 F15000
G1 X146.196 Y134.596 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.001 Y133.044 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.110943
G1 F11349
M204 S6000
G1 X140.964 Y132.915 E.00075
; LINE_WIDTH: 0.147065
G1 X140.933 Y132.789 E.0011
; LINE_WIDTH: 0.185506
G1 X140.92 Y132.672 E.00137
; LINE_WIDTH: 0.218732
G1 X140.911 Y132.584 E.00126
; LINE_WIDTH: 0.24723
G1 X140.905 Y132.39 E.00323
M204 S10000
G1 X140.82 Y132.611 F42000
; LINE_WIDTH: 0.121196
G1 F11349
M204 S6000
G3 X141.111 Y132.246 I4.012 J2.893 E.00298
M204 S10000
G1 X141.096 Y132.232 F42000
; LINE_WIDTH: 0.198007
G1 F11349
M204 S6000
G1 X140.829 Y132.644 E.0062
; WIPE_START
G1 F15000
G1 X141.096 Y132.232 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X146.512 Y126.855 Z5.2 F42000
G1 X148.316 Y125.064 Z5.2
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.120204
G1 F11349
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168498
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218006
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267513
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X147.84 Y123.724 F42000
; LINE_WIDTH: 0.119648
G1 F11349
M204 S6000
G1 X147.928 Y123.845 E.00094
; LINE_WIDTH: 0.165101
G1 X148.016 Y123.966 E.00149
; LINE_WIDTH: 0.18976
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 F15000
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.756 Y122.914 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.168824
G1 F11349
M204 S6000
G1 X147.41 Y122.819 E.00368
; WIPE_START
G1 F15000
G1 X147.756 Y122.914 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.392 Y128.344 Z5.2 F42000
G1 X138.362 Y132.423 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11349
M204 S6000
G1 X138.422 Y132.423 E.00199
G1 X138.481 Y132.736 E.01057
G3 X138.732 Y134.417 I-15.995 J3.239 E.05639
G3 X138.2 Y134.79 I-.413 J-.023 E.02477
G3 X137.975 Y134.534 I.036 J-.258 E.0123
G3 X137.949 Y134.235 I1.737 J-.307 E.00998
G3 X138.22 Y132.423 I18.446 J1.837 E.06079
G1 X138.302 Y132.423 E.00273
; WIPE_START
G1 F11791.304
G1 X138.422 Y132.423 E-.04564
G1 X138.481 Y132.736 E-.12108
G1 X138.635 Y133.581 E-.32628
G1 X138.716 Y134.279 E-.267
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.362 Y129.997 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11349
M204 S5000
G1 X138.383 Y130.11 E.00354
G3 X139.022 Y133.522 I-226.875 J44.258 E.10666
G1 X139.126 Y134.368 E.02619
G3 X138.145 Y135.179 I-.805 J.025 E.04511
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.256 J-.4 E.012
G3 X137.775 Y132.666 I11.982 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120842
G1 F11349
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168683
G1 X138.321 Y131.271 E.00163
; LINE_WIDTH: 0.216523
G1 X138.321 Y131.431 E.00225
; LINE_WIDTH: 0.264364
G1 X138.321 Y131.59 E.00287
; LINE_WIDTH: 0.312205
G1 X138.321 Y131.749 E.0035
; LINE_WIDTH: 0.360046
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.407887
G1 X138.321 Y132.068 E.00474
; LINE_WIDTH: 0.455728
G1 X138.321 Y132.227 E.00536
M204 S10000
G1 X138.322 Y133.124 F42000
; LINE_WIDTH: 0.119936
G1 F11349
M204 S6000
G1 X138.323 Y133.265 E.00088
; LINE_WIDTH: 0.165956
G1 X138.323 Y133.405 E.00141
; LINE_WIDTH: 0.211976
G1 X138.324 Y133.545 E.00193
; LINE_WIDTH: 0.246759
G1 X138.327 Y133.628 E.00137
; LINE_WIDTH: 0.282056
G1 X138.328 Y133.834 E.00401
; LINE_WIDTH: 0.329051
G1 X138.33 Y134.039 E.0048
; LINE_WIDTH: 0.376046
G1 X138.331 Y134.245 E.00558
; LINE_WIDTH: 0.404897
G3 X138.347 Y134.591 I-2.283 J.277 E.01024
; WIPE_START
G1 F13260.528
G1 X138.331 Y134.245 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.931 Y130.088 Z5.2 F42000
G1 X130.165 Y128.941 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11349
M204 S6000
G1 X129.986 Y129.041 E.00682
G1 X129.862 Y128.889 E.00651
G1 X129.589 Y128.418 E.01807
G1 X129.379 Y127.867 E.01956
G1 X129.233 Y127.193 E.02287
G1 X129.183 Y126.431 E.02531
G1 X129.234 Y125.666 E.02545
G1 X129.364 Y125.046 E.02103
G1 X129.579 Y124.475 E.02022
G1 X129.891 Y123.934 E.02073
G1 X130 Y123.804 E.00563
G1 X130.175 Y123.899 E.00662
G1 X129.979 Y124.539 E.02222
G1 X129.84 Y125.379 E.02823
G1 X129.788 Y126.47 E.03621
G1 X129.849 Y127.612 E.03796
G1 X130.022 Y128.54 E.0313
G1 X130.145 Y128.884 E.01212
; WIPE_START
G1 F11791.304
G1 X129.986 Y129.041 E-.085
G1 X129.862 Y128.889 E-.07459
G1 X129.589 Y128.418 E-.20697
G1 X129.379 Y127.867 E-.22411
G1 X129.285 Y127.431 E-.16933
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.49 Y130.117 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11349
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.0436
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.582 J.981 E.02847
G3 X132.772 Y122.335 I1.777 J1.413 E.0618
G3 X133.879 Y122.579 I.071 J2.311 E.03518
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.27 J.215 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
G1 F12000
M204 S6000
G1 X131.187 Y129.867 E-.17177
G1 X130.87 Y129.484 E-.18908
G1 X130.611 Y129.024 E-.20073
G1 X130.436 Y128.532 E-.19842
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.563 Y128.876 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11349
M204 S6000
G1 X135.718 Y128.329 E.01883
G1 X135.838 Y127.552 E.02609
G1 X135.88 Y126.387 E.03866
G1 X135.769 Y124.963 E.04739
G1 X135.565 Y124.109 E.02911
G1 X135.479 Y123.892 E.00774
G1 X135.663 Y123.787 E.00703
G1 X135.868 Y124.05 E.01105
G3 X136.444 Y125.699 I-3.614 J2.189 E.05836
G1 X136.488 Y126.439 E.02458
G1 X136.427 Y127.282 E.02805
G1 X136.29 Y127.89 E.02068
G1 X136.068 Y128.448 E.0199
G1 X135.76 Y128.96 E.01986
G1 X135.619 Y128.899 E.0051
; WIPE_START
G1 F11791.304
G1 X135.718 Y128.329 E-.21994
G1 X135.838 Y127.552 E-.29888
G1 X135.861 Y126.918 E-.24117
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11349
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02124
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01977
G3 X132.054 Y122.087 I2.312 J3.281 E.05192
G1 X132.817 Y122.034 E.02348
G1 X133.476 Y122.089 E.02033
G1 X134.11 Y122.248 E.02009
G3 X135.81 Y123.337 I-1.344 J3.969 E.06264
G1 X136.196 Y123.834 E.01934
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02265
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02075
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01984
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
M204 S10000
G1 X129.528 Y127.151 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.231591
G1 F11349
M204 S6000
G3 X129.551 Y125.531 I6.307 J-.721 E.02499
; LINE_WIDTH: 0.185931
G1 X129.573 Y125.355 E.00207
; LINE_WIDTH: 0.157418
G3 X129.663 Y124.948 I4.235 J.72 E.00389
; LINE_WIDTH: 0.113017
G1 X129.708 Y124.777 E.00101
M204 S10000
G1 X129.528 Y127.151 F42000
; LINE_WIDTH: 0.208559
G1 F11349
M204 S6000
G1 X129.56 Y127.395 E.00332
; LINE_WIDTH: 0.160675
G1 X129.624 Y127.794 E.00387
; LINE_WIDTH: 0.120919
G1 X129.704 Y128.078 E.00188
; WIPE_START
G1 F15000
G1 X129.624 Y127.794 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.325 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.50548
G1 F10377.033
M204 S6000
G1 X130.3 Y129.361 E.01271
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448156
G1 F11349
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403276
G1 X130.561 Y129.681 E.00404
; LINE_WIDTH: 0.361951
G2 X130.709 Y129.835 I1.852 J-1.629 E.00554
; LINE_WIDTH: 0.326607
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.289369
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.25213
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218542
G2 X131.122 Y130.176 I1.346 J-1.664 E.00264
; LINE_WIDTH: 0.185258
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146085
G1 X131.343 Y130.313 E.00109
; LINE_WIDTH: 0.111399
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 F15000
G1 X131.343 Y130.313 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.116581
G1 F11349
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.155883
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183756
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211096
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249537
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.28635
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327157
G2 X135.106 Y129.695 I-1.113 J-1.142 E.00452
; LINE_WIDTH: 0.374467
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416534
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.443369
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492717
G1 F10671.497
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.997 Y128.01 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.116388
G1 F11349
M204 S6000
G1 X136.05 Y127.816 E.0012
; LINE_WIDTH: 0.14428
G1 X136.096 Y127.575 E.00203
; LINE_WIDTH: 0.167891
G1 X136.118 Y127.407 E.00172
; LINE_WIDTH: 0.216418
G2 X136.18 Y126.581 I-15.987 J-1.601 E.01171
; LINE_WIDTH: 0.243733
G2 X136.138 Y125.739 I-5.074 J-.172 E.01383
; LINE_WIDTH: 0.232287
G1 X136.094 Y125.422 E.00494
; LINE_WIDTH: 0.193663
G1 X136.05 Y125.105 E.00393
; LINE_WIDTH: 0.149193
G1 X136.01 Y124.922 E.00162
; LINE_WIDTH: 0.110704
G1 X135.933 Y124.662 E.0015
; WIPE_START
G1 F15000
G1 X136.01 Y124.922 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.489 Y123.661 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.487689
G1 F10792.12
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445993
G1 F11349
G1 X135.226 Y123.348 E.00672
; LINE_WIDTH: 0.401304
G2 X135.075 Y123.17 I-2.21 J1.721 E.00681
; LINE_WIDTH: 0.37001
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344927
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307418
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269908
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230222
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201492
G1 X134.564 Y122.735 E.00145
; LINE_WIDTH: 0.170261
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124744
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994508
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 F15000
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.0995058
G1 F11349
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127456
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177271
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204257
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.224481
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260967
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.30006
G2 X130.759 Y122.986 I1.396 J1.825 E.00351
M204 S10000
G1 X130.742 Y122.832 F42000
; LINE_WIDTH: 0.513086
G1 F10209.177
M204 S6000
G1 X130.191 Y123.685 E.03888
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444828
G1 F11349
M204 S6000
G3 X130.649 Y123.102 I6.949 J5.531 E.02451
; LINE_WIDTH: 0.396831
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361847
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 F15000
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.558 Y122.828 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11349
M204 S6000
G1 X126.511 Y122.956 E.00452
G2 X126.456 Y123.302 I1.263 J.379 E.01167
G1 X126.456 Y135.672 E.41033
G1 X125.524 Y135.623 E.03095
G1 X125.784 Y135.325 E.01312
G2 X126.03 Y134.419 I-1.382 J-.863 E.03159
G1 X126.03 Y123.508 E.36192
G2 X125.753 Y122.602 I-1.688 J.022 E.03188
G1 X126.685 Y122.602 E.03093
G1 X126.584 Y122.774 E.00662
M204 S250
G1 X126.922 Y122.974 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11349
M204 S5000
G2 X126.848 Y123.319 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.474 E.0291
G2 X125.525 Y134.988 I-.34 J-1.231 E.02983
G2 X125.638 Y134.406 I-1.364 J-.568 E.01833
G1 X125.638 Y123.519 E.33453
G2 X124.736 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.767 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.641 Y122.528 I-.405 J7.675 E.03133
G2 X126.955 Y122.924 I.1 J.963 E.02505
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0999435
G1 F11349
M204 S6000
G3 X127.108 Y122.406 I1.911 J1.478 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101442
G1 F11349
M204 S6000
G2 X126.982 Y122.483 I.463 J2.585 E.00117
; WIPE_START
G1 F15000
G1 X127.221 Y122.428 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.234 Y123.234 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.120461
G1 F11349
M204 S6000
G1 X126.214 Y122.806 E.00271
M204 S10000
G1 X125.534 Y122.655 F42000
; LINE_WIDTH: 0.118066
G1 F11349
M204 S6000
G2 X125.339 Y122.406 I-3.248 J2.333 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162091
G1 F11349
M204 S6000
G3 X125.481 Y122.505 I-1.019 J3.896 E.00281
; WIPE_START
G1 F15000
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.834 Y130.028 Z5.2 F42000
G1 X126.229 Y134.784 Z5.2
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.121675
G1 F11349
M204 S6000
G1 X126.201 Y135.033 E.00161
; LINE_WIDTH: 0.169671
G1 X126.177 Y135.16 E.00134
; LINE_WIDTH: 0.215773
G1 X126.155 Y135.28 E.00172
; LINE_WIDTH: 0.255287
G1 X126.11 Y135.45 E.00304
M204 S10000
G1 X125.29 Y135.557 F42000
; LINE_WIDTH: 0.0991428
G1 F11349
M204 S6000
G1 X125.253 Y135.591 E.00023
; LINE_WIDTH: 0.121579
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162782
G3 X125.058 Y135.733 I-.131 J-.077 E.00133
; LINE_WIDTH: 0.149291
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.11438
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 F15000
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.949 Y130.272 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11349
M204 S6000
G1 X121.949 Y130.272 E.00001
G2 X122.227 Y129.861 I-1.203 J-1.116 E.01653
G1 X122.348 Y130.013 E.00645
G1 X122.622 Y130.272 E.01249
G1 X122.009 Y130.272 E.02035
; WIPE_START
G1 F11791.304
G1 X121.949 Y130.272 E-.02628
G1 X122.103 Y130.078 E-.10822
G1 X122.227 Y129.861 E-.10892
G1 X122.348 Y130.013 E-.08482
G1 X122.622 Y130.272 E-.16425
G1 X122.009 Y130.272 E-.26752
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.481 Y130.272 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G2 X115.891 Y129.724 I-1.492 J-1.546 E.0228
G1 X119.209 Y122.767 E.25568
G1 X119.417 Y123.267 E.01797
G1 X116.376 Y129.636 E.23411
G1 X116.721 Y129.879 E.01398
G2 X116.879 Y130.272 I1.209 J-.259 E.01414
G1 X115.541 Y130.272 E.0444
; WIPE_START
G1 F11791.304
G1 X115.742 Y129.968 E-.1386
G1 X115.891 Y129.724 E-.10855
G1 X116.472 Y128.506 E-.51285
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.28 Y120.967 Z5.2 F42000
G1 X115.146 Y120.124 Z5.2
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G3 X114.732 Y119.747 I-.074 J-.336 E.02175
G3 X115.054 Y119.165 I.73 J.024 E.02291
G1 X115.378 Y118.976 E.01244
G1 X115.275 Y119.339 E.01251
G2 X115.313 Y119.833 I1.15 J.161 E.01657
G3 X115.338 Y120.007 I-.693 J.19 E.00585
G3 X115.204 Y120.106 I-.265 J-.219 E.00559
; WIPE_START
G1 F11791.304
G1 X115.002 Y120.124 E-.0771
G1 X114.92 Y120.097 E-.03254
G1 X114.825 Y120.029 E-.04447
G1 X114.777 Y119.962 E-.03122
G1 X114.732 Y119.747 E-.08371
G1 X114.744 Y119.606 E-.05383
G1 X114.804 Y119.434 E-.06887
G1 X114.934 Y119.264 E-.08159
G1 X115.054 Y119.165 E-.05907
G1 X115.378 Y118.976 E-.14247
G1 X115.317 Y119.192 E-.08515
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.243 Y126.178 Z5.2 F42000
G1 X110.311 Y130.57 Z5.2
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G1 X110.311 Y124.008 E.21768
G3 X110.778 Y122.825 I1.61 J-.049 E.04338
G3 X111.024 Y122.655 I.649 J.675 E.00996
G1 X111.154 Y122.806 E.00662
G2 X110.737 Y124.239 I1.943 J1.342 E.05039
G1 X110.737 Y131.765 E.24964
G1 X110.558 Y131.815 E.00616
G1 X110.203 Y131.226 E.0228
G2 X109.527 Y130.57 I-2.491 J1.894 E.03137
G1 X110.251 Y130.57 E.02402
M204 S250
G1 X109.919 Y130.178 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11349
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05006
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05705
G1 X114.513 Y124.559 E.02131
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.37 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.964 Y130.142 I-.322 J-3.237 E.02985
G2 X115.546 Y129.537 I-.692 J-1.248 E.02618
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06387
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.344 J.36 E.01894
G3 X115.072 Y120.522 I-.563 J.187 E.03632
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X115.808 Y118.591 I.615 J2.428 E.01891
G3 X117.064 Y118.892 I-.079 J3.101 E.03997
G1 X117.568 Y119.2 E.01816
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.65 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.041 Y130.27 E.01688
G2 X121.778 Y129.857 I-.172 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20009
G3 X117.08 Y129.654 I-.537 J.968 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.831 E.01818
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102637
G1 F11349
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124369
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155201
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 F15000
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.908 Y133.478 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.119128
G1 F11349
M204 S6000
G1 X110.885 Y133.243 E.00146
; LINE_WIDTH: 0.163525
G1 X110.862 Y133.008 E.00232
; LINE_WIDTH: 0.209475
G2 X110.837 Y132.758 I-2.97 J.174 E.00342
; LINE_WIDTH: 0.255826
G1 X110.808 Y132.602 E.00274
; LINE_WIDTH: 0.298301
G1 X110.78 Y132.447 E.00329
; LINE_WIDTH: 0.340775
G1 X110.751 Y132.291 E.00384
; LINE_WIDTH: 0.383249
G1 X110.723 Y132.136 E.00438
; LINE_WIDTH: 0.425723
G1 X110.694 Y131.981 E.00493
M204 S10000
G1 X110.524 Y131.305 F42000
; LINE_WIDTH: 0.225198
G1 F11349
M204 S6000
G1 X110.351 Y130.774 E.00829
M204 S10000
G1 X110.933 Y130.421 F42000
; LINE_WIDTH: 0.13636
G1 F11349
M204 S6000
G1 X113.83 Y130.421 E.02206
M204 S10000
G1 X114.943 Y130.468 F42000
; LINE_WIDTH: 0.132595
G1 F11349
M204 S6000
G2 X115.218 Y130.242 I-2.705 J-3.568 E.0026
; WIPE_START
G1 F15000
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.113999
G1 F11349
M204 S6000
G2 X117.278 Y130.468 I2.294 J-1.707 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112465
G1 F11349
M204 S6000
G3 X117.164 Y130.397 I.585 J-2.812 E.00119
; WIPE_START
G1 F15000
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.130449
G1 F11349
M204 S6000
G2 X121.608 Y130.384 I-.566 J-4.79 E.00274
M204 S10000
G1 X121.687 Y130.248 F42000
; LINE_WIDTH: 0.11705
G1 F11349
M204 S6000
G3 X121.434 Y130.468 I-3.024 J-3.229 E.00202
M204 S10000
G1 X122.124 Y129.318 F42000
; LINE_WIDTH: 0.115522
G1 F11349
M204 S6000
G3 X122.174 Y129.559 I-3.72 J.896 E.00146
M204 S10000
G1 X122.104 Y129.636 F42000
; LINE_WIDTH: 0.107567
G1 F11349
M204 S6000
G2 X122.185 Y129.406 I-3.511 J-1.37 E.00129
M204 S10000
G1 X122.921 Y130.253 F42000
; LINE_WIDTH: 0.115581
G1 F11349
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152902
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.122885
G1 F11349
M204 S6000
G3 X123.03 Y130.387 I.568 J-4.422 E.00228
; WIPE_START
G1 F15000
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.382 Y123.94 Z5.2 F42000
G1 X116.263 Y118.858 Z5.2
M73 P97 R0
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.106043
G1 F11349
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.134299
G1 X115.927 Y118.851 E.00107
; LINE_WIDTH: 0.175122
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.210041
G1 X115.601 Y118.909 E.00275
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.167954
G1 F11349
M204 S6000
G1 X115.775 Y118.785 E.00388
; WIPE_START
G1 F15000
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.017 Y119.479 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.173084
G1 F11349
M204 S6000
G2 X115.008 Y119.749 I1.822 J.193 E.00287
G1 X115.045 Y119.861 E.00125
; LINE_WIDTH: 0.146638
G1 X115.116 Y119.921 E.00079
; WIPE_START
G1 F15000
G1 X115.045 Y119.861 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.110386
G1 F11349
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139225
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166693
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200505
G2 X111.979 Y122.317 I.107 J1.469 E.002
; LINE_WIDTH: 0.238851
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282854
G2 X111.737 Y122.375 I.318 J1.591 E.00265
; LINE_WIDTH: 0.321783
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354828
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394172
G1 X111.495 Y122.469 E.00297
; LINE_WIDTH: 0.433223
G1 X111.424 Y122.504 E.00252
; LINE_WIDTH: 0.440606
G1 X111.263 Y122.448 E.00551
; LINE_WIDTH: 0.413493
G1 X111.103 Y122.393 E.00513
; WIPE_START
G1 F12952.91
G1 X111.263 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.047 Y126.212 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F11349
M204 S6000
G1 X107.124 Y125.848 E.01236
G2 X107.141 Y125.672 I-2.557 J-.345 E.00585
G1 X107.368 Y125.672 E.00754
G1 X107.404 Y126.143 E.01566
G3 X106.804 Y127.929 I-2.862 J.034 E.0637
G3 X106.118 Y128.523 I-2.315 J-1.983 E.03021
G1 X105.496 Y128.856 E.0234
G1 X104.238 Y129.311 E.04441
G1 X101.436 Y130.075 E.09634
G1 X100.494 Y130.428 E.03335
G2 X99.03 Y132.074 I1.197 J2.538 E.0751
G1 X98.924 Y132.531 E.01555
G1 X98.915 Y132.667 E.00451
G1 X98.687 Y132.667 E.00756
G3 X98.917 Y130.83 I3.406 J-.507 E.06216
G3 X99.677 Y129.913 I2.381 J1.199 E.03987
G1 X100.19 Y129.605 E.01985
G1 X101.04 Y129.252 E.03053
G3 X104.862 Y128.194 I41.698 J143.159 E.13155
G1 X105.53 Y127.924 E.0239
G1 X106.052 Y127.612 E.02017
G2 X107.03 Y126.27 I-1.486 J-2.11 E.0561
; WIPE_START
G1 F11791.304
G1 X107.124 Y125.848 E-.16431
G1 X107.141 Y125.672 E-.06699
G1 X107.368 Y125.672 E-.08632
G1 X107.404 Y126.143 E-.17941
G1 X107.392 Y126.398 E-.09723
G1 X107.334 Y126.83 E-.16575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.981 Y134.047 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G1 X106.306 Y133.519 E.02055
G1 X106.486 Y133.108 E.01489
G1 X106.68 Y133.148 E.00659
G1 X106.68 Y134.932 E.05918
G1 X106.508 Y134.985 E.00598
G1 X105.927 Y134.135 E.03417
G1 X105.95 Y134.098 E.00145
; WIPE_START
G1 F11791.304
G1 X106.306 Y133.519 E-.25821
G1 X106.486 Y133.108 E-.1706
G1 X106.68 Y133.148 E-.07544
G1 X106.68 Y133.821 E-.25575
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X102.171 Y127.663 Z5.2 F42000
G1 X99.457 Y123.958 Z5.2
G1 Z4.8
G1 E.8 F1800
G1 F11349
M204 S6000
G1 X99.187 Y124.282 E.01399
G1 X98.647 Y125.201 E.03536
G1 X98.467 Y125.152 E.00619
G1 X98.467 Y122.788 E.07844
G1 X99.418 Y123.912 E.04886
; WIPE_START
G1 F11791.304
G1 X99.187 Y124.282 E-.16578
G1 X98.647 Y125.201 E-.40511
G1 X98.467 Y125.152 E-.07093
G1 X98.467 Y124.841 E-.11818
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X103.041 Y130.951 Z5.2 F42000
G1 X105.735 Y134.549 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11349
M204 S5000
G1 X105.012 Y135.148 E.02886
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.0221
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.401 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.822 I41.765 J143.349 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08444
G2 X104.026 Y122.373 I-1.967 J3.002 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02062
G1 X101.399 Y122.828 E.02363
G1 X100.775 Y123.216 E.02259
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.208 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.477 Y122.031 E.02973
G1 X103.903 Y122.048 E.0131
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.35 Y124.204 E.01981
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.965 J-1.261 E.04254
G1 X106.33 Y128.854 E.01715
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08918
G1 X100.663 Y130.783 E.0293
G2 X99.406 Y132.192 I1.016 J2.173 E.05963
G2 X99.322 Y133.499 I3.084 J.853 E.04056
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.02639
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.115011
G1 F11349
M204 S6000
G1 X105.696 Y134.144 E.00039
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.133203
G1 F11349
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
; WIPE_START
G1 F15000
G1 X105.692 Y134.25 E-.70024
G1 X105.695 Y134.21 E-.05976
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F11349
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 F15000
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.178 Y135.316 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.106752
G1 F11349
M204 S6000
G1 X99.949 Y135.14 E.0015
; LINE_WIDTH: 0.131357
G1 X99.858 Y135.058 E.00088
; LINE_WIDTH: 0.159968
G1 X99.768 Y134.976 E.00117
; LINE_WIDTH: 0.191723
G3 X99.549 Y134.747 I1.561 J-1.706 E.00384
; LINE_WIDTH: 0.240305
G1 X99.325 Y134.446 E.00604
; LINE_WIDTH: 0.288576
G3 X99.236 Y134.304 I1.68 J-1.154 E.00336
; LINE_WIDTH: 0.336685
G3 X99.087 Y134.016 I3.594 J-2.035 E.00776
; LINE_WIDTH: 0.374668
G1 X99.054 Y133.936 E.00233
; LINE_WIDTH: 0.40041
G1 X99.02 Y133.857 E.00251
; LINE_WIDTH: 0.435387
G3 X98.92 Y133.548 I3.507 J-1.307 E.01039
; LINE_WIDTH: 0.478978
G1 F11007.731
G1 X98.892 Y133.429 E.00436
; LINE_WIDTH: 0.516479
G1 F10136.015
G1 X98.864 Y133.309 E.00473
; LINE_WIDTH: 0.548783
G1 F9488.735
G1 X98.796 Y132.863 E.01862
; WIPE_START
G1 X98.864 Y133.309 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.9 Y131.789 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.114966
G1 F11349
M204 S6000
G1 X98.932 Y131.648 E.00085
; LINE_WIDTH: 0.153118
G1 X98.992 Y131.479 E.00162
; LINE_WIDTH: 0.197158
G1 X99.03 Y131.383 E.0013
; LINE_WIDTH: 0.230956
G1 X99.068 Y131.287 E.00158
; LINE_WIDTH: 0.261701
G1 X99.139 Y131.141 E.00288
; LINE_WIDTH: 0.291538
G1 X99.191 Y131.053 E.00208
; LINE_WIDTH: 0.322968
G1 X99.234 Y130.982 E.00188
; LINE_WIDTH: 0.351139
G1 X99.321 Y130.86 E.00378
; LINE_WIDTH: 0.379403
G1 X99.408 Y130.737 E.00412
; LINE_WIDTH: 0.415416
G3 X99.539 Y130.599 I.68 J.512 E.00581
; LINE_WIDTH: 0.447786
G1 X99.644 Y130.493 E.00491
; LINE_WIDTH: 0.465002
G1 X99.812 Y130.349 E.0076
; LINE_WIDTH: 0.494299
G1 F10634.083
G3 X100.388 Y129.998 I2.922 J4.155 E.02484
; LINE_WIDTH: 0.5428
G1 F9602.304
G3 X101.286 Y129.65 I3.457 J7.586 E.03925
G2 X104.541 Y128.735 I-51.662 J-189.962 E.13773
; LINE_WIDTH: 0.493695
G1 F10648.344
G1 X104.983 Y128.595 E.01703
; LINE_WIDTH: 0.471695
G1 F11194.687
G2 X105.695 Y128.292 I-2.404 J-6.625 E.02706
; LINE_WIDTH: 0.433677
G1 F11349
G2 X106.262 Y127.934 I-2.208 J-4.127 E.02136
; LINE_WIDTH: 0.38376
G2 X106.523 Y127.695 I-2.896 J-3.42 E.00983
; LINE_WIDTH: 0.348886
G1 X106.613 Y127.597 E.00331
; LINE_WIDTH: 0.320231
G2 X106.735 Y127.443 I-1.83 J-1.572 E.00443
; LINE_WIDTH: 0.292314
G1 X106.814 Y127.324 E.00291
; LINE_WIDTH: 0.256004
G1 X106.893 Y127.205 E.00249
; LINE_WIDTH: 0.220473
G2 X106.983 Y127.022 I-1.061 J-.632 E.00295
; LINE_WIDTH: 0.180155
G1 X107.037 Y126.901 E.00148
; LINE_WIDTH: 0.14682
G1 X107.091 Y126.78 E.00112
; LINE_WIDTH: 0.112557
G1 X107.131 Y126.631 E.00088
; WIPE_START
G1 F15000
G1 X107.091 Y126.78 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X107.259 Y125.476 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.563064
G1 F9228.216
M204 S6000
G1 X107.223 Y125.208 E.01146
G2 X107.177 Y124.94 I-6.755 J1.02 E.01152
; LINE_WIDTH: 0.522389
G1 F10011.079
G1 X107.149 Y124.832 E.00436
; LINE_WIDTH: 0.486112
G1 F10830.529
G2 X107.111 Y124.691 I-1.779 J.404 E.00528
; LINE_WIDTH: 0.44769
G1 F11349
G1 X107.004 Y124.385 E.01067
; LINE_WIDTH: 0.402689
G1 X106.936 Y124.232 E.00492
; LINE_WIDTH: 0.374803
G1 X106.923 Y124.208 E.00074
; LINE_WIDTH: 0.358815
G1 X106.829 Y124.036 E.00504
; LINE_WIDTH: 0.32626
G2 X106.694 Y123.803 I-1.506 J.718 E.00622
; LINE_WIDTH: 0.296017
G1 X106.683 Y123.787 E.0004
; LINE_WIDTH: 0.276539
G1 X106.531 Y123.593 E.00468
; LINE_WIDTH: 0.240881
G2 X106.371 Y123.389 I-2.495 J1.785 E.00419
; LINE_WIDTH: 0.211773
G1 X106.207 Y123.227 E.00317
; LINE_WIDTH: 0.184722
G1 X106.1 Y123.133 E.00164
; LINE_WIDTH: 0.153202
G1 X105.988 Y123.035 E.00134
; LINE_WIDTH: 0.120228
G2 X105.616 Y122.762 I-1.869 J2.16 E.00291
; WIPE_START
G1 F15000
G1 X105.988 Y123.035 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X100.489 Y123.172 Z5.2 F42000
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.122041
G1 F11349
M204 S6000
G2 X99.912 Y123.647 I9.343 J11.938 E.00482
; LINE_WIDTH: 0.147268
G1 X99.787 Y123.772 E.0015
; LINE_WIDTH: 0.173373
G1 X99.662 Y123.896 E.00188
M204 S10000
G1 X98.975 Y123.703 F42000
; LINE_WIDTH: 0.428286
G1 F11349
M204 S6000
G1 X98.671 Y124.662 E.03159
M204 S10000
G1 X98.527 Y125.372 F42000
; LINE_WIDTH: 0.449899
G1 F11349
M204 S6000
G1 X98.495 Y125.538 E.0056
; LINE_WIDTH: 0.402731
G1 X98.463 Y125.704 E.00495
; LINE_WIDTH: 0.355562
G1 X98.432 Y125.87 E.0043
; LINE_WIDTH: 0.308393
G1 X98.4 Y126.036 E.00366
; LINE_WIDTH: 0.261225
G1 X98.368 Y126.202 E.00301
; LINE_WIDTH: 0.235525
G1 X98.366 Y126.215 E.00022
; LINE_WIDTH: 0.210675
G1 X98.343 Y126.416 E.00277
; LINE_WIDTH: 0.165173
G1 X98.319 Y126.618 E.00202
; LINE_WIDTH: 0.119671
G1 X98.295 Y126.819 E.00127
; CHANGE_LAYER
; Z_HEIGHT: 5
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.319 Y126.618 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 25/25
; update layer progress
M73 L25
M991 S0 P24 ;notify layer change
; OBJECT_ID: 91
M204 S10000
G17
G3 Z5.2 I-.068 J1.215 P1  F42000
G1 X151.021 Y129.586 Z5.2
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X151.33 Y133.842 E.1311
G1 X152.855 Y133.544 E.04776
G1 X154.155 Y133.438 E.04007
G3 X155.668 Y133.705 I-.059 J4.757 E.04742
G1 X156.176 Y133.962 E.01748
G3 X157.175 Y135.119 I-1.408 J2.225 E.04766
G1 X156.667 Y134.911 E.01685
G1 X156.012 Y134.754 E.02069
G1 X154.802 Y134.647 E.03734
G1 X152.778 Y134.819 E.06243
G1 X151.041 Y135.149 E.05433
G2 X150.914 Y132.263 I-45.43 J.551 E.08877
G1 X150.704 Y129.357 E.08952
G2 X150.326 Y128.793 I-6.106 J3.679 E.02088
G3 X150.24 Y128.113 I.701 J-.434 E.02172
G3 X150.66 Y128.069 I.23 J.174 E.01456
G3 X150.911 Y128.563 I-.571 J.601 E.01736
G1 X150.99 Y129.07 E.01576
G2 X152.432 Y130.006 I3.278 J-3.474 E.05312
G2 X155.632 Y129.12 I.98 J-2.682 E.10887
G2 X156.206 Y127.844 I-2.912 J-2.077 E.04327
G2 X156.353 Y126.398 I-6.095 J-1.351 E.04475
G1 X156.35 Y126.199 E.00612
G1 X156.243 Y124.99 E.0373
G1 X156.069 Y124.286 E.02226
G1 X155.843 Y123.765 E.01746
G2 X154.213 Y122.468 I-2.374 J1.31 E.06572
G2 X152.552 Y122.373 I-1.092 J4.555 E.05138
G2 X151.017 Y123.02 I.381 J3.05 E.05184
G2 X150.497 Y124.013 I.946 J1.127 E.03531
G2 X150.8 Y124.444 I.571 J-.079 E.01683
G3 X151.438 Y124.802 I-.844 J2.255 E.02255
G3 X151.563 Y125.601 I-.91 J.552 E.0255
G3 X150.029 Y125.875 I-.81 J-.101 E.06368
G3 X149.837 Y124.828 I1.971 J-.902 E.03304
G3 X150.382 Y123.329 I2.529 J.071 E.04986
G3 X151.579 Y122.375 I2.768 J2.245 E.0474
G3 X153.404 Y122.031 I1.699 J3.999 E.05749
G1 X154.334 Y122.115 E.02871
G1 X155.036 Y122.291 E.02221
G1 X155.696 Y122.574 E.02208
G1 X156.273 Y122.947 E.02109
G3 X157.709 Y124.962 I-2.535 J3.326 E.07718
G1 X157.867 Y125.641 E.02145
G1 X157.925 Y126.425 E.02414
G1 X157.896 Y126.952 E.01624
G1 X157.766 Y127.609 E.02057
G3 X156.841 Y129.213 I-3.997 J-1.237 E.05736
G1 X156.319 Y129.682 E.02158
G1 X155.779 Y130.027 E.01968
G1 X155.172 Y130.282 E.02022
G1 X154.564 Y130.426 E.01919
G1 X153.828 Y130.482 E.0227
G1 X153.123 Y130.412 E.02178
G1 X152.421 Y130.219 E.02234
G1 X151.076 Y129.611 E.04538
; WIPE_START
M204 S6000
G1 X151.196 Y131.608 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.4 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z5.4
G1 X0 Y128 F18000 ; move to safe pos
G1 X-48.2 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z5.4 F4000
            G39.3 S1
            G0 Z5.4 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END


G1 X150.71 Y128.997 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.28867
G1 F15000
M204 S6000
G2 X150.503 Y128.334 I-72.192 J22.106 E.0139
; LINE_WIDTH: 0.240776
G1 X150.486 Y128.297 E.00065
; LINE_WIDTH: 0.196978
G1 X150.466 Y128.27 E.00043
; LINE_WIDTH: 0.15879
G1 X150.452 Y128.253 E.00021
; LINE_WIDTH: 0.122898
G1 X150.41 Y128.21 E.00039
; WIPE_START
G1 X150.452 Y128.253 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.364 Y125.501 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X150.305 Y124.442 E.04602
G1 X150.061 Y124.731
G1 X151.207 Y125.878 E.04983
G1 X150.884 Y126.088
G1 X150.062 Y125.266 E.03573
; WIPE_START
M204 S6000
G1 X150.884 Y126.088 E-.44192
G1 X151.207 Y125.878 E-.14642
G1 X150.888 Y125.558 E-.17166
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X151.383 Y125.177 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.201315
G1 F15000
M204 S6000
G2 X151.134 Y124.898 I-.903 J.555 E.00486
; LINE_WIDTH: 0.175808
G1 X151.042 Y124.833 E.00121
; LINE_WIDTH: 0.140751
G1 X150.951 Y124.768 E.00089
; LINE_WIDTH: 0.105694
G1 X150.859 Y124.703 E.00057
; WIPE_START
G1 X150.951 Y124.768 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.605 Y126.097 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.0902429
G1 F15000
M204 S6000
G1 X150.579 Y126.084 E.00011
; LINE_WIDTH: 0.106258
G1 X150.514 Y126.039 E.00041
; LINE_WIDTH: 0.145676
G3 X150.229 Y125.759 I.788 J-1.086 E.00335
; LINE_WIDTH: 0.107672
G1 X150.149 Y125.646 E.00073
; WIPE_START
G1 X150.229 Y125.759 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.221 Y124.215 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.12308
G1 F15000
M204 S6000
G3 X150.289 Y123.904 I1.881 J.247 E.00209
; WIPE_START
G1 X150.221 Y124.215 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.782 Y122.454 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.118035
G1 F15000
M204 S6000
G1 X154.957 Y122.523 E.00115
; LINE_WIDTH: 0.148768
G1 X155.126 Y122.606 E.00162
; LINE_WIDTH: 0.179216
G1 X155.267 Y122.689 E.00183
; LINE_WIDTH: 0.221064
G1 X155.4 Y122.769 E.00225
; LINE_WIDTH: 0.261706
G1 X155.533 Y122.848 E.00276
; LINE_WIDTH: 0.306033
G1 X155.67 Y122.961 E.0038
; LINE_WIDTH: 0.349893
G1 X155.789 Y123.063 E.00392
; LINE_WIDTH: 0.39102
G1 F13789.144
G1 X155.908 Y123.164 E.00444
; LINE_WIDTH: 0.417
G1 F12831.484
G1 X156.253 Y123.483 E.01432
M204 S10000
G1 X156.218 Y123.505 F42000
; LINE_WIDTH: 0.487714
G1 F10791.524
M204 S6000
G1 X155.547 Y122.723 E.03735
; WIPE_START
G1 X156.218 Y123.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X157.293 Y124.498 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X156.418 Y123.623 E.03799
G1 X156.151 Y123.889
G1 X157.578 Y125.316 E.06203
G1 X157.682 Y125.953
G1 X156.371 Y124.642 E.05699
G1 X156.477 Y125.282
G1 X157.712 Y126.516 E.05366
G1 X157.673 Y127.011
G1 X156.529 Y125.867 E.0497
G1 X156.551 Y126.422
G1 X157.585 Y127.456 E.04496
G1 X157.453 Y127.858
G1 X156.533 Y126.938 E.03997
G1 X156.485 Y127.422
G1 X157.289 Y128.226 E.03494
G1 X157.094 Y128.565
G1 X156.41 Y127.881 E.02973
G1 X156.288 Y128.292
G1 X156.857 Y128.861 E.02472
M204 S10000
G1 X156.707 Y129.08 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.258898
G1 F15000
M204 S6000
G1 X156.149 Y128.601 E.01294
M204 S10000
G1 X155.916 Y129.077 F42000
; LINE_WIDTH: 0.458071
G1 F11562.075
M204 S6000
G1 X155.937 Y129.238 E.00551
; LINE_WIDTH: 0.492704
G1 F10671.789
G1 X155.958 Y129.402 E.00603
; LINE_WIDTH: 0.492631
G1 F10673.531
G1 X155.841 Y129.5 E.0056
; LINE_WIDTH: 0.453254
G1 F11697.79
G1 X155.724 Y129.598 E.00511
; LINE_WIDTH: 0.410317
G1 F13064.893
G1 X155.585 Y129.71 E.00536
; LINE_WIDTH: 0.362704
G1 F15000
G1 X155.446 Y129.793 E.00422
; LINE_WIDTH: 0.317843
G1 X155.307 Y129.876 E.00363
; LINE_WIDTH: 0.270731
G3 X155.153 Y129.966 I-1.195 J-1.849 E.00331
; LINE_WIDTH: 0.24256
G1 X155.081 Y130.002 E.00131
; LINE_WIDTH: 0.213439
G1 X154.918 Y130.065 E.00243
; LINE_WIDTH: 0.164576
G1 X154.756 Y130.129 E.00173
; LINE_WIDTH: 0.120194
G1 X154.748 Y130.132 E.00005
G3 X154.45 Y130.215 I-.674 J-1.844 E.00195
; WIPE_START
G1 X154.748 Y130.132 E-.74105
G1 X154.756 Y130.129 E-.01895
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X154.758 Y133.694 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X155.503 Y134.439 E.03237
G1 X154.986 Y134.455
G1 X154.177 Y133.647 E.03513
G1 X153.682 Y133.685
G1 X154.465 Y134.468 E.03402
G1 X153.973 Y134.51
G1 X153.189 Y133.725 E.0341
G1 X152.713 Y133.783
G1 X153.482 Y134.551 E.0334
G1 X152.99 Y134.593
G1 X152.267 Y133.87 E.03142
G1 X151.821 Y133.957
G1 X152.521 Y134.657 E.03041
G1 X152.073 Y134.742
G1 X151.375 Y134.044 E.03032
G1 X151.229 Y134.431
G1 X151.625 Y134.827 E.0172
; WIPE_START
M204 S6000
G1 X151.229 Y134.431 E-.21267
G1 X151.375 Y134.044 E-.1572
G1 X152.073 Y134.742 E-.37491
G1 X152.112 Y134.735 E-.01522
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X155.664 Y134.1 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.32728
G1 F15000
M204 S6000
G1 X155.187 Y133.754 E.01367
M204 S10000
G1 X155.803 Y134.256 F42000
; LINE_WIDTH: 0.429371
G1 F12420.728
M204 S6000
G1 X156.089 Y134.375 E.00973
; LINE_WIDTH: 0.401468
G1 F13387.362
G1 X156.371 Y134.505 E.00907
; LINE_WIDTH: 0.359274
G1 F15000
G1 X156.652 Y134.635 E.00801
; WIPE_START
G1 X156.371 Y134.505 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X150.228 Y129.975 Z5.4 F42000
G1 X141.816 Y123.77 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X141.854 Y124.138 I.302 J.155 E.01203
G1 X142.546 Y124.878 E.03113
G1 X143.291 Y125.535 E.03051
G1 X145.827 Y127.65 E.10146
G1 X146.708 Y128.471 E.037
G1 X147.501 Y129.368 E.03679
G1 X147.891 Y129.933 E.02112
G1 X148.181 Y130.538 E.0206
G1 X148.372 Y131.201 E.02119
G1 X148.435 Y131.848 E.01999
G3 X147.225 Y134.307 I-3.094 J.005 E.08723
G1 X146.645 Y134.674 E.02107
G1 X145.963 Y134.965 E.02281
G1 X145.291 Y135.13 E.02123
G1 X144.513 Y135.191 E.02399
G1 X143.793 Y135.14 E.0222
G1 X143.032 Y134.959 E.02403
G1 X142.375 Y134.686 E.02186
G1 X141.777 Y134.321 E.02154
G3 X140.574 Y132.448 I1.812 J-2.485 E.06997
G1 X140.525 Y131.874 E.01772
G3 X140.975 Y130.546 I1.96 J-.076 E.04406
G3 X142.398 Y130.442 I.759 J.606 E.04924
G3 X142.359 Y131.777 I-.714 J.647 E.04532
G3 X141.865 Y132.001 I-.763 J-1.022 E.01679
G2 X141.353 Y132.269 I.244 J1.091 E.01797
G2 X141.199 Y132.887 I.639 J.487 E.02013
G2 X141.572 Y133.741 I1.598 J-.191 E.02904
G2 X143.117 Y134.727 I2.406 J-2.066 E.05712
G2 X145.375 Y134.742 I1.158 J-4.218 E.07019
G2 X146.928 Y133.096 I-.75 J-2.263 E.07244
G2 X147.045 Y132.157 I-3.387 J-.899 E.02916
G1 X146.974 Y131.438 E.0222
G1 X146.76 Y130.647 E.02518
G1 X146.377 Y129.765 E.02955
G1 X145.684 Y128.682 E.03952
G2 X142.792 Y125.502 I-47.582 J40.372 E.13207
G1 X139.981 Y122.408 E.12845
G1 X139.981 Y122.21 E.0061
G1 X148.294 Y122.21 E.25542
G1 X148.598 Y125.774 E.10991
G1 X148.266 Y125.774 E.0102
G2 X147.77 Y124.074 I-10.116 J2.029 E.05447
G2 X146.657 Y123.256 I-1.166 J.419 E.04504
G2 X146.073 Y123.24 I-.41 J4.346 E.01795
G1 X143.768 Y123.3 E.07087
G1 X142.543 Y123.431 E.03784
G2 X141.873 Y123.69 I.17 J1.438 E.02232
G2 X141.848 Y123.719 I.246 J.234 E.00117
; WIPE_START
M204 S6000
G1 X141.782 Y123.855 E-.05757
G1 X141.777 Y123.957 E-.03866
G1 X141.803 Y124.049 E-.03653
G1 X141.854 Y124.138 E-.03904
G1 X142.546 Y124.878 E-.38496
G1 X142.947 Y125.232 E-.20324
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X143.795 Y126.244 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.114804
G1 F15000
M204 S6000
G1 X144.018 Y126.454 E.00179
; LINE_WIDTH: 0.150556
G1 X144.24 Y126.664 E.00269
; LINE_WIDTH: 0.186309
G1 X144.463 Y126.873 E.00358
; LINE_WIDTH: 0.228097
G1 X144.685 Y127.09 E.00468
; LINE_WIDTH: 0.275812
G1 X144.905 Y127.304 E.00583
; LINE_WIDTH: 0.32331
G1 X145.125 Y127.518 E.00702
; LINE_WIDTH: 0.370809
G1 F14639.119
G1 X145.345 Y127.733 E.0082
; LINE_WIDTH: 0.418308
G1 F12786.796
G1 X145.565 Y127.947 E.00939
; LINE_WIDTH: 0.458217
G1 F11558.016
G1 X145.79 Y128.179 E.01093
; LINE_WIDTH: 0.490558
G1 F10722.958
G1 X146.015 Y128.41 E.01178
; LINE_WIDTH: 0.50987
G1 F10279.48
G1 X146.039 Y128.437 E.00136
; LINE_WIDTH: 0.536687
G1 F9721.184
G1 X146.325 Y128.78 E.01798
; WIPE_START
G1 X146.039 Y128.437 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.004 Y130.673 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X146.356 Y129.025 E.07161
G1 X146.633 Y129.836
G1 X148.182 Y131.384 E.06729
G1 X148.221 Y131.956
G1 X146.999 Y130.734 E.0531
G1 X147.184 Y131.453
G1 X148.162 Y132.431 E.04252
G1 X148.043 Y132.845
G1 X147.242 Y132.044 E.03479
G1 X147.229 Y132.564
G1 X147.878 Y133.214 E.02822
G1 X147.674 Y133.543
G1 X147.154 Y133.023 E.02262
M204 S10000
G1 X147.537 Y133.744 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.151348
G1 F15000
M204 S6000
G1 X147.061 Y133.278 E.00589
; WIPE_START
G1 X147.537 Y133.744 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X147.063 Y130.67 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.185979
G1 F15000
M204 S6000
G1 X146.998 Y130.559 E.0015
; LINE_WIDTH: 0.151372
G1 X146.928 Y130.456 E.0011
; LINE_WIDTH: 0.109241
G1 X146.858 Y130.353 E.00067
M204 S10000
G1 X147.757 Y130.133 F42000
; LINE_WIDTH: 0.102156
G1 F15000
M204 S6000
G1 X147.696 Y130.047 E.00051
; LINE_WIDTH: 0.135842
G1 X147.556 Y129.879 E.00165
; LINE_WIDTH: 0.175231
G1 X147.416 Y129.711 E.00235
; LINE_WIDTH: 0.214621
G1 X147.276 Y129.543 E.00305
; LINE_WIDTH: 0.248
G1 X146.931 Y129.176 E.00843
; LINE_WIDTH: 0.2754
G1 X146.586 Y128.809 E.00955
; WIPE_START
G1 X146.931 Y129.176 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.316 Y125.064 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.120213
G1 F15000
M204 S6000
G1 X148.263 Y124.75 E.002
; LINE_WIDTH: 0.168504
G1 X148.206 Y124.48 E.00283
; LINE_WIDTH: 0.218009
G1 X148.149 Y124.209 E.00394
; LINE_WIDTH: 0.267514
G1 X148.092 Y123.939 E.00506
M204 S10000
G1 X148.016 Y123.966 F42000
; LINE_WIDTH: 0.165127
G1 F15000
M204 S6000
G1 X147.928 Y123.845 E.00149
; LINE_WIDTH: 0.119655
G1 X147.839 Y123.724 E.00094
M204 S10000
G1 X148.016 Y123.966 F42000
; LINE_WIDTH: 0.189793
G1 F15000
M204 S6000
G1 X148.28 Y124.356 E.00563
; WIPE_START
G1 X148.016 Y123.966 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X148.137 Y122.807 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X147.747 Y122.417 E.01694
G1 X147.214 Y122.417
G1 X148.186 Y123.39 E.04227
G1 X147.776 Y123.513
G1 X146.681 Y122.417 E.04762
G1 X146.147 Y122.417
G1 X146.805 Y123.075 E.02857
G1 X146.231 Y123.035
G1 X145.614 Y122.417 E.02683
G1 X145.081 Y122.417
G1 X145.71 Y123.047 E.02736
G1 X145.189 Y123.059
G1 X144.547 Y122.417 E.02789
G1 X144.014 Y122.417
G1 X144.668 Y123.071 E.02841
G1 X144.147 Y123.083
G1 X143.481 Y122.417 E.02894
G1 X142.948 Y122.417
G1 X143.636 Y123.105 E.02989
G1 X143.154 Y123.157
G1 X142.414 Y122.417 E.03213
G1 X141.881 Y122.417
G1 X142.672 Y123.208 E.03437
G1 X142.225 Y123.295
G1 X141.348 Y122.417 E.03813
G1 X140.815 Y122.417
G1 X141.849 Y123.452 E.04496
; WIPE_START
M204 S6000
G1 X140.815 Y122.417 E-.55604
G1 X141.348 Y122.417 E-.20264
G1 X141.35 Y122.42 E-.00132
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X140.753 Y122.399 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.238048
G1 F15000
M204 S6000
G1 X140.683 Y122.445 E.00134
; LINE_WIDTH: 0.271581
G1 X140.612 Y122.492 E.00157
; LINE_WIDTH: 0.30182
G1 X140.542 Y122.538 E.00177
G1 X140.599 Y122.633 E.00234
; LINE_WIDTH: 0.29274
G1 X141.059 Y123.116 E.01358
; LINE_WIDTH: 0.324671
G1 X141.519 Y123.599 E.01531
; WIPE_START
G1 X141.059 Y123.116 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.407 Y130.475 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X142.363 Y131.431 E.04154
G1 X142.097 Y131.699
G1 X141.109 Y130.711 E.04295
G1 X140.899 Y131.034
G1 X141.707 Y131.842 E.03509
G1 X141.341 Y132.009
G1 X140.775 Y131.443 E.02456
; WIPE_START
M204 S6000
G1 X141.341 Y132.009 E-.30369
G1 X141.707 Y131.842 E-.15296
G1 X141.142 Y131.277 E-.30335
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.352 Y130.5 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.0948846
G1 F15000
M204 S6000
G1 X141.251 Y130.586 E.00056
; WIPE_START
G1 X141.352 Y130.5 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X142.449 Y131.066 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.378634
G1 F14297.913
M204 S6000
G2 X141.787 Y130.374 I-3.005 J2.215 E.02626
; WIPE_START
G1 X142.131 Y130.689 E-.36918
G1 X142.449 Y131.066 E-.39082
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X141.096 Y132.232 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.197993
G1 F15000
M204 S6000
G1 X140.829 Y132.644 E.0062
M204 S10000
G1 X140.821 Y132.612 F42000
; LINE_WIDTH: 0.121168
G1 F15000
M204 S6000
G3 X141.111 Y132.246 I3.933 J2.825 E.00298
M204 S10000
G1 X140.905 Y132.39 F42000
; LINE_WIDTH: 0.247214
G1 F15000
M204 S6000
G1 X140.911 Y132.584 E.00323
; LINE_WIDTH: 0.218711
G1 X140.92 Y132.672 E.00126
; LINE_WIDTH: 0.185507
G1 X140.933 Y132.789 E.00137
; LINE_WIDTH: 0.14708
G1 X140.964 Y132.915 E.0011
; LINE_WIDTH: 0.110953
G1 X141.001 Y133.044 E.00075
; WIPE_START
G1 X140.964 Y132.915 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X145.883 Y134.759 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.121274
G1 F15000
M204 S6000
G1 X146.196 Y134.596 E.00225
; LINE_WIDTH: 0.164871
G1 X146.304 Y134.529 E.00126
; LINE_WIDTH: 0.203343
G1 X146.404 Y134.466 E.00154
; LINE_WIDTH: 0.240475
G1 X146.503 Y134.403 E.0019
; LINE_WIDTH: 0.263772
G1 X146.552 Y134.367 E.0011
; LINE_WIDTH: 0.291683
G2 X146.669 Y134.265 I-1.206 J-1.497 E.00313
; LINE_WIDTH: 0.337794
G1 X146.771 Y134.175 E.00326
; LINE_WIDTH: 0.381014
G1 F14197.241
G1 X146.872 Y134.085 E.00374
; LINE_WIDTH: 0.408413
G1 F13132.945
G1 X147.204 Y133.768 E.01366
M204 S10000
G1 X147.167 Y133.747 F42000
; LINE_WIDTH: 0.481866
G1 F10935.284
M204 S6000
G1 X146.549 Y134.501 E.03486
; WIPE_START
G1 X147.167 Y133.747 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X140.145 Y130.756 Z5.4 F42000
G1 X138.362 Y129.997 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.867 Y132.666 E.08346
G3 X139.122 Y134.451 I-13.395 J2.827 E.05545
G3 X138.145 Y135.179 I-.8 J-.054 E.04254
G3 X137.59 Y134.613 I.105 J-.657 E.02608
G3 X137.555 Y134.224 I2.26 J-.4 E.012
G3 X137.775 Y132.666 I11.988 J.894 E.04838
G1 X138.28 Y129.997 E.08346
G1 X138.302 Y129.997 E.00068
M204 S10000
G1 X138.321 Y130.953 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.120842
G1 F15000
M204 S6000
G1 X138.321 Y131.112 E.00101
; LINE_WIDTH: 0.168683
G1 X138.321 Y131.271 E.00163
; LINE_WIDTH: 0.216523
G1 X138.321 Y131.431 E.00225
; LINE_WIDTH: 0.264364
G1 X138.321 Y131.59 E.00287
; LINE_WIDTH: 0.312205
G1 X138.321 Y131.749 E.0035
; LINE_WIDTH: 0.360046
G1 X138.321 Y131.909 E.00412
; LINE_WIDTH: 0.407887
G1 F13151.885
G1 X138.321 Y132.068 E.00474
; LINE_WIDTH: 0.455728
G1 F11627.694
G1 X138.321 Y132.227 E.00536
; WIPE_START
G1 X138.321 Y132.068 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.743 Y133.144 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X138.037 Y132.438 E.03067
G1 X137.954 Y132.888
G1 X138.845 Y133.779 E.03873
G1 X138.916 Y134.384
G1 X137.87 Y133.338 E.04546
G1 X137.808 Y133.809
G1 X138.784 Y134.784 E.04239
G1 X138.439 Y134.973
G1 X137.771 Y134.305 E.02904
M204 S10000
G1 X138.142 Y134.964 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0940423
G1 F15000
M204 S6000
G1 X138.105 Y134.946 E.00017
; LINE_WIDTH: 0.137247
G3 X137.805 Y134.653 I.571 J-.885 E.00324
; WIPE_START
G1 X137.918 Y134.793 E-.32436
G1 X138.105 Y134.946 E-.43564
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.94 Y130.446 Z5.4 F42000
G1 X131.49 Y130.117 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X130.611 Y129.024 I1.592 J-2.18 E.04361
G1 X130.402 Y128.437 E.01913
G1 X130.239 Y127.565 E.02726
G1 X130.18 Y126.469 E.03375
G1 X130.231 Y125.421 E.03224
G1 X130.361 Y124.629 E.02465
G1 X130.558 Y123.987 E.02064
G3 X131.025 Y123.192 I2.583 J.981 E.02847
G3 X132.54 Y122.347 I1.8 J1.446 E.05466
G3 X133.879 Y122.579 I.257 J2.491 E.04228
G3 X135.19 Y124.228 I-1.394 J2.454 E.06634
G1 X135.38 Y125.024 E.02516
G1 X135.488 Y126.405 E.04257
G3 X135.447 Y127.513 I-9.258 J.216 E.03408
G1 X135.334 Y128.246 E.02278
G1 X135.17 Y128.825 E.01849
G1 X134.973 Y129.26 E.01469
G3 X131.784 Y130.304 I-2.142 J-1.149 E.1138
G3 X131.538 Y130.152 I1.297 J-2.367 E.00889
; WIPE_START
M204 S6000
G1 X131.187 Y129.867 E-.17181
G1 X130.87 Y129.485 E-.18905
G1 X130.611 Y129.024 E-.20075
G1 X130.436 Y128.532 E-.19839
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X128.844 Y127.247 Z5.4 F42000
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S5000
G1 X128.79 Y126.431 E.02513
G1 X128.845 Y125.613 E.02521
G1 X128.986 Y124.936 E.02125
G1 X129.223 Y124.307 E.02064
G1 X129.568 Y123.708 E.02125
G1 X130.024 Y123.165 E.02178
G1 X130.512 Y122.745 E.01978
G3 X132.054 Y122.087 I2.312 J3.282 E.05192
G1 X132.767 Y122.03 E.02196
G1 X133.476 Y122.089 E.02187
G1 X134.11 Y122.249 E.02009
G3 X135.81 Y123.337 I-1.344 J3.968 E.06264
G1 X136.196 Y123.834 E.01933
G1 X136.481 Y124.352 E.01816
G1 X136.689 Y124.926 E.01876
G1 X136.834 Y125.648 E.02264
G1 X136.881 Y126.441 E.0244
G1 X136.816 Y127.34 E.02768
G1 X136.665 Y128.006 E.021
G1 X136.421 Y128.622 E.02036
G1 X136.073 Y129.201 E.02074
G1 X135.659 Y129.683 E.01953
G1 X135.169 Y130.104 E.01985
G1 X134.656 Y130.423 E.01856
G1 X134.134 Y130.641 E.01738
G1 X133.536 Y130.787 E.01891
G1 X132.808 Y130.844 E.02244
G1 X132.031 Y130.777 E.02397
G3 X130.501 Y130.114 I.822 J-3.995 E.0516
G1 X129.983 Y129.657 E.02122
G1 X129.538 Y129.113 E.0216
G1 X129.234 Y128.587 E.01867
G1 X129.002 Y127.979 E.02
G1 X128.857 Y127.306 E.02114
; WIPE_START
M204 S6000
G1 X128.79 Y126.431 E-.33339
G1 X128.845 Y125.613 E-.31179
G1 X128.907 Y125.317 E-.11481
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.965 Y129.326 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.505452
G1 F10377.668
M204 S6000
G1 X130.3 Y129.361 E.01271
G1 X130.387 Y129.467 E.00519
; LINE_WIDTH: 0.448122
G1 F11845.941
G1 X130.474 Y129.574 E.00455
; LINE_WIDTH: 0.403232
G1 F13321.807
G1 X130.561 Y129.681 E.00405
; LINE_WIDTH: 0.361917
G1 F15000
G2 X130.709 Y129.835 I1.863 J-1.639 E.00554
; LINE_WIDTH: 0.326592
G1 X130.797 Y129.912 E.00271
; LINE_WIDTH: 0.28937
G1 X130.886 Y129.989 E.00236
; LINE_WIDTH: 0.252148
G1 X130.974 Y130.066 E.002
; LINE_WIDTH: 0.218557
G2 X131.122 Y130.176 I1.361 J-1.683 E.00264
; LINE_WIDTH: 0.185258
G1 X131.233 Y130.245 E.00151
; LINE_WIDTH: 0.146066
G1 X131.343 Y130.314 E.00109
; LINE_WIDTH: 0.111382
G1 X131.549 Y130.42 E.00129
; WIPE_START
G1 X131.343 Y130.314 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X134.264 Y130.349 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.11657
G1 F15000
M204 S6000
G1 X134.4 Y130.269 E.00094
; LINE_WIDTH: 0.155879
G1 X134.535 Y130.189 E.00145
; LINE_WIDTH: 0.183748
G1 X134.655 Y130.105 E.00168
; LINE_WIDTH: 0.211095
G1 X134.768 Y130.012 E.00201
; LINE_WIDTH: 0.249531
G1 X134.871 Y129.925 E.00227
; LINE_WIDTH: 0.286342
G1 X134.975 Y129.839 E.00267
; LINE_WIDTH: 0.327144
G2 X135.106 Y129.695 I-1.113 J-1.141 E.00452
; LINE_WIDTH: 0.374456
G1 F14478.09
G1 X135.207 Y129.58 E.00415
; LINE_WIDTH: 0.416522
G1 F12847.909
G1 X135.309 Y129.465 E.00468
; LINE_WIDTH: 0.443378
G1 F11986.275
G1 X135.602 Y129.106 E.01511
M204 S10000
G1 X135.56 Y129.088 F42000
; LINE_WIDTH: 0.492746
G1 F10670.811
M204 S6000
G1 X134.988 Y129.985 E.03902
; WIPE_START
G1 X135.56 Y129.088 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X136.499 Y125.034 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X135.439 Y123.974 E.04608
G1 X135.48 Y124.548
G1 X136.629 Y125.697 E.04993
G1 X136.663 Y126.264
G1 X135.602 Y125.204 E.04607
G1 X135.647 Y125.782
G1 X136.648 Y126.783 E.04349
G1 X136.612 Y127.28
G1 X135.692 Y126.36 E.03997
G1 X135.678 Y126.879
G1 X136.518 Y127.719 E.03649
G1 X136.394 Y128.128
G1 X135.659 Y127.394 E.03192
G1 X135.602 Y127.87
G1 X136.242 Y128.51 E.02782
G1 X136.044 Y128.845
G1 X135.526 Y128.327 E.02251
; WIPE_START
M204 S6000
G1 X136.044 Y128.845 E-.27837
G1 X136.242 Y128.51 E-.14798
G1 X135.621 Y127.889 E-.33366
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X136.359 Y124.584 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.169542
G1 F15000
M204 S6000
G1 X136.251 Y124.441 E.00185
; LINE_WIDTH: 0.208481
G1 X136.143 Y124.297 E.00242
; LINE_WIDTH: 0.247419
G1 X136.036 Y124.154 E.00299
; LINE_WIDTH: 0.286357
G1 X135.928 Y124.01 E.00356
; LINE_WIDTH: 0.319273
G1 X135.689 Y123.739 E.00815
; WIPE_START
G1 X135.928 Y124.01 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.675 Y125.131 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.11522
G1 F15000
M204 S6000
G1 X135.57 Y124.925 E.00136
; WIPE_START
G1 X135.675 Y125.131 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.999 Y128.919 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.0981858
G1 F15000
M204 S6000
G1 X135.934 Y129.002 E.00047
; LINE_WIDTH: 0.128495
G1 X135.902 Y129.026 E.00028
G1 X135.879 Y129.011 E.00019
; LINE_WIDTH: 0.151674
G1 X135.652 Y128.814 E.00266
; LINE_WIDTH: 0.187423
G1 X135.425 Y128.617 E.00354
; WIPE_START
G1 X135.652 Y128.814 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X135.488 Y123.661 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.487671
G1 F10792.554
M204 S6000
G1 X135.357 Y123.504 E.00741
; LINE_WIDTH: 0.445982
G1 F11908.863
G1 X135.226 Y123.348 E.00671
; LINE_WIDTH: 0.401302
G1 F13393.563
G2 X135.075 Y123.17 I-2.198 J1.711 E.0068
; LINE_WIDTH: 0.370004
G1 F14675.162
G1 X135.021 Y123.116 E.00204
; LINE_WIDTH: 0.344929
G1 F15000
G1 X134.932 Y123.039 E.00288
; LINE_WIDTH: 0.307422
G1 X134.843 Y122.963 E.00253
; LINE_WIDTH: 0.269914
G1 X134.754 Y122.887 E.00217
; LINE_WIDTH: 0.230226
G1 X134.655 Y122.801 E.002
; LINE_WIDTH: 0.201476
G1 X134.563 Y122.735 E.00145
; LINE_WIDTH: 0.170259
G1 X134.438 Y122.658 E.00153
; LINE_WIDTH: 0.124761
G1 X134.309 Y122.578 E.00101
; LINE_WIDTH: 0.0994596
M73 P98 R0
G1 X134.254 Y122.55 E.00028
; WIPE_START
G1 X134.309 Y122.578 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X131.574 Y122.437 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.0995112
G1 F15000
M204 S6000
G1 X131.49 Y122.477 E.00043
; LINE_WIDTH: 0.127467
G1 X131.309 Y122.581 E.00144
; LINE_WIDTH: 0.177273
G1 X131.128 Y122.686 E.00229
; LINE_WIDTH: 0.204269
G1 X131.116 Y122.694 E.00018
; LINE_WIDTH: 0.22448
G1 X131.002 Y122.787 E.00218
; LINE_WIDTH: 0.260965
G1 X130.888 Y122.88 E.00261
; LINE_WIDTH: 0.300057
G2 X130.759 Y122.986 I1.381 J1.807 E.00351
M204 S10000
G1 X130.741 Y122.833 F42000
; LINE_WIDTH: 0.513102
G1 F10208.821
M204 S6000
G1 X130.191 Y123.685 E.03886
M204 S10000
G1 X130.158 Y123.667 F42000
; LINE_WIDTH: 0.444822
G1 F11943.224
M204 S6000
G3 X130.649 Y123.102 I6.945 J5.527 E.02451
; LINE_WIDTH: 0.396817
G1 F13563.279
G1 X130.87 Y122.859 E.00947
; LINE_WIDTH: 0.361829
G1 F15000
G1 X131.091 Y122.616 E.00854
; WIPE_START
G1 X130.87 Y122.859 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X130.164 Y124.565 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X129.625 Y124.025 E.02344
G1 X129.43 Y124.364
G1 X130.087 Y125.021 E.02854
G1 X130.02 Y125.487
G1 X129.279 Y124.746 E.03219
G1 X129.153 Y125.153
G1 X129.995 Y125.996 E.03662
G1 X129.975 Y126.509
G1 X129.061 Y125.594 E.03972
G1 X129.021 Y126.088
G1 X130.005 Y127.072 E.04276
G1 X130.042 Y127.643
G1 X129.01 Y126.61 E.04487
G1 X129.048 Y127.181
G1 X130.165 Y128.299 E.04856
G1 X130.223 Y128.89
G1 X129.187 Y127.854 E.045
; WIPE_START
M204 S6000
G1 X130.223 Y128.89 E-.55651
G1 X130.171 Y128.357 E-.2035
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X130.291 Y124.216 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.311204
G1 F15000
M204 S6000
G1 X129.953 Y123.907 E.01
; LINE_WIDTH: 0.285035
G1 X129.86 Y123.832 E.00236
; LINE_WIDTH: 0.2562
G1 X129.838 Y123.833 E.00038
; LINE_WIDTH: 0.223846
G1 X129.816 Y123.834 E.00032
; LINE_WIDTH: 0.190524
G1 X129.789 Y123.839 E.00033
; LINE_WIDTH: 0.156219
G1 X129.763 Y123.844 E.00025
; LINE_WIDTH: 0.125526
G1 X129.734 Y123.868 E.00025
; LINE_WIDTH: 0.100064
G1 X129.665 Y123.958 E.00053
; WIPE_START
G1 X129.734 Y123.868 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X129.719 Y128.817 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.256808
G1 F15000
M204 S6000
G1 X129.591 Y128.65 E.00366
; LINE_WIDTH: 0.219862
G1 X129.463 Y128.483 E.00303
; LINE_WIDTH: 0.182917
G1 X129.335 Y128.316 E.0024
; WIPE_START
G1 X129.463 Y128.483 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.922 Y122.974 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X126.848 Y123.319 I.823 J.356 E.01091
G1 X126.848 Y136.086 E.39229
G1 X123.827 Y135.927 E.09295
G1 X123.827 Y135.611 E.00968
G2 X124.77 Y135.561 I.287 J-3.475 E.02911
G2 X125.525 Y134.988 I-.34 J-1.231 E.02984
G2 X125.638 Y134.406 I-1.364 J-.568 E.01832
G1 X125.638 Y123.519 E.33453
G2 X124.735 Y122.526 I-.954 J-.04 E.04575
G2 X123.827 Y122.514 I-.55 J7.757 E.02792
G1 X123.827 Y122.21 E.00935
G1 X128.659 Y122.21 E.14847
G1 X128.659 Y122.514 E.00935
G2 X127.64 Y122.528 I-.405 J7.68 E.03133
G2 X126.955 Y122.924 I.1 J.964 E.02504
M204 S10000
G1 X126.939 Y122.602 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0998638
G1 F15000
M204 S6000
G3 X127.109 Y122.406 I1.816 J1.401 E.0012
M204 S10000
G1 X127.221 Y122.428 F42000
; LINE_WIDTH: 0.101446
G1 F15000
M204 S6000
G2 X126.982 Y122.483 I.459 J2.57 E.00117
M204 S10000
G1 X126.652 Y123.186 F42000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X125.883 Y122.417 E.03341
G1 X125.713 Y122.781
G1 X126.652 Y123.719 E.04078
G1 X126.651 Y124.252
G1 X125.838 Y123.439 E.03533
G1 X125.846 Y123.979
G1 X126.651 Y124.785 E.03499
G1 X126.65 Y125.317
G1 X125.846 Y124.513 E.03497
G1 X125.846 Y125.046
G1 X126.65 Y125.85 E.03495
G1 X126.649 Y126.383
G1 X125.846 Y125.579 E.03493
G1 X125.846 Y126.112
G1 X126.649 Y126.916 E.0349
G1 X126.649 Y127.448
G1 X125.846 Y126.646 E.03488
G1 X125.846 Y127.179
G1 X126.648 Y127.981 E.03486
G1 X126.648 Y128.514
G1 X125.846 Y127.712 E.03484
G1 X125.846 Y128.245
G1 X126.647 Y129.047 E.03482
G1 X126.647 Y129.58
G1 X125.846 Y128.779 E.0348
G1 X125.846 Y129.312
G1 X126.646 Y130.112 E.03478
G1 X126.646 Y130.645
G1 X125.846 Y129.845 E.03476
G1 X125.846 Y130.379
G1 X126.645 Y131.178 E.03474
G1 X126.645 Y131.711
G1 X125.846 Y130.912 E.03472
G1 X125.846 Y131.445
G1 X126.644 Y132.244 E.0347
G1 X126.644 Y132.776
G1 X125.846 Y131.978 E.03468
G1 X125.846 Y132.512
G1 X126.643 Y133.309 E.03466
G1 X126.643 Y133.842
G1 X125.846 Y133.045 E.03464
G1 X125.846 Y133.578
G1 X126.642 Y134.375 E.03462
G1 X126.642 Y134.907
G1 X125.846 Y134.111 E.0346
G1 X125.832 Y134.631
G1 X126.641 Y135.44 E.03518
G1 X126.529 Y135.861
G1 X125.715 Y135.047 E.03538
; WIPE_START
M204 S6000
G1 X126.529 Y135.861 E-.43754
G1 X126.641 Y135.44 E-.1655
G1 X126.349 Y135.148 E-.15696
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X126.586 Y127.519 Z5.4 F42000
G1 X126.745 Y122.399 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.298709
G1 F15000
M204 S6000
G1 X126.618 Y122.473 E.00308
; LINE_WIDTH: 0.326103
G1 X126.49 Y122.547 E.00341
; LINE_WIDTH: 0.3185
G1 X126.527 Y122.614 E.00172
; LINE_WIDTH: 0.266722
G1 X126.564 Y122.681 E.0014
G1 X126.769 Y122.863 E.005
M204 S10000
G1 X125.913 Y123.364 F42000
; LINE_WIDTH: 0.0910685
G1 F15000
M204 S6000
G2 X125.801 Y123.159 I-2.132 J1.04 E.00091
; WIPE_START
G1 X125.913 Y123.364 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.662 Y130.992 Z5.4 F42000
G1 X125.52 Y135.318 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.331858
G1 F15000
M204 S6000
G1 X125.698 Y135.502 E.00602
; LINE_WIDTH: 0.356903
G1 X125.738 Y135.575 E.00213
; LINE_WIDTH: 0.403515
G1 F13311.355
G1 X125.778 Y135.648 E.00245
; LINE_WIDTH: 0.408916
G1 F13114.911
G1 X125.749 Y135.665 E.00099
; LINE_WIDTH: 0.373106
G1 F14537.277
G1 X125.72 Y135.681 E.00089
; LINE_WIDTH: 0.337296
G1 F15000
G1 X125.691 Y135.697 E.0008
; LINE_WIDTH: 0.296253
G1 X125.576 Y135.761 E.00272
; LINE_WIDTH: 0.249974
G1 X125.46 Y135.824 E.00222
M204 S10000
G1 X125.291 Y135.556 F42000
; LINE_WIDTH: 0.0991933
G1 F15000
M204 S6000
G1 X125.253 Y135.592 E.00024
; LINE_WIDTH: 0.121669
G1 X125.168 Y135.66 E.0007
; LINE_WIDTH: 0.162881
G3 X125.058 Y135.733 I-.131 J-.078 E.00134
; LINE_WIDTH: 0.14931
G1 X124.956 Y135.748 E.0009
; LINE_WIDTH: 0.114386
G1 X124.854 Y135.762 E.0006
; WIPE_START
G1 X124.956 Y135.748 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X125.293 Y128.123 Z5.4 F42000
G1 X125.534 Y122.656 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.118115
G1 F15000
M204 S6000
G2 X125.339 Y122.406 I-3.282 J2.359 E.00194
M204 S10000
G1 X125.204 Y122.421 F42000
; LINE_WIDTH: 0.162074
G1 F15000
M204 S6000
G3 X125.481 Y122.505 I-1.01 J3.869 E.00281
; WIPE_START
G1 X125.204 Y122.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X118.397 Y125.875 Z5.4 F42000
G1 X109.919 Y130.178 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X109.919 Y124.004 E.18973
G3 X110.512 Y122.535 I1.989 J-.051 E.05006
G3 X111.645 Y122.051 I1.349 J1.591 E.03841
G3 X113.338 Y122.385 I.362 J2.62 E.05401
G3 X114.373 Y123.879 I-1.495 J2.142 E.05705
G1 X114.513 Y124.559 E.02131
G1 X114.552 Y125.05 E.01514
G1 X114.243 Y125.05 E.00949
G1 X114.167 Y124.359 E.02136
G1 X114.016 Y123.77 E.01868
G2 X112.942 Y122.581 I-1.8 J.546 E.05088
G2 X111.294 Y123.335 I-.423 J1.253 E.06134
G2 X111.129 Y124.25 I2.369 J.9 E.02872
G1 X111.129 Y130.178 E.18217
G1 X114.026 Y130.178 E.08903
G1 X114.026 Y130.38 E.00619
G2 X114.965 Y130.142 I-.323 J-3.237 E.02985
G2 X115.546 Y129.537 I-.693 J-1.249 E.02617
G1 X119.067 Y122.153 E.25135
G2 X118.133 Y120.23 I-13.235 J5.242 E.06577
G2 X116.454 Y119.096 I-2.211 J1.463 E.06388
G2 X115.803 Y119.177 I-.215 J.931 E.02057
G2 X115.695 Y119.744 I.345 J.36 E.01895
G3 X115.072 Y120.522 I-.563 J.187 E.03631
G3 X114.338 Y119.744 I-.007 J-.729 E.0369
G3 X115.199 Y118.668 I1.146 J.035 E.0454
G3 X116.238 Y118.624 I.627 J2.546 E.03216
G3 X117.568 Y119.2 I-.683 J3.402 E.04487
G1 X117.781 Y119.376 E.00847
G3 X118.504 Y120.309 I-3.074 J3.128 E.03638
G1 X119.18 Y121.677 E.04688
G1 X122.392 Y129.392 E.25679
G2 X123.651 Y130.298 I1.573 J-.859 E.04927
G1 X123.878 Y130.331 E.00707
G1 X123.878 Y130.664 E.01023
G1 X120.495 Y130.664 E.10395
G1 X120.495 Y130.336 E.01009
G1 X121.04 Y130.27 E.01688
G2 X121.778 Y129.857 I-.171 J-1.171 E.02655
G2 X121.902 Y129.247 I-.736 J-.467 E.01956
G1 X121.849 Y128.909 E.01051
G1 X121.689 Y128.463 E.01454
G1 X119.679 Y123.63 E.16086
G1 X116.873 Y129.506 E.20009
G3 X117.08 Y129.654 I-.532 J.962 E.00784
G2 X117.674 Y130.322 I.713 J-.036 E.02969
G2 X118.264 Y130.359 I.537 J-3.828 E.01819
G1 X118.264 Y130.664 E.00935
G1 X111.129 Y130.664 E.21925
G1 X111.129 Y134.467 E.11686
G1 X110.809 Y134.467 E.00982
G1 X110.766 Y133.892 E.01773
G1 X110.558 Y132.846 E.03276
G1 X110.279 Y132.111 E.02416
G1 X109.885 Y131.457 E.02345
G2 X108.289 Y130.493 I-2.1 J1.673 E.05852
G1 X108.289 Y130.178 E.00966
G1 X109.859 Y130.178 E.04824
M204 S10000
G1 X109.225 Y130.604 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.102637
G1 F15000
M204 S6000
G1 X109.14 Y130.543 E.00051
; LINE_WIDTH: 0.124374
G1 X109.003 Y130.458 E.00107
; LINE_WIDTH: 0.155202
G1 X108.866 Y130.374 E.00147
; WIPE_START
G1 X109.003 Y130.458 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.933 Y130.421 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.13636
G1 F15000
M204 S6000
G1 X113.83 Y130.421 E.02206
; WIPE_START
G1 X111.83 Y130.421 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X114.943 Y130.468 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.132565
G1 F15000
M204 S6000
G2 X115.218 Y130.242 I-2.596 J-3.44 E.0026
; WIPE_START
G1 X114.943 Y130.468 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X117.135 Y130.291 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.113976
G1 F15000
M204 S6000
G2 X117.278 Y130.468 I2.313 J-1.72 E.00131
M204 S10000
G1 X117.368 Y130.447 F42000
; LINE_WIDTH: 0.112468
G1 F15000
M204 S6000
G3 X117.164 Y130.396 I.567 J-2.732 E.00119
; WIPE_START
G1 X117.368 Y130.447 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X121.229 Y130.445 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.13048
G1 F15000
M204 S6000
G2 X121.609 Y130.384 I-.57 J-4.822 E.00274
M204 S10000
G1 X121.689 Y130.247 F42000
; LINE_WIDTH: 0.117441
G1 F15000
M204 S6000
G3 X121.435 Y130.468 I-3.027 J-3.227 E.00204
M204 S10000
G1 X122.14 Y129.872 F42000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X122.61 Y130.342 E.02041
M204 S10000
G1 X122.08 Y129.829 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.145672
G1 F15000
M204 S6000
G1 X121.971 Y129.983 E.00158
; LINE_WIDTH: 0.142523
G1 X121.914 Y130.229 E.00205
; LINE_WIDTH: 0.175406
G1 X121.857 Y130.475 E.00273
M204 S10000
G1 X121.897 Y130.475 F42000
; LINE_WIDTH: 0.260593
G1 F15000
M204 S6000
G1 X122.016 Y130.405 E.00245
; LINE_WIDTH: 0.299239
G1 X122.135 Y130.334 E.00289
G1 X122.077 Y130.23 E.00247
; LINE_WIDTH: 0.257567
G1 X121.883 Y130.028 E.00491
M204 S10000
G1 X122.757 Y130.16 F42000
; LINE_WIDTH: 0.113367
G1 F15000
M204 S6000
G1 X122.477 Y129.898 E.0022
G1 X122.327 Y129.731 E.00129
M204 S10000
G1 X122.174 Y129.56 F42000
; LINE_WIDTH: 0.115534
G1 F15000
M204 S6000
G2 X122.124 Y129.318 I-3.583 J.613 E.00146
M204 S10000
G1 X122.185 Y129.406 F42000
; LINE_WIDTH: 0.10766
G1 F15000
M204 S6000
G3 X122.104 Y129.636 I-3.584 J-1.137 E.00129
; WIPE_START
G1 X122.185 Y129.406 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X122.921 Y130.253 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.115586
G1 F15000
M204 S6000
G1 X123.078 Y130.36 E.00113
; LINE_WIDTH: 0.152904
G1 X123.235 Y130.468 E.0017
M204 S10000
G1 X123.374 Y130.445 F42000
; LINE_WIDTH: 0.12287
G1 F15000
M204 S6000
G3 X123.03 Y130.387 I.572 J-4.446 E.00227
; WIPE_START
G1 X123.374 Y130.445 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.658 Y123.778 Z5.4 F42000
G1 X119.508 Y123.507 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X118.928 Y122.927 E.02519
G1 X118.756 Y123.289
G1 X119.335 Y123.868 E.02518
G1 X119.163 Y124.229
G1 X118.584 Y123.65 E.02517
G1 X118.411 Y124.011
G1 X118.991 Y124.59 E.02516
G1 X118.818 Y124.951
G1 X118.239 Y124.372 E.02516
G1 X118.067 Y124.733
G1 X118.646 Y125.312 E.02515
G1 X118.473 Y125.672
G1 X117.895 Y125.094 E.02514
G1 X117.723 Y125.455
G1 X118.301 Y126.033 E.02514
G1 X118.129 Y126.394
G1 X117.55 Y125.816 E.02513
G1 X117.378 Y126.177
G1 X117.956 Y126.755 E.02512
G1 X117.784 Y127.116
G1 X117.206 Y126.538 E.02512
G1 X117.034 Y126.899
G1 X117.612 Y127.477 E.02511
G1 X117.439 Y127.838
G1 X116.862 Y127.26 E.0251
G1 X116.69 Y127.621
G1 X117.267 Y128.199 E.0251
G1 X117.095 Y128.56
G1 X116.517 Y127.982 E.02509
G1 X116.345 Y128.343
G1 X116.922 Y128.921 E.02508
G1 X116.75 Y129.282
G1 X116.173 Y128.705 E.02507
G1 X116.001 Y129.066
G1 X116.972 Y130.037 E.04223
G1 X116.858 Y130.456
G1 X115.829 Y129.427 E.04475
G1 X115.644 Y129.775
G1 X116.325 Y130.456 E.02962
M204 S10000
G1 X115.455 Y130.475 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.246147
G1 F15000
M204 S6000
G1 X115.533 Y130.422 E.00157
; LINE_WIDTH: 0.293232
G1 X115.611 Y130.368 E.00194
; LINE_WIDTH: 0.340674
G1 X115.69 Y130.315 E.0023
G1 X115.634 Y130.227 E.00254
; LINE_WIDTH: 0.311967
G1 X115.435 Y130.012 E.0064
; WIPE_START
G1 X115.634 Y130.227 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X119.447 Y123.615 Z5.4 F42000
G1 X119.622 Y123.311 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.14593
G1 F15000
M204 S6000
G1 X119.535 Y123.18 E.00132
; LINE_WIDTH: 0.190756
G1 X119.447 Y123.05 E.00189
; LINE_WIDTH: 0.235583
G1 X119.36 Y122.919 E.00247
; LINE_WIDTH: 0.28041
G1 X119.273 Y122.789 E.00304
; LINE_WIDTH: 0.325236
G1 X119.185 Y122.658 E.00361
; LINE_WIDTH: 0.370063
G1 F14672.504
G1 X119.098 Y122.528 E.00419
; WIPE_START
G1 X119.185 Y122.658 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X116.263 Y118.858 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.106042
G1 F15000
M204 S6000
G1 X116.071 Y118.846 E.00099
; LINE_WIDTH: 0.134317
G1 X115.927 Y118.851 E.00108
; LINE_WIDTH: 0.175134
G1 X115.798 Y118.865 E.0014
; LINE_WIDTH: 0.205609
G2 X115.598 Y118.919 I.117 J.833 E.00276
M204 S10000
G1 X115.559 Y119.099 F42000
; LINE_WIDTH: 0.168057
G1 F15000
M204 S6000
G1 X115.774 Y118.787 E.00386
; WIPE_START
G1 X115.559 Y119.099 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X114.708 Y119.241 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X115.507 Y120.04 E.03472
G1 X115.223 Y120.289
G1 X114.557 Y119.623 E.02891
M204 S10000
G1 X114.945 Y120.3 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0906276
G1 F15000
M204 S6000
G1 X114.918 Y120.286 E.00012
; LINE_WIDTH: 0.105799
G1 X114.856 Y120.242 E.00039
; LINE_WIDTH: 0.140321
G3 X114.668 Y120.072 I.413 J-.647 E.00202
; LINE_WIDTH: 0.131276
G1 X114.624 Y120.01 E.00055
; LINE_WIDTH: 0.100717
G3 X114.566 Y119.922 I.376 J-.31 E.0005
; WIPE_START
G1 X114.624 Y120.01 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X115.389 Y118.82 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.288647
G1 F15000
M204 S6000
G1 X115.124 Y119.031 E.00676
; LINE_WIDTH: 0.307771
G1 X115.096 Y119.069 E.00103
; LINE_WIDTH: 0.344261
G1 X115.067 Y119.107 E.00117
G1 X115.147 Y119.214 E.0033
G1 X115.463 Y119.478 E.01009
M204 S10000
G1 X115.124 Y118.899 F42000
; LINE_WIDTH: 0.235798
G1 F15000
M204 S6000
G1 X115.456 Y119.722 E.01396
; WIPE_START
G1 X115.124 Y118.899 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X112.484 Y122.296 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.110389
G1 F15000
M204 S6000
G1 X112.362 Y122.292 E.00067
; LINE_WIDTH: 0.139239
G1 X112.222 Y122.289 E.0011
; LINE_WIDTH: 0.166716
G1 X112.133 Y122.298 E.0009
; LINE_WIDTH: 0.200521
G2 X111.979 Y122.317 I.108 J1.475 E.002
; LINE_WIDTH: 0.238869
G1 X111.868 Y122.343 E.00181
; LINE_WIDTH: 0.282872
G2 X111.737 Y122.375 I.315 J1.578 E.00265
; LINE_WIDTH: 0.321779
G1 X111.688 Y122.391 E.00118
; LINE_WIDTH: 0.354828
G1 X111.591 Y122.43 E.00264
; LINE_WIDTH: 0.394174
G1 F13665.34
G1 X111.495 Y122.469 E.00298
; LINE_WIDTH: 0.433439
G1 F12291.342
G1 X111.423 Y122.504 E.00254
; LINE_WIDTH: 0.44123
G1 F12050.932
G1 X111.263 Y122.449 E.00551
; LINE_WIDTH: 0.414486
G1 F12918.313
G1 X111.103 Y122.393 E.00514
M204 S10000
G1 X111.156 Y123.154 F42000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X110.673 Y122.672 E.02097
G1 X110.425 Y122.957
G1 X111.005 Y123.537 E.02519
G1 X110.934 Y123.999
G1 X110.243 Y123.308 E.03003
G1 X110.152 Y123.75
G1 X110.921 Y124.52 E.03342
G1 X110.921 Y125.053
G1 X110.126 Y124.258 E.03455
G1 X110.126 Y124.791
G1 X110.921 Y125.586 E.03455
G1 X110.921 Y126.119
G1 X110.126 Y125.324 E.03455
G1 X110.126 Y125.857
G1 X110.921 Y126.653 E.03455
G1 X110.921 Y127.186
G1 X110.126 Y126.391 E.03455
G1 X110.126 Y126.924
G1 X110.921 Y127.719 E.03455
G1 X110.921 Y128.252
G1 X110.126 Y127.457 E.03455
G1 X110.126 Y127.991
G1 X110.921 Y128.786 E.03455
G1 X110.921 Y129.319
G1 X110.126 Y128.524 E.03455
G1 X110.126 Y129.057
G1 X110.921 Y129.852 E.03455
G1 X110.726 Y130.19
G1 X110.126 Y129.59 E.02604
G1 X110.126 Y130.124
G1 X110.921 Y130.919 E.03455
G1 X110.921 Y131.452
G1 X109.855 Y130.386 E.04633
G1 X109.506 Y130.57
G1 X110.704 Y131.768 E.05206
M204 S10000
G1 X110.414 Y131.84 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.143215
G1 F15000
M204 S6000
G1 X110.294 Y131.686 E.0016
; LINE_WIDTH: 0.106531
G1 X110.173 Y131.532 E.00101
; WIPE_START
G1 X110.294 Y131.686 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.339 Y124.054 Z5.4 F42000
G1 X110.344 Y123.142 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.104391
G1 F15000
M204 S6000
G1 X110.255 Y123.27 E.00078
; WIPE_START
G1 X110.344 Y123.142 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X110.646 Y130.769 Z5.4 F42000
G1 X110.694 Y131.981 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.425723
G1 F12539.09
M204 S6000
G1 X110.723 Y132.136 E.00493
; LINE_WIDTH: 0.383249
G1 F14104.015
G1 X110.751 Y132.291 E.00438
; LINE_WIDTH: 0.340775
G1 F15000
G1 X110.78 Y132.447 E.00384
; LINE_WIDTH: 0.298301
G1 X110.808 Y132.602 E.00329
; LINE_WIDTH: 0.255826
G1 X110.837 Y132.758 E.00274
; LINE_WIDTH: 0.209475
G3 X110.862 Y133.008 I-2.944 J.424 E.00342
; LINE_WIDTH: 0.163525
G1 X110.885 Y133.243 E.00232
; LINE_WIDTH: 0.119128
G1 X110.908 Y133.478 E.00146
; WIPE_START
G1 X110.885 Y133.243 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.735 Y134.549 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X105.012 Y135.148 E.02887
G1 X104.296 Y135.607 E.02612
G1 X103.656 Y135.883 E.02141
G1 X103.022 Y136.04 E.02007
G1 X102.306 Y136.097 E.0221
G3 X100.125 Y135.55 I-.04 J-4.465 E.06982
G1 X99.602 Y135.18 E.01968
G3 X98.307 Y132.853 I2.494 J-2.912 E.08358
G1 X98.257 Y132.138 E.02201
G3 X98.562 Y130.661 I3.706 J-.005 E.04669
G3 X99.444 Y129.595 I2.777 J1.402 E.04286
G1 X100.013 Y129.254 E.02039
G1 X100.911 Y128.881 E.02986
G3 X104.737 Y127.821 I41.787 J143.428 E.12199
G1 X105.355 Y127.571 E.02049
G1 X105.825 Y127.292 E.0168
G2 X106.763 Y125.231 I-1.38 J-1.872 E.07266
G2 X105.461 Y122.92 I-2.981 J.157 E.08445
G2 X104.026 Y122.373 I-1.967 J3.001 E.04758
G1 X103.425 Y122.333 E.0185
G1 X102.762 Y122.381 E.02041
G1 X102.109 Y122.532 E.02061
G1 X101.399 Y122.828 E.02364
G1 X100.775 Y123.216 E.02258
G1 X100.088 Y123.814 E.02798
G1 X99.509 Y124.508 E.02778
G1 X99.036 Y125.314 E.02871
G1 X98.646 Y126.297 E.03248
G1 X98.424 Y127.223 E.02927
G1 X98.075 Y127.223 E.01072
G1 X98.075 Y122.21 E.15404
G1 X98.492 Y122.21 E.01281
G1 X99.636 Y123.562 E.05441
G1 X100.208 Y123.089 E.02283
G1 X100.923 Y122.633 E.02605
G1 X101.715 Y122.295 E.02647
G1 X102.512 Y122.102 E.02518
G1 X103.457 Y122.03 E.02912
G1 X103.903 Y122.048 E.01372
G1 X104.633 Y122.156 E.02267
G1 X105.253 Y122.343 E.01993
G1 X105.803 Y122.609 E.01876
G1 X106.378 Y123.011 E.02155
G1 X106.574 Y123.186 E.00808
G1 X107.001 Y123.661 E.01964
G1 X107.349 Y124.204 E.0198
G1 X107.6 Y124.803 E.01994
G1 X107.742 Y125.404 E.019
G1 X107.796 Y126.137 E.02257
G3 X107.571 Y127.398 I-4.069 J-.077 E.03953
G3 X106.776 Y128.519 I-2.964 J-1.261 E.04255
G1 X106.33 Y128.854 E.01714
G1 X105.656 Y129.215 E.02347
G1 X104.356 Y129.685 E.04249
G1 X101.556 Y130.449 E.08918
G1 X100.664 Y130.783 E.02929
G2 X99.406 Y132.192 I1.016 J2.173 E.05964
G2 X99.322 Y133.499 I3.084 J.853 E.04055
G2 X101.268 Y135.654 I2.738 J-.518 E.09382
G2 X103.924 Y135.417 I1.001 J-3.775 E.0836
G1 X104.467 Y135.098 E.01936
G1 X104.98 Y134.673 E.02048
G1 X105.508 Y134.068 E.02464
G1 X105.958 Y133.337 E.0264
G1 X106.392 Y132.341 E.03338
G1 X106.714 Y131.265 E.03452
G1 X107.072 Y131.265 E.011
G1 X107.072 Y135.916 E.14291
G1 X106.669 Y135.916 E.0124
G1 X105.769 Y134.599 E.049
M204 S10000
G1 X105.695 Y134.21 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.13321
G1 F15000
M204 S6000
G1 X105.692 Y134.25 E.00029
G1 X105.36 Y134.574 E.00342
M204 S10000
G1 X105.695 Y134.21 F42000
; LINE_WIDTH: 0.115059
G1 F15000
M204 S6000
G1 X105.696 Y134.144 E.00039
; WIPE_START
G1 X105.695 Y134.21 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.865 Y133.794 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X106.252 Y133.182 E.02663
G1 X106.077 Y133.54
G1 X106.865 Y134.328 E.03425
G1 X106.865 Y134.861
G1 X105.964 Y133.96 E.03914
G1 X105.914 Y134.444
G1 X106.865 Y135.394 E.0413
M204 S10000
G1 X106.884 Y135.387 F42000
; FEATURE: Gap infill
; LINE_WIDTH: 0.224342
G1 F15000
M204 S6000
G1 X106.791 Y135.598 E.0034
; LINE_WIDTH: 0.210486
G1 X106.762 Y135.584 E.00045
; LINE_WIDTH: 0.176643
G1 X106.732 Y135.57 E.00036
; LINE_WIDTH: 0.1428
G1 X106.702 Y135.557 E.00027
; LINE_WIDTH: 0.107009
G1 X106.558 Y135.383 E.00118
; WIPE_START
G1 X106.702 Y135.557 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.637 Y132.939 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.351993
G1 F15000
M204 S6000
G1 X106.723 Y132.453 E.01244
; LINE_WIDTH: 0.327698
G1 X106.745 Y132.305 E.00347
; LINE_WIDTH: 0.285738
G1 X106.767 Y132.157 E.00296
; LINE_WIDTH: 0.243779
G1 X106.788 Y132.009 E.00245
; LINE_WIDTH: 0.201819
G1 X106.81 Y131.861 E.00193
; LINE_WIDTH: 0.15986
G1 X106.831 Y131.713 E.00142
; LINE_WIDTH: 0.1179
G1 X106.853 Y131.565 E.00091
; WIPE_START
G1 X106.831 Y131.713 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X106.936 Y125.866 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X107.565 Y126.496 E.02735
G1 X107.49 Y126.954
G1 X106.825 Y126.289 E.02889
G1 X106.66 Y126.657
G1 X107.36 Y127.357 E.0304
G1 X107.183 Y127.713
G1 X106.447 Y126.978 E.03197
G1 X106.192 Y127.255
G1 X106.962 Y128.026 E.03349
G1 X106.701 Y128.298
G1 X105.894 Y127.491 E.03506
G1 X105.56 Y127.69
G1 X106.407 Y128.537 E.03678
G1 X106.086 Y128.75
G1 X105.196 Y127.859 E.03868
G1 X104.816 Y128.013
G1 X105.739 Y128.935 E.04008
G1 X105.368 Y129.098
G1 X104.398 Y128.128 E.04216
G1 X103.978 Y128.242
G1 X104.977 Y129.24 E.04338
G1 X104.585 Y129.382
G1 X103.559 Y128.355 E.0446
G1 X103.139 Y128.469
G1 X104.187 Y129.517 E.04552
G1 X103.768 Y129.631
G1 X102.72 Y128.583 E.04554
G1 X102.303 Y128.7
G1 X103.349 Y129.745 E.04543
G1 X102.93 Y129.859
G1 X101.888 Y128.818 E.04525
G1 X101.474 Y128.936
G1 X102.511 Y129.974 E.04508
G1 X102.092 Y130.088
G1 X101.059 Y129.055 E.0449
G1 X100.674 Y129.204
G1 X101.673 Y130.202 E.04338
G1 X101.272 Y130.334
G1 X100.298 Y129.36 E.04232
G1 X99.942 Y129.538
G1 X100.884 Y130.479 E.0409
G1 X100.506 Y130.635
G1 X99.609 Y129.738 E.03898
G1 X99.32 Y129.982
G1 X100.17 Y130.833 E.03696
G1 X99.879 Y131.075
G1 X99.063 Y130.259 E.03547
G1 X98.849 Y130.578
G1 X99.622 Y131.351 E.0336
G1 X99.409 Y131.672
G1 X98.677 Y130.939 E.03184
G1 X98.553 Y131.348
G1 X99.243 Y132.039 E.02999
G1 X99.13 Y132.459
G1 X98.486 Y131.815 E.028
; WIPE_START
M204 S6000
G1 X99.13 Y132.459 E-.34621
G1 X99.243 Y132.039 E-.16544
G1 X98.781 Y131.576 E-.24835
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.12 Y127.326 Z5.4 F42000
G1 X106.921 Y126.119 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.0985101
G1 F15000
M204 S6000
G3 X106.841 Y126.248 I-1.634 J-.928 E.00069
M204 S10000
G1 X107.574 Y125.688 F42000
; LINE_WIDTH: 0.0916322
G1 F15000
M204 S6000
G1 X106.934 Y125.723 E.00254
; WIPE_START
G1 X107.574 Y125.688 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X101.667 Y130.522 Z5.4 F42000
G1 X99.123 Y132.605 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.1004
G1 F15000
M204 S6000
G1 X98.481 Y132.645 E.00301
M204 S10000
G1 X98.796 Y132.863 F42000
; LINE_WIDTH: 0.548792
G1 F9488.572
M204 S6000
G1 X98.864 Y133.309 E.01862
; LINE_WIDTH: 0.516487
G1 F10135.846
G1 X98.892 Y133.429 E.00473
; LINE_WIDTH: 0.478977
G1 F11007.749
G1 X98.92 Y133.548 E.00436
; LINE_WIDTH: 0.435401
G1 F12229.915
G2 X99.02 Y133.857 I3.629 J-1.005 E.01039
; LINE_WIDTH: 0.400416
G1 F13426.752
G1 X99.054 Y133.936 E.00251
; LINE_WIDTH: 0.374658
G1 F14469.253
G1 X99.087 Y134.016 E.00233
; LINE_WIDTH: 0.336671
G1 F15000
G2 X99.236 Y134.303 I3.724 J-1.737 E.00776
; LINE_WIDTH: 0.288559
G2 X99.325 Y134.446 I1.764 J-1.009 E.00336
; LINE_WIDTH: 0.240275
G1 X99.549 Y134.747 E.00604
; LINE_WIDTH: 0.191706
G2 X99.768 Y134.976 I1.781 J-1.478 E.00384
; LINE_WIDTH: 0.159975
G1 X99.858 Y135.058 E.00117
; LINE_WIDTH: 0.131364
G1 X99.949 Y135.14 E.00088
; LINE_WIDTH: 0.106744
G1 X100.178 Y135.316 E.0015
; WIPE_START
G1 X99.949 Y135.14 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.461 Y127.654 Z5.4 F42000
G1 X98.295 Y126.819 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.119668
G1 F15000
M204 S6000
G1 X98.319 Y126.618 E.00127
; LINE_WIDTH: 0.165163
G1 X98.343 Y126.416 E.00202
; LINE_WIDTH: 0.210659
G1 X98.366 Y126.215 E.00277
; LINE_WIDTH: 0.235506
G1 X98.368 Y126.202 E.00022
; LINE_WIDTH: 0.261207
G1 X98.4 Y126.036 E.00301
; LINE_WIDTH: 0.308381
G1 X98.432 Y125.87 E.00366
; LINE_WIDTH: 0.355554
G1 X98.463 Y125.704 E.0043
; LINE_WIDTH: 0.402728
G1 F13340.479
G1 X98.495 Y125.538 E.00495
; LINE_WIDTH: 0.449901
G1 F11794.171
G1 X98.527 Y125.372 E.0056
; WIPE_START
G1 X98.495 Y125.538 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X99.662 Y123.896 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.173393
G1 F15000
M204 S6000
G1 X99.787 Y123.772 E.00188
; LINE_WIDTH: 0.147285
G1 X99.912 Y123.647 E.0015
; LINE_WIDTH: 0.122056
G3 X100.49 Y123.172 I9.902 J11.441 E.00482
; WIPE_START
G1 X99.912 Y123.647 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X98.282 Y123.079 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X99.454 Y124.25 E.05091
G1 X99.235 Y124.565
G1 X98.282 Y123.612 E.0414
G1 X98.282 Y124.145
G1 X99.038 Y124.901 E.03283
G1 X98.82 Y125.217
G1 X98.282 Y124.679 E.02338
; WIPE_START
M204 S6000
G1 X98.82 Y125.217 E-.2891
G1 X99.038 Y124.901 E-.1457
G1 X98.433 Y124.296 E-.32521
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X99.401 Y123.762 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.316481
G1 F15000
M204 S6000
G1 X98.97 Y123.293 E.01421
; LINE_WIDTH: 0.364354
G1 F14933.088
G1 X98.538 Y122.823 E.0167
; LINE_WIDTH: 0.408072
G1 F13145.218
G1 X98.456 Y122.757 E.00313
; LINE_WIDTH: 0.407209
G1 F13176.381
G1 X98.418 Y122.804 E.0018
; LINE_WIDTH: 0.365891
G1 F14862.025
G1 X98.379 Y122.851 E.00159
; LINE_WIDTH: 0.324574
G1 F15000
G1 X98.341 Y122.897 E.00139
; LINE_WIDTH: 0.283256
G1 X98.302 Y122.944 E.00118
; LINE_WIDTH: 0.241939
G1 X98.264 Y122.991 E.00098
; WIPE_START
G1 X98.302 Y122.944 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X105.616 Y122.762 Z5.4 F42000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.120215
G1 F15000
M204 S6000
G3 X105.988 Y123.035 I-1.497 J2.433 E.00291
; LINE_WIDTH: 0.153184
G1 X106.1 Y123.133 E.00134
; LINE_WIDTH: 0.184714
G1 X106.207 Y123.227 E.00164
; LINE_WIDTH: 0.211787
G1 X106.371 Y123.389 E.00317
; LINE_WIDTH: 0.240878
G3 X106.531 Y123.593 I-2.333 J1.989 E.00419
; LINE_WIDTH: 0.276538
G1 X106.682 Y123.787 E.00468
; LINE_WIDTH: 0.296019
G1 X106.694 Y123.803 E.0004
; LINE_WIDTH: 0.326283
G3 X106.829 Y124.036 I-1.372 J.952 E.00622
; LINE_WIDTH: 0.358855
G1 X106.924 Y124.208 E.00504
; LINE_WIDTH: 0.374832
G1 F14461.661
G1 X106.936 Y124.232 E.00074
; LINE_WIDTH: 0.402703
G1 F13341.376
G1 X107.004 Y124.385 E.00492
; LINE_WIDTH: 0.44768
G1 F11858.892
G1 X107.11 Y124.691 E.01067
; LINE_WIDTH: 0.486103
G1 F10830.738
G3 X107.149 Y124.832 I-1.746 J.547 E.00528
; LINE_WIDTH: 0.522391
G1 F10011.039
G1 X107.177 Y124.94 E.00436
; LINE_WIDTH: 0.563064
G1 F9228.228
G3 X107.258 Y125.476 I-7.129 J1.36 E.02298
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F9228.228
G1 X107.177 Y124.94 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.4 I1.217 J0 P1  F42000
M106 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
; filament end gcode 

;===== date: 20231229 =====================
G392 S0 ;turn off nozzle clog detect

M400 ; wait for buffer to clear
G92 E0 ; zero the extruder
G1 E-0.8 F1800 ; retract
G1 Z5.5 F900 ; lower z a little
G1 X0 Y128 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos

M1002 judge_flag timelapse_record_flag
M622 J1
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M991 S0 P-1 ;end timelapse at safe pos
M623


M140 S0 ; turn off bed
M106 S0 ; turn off fan
M106 P2 S0 ; turn off remote part cooling fan
M106 P3 S0 ; turn off chamber cooling fan

;G1 X27 F15000 ; wipe

; pull back filament to AMS
M620 S255
G1 X267 F15000
T255
G1 X-28.5 F18000
G1 X-48.2 F3000
G1 X-28.5 F18000
G1 X-48.2 F3000
M621 S255

M104 S0 ; turn off hotend

M400 ; wait all motion done
M17 S
M17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom

    G1 Z105 F600
    G1 Z103

M400 P100
M17 R ; restore z current

G90
G1 X-48 Y180 F3600

M220 S100  ; Reset feedrate magnitude
M201.2 K1.0 ; Reset acc magnitude
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 0

;=====printer finish  sound=========
M17
M400 S1
M1006 S1
M1006 A0 B20 L100 C37 D20 M40 E42 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C46 D10 M80 E46 F10 N80
M1006 A44 B20 L100 C39 D20 M60 E48 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C48 D10 M60 E44 F10 N80
M1006 A0 B10 L100 C0 D10 M60 E0 F10  N80
M1006 A44 B20 L100 C49 D20 M80 E41 F20 N80
M1006 A0 B20 L100 C0 D20 M60 E0 F20 N80
M1006 A0 B20 L100 C37 D20 M30 E37 F20 N60
M1006 W
;=====printer finish  sound=========

;M17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power
M400
M18 X Y Z

M73 P100 R0
; EXECUTABLE_BLOCK_END

